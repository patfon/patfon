<nav class="nav navbar-btn pull-right" style="width: 300px;">
                            <?php if (!isset($_SESSION['nitesuser'])) { 
                                //getstudentname($pdb,$_SESSION['nitesuser']['id'])
                                ?>
                            <div class="navbar-header active"  style="padding: 2%; width: 100%; font-weight: bold; line-height: 15px; background: #632227; color: #fff;"> 
                           <span style='font-size: 12px; margin-left: 30%; '>   Welcome, Guest </span> <br><br>
                           <span style='font-size: 23px;  margin-left: 30%; '> <a href='testindex.php' target="_blank" style='color: #ff975a;'> Test Drive </a> </span> <br><br>
                           <span style='font-size: 16px;  margin-left: 30%;'> <a href='#' onclick = "getLogin()" style='color: #ff975a;' > User Login </a> </span>
                            
                            </div>
                            <?php } 
                            else if (isset($_SESSION['nitesuser']['id'])) { ?>
                                <div class="navbar-header active btn-primary"  style="padding: 20px; font-weight: bold; line-height: 15px; letter-spacing: 3px;"> 
                           
                            <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="true" style=" letter-spacing: 3px; color: #fff; text-decoration: none;">
                            Welcome, <?php echo getstudentname($pdb,$_SESSION['nitesuser']['id']); ?> <i class="fa fa-caret-down"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-messages">
                                <li>
                                    <a href="#" onclick="editprofile('<?php echo $_SESSION['nitesuser']['id']; ?>')">
                                        
                                            <strong>Edit Profile</strong>
                                        
                                      
                                    
                                    </a>
                                    <a href="#" onclick="genpassword()">
                                        
                                            <strong>Generate OTP</strong>
                                        
                                      
                                    
                                    </a>
                                    <a href="logout.php">
                                        <div>
                                            <strong>Logout</strong>
                                        
                                        </div>
                                    
                                    </a>
                                </li>
                                
                            
                            </ul>
                            <!-- /.dropdown-messages -->
                            </li>
                            </div>
                            <?php } else if (isset($_SESSION['nitesuser']['id_'])) { ?>
                                <div class="navbar-header active btn-primary  glyphicon-forward"  style="padding: 20px; font-weight: bold; line-height: 15px; letter-spacing: 3px;"> 
                           
                           <li class="dropdown">
                           <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="true" style=" letter-spacing: 3px; color: #fff; text-decoration: none;">
                           Welcome, <?php echo getfriendname($pdb,$_SESSION['nitesuser']['id_']); ?> <i class="fa fa-caret-down"></i>
                           </a>
                           <ul class="dropdown-menu dropdown-messages">
                               <li>
                                   <hr>
                                   <a href="logout.php">
                                       <div>
                                           <strong>Logout</strong>
                                       
                                       </div>
                                   
                                   </a>
                               </li>
                               
                           
                           </ul>
                           <!-- /.dropdown-messages -->
                           </li>
                           </div>
                            <?php } ?>
                            </nav>
<?php ////the old menu  ?>

<?php //// the menu buttons ?>
<div class="panel-body pull-left" style="width: 30%">
                            <div class="list-group col-lg-7" >

                           <a class='buttonip yellow'>Locate A Friend</a>
                            
                            <?php if(isset($_SESSION['nitesuser']['id'])){ ?>
                            <a href="#" onclick="getFriend2()">
                               <img src="dist/eclispe2.png" class="responsiveimg" width="305" height="100"/>    
                            </a>
                         
                            <?php } ?>
                            
                            <?php if(!isset($_SESSION['nitesuser']['id'])){ ?>
                             <a href="#" onclick="getLogin()">
                               <img src="dist/eclispe2.png" width="305" height="100"/>    
                            </a>
                            <?php } ?>
                            
                            <?php if(isset($_SESSION['nitesuser']['id_']) || isset($_SESSION['nitesuser']['id'])){ ?>
                            <a href="#" onclick="getFriend3()">
                               <img src="dist/eclispe3.png" width="305" height="100"/>    
                            </a>
                            <?php } ?>
                             <?php if(!isset($_SESSION['nitesuser']['id_']) && !isset($_SESSION['nitesuser']['id'])){ ?>
                            <a href="#" onclick="getLogin()">
                               <img src="dist/eclispe3.png" width="305" height="100"/>    
                            </a>
                            <?php } ?>
                            <?php if(isset($_SESSION['nitesuser']['id'])){ ?>
                            <a href="#" onclick="getFriend4()">
                               <img src="dist/eclispe4.png" width="305" height="100"/>    
                            </a>  
                            <?php } ?>
                            <?php if(!isset($_SESSION['nitesuser']['id'])){ ?>
                            <a href="#" onclick = "getLogin()">
                               <img src="dist/eclispe4.png" width="305" height="100"/>    
                            </a>  
                            <?php } ?>
                           
                            </div>
                            <!-- /.list-group -->
                           
                    </div>

                           