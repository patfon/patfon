<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Journal specification

if (isset($_POST['butadd'])){

$myfields = mysqli_real_escape_string($pdb,$_POST['journal']);
$myfield2s = mysqli_real_escape_string($pdb,$_POST['jvol']);
$myfield3s = mysqli_real_escape_string($pdb,$_POST['jmonth']);
$myfield4s = mysqli_real_escape_string($pdb,$_POST['jissue']);


    $query = ("INSERT INTO journal_spec (_journalid,_vol,_month,_issue,_current) 
    VALUES ($myfields,$myfield2s,'$myfield3s',$myfield4s,0) ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addjournal'] = 1;
            header('Location: ../../includes/journal/volume.php');
    }
    else{
       
        echo mysqli_error($pdb);
    }

   

}


//update a new journal specification
if (isset($_POST['butupdate'])){

    $myid = $_POST['jid'];
   
    $myfield2s = mysqli_real_escape_string($pdb,$_POST['jvol']);
    $myfield3s = mysqli_real_escape_string($pdb,$_POST['jmonth']);
    $myfield4s = mysqli_real_escape_string($pdb,$_POST['jissue']);
    
    
        $query = ("UPDATE journal_spec SET _vol = $myfield2s, _month = '$myfield3s', _issue = $myfield4s WHERE id = $myid ");
    
        if (mysqli_query($pdb, $query)) {
                $_SESSION['msg']['updatejournal'] = 1;
                header('Location: ../../includes/journal/volume.php');
        }
    
    
    
    }