<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
include '../../functions/index.php';

if (isset($_POST['butadd'])){

    $check_ =  checkpagecontent($pdb,'journal_copyright');
    if (isset($_POST['jcopyright'])){
        if (count($check_) <= 0 ){
            $myfield =  mysqli_real_escape_string($pdb,$_POST['jcopyright']);
        
            $query = ("INSERT INTO page (_metadata,_content) 
            VALUES ('journal_copyright','$myfield' ) ");
        
            mysqli_query($pdb, $query);
            $_SESSION['msg']['addjournal'] = 1;
            header('Location: ../../includes/journal/copyright.php');
        
           }
           else{ 
            $myfield =  mysqli_real_escape_string($pdb,$_POST['jcopyright']);
        
            $query = ("UPDATE page SET _content = '$myfield' WHERE _metadata = 'journal_copyright' ");
        
            mysqli_query($pdb, $query);
            $_SESSION['msg']['updatejournal'] = 1;
            header('Location: ../../includes/journal/copyright.php');
           }
} 

}