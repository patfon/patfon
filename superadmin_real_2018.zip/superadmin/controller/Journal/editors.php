<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Subject

if (isset($_POST['butadd'])){


    $myfield =  mysqli_real_escape_string($pdb,$_POST['journal']);
    $myfield2 =  mysqli_real_escape_string($pdb,$_POST['user']);
    $mydate = date('y-m-d');

    $query = ("INSERT INTO editorials (_userid,_journalid,_lastactivity) 
    VALUES ($myfield,$myfield2,'$mydate') ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addjournal'] = 1;
            header('Location: ../../includes/journal/editorial.php');
    }
    else{
        if (mysqli_errno($pdb) == 1062){
            $_SESSION['msg']['username_exists'] = 1;
            header("Location:  ../../includes/journal/editorial.php ");
            return;
        }
        echo mysqli_error($pdb);
    }

  

}