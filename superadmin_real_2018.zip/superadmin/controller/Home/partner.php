<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
if (isset($_POST['butadd'])){
        $path = "../../images/partners/";
        $mycount = count($_FILES['partner']['tmp_name']);

        $id = $_POST['partnerid'];
        $namex = $_POST['name'];
        
        for ($i=0;$i<$mycount;$i++) {

        //$_FILES['slidetmp'] = $s;

        $valid_formats = array("png","PNG","jpg","JPEG");
        
        $newname = $id[$i];
        
          
            $name = $_FILES['partner']['name'][$i];
            $size = $_FILES['partner']['size'][$i];
          
            if(strlen($name))
              {
              list($txt, $ext) = explode(".", $name);
              if(in_array($ext,$valid_formats))
              {
                                      //200KB limit     
              if($size<(1024*200))
              {
            
              $tmp = $_FILES['partner']['tmp_name'][$i];
              $canid = $newname .".".$ext;
            
              $urlpath = $path.$canid;

              move_uploaded_file($tmp, $urlpath);
           

              $urlpath = str_replace('../../','',$urlpath);
  
              $query = ("INSERT INTO partners (_url,_name) 
              VALUES ('$urlpath','$namex[$i]' ) ");
          
              if (mysqli_query($pdb, $query)) {
                $_SESSION['msg']['addpartner'] = 1;
                header('Location: ../../includes/home/partners.php');
              }
              else{
                  echo mysqli_error($pdb);
              }
            
              return;  
              }
              else{
                $_SESSION['msg']['error'] = "Slide Maximum size is 200 kilobytes.";
                header('Location: ../../includes/home/partners.php');	}					
              }
              else{
                $_SESSION['msg']['error'] = "Invalid slide format.";
                header('Location: ../../includes/home/partners.php');	}
              }
        
        
      }
    } 
    