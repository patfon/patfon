<?php include '../../includes/general/header.php'; ?>
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>

<?php if (isset($_GET['id'])){ 
    $myid = $_GET['id'];
    $myj = getnewsid($pdb, $myid);
    ?>
<div id="content" style="background: #fff; margin: 50px 20% 0px 20%; line-height: 20px; padding: 40px;">
<h3> Update News Information</h3><br>
<form action="<?php echo $myurl.'controller/News/index.php'; ?>" method="post">

<div style="display: inline-block; width: 80%;">
<label> Title :  </label> <br><br>
<input type="hidden" name="jid" value="<?php echo $myid; ?>">
<input type ="text" class="form2input" name="title" value="<?php echo $myj[0]['_title']; ?> "><br><br>
</div>

<div style="display: inline-block; width: 80%;">
<label> Content: </label> <br><br>

<textarea class="myeditarea" name="jnews"> 
<?php if (isset($myj[0]['_content'])){ 
    echo $myj[0]['_content'];
} ?>
</textarea> <br><br>
</div>

<div class="buttons" style="text-align:center;padding-top:10px;margin:0;padding-left:400px;x;border-top:1px solid #DDD;">
<input type="reset" name="reset" value="Reset" class="ui-button ui-widget ui-state-default ui-corner-all ui-state-hover" style="float:left;cursor:pointer;" role="button" aria-disabled="false">
<div class="highlight" style="float:left;margin-left:20px;">
<input type="submit" name="butupdate" id="next1" value="Update" class="ui-button ui-widget ui-state-default ui-corner-all" style="cursor:pointer;" role="button" aria-disabled="false">
</div>
<div style="clear:both;height:1px;margin-top:-1px;overflow: hidden;"></div>
</div>
</form>

</div>

<?php } ?>
<?php include '../../includes/general/footer.php'; ?>