<?php include '../../includes/general/header.php'; ?>
            
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>

<?php if (isset($_GET['confirmid'])){ 
      $myid = $_GET['confirmid'];
      $myid2 = $_GET['artid'];
      confirmpay($pdb,$myid,$myid2);
}
    ?>
    <?php if (isset($_GET['rejid'])){ 
      $myid = $_GET['rejid'];
      $myid2 = $_GET['artid'];
      rejectpay($pdb,$myid,$myid2);
}
    ?>

            <div id="content" style="height: 80%;">
                
            <?php include '../../includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                <div class="box">
                   <!--Alert msg-->
            <?php if (isset($_SESSION['msg']['confirmjournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> User payment has been confirmed..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['confirmjournal']); ?>
            <?php if (isset($_SESSION['msg']['rejectjournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> User payment has been rejected..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['rejectjournal']); ?>
            
             <!--end Alert msg-->

<!-- First Header showing Example-->
                <div>

                <div id="box-tabs" class="box">
                    <!-- box / title -->
                            <div class="title">
                                        <h5>Verify Payment Example</h5>
                                    </div>
                                    <!-- box / title -->
                                    <div id="box-messages">
                                        <div class="messages">
                            <div id="ctl00_ContentPlaceHolder1_BoxMessage_Info_Panel_SuccessMessage">
                                <div id="message-success" class="message message-warning">
                                                <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                            <h6>Examples</h6>
                                            <span id="examples"> An author goes ahead to pay for an article after it has been accepted. Please do not click 'confirm' if the Fee is not Correct with what is the benchmark fee. </span>
                                            </div>
                                </div>
                            </div>
                                        </div>
                                    </div>
                </div>
                </div>
<!-- end First Header showing Example-->
<!-- Second Header showing Table List-->
                        <div class="title">
                        <h5>Verify Payment Information</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:16px;padding-right:16px;">
                               
                                    <?php $sub = getpaidusers($pdb); ?>
                                    <table class="mydatatables" width="100%">
                                        
                                       <thead  style="color: #fff; ">
                                       <tr>
                                       <td class="tablehead">S/N </td> <td class="tablehead">Name of Author </td> <td class="tablehead"> Article ID </td> 
                                       <td class="tablehead"> Amount Paid </td>  <td class="tablehead"> Amount Expected </td>  <td class="tablehead"> Method of Payment </td> 
                                       <td class="tablehead">Action </td>
                                       </tr>
                                       </thead>

                                        <tbody>
                                      <?php  
                                      $i = 1;
                                      if (!empty($sub)) {
                                      foreach ($sub as $s){ ?>
                                            <tr> <td> <?php echo $i; ?></td> <td> <?php echo getusername($pdb,$s['_userid']); ?></td> <td> <?php echo $s['_articleid']; ?></td> 
                                            <td> <?php echo $s['_amount']; ?></td> <td> <?php echo getamountjournal($pdb,$s['_articleid']); ?></td> 
                                            <td> <?php echo $s['_method']; ?></td> 
                                            <td> <a href="verifypay.php?confirmid=<?php echo $s['id']; ?>&artid=<?php echo $s['_articleid']; ?>" onclick="return confirm('Are you sure you want to confirm this?')">Confirm Fee</a>&nbsp;&nbsp;&nbsp;<a href="verifypay.php?rejid=<?php echo $s['id']; ?>&artid=<?php echo $s['_articleid']; ?>" target="_blank" >Reject Fee</a></td></tr>
                                      <?php $i++;} } else { ?>
                                        <tr> <td colspan="7" style="text-align: center;"> No User has paid anything yet. </td></tr>

                                      <?php } ?>
                                        </tbody>
                                    </table>
                                   
                                
                            </div>             
<!-- end Second Header showing Table List-->                    
                            <!-- Add New Subjects to the Group-->
                                 
                            <!--   Add new Subjects end -->
                        </div> 
            
                </div>
            
            </div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include '../../includes/general/footer.php'; ?>