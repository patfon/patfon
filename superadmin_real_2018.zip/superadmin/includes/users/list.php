<?php include '../../includes/general/header.php'; ?>
            
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>


            <div id="content" style="height: 80%;">
                
            <?php include '../../includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                <div class="box">
            <!--Alert msg-->
          
             <!--end Alert msg-->

<!-- First Header showing Example-->
                <div>

                <div id="box-tabs" class="box">
                    <!-- box / title -->
                            <div class="title">
                                        <h5>Members Example</h5>
                                    </div>
                                    <!-- box / title -->
                                    <div id="box-messages">
                                        <div class="messages">
                            <div id="ctl00_ContentPlaceHolder1_BoxMessage_Info_Panel_SuccessMessage">
                                <div id="message-success" class="message message-warning">
                                                <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                            <h6>Examples</h6>
                                            <span id="examples"> A member has registered and is an active member of our system. Please endeavour to excercise caution with access. </span>
                                            </div>
                                </div>
                            </div>
                                        </div>
                                    </div>
                </div>
                </div>
<!-- end First Header showing Example-->
<!-- Second Header showing Table List-->
                        <div class="title">
                        <h5>List Members Information</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:16px;padding-right:16px;">
                               
                                    <?php $sub = getallusers($pdb); ?>
                                    <table class="mydatatables" width="100%">
                                        
                                       <thead  style="color: #fff; ">
                                       <tr>
                                       <td class="tablehead">S/N </td> <td class="tablehead">Name of Member </td> <td class="tablehead"> Email </td>  <td class="tablehead"> Affiliation </td> 
                                       <td class="tablehead"> State of origin </td>  <td class="tablehead"> Country </td>   
                                       
                                       </tr>
                                       </thead>

                                        <tbody>
                                      <?php  
                                      $i = 1;
                                      if (!empty($sub)) {
                                      foreach ($sub as $s){ ?>
                                            <tr> <td> <?php echo $i; ?></td> <td> <?php echo getusername($pdb,$s['id']); ?></td> 
                                            <td> <?php echo $s['_email']; ?></td>     <td> <?php echo $s['_uni']; ?></td> 
                                            <td> <?php echo $s['_state']; ?></td> <td> <?php echo $s['_country']; ?></td> 
                                           
                                            </tr>
                                      <?php $i++;} } else { ?>
                                        <tr> <td colspan="6" style="text-align: center;"> No user has been registered yet. </td></tr>

                                      <?php } ?>
                                        </tbody>
                                    </table>
                                   
                                
                            </div>             
<!-- end Second Header showing Table List-->                    
                            <!-- Add New Subjects to the Group-->
                                 
                            <!--   Add new Subjects end -->
                        </div> 
            
                </div>
            
            </div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include '../../includes/general/footer.php'; ?>