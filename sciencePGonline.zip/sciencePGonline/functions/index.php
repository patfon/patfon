<?php 

/*** functions **/


function getsubjects($con){

  $query = (" SELECT * FROM subject ");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[] = $r;
      }
   }
  
   return $src;
  
  }

  function getsubjectname($con,$id){

    $query = (" SELECT _name FROM subject WHERE id = $id ");
    $src = '';
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
      $src = $r['_name'];
      }
     }
    
     return $src;
    
    } 
    
    function getsubjectnameInJournal($con,$id){

      $query = (" SELECT _name FROM subject WHERE id IN (SELECT _subject FROM journal WHERE id = $id) ");
      $src = '';
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
        $src = $r['_name'];
        }
       }
      
       return $src;
      
      } 

      function getcurrentJournal($con,$id){

        $query = (" SELECT _vol,_month,_issue FROM  journal_spec WHERE _journalid = $id AND _current = 1 ");
        $src = '';
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          $mymnt = $r['_month'];
          $mid= strtotime($mymnt);  
          $newmnt = date('F Y',$mid);
          $src = "Vol. ".$r['_vol']. "Issue ".$r['_issue']." ".$newmnt ;
          }
         }
        
         return $src;
        
        } 
  
    function getjournals($con,$id){

      $query = (" SELECT * FROM journal WHERE _subject =  $id");
      $src = array();
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src[] = $r;
          }
       }
      
       return $src;
      
      }

      function getjournalbyID($con,$id){

        $query = (" SELECT * FROM journal WHERE id =  $id");
        $src = array();
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src[] = $r;
            }
         }
        
         return $src;
        
        }

      function getjournalprice($con,$id){

        $query = (" SELECT _fee FROM journal WHERE id = $id ");
        $src = '';
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
          $src = $r['_fee'];
          }
         }
        
         return $src;
        
        } 

      function getjournalarch($con,$id){

        $query = (" SELECT * FROM journal_spec WHERE _journalid =  $id ORDER BY _month DESC LIMIT 7 ");
        $src = array();
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src[] = $r;
            }
         }
        
         return $src;
        
        }

        function getjournalcurrent($con,$id){

          $query = (" SELECT * FROM journal_spec WHERE _journalid =  $id AND _current = 1 ");
          $src = array();
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src[] = $r;
              }
           }
          
           return $src;
          
          }

        function getjournalarchbyissue($con,$id,$vol){

          $query = (" SELECT * FROM journal_spec WHERE _journalid =  $id AND _vol = $vol ");
          $src = array();
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src[] = $r;
              }
           }
          
           return $src;
          
          }

      function getarticles($con,$id){

        $query = (" SELECT * FROM articles WHERE _journalid =  $id AND _paid = 1");
        $src = array();
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src[] = $r;
            }
         }
        
         return $src;
        
        }

        function geteditors($con,$id){

          $query = (" SELECT * FROM editorials WHERE _journalid =  $id");
          $src = array();
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src[] = $r;
              }
           }
          
           return $src;
          
          }

          function getreviewers($con,$id){

            $query = (" SELECT * FROM reviewers WHERE _journalid =  $id");
            $src = array();
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src[] = $r;
                }
             }
            
             return $src;
            
            }

        function getarticleauthors($con,$id){

          $query = (" SELECT _name FROM  authors WHERE _articleid = $id");
          $src = '';
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
            $src .= $r['_name'].", " ;
            }
           }
          
           return $src;
          
          } 

          function getarticlebyyear($con,$id,$y){

            $query = (" SELECT * FROM  articles WHERE _journalid = $id AND YEAR(_pubdate) = '$y' ");
            $src = '';
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
              $src .= $r['_name'].", " ;
              }
             }
            
             return $src;
            
            }
            
            function getarticlebyissue($con,$id,$y){

              $query = (" SELECT * FROM  articles WHERE _journalid = $id AND _journalspec IN (SELECT id from journal_spec WHERE _journalid = $id AND _issue = $y)  ");
              $src = '';
              $result = mysqli_query($con,$query) or die(mysqli_error($con));
               if (mysqli_num_rows($result) > 0){
                 while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
                $src .= $r['_name'].", " ;
                }
               }
              
               return $src;
              
              }

      function getjournalname($con,$id){

        $query = (" SELECT _name FROM journal WHERE id = $id ");
        $src = '';
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
          $src = $r['_name'];
          }
         }
        
         return $src;
        
        }  

        function getjournalabout($con,$id){

          $query = (" SELECT _about FROM journal WHERE id = $id ");
          $src = '';
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
            $src = $r['_about'];
            }
           }
          
           return $src;
          
          }  

   

      function getslides($con){

        $query = (" SELECT * FROM slides ");
        $src = array();
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src[] = $r;
            }
         }
        
         return $src;
        
        }

        function gettestimonials($con){

          $query = (" SELECT * FROM testimonials ");
          $src = array();
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src[] = $r;
              }
           }
          
           return $src;
          
          }

          
        function getnews($con){

          $query = (" SELECT * FROM news ");
          $src = array();
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src[] = $r;
              }
           }
          
           return $src;
          
          }

        function getfaq($con){

            $query = (" SELECT * FROM faq ");
            $src = array();
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src[] = $r;
                }
             }
            
             return $src;
            
            }
      

          function getnewstitle($con, $id){

            $query = (" SELECT _title FROM news WHERE id = $id ");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['_title'];
                }
             }
            
             return $src;
            
            }

            function getnewscontent($con, $id){

              $query = (" SELECT _content FROM news WHERE id = $id ");
              $src = "";
              $result = mysqli_query($con,$query) or die(mysqli_error($con));
               if (mysqli_num_rows($result) > 0){
                 while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                  
                   $src = $r['_content'];
                  }
               }
              
               return $src;
              
              }

      

          function getpagecontent($con,$page){

            $query = (" SELECT _content FROM page WHERE _metadata = '$page' ");
            $src = '';
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                $src = $r['_content'];
                }
             }
            
             return $src;
            
            }     
            function checkpagecontent($con,$page){

              $query = (" SELECT * FROM page WHERE _metadata = '$page' ");
              $src = array();
              $result = mysqli_query($con,$query) or die(mysqli_error($con));
               if (mysqli_num_rows($result) > 0){
                 while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                  
                  $src[] = $r;
                  }
               }
              
               return $src;
              
              }   
              
              function strip_single_tag($str,$tag){

                $str=preg_replace('/<'.$tag.'[^>]*>/i', '', $str);
            
                $str=preg_replace('/<\/'.$tag.'>/i', '', $str);
            
                return $str;
            }     
            
            function getusername($con, $id){

              $query = (" SELECT CONCAT (_fname,' ',_lname) as _thename FROM users WHERE id = $id ");
              $src = "";
              $result = mysqli_query($con,$query) or die(mysqli_error($con));
               if (mysqli_num_rows($result) > 0){
                 while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                  
                   $src = $r['_thename'];
                  }
               }
              
               return $src;
              
              }

            function getuserpic($con, $id){

                $query = (" SELECT _image FROM users WHERE id = $id ");
                $src = "";
                $result = mysqli_query($con,$query) or die(mysqli_error($con));
                 if (mysqli_num_rows($result) > 0){
                   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                    
                     $src = $r['_image'];
                    }
                 }
                
                 return $src;
                
                }
            function getuseruni($con, $id){

                  $query = (" SELECT CONCAT(_uni,' ',_city, ' ', _country) as theuni FROM users WHERE id = $id ");
                  $src = "";
                  $result = mysqli_query($con,$query) or die(mysqli_error($con));
                   if (mysqli_num_rows($result) > 0){
                     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                      
                       $src = $r['theuni'];
                      }
                   }
                  
                   return $src;
                  
                  }
             
  