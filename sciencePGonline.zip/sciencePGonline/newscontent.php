<?php include 'includes/general/header.php'; ?>
<?php include 'classes/connection.php'; ?>
<?php include 'functions/index.php'; ?>

    <?php include 'includes/general/topmenu.php'; ?>

    <?php if (isset($_GET['newscontent'])){ ?>
        <div class="special_issue"><a>
            </a><div class="issue_title"><a></a><a href="javascript:void(0);"><?php echo getnewstitle($pdb,$_GET['newscontent']); ?></a></div>
           
        </div>
        <div class="middle">
       
        <?php include 'includes/news/newscontent.php'; ?>

            
        </div>
    <?php } ?>  
    
</div></body></html>
