<?php session_start(); ?>
<?php

unset ($_SESSION['pubcouser']);

$_SESSION['logout'] = 1;
header('Location: index.php');
?>