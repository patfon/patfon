<?php include 'includes/general/header.php'; ?>
<?php include 'classes/connection.php'; ?>
<?php include 'functions/index.php'; ?>

    <?php include 'includes/general/topmenu.php'; ?>
        <div class="special_issue"><a>
            </a><div class="issue_title"><a></a><a href="javascript:void(0);">News</a></div>
           
        </div>
        <div class="middle">
       
        <?php include 'includes/news/newslist.php'; ?>

            
        </div>
      
    
</div></body></html>
