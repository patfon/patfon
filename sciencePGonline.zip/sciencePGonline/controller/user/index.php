<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//
if (isset($_POST['check'])){

    $check = $_POST['check'];
    $query = (" SELECT * FROM users WHERE _uname = '$check' ");
    $src = array();
    $result = mysqli_query($pdb,$query) or die(mysqli_error($pdb));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
      $src[] = $r;
      }
     }

     if (!empty($src)){
         echo "0";
     }
     else {
         echo "1";
     }
    
    
}

if (isset($_POST['checkmail'])){

    $check = $_POST['checkmail'];
    $query = (" SELECT * FROM users WHERE _email = '$check' ");
    $src = array();
    $result = mysqli_query($pdb,$query) or die(mysqli_error($pdb));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
      $src[] = $r;
      }
     }

     if (!empty($src)){
         echo "0";
     }
     else {
         echo "1";
     }
    
    
}

if (isset($_POST['jregister'])){

$uname = mysqli_real_escape_string($pdb,$_POST['uname']);
$pass = md5(mysqli_real_escape_string($pdb,$_POST['pass2']));
$fname = mysqli_real_escape_string($pdb,$_POST['fname']);
$lname =  mysqli_real_escape_string($pdb,$_POST['lname']);
$email = mysqli_real_escape_string($pdb,$_POST['email1']);
$email2 = mysqli_real_escape_string($pdb,$_POST['email2']);
$area = mysqli_real_escape_string($pdb,$_POST['areaCode']);
$tel = mysqli_real_escape_string($pdb,$_POST['tel']);
$uni = mysqli_real_escape_string($pdb,$_POST['uni']);
$city = mysqli_real_escape_string($pdb,$_POST['city']);
$state = mysqli_real_escape_string($pdb,$_POST['statex']);
$country = mysqli_real_escape_string($pdb,$_POST['country']);
$subject = $_POST['research'];///an array of subjects

$cap =  strtolower(mysqli_real_escape_string($pdb,$_POST['captcha']));
$code = strtolower($_SESSION['captcha']['code']);

$thecount = count($subject);

if ($cap !== $code) {
       
    $_SESSION['captcha_fail'] = 1;
    header("Location:  ../../register.php ");
    return;
} 

    $query = ("INSERT INTO users (_uname,_pass,_fname,_lname,_email,_email2,_pnum,_uni,_state,_city,_areacode,_country) 
    VALUES ('$uname','$pass', '$fname' , '$lname', '$email', '$email2', '$tel', '$uni' , '$state', '$city', '$area', '$country' ) ");

    $query2 = (" SELECT id FROM users WHERE _uname = '$uname' ");

    if (mysqli_query($pdb, $query)) {
          
          $re = mysqli_query ($pdb,$query2);
          $rov = mysqli_fetch_array($re,MYSQLI_ASSOC);
          $myid = $rov['id'];

          for($i = 0; $i < $thecount ; $i ++){
              $mycat =  $subject[$i];
          $query3 = ("INSERT INTO users_cat (_cat,_userid) 
          VALUES ($mycat,$myid) ");   
          mysqli_query($pdb, $query3); } 
          $_SESSION['success_reg'] = 1;
          header("Location:  ../../index.php ");
    }
    else{
          echo mysqli_error($pdb);
    }



}