<?php session_start(); ?>
<?php include '../../classes/connection.php' ;

if (isset($_POST['butlogin'])){

$userx = mysqli_real_escape_string($pdb,$_POST['username']);
$pass = mysqli_real_escape_string($pdb,$_POST['password']);
$q = "SELECT * FROM users WHERE _uname='$userx' and _pass='".md5($pass)."'";

$r = mysqli_query ($pdb,$q);
$rov = mysqli_fetch_array($r,MYSQLI_ASSOC);
$row = mysqli_num_rows($r);

if ($row > 0) {
    
    $_SESSION['pubcouser']['id'] = $rov['id'];
    $_SESSION['pubcouser']['title'] = $rov['title'];
    $_SESSION['pubcouser']['firstname'] = $rov['_fname'];
    $_SESSION['pubcouser']['lastname'] = $rov['_lname'];
    $_SESSION['pubcouser']['school'] = $rov['_uni'];
  
    $_SESSION['pubcouser']['name'] = $rov['_fname']." ".$rov['_lname'];
    $_SESSION['pubcouser']['email'] = $rov['_email'];
    $_SESSION['pubcouser']['country'] = $rov['_country'];
   
    $myid = $rov['id'];
    
    $q2 = "SELECT _cat FROM users_cat WHERE _userid=$myid ";

    $r2 = mysqli_query ($pdb,$q2);
   
    $src = array();
    if (mysqli_num_rows($r2) > 0){
        while ($re = mysqli_fetch_array ($r2, MYSQLI_ASSOC)) { 
       
       $src = $re['_cat'];
       }
      }
 
    $_SESSION['pubcouser']['category'] = $src;//the category of subjects the Author joined
  

    header('Location: ../../admin/index.php'); 
}
else {
    $_SESSION['login_fail'] =  true;
    header("Location: ../../login.php");
    exit;
} 

}

if (isset($_POST['butlogin2'])){

    $userx = mysqli_real_escape_string($pdb,$_POST['username']);
    $pass = mysqli_real_escape_string($pdb,$_POST['password']);
    $q = "SELECT * FROM users WHERE _uname='$userx' and _pass='".md5($pass)."'";
    
    $r = mysqli_query ($pdb,$q);
    $rov = mysqli_fetch_array($r,MYSQLI_ASSOC);
    $row = mysqli_num_rows($r);
    
    if ($row > 0) {
        
        $_SESSION['pubcosuperadmin']['id'] = $rov['id'];
       
        header('Location: ../../superadmin/includes/home/subjects.php'); 
    }
    else {
        $_SESSION['login_fail'] =  true;
        header("Location: ../../login.php");
        exit;
    } 
    
    }