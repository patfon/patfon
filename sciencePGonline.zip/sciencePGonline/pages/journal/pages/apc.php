<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>

<?php if (isset($_GET['catid7'])) { ?>
<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo getjournalname($pdb,$_GET['catid7']); ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/journal/journalbycat.php?catid2=".$_GET['catid7']; ?>" style=""><div class="tit">Home</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/journal/pages/archive.php?catid3=".$_GET['catid7']; ?>"><span class="tit">Archive</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/journal/pages/editorial.php?catid4=".$_GET['catid7']; ?>" ><div class="tit" >Editorial Board</div></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/reviewers.php?catid5=".$_GET['catid7']; ?>" ><span class="tit" style="">Reviewers</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/guidelines.php?catid6=".$_GET['catid7']; ?>"><span class="tit">Guidelines</span></a>
        <div class="separater">|</div>
        
        <a  href="<?php echo $myurl."pages/journal/pages/apc.php?catid7=".$_GET['catid7']; ?>"  style=" background-color:#FFFFFF;color:#111111;"><span class="tit" >Article Processing Charges</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/ethics.php?catid8=".$_GET['catid7']; ?>"><span class="tit">Publication Ethics</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/copyright.php?catid9=".$_GET['catid7']; ?>"><span class="tit">Copyright</span></a>
        <div class="separater">|</div>

        <a href="<?php echo $myurl."pages/journal/pages/faq.php?catid10=".$_GET['catid7']; ?>"><span class="tit">FAQ</span></a>
    </div>
</div>

<div class="middle">

<div class="middle_title">
<a href="" class="title_link">Home</a>  /  <a href="<?php echo $myurl.'pages/journal/journallist.php'; ?>" class="title_link">Journals</a>  /  <a href="#" class="title_link"> <?php echo getsubjectnameInJournal($pdb,$_GET['catid7']); ?></a>  /  <?php echo getjournalname($pdb,$_GET['catid7']); ?>
</div> 

            <div class="middle_title2">Article Processing Charges</div>
            <div class="middle_line"></div>

            <div class="middle_right_tit" style="margin-left:20px;width:1218px;">Why do Science Publishing Group journals have Article Processing Charge?</div>
<div class="middle_right_text" style="margin-left:20px;width:1218px;margin-top:5px;">
Traditional journals are solely based on a reader-pays model, in which institutional libraries typically pay for the access to content. However, all journals published by Science Publishing Group (SciencePG) are full open access. The scientific community and general public can access all articles published in the journal for free. 
<br>
This means that Science Publishing Group does not gain any income through selling subscriptions of the printed or online versions of the published articles. Therefore, by collecting Article Processing Charge from authors' institutes or research funding bodies, Science Publishing Group is able to cover the various publishing services:
<div class="guide_content1" style="padding-top:5px;">
●&nbsp;&nbsp;<b>Editorial work:</b> peer review, administrative support, commissioning content, journal development.   <br>
●&nbsp;&nbsp;<b>Technical infrastructure and innovation:</b> development, maintenance and operation of online journal system and websites.   <br>
●&nbsp;&nbsp;<b>Production of articles:</b> formatting and mark-up of articles and inclusion in indexing services.   <br>
●&nbsp;&nbsp;<b>Marketing of journal and content:</b> making sure readers and authors know about the work published in the title.   <br>
●&nbsp;&nbsp;<b>Customer service:</b> responding to authors and readers.
</div>

</div>
<div class="middle_right_tit" style="margin-left:20px;width:1218px;">How Much Does Science Publishing Group Charge for the Journal?</div>
 <p class="middle_tit3" style="margin-left:20px;width:1218px;margin-top:5px;"> 
    <i><?php echo getjournalname($pdb,$_GET['catid7']); ?></i> is an Open Access journal accessible for free on the Internet. With Open Access, Science Publishing Group (SPG) allows us to distribute knowledge more widely and at a lower cost than was previously possible. However, to cover the editorial services and production of an article, the journal depends on Article Processing Charge (APC). 
</p>

<p class="middle_tit3" style="margin-left:20px;width:1218px;margin-top:5px;">

<br>

    </p>
   <table class="t1" style="border: 1px #ccc solid; color: #333333;margin-left: 20px;">
               <tbody>
               <tr class="tr1" style="color: #fff;height: 30px;">
                   <td width="550px">Journal Title</td>
                 
                   <td width="300px">Article Processing Charge for Authors<br> from Upper Middle Income Countries</td>
               </tr>
                <tr align="center" style="line-height: 20px;height: 40px;">
                   <td width="550px"><?php echo getjournalname($pdb,$_GET['catid7']); ?></td>
                  
                   <td width="300px" style="font-weight: bold;color: red;"><?php echo getjournalprice($pdb,$_GET['catid7']);?> NGN</td>
             </tr>
        </tbody>
  </table> 
  
<p class="middle_tit3" style="margin-left:20px;width:1218px;margin-top:15px;">
Article Processing Charge discounts or waivers are given to authors from low-income countries or lower-middle-income countries (classified by the Word Bank, learn more, click: <a href="https://datahelpdesk.worldbank.org/knowledgebase/articles/906519-world-bank-country-and-lending-groups" target="_blank">https://datahelpdesk.worldbank.org/knowledgebase/articles/906519-world-bank-country-and-lending-groups</a> ).
<br>
For more details, please contact with the editor directly once the manuscript is accepted.

<div class="middle_right_tit" style="margin-left:20px;width:1218px;"> Who is Responsible for Paying the Article Processing Charge?</div>
           <div class="middle_right_text" style="margin-left:20px;width:1218px;margin-top:5px;">Upon an article is editorially accepted, the corresponding author will be notified about the payment issue, which is charged to either the author, or the funder, institution or employer.</div>
           
       
			<div class="middle_right_tit" style="margin-left:20px;width:1218px;">When and How do Authors Pay?</div>
			    <div class="middle_right_text" style="margin-left:20px;width:1218px;margin-top:5px;">
                    The submitting author needs to arrange payment of the article-processing charge unless a waiver has been granted. Following peer review, once a manuscript has received editorial acceptance in principle, the article-processing charge becomes payable and formatting checks on the manuscript will commence. Once formatting checks are completed, and payment of the article-processing charge has been received, the article will be published.
                    <p style="width:360px;">Science Publishing Group currently supports the following payment methods:
                        </p><p style="margin-left:10px;margin-top:2px;">
                            <img src="<?php echo $myurl.'images/black_dot.png'; ?>" style="margin-right:10px;">Payment through PayPal<br>
                             <img src="<?php echo $myurl.'images/black_dot.png'; ?>" style="margin-right:10px;">Pay with Debit or Credit Card<br>
                            <img src="<?php echo $myurl.'images/black_dot.png'; ?>" style="margin-right:10px;">Wire Transfer in US Dollars (USD)<br>
                            <img src="<?php echo $myurl.'images/black_dot.png'; ?>" style="margin-right:10px;">Western Union in US Dollars (USD)<br>
                             <img src="<?php echo $myurl.'images/black_dot.png'; ?>" style="margin-right:10px;">MoneyGram in US Dollars (USD)
                          
                        </p>We recommend you use our PayPal Secure Payment system:
                    <p></p>
                </div>

                <div style="clear: both;"> </div>
                
           <div class="middle_right_tit" style="margin-left:20px;width:1218px;"> Are reprints of my article included in the Article Processing Charge (APC)? -<span style="color:#B60505;"> No.</span></div>
           <div class="middle_right_text" style="margin-left:20px;width:1218px;margin-top:5px;">Article Processing Charge (APC) do not entitle the authors to receive reprints of their published article. Reprints can be ordered separately and optionally for any article that has been published in a Science Publishing Group journal. To request an offer for reprints of an article, please send an e-mail to <a href="mailto:service@sciencepublishinggroup.com">service@sciencepublishinggroup.com</a></div>
                
                
        
              <div class="clear"></div>
         
            <div class="clear"></div>
        </div>

<?php } ?>
    
<?php include '../../../includes/general/footer.php'; ?>