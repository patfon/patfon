<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>

<?php if (isset($_GET['catid3'])) { 
    $myjournalarch = getjournalarch($pdb,$_GET['catid3']);
    $myjournalcurrent = getjournalcurrent($pdb,$_GET['catid3']);
    
    ?>
<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo getjournalname($pdb,$_GET['catid3']); ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/journal/journalbycat.php?catid2=".$_GET['catid3']; ?>" ><div class="tit">Home</div></a>
        <div class="separater">|</div>
    
        <a href="<?php echo $myurl."pages/journal/pages/archive.php?catid3=".$_GET['catid3']; ?>" style=" background-color:#FFFFFF;color:#111111;"><div class="tit" >Archive</div></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/journal/pages/editorial.php?catid4=".$_GET['catid3']; ?>"><span class="tit" style="">Editorial Board</span></a>
        <div class="separater">|</div>

        <a href="<?php echo $myurl."pages/journal/pages/reviewers.php?catid5=".$_GET['catid3']; ?>"><span class="tit" style="">Reviewers</span></a>
        <div class="separater">|</div>

        <a href="<?php echo $myurl."pages/journal/pages/guidelines.php?catid6=".$_GET['catid3']; ?>"><span class="tit">Guidelines</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/journal/pages/apc.php?catid7=".$_GET['catid3']; ?>"><span class="tit" >Article Processing Charges</span></a>
        <div class="separater">|</div>

        <a href="<?php echo $myurl."pages/journal/pages/ethics.php?catid8=".$_GET['catid3']; ?>"><span class="tit">Publication Ethics</span></a>
        <div class="separater">|</div>

        <a href="<?php echo $myurl."pages/journal/pages/copyright.php?catid9=".$_GET['catid3']; ?>"><span class="tit">Copyright</span></a>
        <div class="separater">|</div>

        <a href="<?php echo $myurl."pages/journal/pages/faq.php?catid10=".$_GET['catid3']; ?>"><span class="tit">FAQ</span></a>
    </div>
</div>

<div class="middle">
<?php if (!empty($myjournalarch)) {  ?>
<div class="middle_left" id="middle_left">
            <div class="middle_left_title">Archive</div>
            <div class="middle_left_link">
                
                    
                        <?php foreach ($myjournalarch as $iss) {  ?>
                        <div class="link_title" id="down_up_0" onclick="downUp(0)"><?php echo date('Y', strtotime($iss['_month']) ).", "."Volume ". $iss['_vol'] ; ?> </div>
                        <div class="line"></div>
                        <div class="content" id="content_0">
                        <?php $issue = getjournalarchbyissue($pdb,$iss['_journalid'],$iss['_vol']); 
                                        foreach ( $issue as $isx ) {
                                        ?>
 <a href="<?php echo $myurl."pages/journal/pages/archive.php?catid3=".$_GET['catid3'].'&issueid='.$isx['id'] ; ?>" > <?php echo "Vol. ".$isx['_vol']. " Issue ".$isx['_issue']." ". date('M, d',strtotime($isx['_month'])); ?></a>
                                        
        <?php     }     ?>   
                            <div class="line"></div>
                                
                            
                        </div>
                        <?php } ?>
            </div>

            <div class="middle_right_image_link1"><a href="<?php echo $myurl.'login.php'; ?>" target="_blank"><img src="<?php echo $myurl."images/".'submit_btn.jpg'; ?>" border="0"></a></div>

            
            <div class="middle_right_image_link2"><a href="#"><img src="<?php echo $myurl.'images/become_btn.jpg'; ?>" border="0"></a></div>
        </div>

                                        <?php } ?>

       

            <div class="clear"></div>
 </div>

<?php } ?>
    
<?php include '../../../includes/general/footer.php'; ?>