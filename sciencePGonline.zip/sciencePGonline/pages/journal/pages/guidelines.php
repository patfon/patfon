<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>

<?php if (isset($_GET['catid6'])) { ?>
<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo getjournalname($pdb,$_GET['catid6']); ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/journal/journalbycat.php?catid2=".$_GET['catid6']; ?>" style=""><div class="tit">Home</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/journal/pages/archive.php?catid3=".$_GET['catid6']; ?>"><span class="tit">Archive</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/journal/pages/editorial.php?catid4=".$_GET['catid6']; ?>"  ><div class="tit" >Editorial Board</div></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/reviewers.php?catid5=".$_GET['catid6']; ?>"><span class="tit" style="">Reviewers</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/guidelines.php?catid6=".$_GET['catid6']; ?>" style=" background-color:#FFFFFF;color:#111111;"><span class="tit">Guidelines</span></a>
        <div class="separater">|</div>
        
        <a  href="<?php echo $myurl."pages/journal/pages/apc.php?catid7=".$_GET['catid6']; ?>"><span class="tit" >Article Processing Charges</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/ethics.php?catid8=".$_GET['catid6']; ?>"><span class="tit">Publication Ethics</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/copyright.php?catid9=".$_GET['catid6']; ?>"><span class="tit">Copyright</span></a>
        <div class="separater">|</div>

        <a href="<?php echo $myurl."pages/journal/pages/faq.php?catid10=".$_GET['catid6']; ?>"><span class="tit">FAQ</span></a>
    </div>
</div>

<div class="middle">


<div class="middle_left" id="middle_left" style="height: 1200px" >
</div>
            <?php echo strip_tags(getpagecontent($pdb, 'journal_guide'),'<div><span><img><h1><a>');
            // getpagecontent($pdb, 'journal_guide');
            ?>
            <div class="clear"></div>
 </div>

<?php } ?>
    
<?php include '../../../includes/general/footer.php'; ?>