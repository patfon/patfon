<?php include '../../includes/general/header.php'; ?>
<?php include '../../classes/connection.php'; ?>
<?php include '../../functions/index.php'; ?>

    <?php include '../../includes/general/topmenu.php'; ?>

        <div class="special_issue"><a>
            </a><div class="issue_title"><a></a><a href="javascript:void(0);">Journals</a></div>
           
        </div>
        <div class="middle">
              
                <?php include '../../includes/journal/left_side.php'; ?>

                <?php include '../../includes/journal/journallist.php'; ?>
                
                <div class="clear"></div>
        </div>
      
    
<?php include '../../includes/general/footer.php'; ?>
