<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>" ><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/join/joineditorinchief.php"; ?>" style=" background-color:#FFFFFF;color:#111111;"><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/resources/openaccess.php"; ?>" ><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
            <div class="middle_left" id="middle_left" style="height: 652px;">
                <div class="middle_left_title">Join Us</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/join/editorinchief.php'; ?>">Join as an Editor-in-Chief</a>
                    <a href="<?php echo $myurl.'pages/info/join/editor.php'; ?>"  style="background:#2F5BA6;color:#FFFFFF;">Join as an Editorial Member</a>
                    <a href="<?php echo $myurl.'pages/info/join/reviewer.php'; ?>">Become a Reviewer</a>
                    <a href="<?php echo $myurl.'pages/info/join/qualification.php'; ?>">Qualification &amp; Requirement</a>
                    <a href="<?php echo $myurl.'pages/info/join/benefits.php'; ?>">Benefits &amp; Responsibilities</a>
                </div>
            </div>
            
            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="/home/index">Home</a>&nbsp;/&nbsp;<a href="/info/journalsservice">Services</a>&nbsp;/&nbsp;<a href="/info/joinasaneditorinchief">Join Us</a>&nbsp;/&nbsp;Join as an Editor</div>
               
                <div id="vol">
                    <div class="economics">Join as an Editorial Member</div>
                    <div class="line2"></div>

                    <div class="middle_right_container" style="width:918px;">
<div class="middle_right_content_line" style="line-height: 26px;">                  
We are seeking professionals to join our Editorial Board. You will be entitled following benefits while working with us as an editorial board member of the journal.
<br>1. You are enforced to read carefully various manuscripts in your area of importance and interest. This is the way you are routinely forced to keep yourself up-to-date while checking and suggesting the changes in manuscripts.
<br>2. This work helps to add in and provides a better way to create your identity as a well known expert in your field and may lead to increased invitations to speak at conferences or demand for invited research of your specialized area.
<br>3. You will be among the contributors who will shape and decide the urgent ways as required with changing societal needs.
<br>4. Your ideas and subject inputs may help in arranging special issues as per topics of your interest and choice.
<br>5. You will come across the latest research before everyone else and gives you a position of leadership in your research community.
<br>6. The editorial board members who need financial support could enjoy 20% discount to publish their articles in SciencePG.
</div>

<div class="middle_right_content_line" style="line-height: 26px;"> 
If you are interested in being an editorial board member for the journal, please join us via SciencePG online system:<br>
Here are the procedures:<br>
Step 1: If you didn’t register before, please create an account first:
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $myurl.'register.php';?>" target="_blank" style="color: #2F5BA6;"></a>

<br>Step 2: Login with your username and password.
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $myurl.'register.php';?>" target="_blank" style="color: #2F5BA6;">http://www.sciencepublishinggroup.com/login</a>
<br>
Step 3: Click “Editorial Board” on the left menu under the button “Join Us”.<br>
Step 4: Upload your CV and complete the necessary information and submit.<br>
Step 5: Perfect your “Personal Profile” on the left menu.

</div>
<div class="middle_right_content_line"> 
Any questions, please contact&nbsp;<a href="mailto:EditorialMember@nigeriapg.com">EditorialMember@snigeriapg.com</a>

</div>


                </div>

                </div>
            </div>
            <div class="clear"></div>
        </div>
    
<?php include '../../../includes/general/footer.php'; ?>