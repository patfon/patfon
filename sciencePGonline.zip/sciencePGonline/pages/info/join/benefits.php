<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>" ><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/publication/joineditorinchief.php"; ?>" style=" background-color:#FFFFFF;color:#111111;"><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/resources/openaccess.php"; ?>" ><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
            <div class="middle_left" id="middle_left" style="height: 652px;">
                <div class="middle_left_title">Join Us</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/join/editorinchief.php'; ?>">Join as an Editor-in-Chief</a>
                    <a href="<?php echo $myurl.'pages/info/join/editor.php'; ?>"  >Join as an Editorial Member</a>
                    <a href="<?php echo $myurl.'pages/info/join/reviewer.php'; ?>">Become a Reviewer</a>
                    <a href="<?php echo $myurl.'pages/info/join/qualification.php'; ?>">Qualification &amp; Requirement</a>
                    <a href="<?php echo $myurl.'pages/info/join/benefits.php'; ?>" style="background:#2F5BA6;color:#FFFFFF;">Benefits &amp; Responsibilities</a>
                </div>
            </div>
            
            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="/home/index">Home</a>&nbsp;/&nbsp;<a href="/info/journalsservice">Services</a>&nbsp;/&nbsp;<a href="/info/joinasaneditorinchief">Join Us</a>&nbsp;/&nbsp;Benefits & Responsibilities</div>
               
                <div id="vol">
                    <div class="economics">Benefits</div>
                    <div class="line2"></div>

                    <div class="middle_right_container" style="width:918px;">
<div class="middle_right_content_line">                  
You are invited to be a part of Science Publishing Group journals as a member of editorial board or reviewer and you are requested to read the terms and conditions carefully.
</div>

<div class="middle_right_title_line">1. Benefits</div>
<div class="middle_right_content_line">  
Being on the editorial board or a reviewer of a journal is truly productive, pleasant and in fact prestigious which helps in add-on to the scientific world through the ways and guidelines given by experts in the relevant fields. Though, it is time consuming and often goes unobserved, there are some important rewards that make the editorial board members/reviewers worthwhile. You will be entitled following benefits while working with us as an editorial board member/reviewer of the journal.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;You are enforced to read carefully various manuscripts in your area of importance and interest. This is the way you are routinely forced to keep yourself up-to-date while checking and suggesting the changes in manuscript.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;This work helps to add in and provides a better way to create your identity as a well known expert in your field and may lead to increased invitations to speak at conferences or demand for invited research of your specialized area.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;You will be among the contributors who will shape and decide the urgent ways as required with changing societal needs.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Your ideas and subject inputs may help in arranging special issues as per topics of your interest and choice.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;You will come across the latest research before everyone else and gives you a position of leadership in your research community.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The editorial board members/reviewers who need financial support could enjoy 20% discount to publish their articles in SciencePG.
</div>
<div class="middle_right_title_line">2. Responsibilities</div>
<div class="middle_right_content_line">  
We need our editorial board members and reviewers to be key figures in their professions to have some experience of publishing articles. A reviewer's comment decides the acceptance or rejection of an article so they play an important role in peer review process. All the members are requested to test out the articles submitted to them without any bias to increase the quality of our journals. There is no hard and fast rule to analyse an article and it depends upon the worthiness, quality and originality. While verifying the article, you have to go through following points:
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Detailed examination and relevance of the article as per author guidelines.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Careful examination of purposes and objectives of the work carried out.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Correctness of the conclusions and recommendations along with up-to-date references.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Copyediting and proofreading of the manuscripts in accordance with publishing standards especially with grammar, punctuation and spelling.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Coverage areas of the manuscript in relevance with the scopes of journals.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Plagiarism related issues if any.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;You have to give some suggestions based on the structure of the manuscript. In general, there is no limit for the maximum inputs.
</div>
<div class="middle_right_title_line">3. Agreement</div>
<div class="middle_right_content_line">  
The acceptance of following terms and conditions confirms your appointment as a member on editorial board or reviewer of journals of Science Publishing Group.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Your appointment is initially for two years.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;You are expected to observe carefully general policies, code of ethics and practices of the Science Publishing Group Publications which may change from time to time based on expansion plans for the improvement in quality of the journal system.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;You agree to display your name and photograph on the website of the site and journal cover.
</div>
<div class="middle_right_title_line">4. Termination</div>
<div class="middle_right_content_line">  
It is expected that you will complete the term as stated. This agreement may be terminated at any time based on following conditions.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Lack of mutual understanding on common aspects as per the policies of Science Publishing Group.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Repetitive unsatisfactory performance of the assigned work.
</div>
<div class="middle_right_content_line">
If you’d like to be the editorial member or reviewer, please apply for it through the following website: <br><a href="#" target="_blank" style="color: blue;">http://www.nigeriapb.com/login</a>
</div>                   
                      
                      
                    </div>

                </div>
            </div>
            <div class="clear"></div>
        </div>
    
<?php include '../../../includes/general/footer.php'; ?>