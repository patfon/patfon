<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>" ><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/publication/joineditorinchief.php"; ?>" ><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/publication/openaccess.php"; ?>"  style=" background-color:#FFFFFF;color:#111111;"><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
        <div class="middle_left" id="middle_left" style="height:900px;">
                <div class="middle_left_title">Resources</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/resources/openaccess.php'; ?>" >Open Access</a>
                    <a href="<?php echo $myurl.'pages/info/resources/authors.php'; ?>" id="rec" style="background:#2F5BA6;color:#FFFFFF;">For Authors</a>
                    <a href="<?php echo $myurl.'pages/info/resources/apc.php'; ?>">Article Processing Charges</a>
                </div>
        </div>

            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="#">Home</a>&nbsp;/&nbsp;<a href="#">Services</a>&nbsp;/&nbsp;<a href="#">Resources</a>&nbsp;/&nbsp;For Authors</div>

                <div id="vol">
                    <div class="economics">Resources for Authors</div>
                    <div class="line2"></div>

                    <div class="middle_right_content_line">
                        Science Publishing Group publishes all its journals in full open access format. The scientific community and the general public can unlimitedly and immediately access all content published in our journals for free as soon as it is published on the Internet. This means that Science Publishing Group does not have any income from selling subscriptions to print or online versions of its journals. Therefore, Science Publishing Group needs to defray its editorial and production costs by collecting article processing charges (APC) from authors' institutes or research funding bodies. Science Publishing Group is committed to keep its open access publication charges at a minimum level.
                    </div>

                    <div class="middle_right_content_line">
                        We believe that immediate, worldwide, barrier-free, open access to the full text of research articles is in the best interests of the scientific community.
                    </div>
                </div>
            </div>
            <div class="clear"></div>
</div>
    
<?php include '../../../includes/general/footer.php'; ?>