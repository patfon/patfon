<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>" ><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/publication/editorinchief.php"; ?>" ><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/publication/openaccess.php"; ?>"  style=" background-color:#FFFFFF;color:#111111;"><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
            <div class="middle_left" id="middle_left" style="height:900px;">
                <div class="middle_left_title">Resources</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/resources/openaccess.php'; ?>" style="background:#2F5BA6;color:#FFFFFF;">Open Access</a>
                    <a href="<?php echo $myurl.'pages/info/resources/authors.php'; ?>" id="rec">For Authors</a>
                    <a href="<?php echo $myurl.'pages/info/resources/apc.php'; ?>">Article Processing Charges</a>
                </div>
            </div>

            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="#">Home</a>&nbsp;/&nbsp;<a href="#">Services</a>&nbsp;/&nbsp;<a href="#">Resources</a>&nbsp;/&nbsp;Open Access</div>

                <div id="vol">
                    <div class="economics">Open Access</div>
                    <div class="line2"></div>

                    <div class="middle_right_if">
                        This page gives some introductory information about Open Access publishing; however, this information should not be considered as the final word on the topic.
                    </div>

                    <div class="middle_right_title_line">
                        1. What is Open Access?
                    </div>

                    <div class="middle_right_content_line">
                        • Open access (OA) is the practice of providing unrestricted access via the Internet to peer-reviewed scholarly journal articles. OA is also increasingly being provided to theses, scholarly monographs and book chapters. <br>
                        • By making information freely available in this way, Open Access accelerates research and learning. <br>
                        • By reducing the barriers that restrict access to knowledge, Open Access maximizes the opportunity for publications to be read and for authors to be recognized for their contribution in their chosen field and beyond.
                    </div>

                    <div class="middle_right_title_line">
                        2. Benefits of Open Access
                    </div>

                    <div class="middle_right_content_line">
                        • Open Access makes knowledge available to all, without the barrier of affordability and without restrictions on using it to inform and develop related areas of research. <br>
                        • Open Access enables unrestricted use of knowledge for teaching, conference presentations and lectures. <br>
                        • Open Access offers authors enhanced visibility and offers the potential for greater usage of their work and higher impact. <br>
                        • Open Access brings new audiences to scholarly content, helping expand readership. <br>
                        • Open access reduces the pressure on library budgets for purchasing books and journals and enables librarians to devote more time to connecting their users with high quality content.
                    </div>

                    <div class="middle_right_title_line">
                        3. SciencePG's Open Access Policy
                    </div>

                    <div class="middle_right_content_line">
                        Science Publishing Group is an independent international publisher of 110+ open access, peer-reviewed journals committed to disseminating the fruits of latest research to the global community as widely as possible. In keeping with that commitment, SciencePG offers the following policy: <br>

                        <div class="middle_right_content_line">
                            • All Journal content is freely and openly available after publication on the SciencePG’s website. <br>
                            • All articles are published in accordance with the Creative Commons Attribution (CC BY) license. Under this license, authors retain copyright. <br>
                            • All articles can be read, downloaded, copied, distributed, printed, searched, or linked to in SciencePG’s journal without asking prior permission from the publisher or the author.
                        </div>

                        <div class="middle_right_content_line">
                            The policy will apply to all scholarly articles published in SciencePG, except for any articles completed before the adoption of this policy and any articles for which the author entered into an incompatible licensing or assignment agreement before the adoption of this policy.
                        </div>
                    </div>

                    <div class="middle_right_title_line">
                        4. Open Access and Article Processing Charge
                    </div>

                    <div class="middle_right_content_line">
                        The internet allows us to distribute knowledge more widely, more efficiency and at a lower cost than was previously possible. However, publishing still has costs that need to be covered – such as proof reading, copyediting, digital presentation and preservation, promotion and dissemination of your work. <br>
                        With Open Access, authors (or their institutions or funders) pay an Article Processing Charge to cover these costs, ensuring their work is properly evaluated for quality and made easy to find, download and read.
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    
<?php include '../../../includes/general/footer.php'; ?>