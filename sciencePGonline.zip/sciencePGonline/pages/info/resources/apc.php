<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>" ><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/publication/joineditorinchief.php"; ?>" ><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/publication/openaccess.php"; ?>"  style=" background-color:#FFFFFF;color:#111111;"><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
        <div class="middle_left" id="middle_left" style="height:900px;">
                <div class="middle_left_title">Resources</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/resources/openaccess.php'; ?>" >Open Access</a>
                    <a href="<?php echo $myurl.'pages/info/resources/authors.php'; ?>" id="rec" >For Authors</a>
                    <a href="<?php echo $myurl.'pages/info/resources/apc.php'; ?>" style="background:#2F5BA6;color:#FFFFFF;">Article Processing Charges</a>
                </div>
        </div>

        <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="#">Home</a>&nbsp;/&nbsp;<a href="#">Services</a>&nbsp;/&nbsp;<a href="#">Resources</a>&nbsp;/&nbsp;Article Processing Charges</div>

                <div id="vol">
                    <div class="economics">Article Processing Charges</div>
                    <div class="line2"></div>

                    
                    
                     <div class="middle_right_title_line">
                    Article Processing Charges (APCs)
                    </div>
                    
<div class="middle_right_content_line">
Science Publishing Group is an independent international publisher of 200+ open access, online, peer-reviewed journals covering a wide range of academic disciplines. This is made possible by an article-processing charge (APC) that covers professional copy editing; for efficient and thorough peer review; for immediate publication quickly upon acceptance; for the article to be freely and for universally accessible in various formats online. 
</div>
<div class="middle_right_content_line">
The APC, payable when your manuscript is editorially accepted and before publication, is charged to either you, or your funder, institution or employer. The APC payable for an article is agreed as part of the manuscript submission process. 
</div>
<div class="middle_right_content_line">
The price of journals is based on the type of the journals. Different journals own different charges. For low-income countries, article-processing charge waivers or discounts are granted on a <b>case-by-case basis</b> to authors with insufficient funds. 
</div>
    <div class="middle_right_title_line">Why do Science Publishing Group journals have article processing charges?</div>

                <div class="middle_right_content_line">
                    Science Publishing Group publishes all its journals in full open access format. The scientific community and the general public can unlimitedly and immediately access all content published in our journals 

for free as soon as it is published on the Internet. This means that Science Publishing Group does not have any income from selling subscriptions to print or online versions of its journals. Therefore, Science Publishing 

Group needs to defray its editorial and production costs by collecting article processing charges (APC) from authors' institutes or research funding bodies. Science Publishing Group is committed to keep its open 

access publication charges at a minimum level.<p>We believe that immediate, worldwide, barrier-free, open access to the full text of research articles is in the best interests of the scientific community.</p>
                </div>

                <div class="middle_right_title_line">
                    Are reprints of my article included in the article processing charges (APC)? -<span style="color:#B60505;">No.</span>
                </div>

                <div class="middle_right_content_line">
                    Article processing charges (APC) do not entitle the authors to receive reprints of their published article. Reprints can be ordered separately and optionally for any article that has been published in a 

Science Publishing Group journal. To request an offer for reprints of an article, please send an e-mail to <a href="mailto:service@sciencepublishinggroup.com" style="color:#4583C0;">service@sciencepublishinggroup.com</a>
                </div>

                <div class="middle_right_title_line">How do I pay?</div>

                <div class="middle_right_content_line">
                    The submitting author needs to arrange payment of the article-processing charge unless a waiver has been granted. Following peer review, once a manuscript has received editorial acceptance in 

principle, the article-processing charge becomes payable and formatting checks on the manuscript will commence. Once formatting checks are completed, and payment of the article-processing charge has been 

received, the article will be published.
                    <p style="width:360px;">Science Publishing Group currently supports the following payment methods:
                        </p><p style="margin-left:10px;margin-top:2px;">
                            <img src="<?php echo $myurl.'images/black_dot.png' ?>" style="margin-right:10px;">Payment through PayPal<br>
                            <img src="<?php echo $myurl.'images/black_dot.png' ?>" style="margin-right:10px;">Pay with Debit or Credit Card<br>
                            <img src="<?php echo $myurl.'images/black_dot.png' ?>" style="margin-right:10px;">Wire Transfer in US Dollars (USD)<br>
                            <img src="<?php echo $myurl.'images/black_dot.png' ?>" style="margin-right:10px;">Western Union in US Dollars (USD)<br>
                            <img src="<?php echo $myurl.'images/black_dot.png' ?>" style="margin-right:10px;">MoneyGram in US Dollars (USD)
                            
                            
                        </p>
                        We recommend you use our online PayPal Secure Payment System.
                    <p></p>
                </div>

              
                      <div class="clear"></div>
                    
                    
                </div>
            </div>

            <div class="clear"></div>
</div>
    
<?php include '../../../includes/general/footer.php'; ?>