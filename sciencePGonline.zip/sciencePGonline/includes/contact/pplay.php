<div class="middle">


    
<div class="middle_right" id="middle_right">
           
<div class="middle_right_title">
<a href="" >Home</a>  /  <a href="<?php echo $myurl.'pages/journal/journallist.php'; ?>" >Journals</a>  /  <a href="#" > <?php echo getsubjectnameInJournal($pdb,$_GET['catid8']); ?></a>  /  <?php echo getjournalname($pdb,$_GET['catid8']); ?>
</div>
            <div class="ind">Publication Ethics Statement</div>
            <div class="pre_next_line"></div>

            <div class="inter">
                For all parties involved in the process of publishing (authors, Editorial Board, and reviewers), it is necessary to agree upon standards of expected ethical behavior. To guarantee high ethical standards, Science Publishing Group has developed international standards for all the parties. Science Publishing Group expects all the parties to commit to these standards.
            </div>

            <div class="online">International Standards for Authors:</div>

            <div class="only">
                Science Publishing Group does not require all authors of a research paper to sign a letter of submission, nor does it impose an order on the list of authors. All authors who submit to Science Publishing Group are supposed to observe the international standards for authors voluntarily.
            </div>

            <div class="only2">
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;Authors must certify that their manuscripts are their original work. Plagiarism, Duplicate, Data Fabrication and Falsification, and Redundant<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Publications are forbidden.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;Authors must certify that the manuscript has not previously been published and is not currently being considered for publication elsewhere.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;If the authors have used the work and/or words of others, the authors must ensure that the work and/or words of others are appropriately cited or<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;quoted and identify all sources used in the creation of their manuscripts.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;When an author discovers a significant error or inaccuracy in his/her own published work, it is the author's obligation to promptly notify the Journal<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;editor or publisher and cooperate with the editor to retract or correct the paper.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;Authors must notify Science Publishing Group of any conflicts of interest.
            </div>

            <div class="online">International Standards for Editorial Board:</div>

            <div class="only">Editors and Editorial Board are required to follow the international standards for Editorial Board:</div>

            <div class="only3">
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editorial Board must keep information pertaining to all submitted manuscripts &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;confidential.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editorial Board is responsible for making publication decisions for submitted<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;manuscripts.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editorial Board must strive to meet the needs of readers and authors.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editorial Board must evaluate manuscripts only for their intellectual content.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editorial Board must strive to constantly improve their journals.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editorial Board must maintain the integrity of the academic record.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editorial Board must disclose any conflicts of interest and preclude business needs from &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;compromising intellectual and ethical standards.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editorial Board must always be willing to publish corrections, clarifications, retractions &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;and apologies when needed.
            </div>

            <div class="online">International Standards for Reviewers:</div>

            <div class="only">
                Reviewers of Science Publishing Group are also expected to meet the international standards for reviewers when they accept review invitations.
            </div>

            <div class="only2">
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;Reviewers must keep information pertaining to the manuscript confidential.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;Reviewers must bring to the attention of the Editor Board any information that may be a reason to reject publication of a manuscript.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;Reviewers must evaluate manuscripts only for their intellectual content.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;Reviewers must objectively evaluate the manuscripts based only on their originality, significance and relevance to the domains of the journal.<br>
                <img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;&nbsp;Reviewers must notify Science Publishing Group of any conflicts of interest.
            </div>
        </div>
            <div class="clear"></div>
            <div class="clear"></div>
            <div class="clear"></div>
 </div>