<?php 
 session_start();
 $documentroot = "sciencepg";
 $GLOBALS['myurl'] = "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/";

?>
<!DOCTYPE html>
<html>
<head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Nigerian Publishing Group</title>

        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

        <link href="<?php echo $myurl.'images/littlelogo.gif'; ?> " rel="shortcut icon">

        <?php if ($_SERVER['REQUEST_URI'] !== '/sciencepg/register.php' && $_SERVER['REQUEST_URI'] !== '/sciencepg/login.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/common.css'; ?>">
        <?php } ?>
        
        <?php if ($_SERVER['REQUEST_URI'] === '/sciencepg/'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/home_body.css';?>">
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/slides.css';?>">
        <?php } ?>
        
        <?php if ($_SERVER['REQUEST_URI'] === '/sciencepg/index.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/home_body.css';?>">
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/slides.css';?>">
        <?php } ?>

        <?php if ($_SERVER['REQUEST_URI'] === '/sciencepg/newscontent.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/newsdetail.css';?>">
       
        <?php } ?>
        <?php if (preg_match('/newscontent=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/newsdetail.css';?>">
       
        <?php } ?>
       
        <?php if ($_SERVER['REQUEST_URI'] === '/sciencepg/pages/info/others/privacy.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/contactus.css';?>">
     
        <?php } ?>
        <?php if ($_SERVER['REQUEST_URI'] === '/sciencepg/pages/info/others/terms.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/contactus.css';?>">
     
        <?php } ?>
        <?php if (preg_match('/sciencepg\/pages\/info/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jservices.css';?>">
     
        <?php } ?>

        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/contactus.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/contactus.css';?>">
        <?php } ?>
        
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/news.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/news.css';?>">
        <?php } ?>

  <!-- Journal List of Home -->
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/journallist.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal_body.css';?>">
    
        <?php } ?>
        <?php if (preg_match('/catid=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal_body.css';?>">
       
        <?php } ?>
  <!-- Journal List of Category -->
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/journalbycat.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal3_body.css';?>">

        <?php } ?>
        <?php if (preg_match('/catid2=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal3_body.css';?>">
        <?php } ?>  
  <!-- Journal List of Archive -->
         <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/archive.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jarchive.css';?>">
      
        <?php } ?>
        <?php if (preg_match('/catid3=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jarchive.css';?>">
        
        <?php } ?> 
  <!-- Journal List of Editorial -->
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/editorial.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jeditorial.css';?>">
       
        <?php } ?>
        <?php if (preg_match('/catid4=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jeditorial.css';?>">
       
        <?php } ?>   
 <!-- Journal List of Reviewers -->
          <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/reviewers.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jeditorial.css';?>">
       
        <?php } ?>
        <?php if (preg_match('/catid5=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jeditorial.css';?>">
       
        <?php } ?> 
        
        <!-- Journal List of Guidelines -->
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/guidelines.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jguide.css';?>">
       
        <?php } ?>
        <?php if (preg_match('/catid6=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jguide.css';?>">
       
        <?php } ?> 

        <!-- Journal List of APC -->
          <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/apc.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/japc.css';?>">
       
        <?php } ?>
        <?php if (preg_match('/catid7=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/japc.css';?>">
       
        <?php } ?> 

          <!-- Journal List of Publication Ethics -->
          <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/ethics.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jethics.css';?>">
        
        <?php } ?>
        <?php if (preg_match('/catid8=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jethics.css';?>">
       
        <?php } ?> 

         <!-- Journal List of Copyright -->
         <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/copyright.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jcopyright.css';?>">
        
        <?php } ?>
        <?php if (preg_match('/catid9=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jcopyright.css';?>">
       
        <?php } ?> 

         <!-- Journal List of FAQ -->
         <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/faq.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jfaq.css';?>">
        
        <?php } ?>
        <?php if (preg_match('/catid10=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jfaq.css';?>">
       
        <?php } ?> 
  

        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/register.php' || $_SERVER['REQUEST_URI'] == '/sciencepg/login.php' ){ ?>
       
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/style.css';?>">
        <?php } ?>
      
       <!--   <meta name="google-site-verification" content="coJF3qkXwBNBu5idbbheQnYgIl4NuyKH4tXrilPQdu0"> -->
        <meta name="Keywords" content="Nigerian | scientific current events | academic journals | peer reviewed journals | peer reviewed journal articles">
        <meta name="description" content="EDIT">
        
      
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery-1.9.1.min.js'; ?>"></script>
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/faq.php'){ ?>
            <script type="text/javascript" src="<?php echo $myurl.'js/faq.js'; ?>"></script>
        
        <?php } ?>
        <?php if (preg_match('/catid10=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
            <script type="text/javascript" src="<?php echo $myurl.'js/faq.js'; ?>"></script>
       
        <?php } ?> 
        
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.cycle.all.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.placeholder.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/common.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.slides.min.js'; ?>"></script>
        <?php if ($_SERVER['REQUEST_URI'] !== '/sciencepg/register.php' || $_SERVER['REQUEST_URI'] !== '/sciencepg/login.php'){ ?>
       
        <script type="text/javascript" src="<?php echo $myurl.'js/register.js'; ?>"></script>
        <?php } ?>
       
    
        <script type="text/javascript">
          ///the login for article in home page
            function login(obj) {
                var username = $("#username").val();
                var password = $("#password").val();

                if (username == null || username == '') {
                    alert("please enter your username");
                    return false;
                }
                if (password == null || password == '') {
                    alert("please enter your password");
                    return false;
                }

                $("#form").submit();
            }

            function choiceModel(id) {
                    if (1 == id) {
                        $("#lat_tit1").css("background-color", "#FFFFFF");
                        $("#lat_tit1").css("color", "#333333");
                        $("#lat_tit2").css("background-color", "#4583C0");
                        $("#lat_tit2").css("color", "#FFFFFF");
                        $("#latestArticles").css("display", "block");
                        $("#aboutThisJournal").css("display", "none");
                    } else if (2 == id) {
                        $("#lat_tit1").css("background-color", "#4583C0");
                        $("#lat_tit1").css("color", "#FFFFFF");
                        $("#lat_tit2").css("background-color", "#FFFFFF");
                        $("#lat_tit2").css("color", "#333333");
                        $("#latestArticles").css("display", "none");
                        $("#aboutThisJournal").css("display", "block");
                    }
                }
           
        </script>
        <style>
            /* Prevents slides from flashing */
            #slides {
            display:none;
            }
        </style>

        <!-- The slide show in Home page-->
        <script type="text/javascript">
            $(function(){           
                $("#slides").slidesjs({
                    width: 918,
                    height: 240,
                    play: {
                    active: true,
                    auto: true,
                    interval: 8000,
                    swap: true
                    }
                  
                });
             
            });
        </script>
<!-- Testimonials slideshow -->
        <script type="text/javascript">
            window.setInterval("autoPlayJournalList()", 10000);

            $(function(){
                $('#testimonials').cycle({ 
                    fx: 'scrollHorz',
                    speed:    500,
                    timeout:  12000,
                    startingSlide: 0,
                    next: '.right_btn',
                    prev: '.left_btn'
                });
            })
        </script>
        <!-- end Testimonials slideshow -->
        <!-- -->
        <script type="text/javascript">
                $("#secondAdvGif").css("display", "block");
                $('#advGif').cycle({ 
                    fx: 'scrollHorz',
                    speed:    800,
                    timeout:  8000,
                    startingSlide: 0
                });
        </script>
    </head>

<body>