<div class="middle_container12">
                <div class="left">
                    <div>Testimonials</div>
                    <div style="margin-top:10px;"><img src="images/testinonials_img.png"></div>
                </div>

                <div class="right" id="testimonials" style="position: relative; width: 1068px; height: 119px; overflow: hidden;">
                   
                   <?php $test = gettestimonials($pdb);  
                   foreach ($test as $t){
                   ?>
                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1;">
                        <span style="font-size:14px;font-weight:bold;"><?php echo $t['_name']; ?></span>
                        <p style="margin-top:5px;">
                        <?php echo $t['_content']; ?>
                         </p>
                    </div>
                   <?php } ?>
                    
                </div>

                <div class="clear"></div>
                <a href="javascript:void(0);"><div class="right_btn"><img src="images/right_arrow.png"></div></a>
                <a href="javascript:void(0);"><div class="left_btn"><img src="images/left_arrow.png"></div></a>
            </div>