<div id="slides" class="s_lb">
        <?php $slides = getslides($pdb); 
        foreach ($slides as $s){
        ?>

                    <img src="<?php echo $myurl.'/superadmin/'.$s['_url']; ?>">
        <?php } ?>   
                       
                        
</div>