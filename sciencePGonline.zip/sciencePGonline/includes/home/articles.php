<div class="latest_articles_title" >Latest Articles</div>

<div class="artilces_pic_fw">
    
        
            <div class="artilces_pic_bg" style="margin-left:-2px;">
                <div class="art_img">
                    
                    
                     
                        <a href="/journal/paperinfo?journalid=354&amp;doi=10.11648/j.jmpt.20180401.11">
                     
                      
                    
                        <!--<img src="http://article.sciencepublishinggroup.com/journal/354/3540994/3540994_10_01_20180225.jpg"/> -->
                        <img src="http://article.sciencepublishinggroup.com/journal/354/3540994/3540994_10_01_20180225.jpg">
                    </a>
                </div>
                
                <div class="art_title">
                    
                    
                        
                       <a href="/journal/paperinfo?journalid=354&amp;doi=10.11648/j.jmpt.20180401.11">
                    
                    
                   
                    
                         
                         Third - Order Nonlinear Optical Properties and Optical Limiting Behavior of Celestin Blue B Dye Doped Polymer Films
                    </a>
                </div>
                <div class="art_p_d">
                    <div class="art_p">
                        
                             <i>I. A. H. A. Al-Saidi et al.</i>
                        
                        
                    </div>
                    <div class="art_d"><i>Feb. 23, 2018</i></div>
                    <div class="clear"></div>
                </div>
            </div>
        
        
        
    
        
        
            <div class="artilces_pic_bg">
                <div class="art_img">
                    
                    
                     
                        <a href="/journal/paperinfo?journalid=248&amp;doi=10.11648/j.ajmie.20180301.11">
                     
                     
                    
                        <!--<img src="http://article.sciencepublishinggroup.com/journal/248/2481089/2481089_10_01_20180225.jpg"/> -->
                        <img src="http://article.sciencepublishinggroup.com/journal/248/2481089/2481089_10_01_20180225.jpg">
                    </a>
                </div>
                
                <div class="art_title">
                    
                    
                     
                      <a href="/journal/paperinfo?journalid=248&amp;doi=10.11648/j.ajmie.20180301.11">
                     
                     
                    
                         
                         Optimizing Centrifugal Pump Performance by Different Blade Configuration Patterns
                    </a>
                </div>
                <div class="art_p_d">
                    <div class="art_p">
                        
                             <i>D. M. S. El-Gazzar et al.</i>
                        
                        
                    </div>
                    <div class="art_d"><i>Feb. 23, 2018</i></div>
                    <div class="clear"></div>
                </div>
            </div>
        
        
    
        
        
        
            <div class="artilces_pic_bg">
                <div class="art_img">
                    
                   
                        
                        <a href="/journal/paperinfo?journalid=247&amp;doi=10.11648/j.mcs.20180301.13">
                      
                      
                   
                        <!--<img src="http://article.sciencepublishinggroup.com/journal/220/2201123/2201123_10_01_20180225.jpg"/> -->
                        <img src="http://article.sciencepublishinggroup.com/journal/220/2201123/2201123_10_01_20180225.jpg">
                    </a>
                </div>
                
                <div class="art_title">
                    
                    
                     
                        <a href="/journal/paperinfo?journalid=247&amp;doi=10.11648/j.mcs.20180301.13">
                    
                    
                    
                    
                    
                    
                         
                         Handling and Stability Analysis of Vehicle Plane Motion
                    </a>
                </div>
                <div class="art_p_d">
                    <div class="art_p">
                        
                             <i>V. V. Grigorievich et al.</i>
                        
                        
                    </div>
                    <div class="art_d"><i>Feb. 23, 2018</i></div>
                    <div class="clear"></div>
                </div>
            </div>
        
    
    <div class="clear"></div>
</div>

<!-- Continue to List the Items-->
<div class="art2_fw">
                        <div style="height:10px;"></div>
                        
                            
                            
                                <div class="art2_item" style="margin-top:0;">
                            
                            
                                
                                <div class="art2_p"></div>

                                <div class="art2_t">
                                    
                                    
                                        <span class="art2_p_s"><i>Vito Zepinic: </i></span>
                                    

                                    
                                    
                                       
                                         <a href="/journal/paperinfo?journalid=201&amp;doi=10.11648/j.pbs.20180701.12">
                                      
                                      
                                      
                                    
                                         
                                         Healing Traumatic Memories in Complex PTSD
                                    </a>
                                </div>
                                <div class="art2_d"><i>Mar. 5, 2018</i></div>
                                <div class="clear"></div> 
                            </div>
                            
                        
                            
                            
                            
                                <div class="art2_item">
                            
                                
                                <div class="art2_p"></div>

                                <div class="art2_t">
                                    
                                    
                                        <span class="art2_p_s"><i>Fan Jiang: </i></span>
                                    

                                    
                                    
                                       
                                         <a href="/journal/paperinfo?journalid=173&amp;doi=10.11648/j.ijefm.20180601.14">
                                      
                                      
                                      
                                    
                                         
                                         Analysis and Research on Current Juvenile Delinquency
                                    </a>
                                </div>
                                <div class="art2_d"><i>Mar. 5, 2018</i></div>
                                <div class="clear"></div> 
                            </div>
                            
                        
                            
                            
                            
                                <div class="art2_item">
                            
                                
                                <div class="art2_p"></div>

                                <div class="art2_t">
                                    
                                    
                                        <span class="art2_p_s"><i>Osama Ahmed Marzouk: </i></span>
                                    

                                    
                                    
                                       
                                         <a href="/journal/paperinfo?journalid=122&amp;doi=10.11648/j.ajmp.20180702.14">
                                      
                                      
                                      
                                    
                                         
                                         Multi-Physics Mathematical Model of Weakly-Ionized Plasma Flows
                                    </a>
                                </div>
                                <div class="art2_d"><i>Mar. 5, 2018</i></div>
                                <div class="clear"></div> 
                            </div>
                            
                        
                            
                            
                            
                                <div class="art2_item">
                            
                                
                                <div class="art2_p"></div>

                                <div class="art2_t">
                                    
                                        <span class="art2_p_s"><i>Liu Chenming et al.: </i></span>
                                    
                                    

                                    
                                    
                                       
                                         <a href="/journal/paperinfo?journalid=161&amp;doi=10.11648/j.earth.20180702.13">
                                      
                                      
                                      
                                    
                                         
                                         Research on Paleogeography Recovery of "Impact Point" Based on �Collisions Aggregation Effect�
                                    </a>
                                </div>
                                <div class="art2_d"><i>Mar. 5, 2018</i></div>
                                <div class="clear"></div> 
                            </div>
                            
                        
                            
                            
                            
                                <div class="art2_item">
                            
                                
                                <div class="art2_p"></div>

                                <div class="art2_t">
                                    
                                    
                                        <span class="art2_p_s"><i>Ahmed Raza: </i></span>
                                    

                                    
                                    
                                       
                                         <a href="/journal/paperinfo?journalid=148&amp;doi=10.11648/j.ajam.20180601.12">
                                      
                                      
                                      
                                    
                                         
                                         Mathematical Model of Corrective Maintenance Based on Operability Checks for Safety Critical Systems
                                    </a>
                                </div>
                                <div class="art2_d"><i>Mar. 5, 2018</i></div>
                                <div class="clear"></div> 
                            </div>
                            
                        
                            
                            
                            
                                <div class="art2_item">
                            
                                
                                <div class="art2_p"></div>

                                <div class="art2_t">
                                    
                                        <span class="art2_p_s"><i>Trinh Thi Thu Van et al.: </i></span>
                                    
                                    

                                    
                                    
                                       
                                         <a href="/journal/paperinfo?journalid=162&amp;doi=10.11648/j.ijema.20180601.11">
                                      
                                      
                                      
                                    
                                         
                                         Predicting the Capacity of Receiving Wastewater of Thuong River in Vietnam and Propose ...
                                    </a>
                                </div>
                                <div class="art2_d"><i>Mar. 5, 2018</i></div>
                                <div class="clear"></div> 
                            </div>
                            
                    </div>