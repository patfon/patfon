<div class="middle_left" id="middle_left" style="height: 800px;">
                
               
</div>
<div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="/home/index">Home</a>&nbsp;/&nbsp;SciencePG News</div>
                <div id="vol">
                    <div class="economics">Nigeria PG News</div>
                    <div class="line2"></div>
                    
                   
                        <?php $news = getnews($pdb); 
                        foreach ($news as $n){
                        ?>

	                   <a href="<?php echo $myurl.'newscontent.php?newscontent='.$n['id']; ?>">
                       <div class="middle_right_con"><img src="<?php echo $myurl.'images/black_dot.png'; ?>">&nbsp;&nbsp;&nbsp;
                       <?php echo $n['_title']; ?>
                       </div></a>
	                   <div class="middle_right_time"><?php echo $n['_datesub'];  ?></div>
	                   <div class="clear"></div>

                        <?php } ?>
	                  
                     </div>
            </div>

            <div class="clear"></div>