<div class="middle_left" id="middle_left" style="height: 800px;">
                
               
</div>
<div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="/home/index">Home</a>&nbsp;/&nbsp;News</div>
                <div id="vol">
                  
                <?php echo html_entity_decode(getnewscontent($pdb, $_GET['newscontent'])); ?>
                    
                </div>
            </div>