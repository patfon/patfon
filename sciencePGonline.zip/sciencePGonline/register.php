<?php  include 'includes/general/header.php';  //c.t. studd ?>
<?php include 'classes/connection.php'; ?>
<?php include 'functions/index.php'; ?>
<?php 
include "lib/simple-php-captcha/simple-php-captcha.php";
$_SESSION['captcha'] = simple_php_captcha();
?>

<div id="header">
		<!-- logo -->
		<div id="logo">
			<h1>
 			<a href="#" target="_blank">
			<font color="white" size="8">SciencePG Nigeria</font> </a>
			</h1>
		</div>
		<ul id="user">
		</ul>
		<div id="header-inner">
			<div class="corner tl"></div>
			<div class="corner tr"></div>
		</div>
</div>

<div id="content">
<div id="right">
			<div id="box-tabs" class="box ui-tabs ui-widget ui-widget-content ui-corner-all" style="display: none;">
					<!-- box / title -->
					<div class="title">
						<h5>Message</h5>
					</div>
					<!-- box / title -->
					
					<div id="box-messages" class="ui-tabs-panel ui-widget-content ui-corner-bottom">
						<div class="messages">
							<div id="message-warning" class="message message-warning">
								<div class="image">
									<img src="" alt="Warning" height="32">
								</div>
								<div class="text">
									<h6>Warning Message</h6>
									<span style="color:red;line-height: 10px;" id="waringMsg2"></span>
									<span style="color:red;line-height: 20px;" id="waringMsg"></span>
									<span style="color:red;line-height: 10px;" id="waringMsg3"></span>
								</div>
								<div class="dismiss">
								
								</div>
							</div>
						</div>
					</div>
			</div>


			<!-- forms -->
			<div class="box">
				<!-- box / title -->
				<div class="title">
					<h5>Create an account</h5>
				</div>
            <?php if (isset($_SESSION['captcha_fail'])) { ?>
				<div id="message-warning" class="message message-error">
								
								<div class="text">
									<h6>Warning Message</h6>
									<span style="color:red;line-height: 10px;" id="waringMsg2"> Your capcha text is wrong.  </span>
								
								</div>
                </div>
			<?php } 
			unset($_SESSION['captcha_fail']);
			?>
				<!-- end box / title -->
				<form id="form1" name="register" action="<?php echo $myurl.'controller/user/index.php'; ?>" method="post">
					<div class="form">
						<input type="hidden" name="jregister" value="200">
						<div class="fields">
							<div class="field  field-first">
								<div class="label">
									<label for="input-small">Username:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
								<span style="color:red;line-height: 20px;" id="usernameFlag"></span>
								
								<input type="text" name="uname" value="" id="signUpInfologinName" class="small" maxlength="60">
	       						</div>
	       						<div class="input">
                                    <input type="text" style="border: none;color:red;" value="You can use your email address as your username." class="large" disabled="disabled">
                                </div>
	       						
							</div>
							<div class="field">
								<div class="label">
									<label for="input-small">Password:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
									<input type="password" id="signUpInfoplainPassword" name="pass1" value="" class="small" maxlength="30">
								</div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-small">Re-enter Password:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
									<input type="password" id="rePassword" name="pass2" value="" class="small" maxlength="30">
								</div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-small">First Name:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
									<input type="text" id="personInfofirstName" value="" name="fname" class="small" maxlength="60">
								</div>
								<div class="input">
                                    <input type="text" style="border: none;color:red;" value="Capitalize the first letter of each word without using acronyms." class="large" disabled="disabled">
                                </div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-small">Last Name:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
									<input type="text" id="personInfolastName" value="" maxlength="60" name="lname" class="small">
								</div>
								<div class="input">
                                    <input type="text" style="border: none;color:red;" value="Capitalize the first letter of each word without using acronyms." class="large" disabled="disabled">
                                </div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-medium">Email:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
									<input type="text" id="personInfoemail1" name="email1" value="" class="medium" maxlength="120">
								</div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-medium">Secondary Email:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
									<input type="text" id="personInfoemail2" name="email2" value="" class="medium" maxlength="120">
								</div>
		                <div class="input">
								    <input type="text" style="border: none;color:red;" value="For the sake of timely communication, please offer two of your own email addresses." class="large" disabled="disabled">
                                    <input type="text" style="border: none;color:red;" value="If you have only one email address, you can make the second email address same to the first one." class="large" disabled="disabled">
								</div>							
					
								
								
							</div>
							<div class="field">
								<div class="label">
									<label for="input-large">Mobile Phone:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input" style=" padding-right: 10px;">
                                    <?php include 'includes/register/areacode.php'; ?>
								</div>
								<div class="input">
									<input type="text" value="+" class="small" style="width: 10px;border: none;" disabled="disabled">
							   </div>
								<div class="input">
									<input type="text" id="personInfotelephone1" name="tel" value="" class="small" maxlength="30">
							   </div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-large">Affiliation:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
									<input type="text" id="personInfoAffiliation" name="uni" value="" maxlength="500" class="large" placeholder="For example: Department of Chemistry, Columbia University">
								</div>
								<div class="input">
								<div style="clear: both;"></div>
								    <span type="text" style="border: none;color:red;display: block;margin-top: 5px;text-indent: 6px;" class="large">The affiliation should only include: Department, University/Institute. Such as: Department of Chemistry, Columbia University</span>
                                    <input type="text" style="border: none;color:red;" value="Please only capitalize the first letter of each notional word. Do not use acronyms in the affiliation." class="large" disabled="disabled">
								</div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-large">City:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="input">
									<input type="text" id="personInfoCity" name="city" value="" maxlength="100" class="large">
								</div>
								<div class="input">
								    <input type="text" style="border: none;color:red;" value="Capitalize the first letter of each word without using acronyms." class="large" disabled="disabled">
								</div>
							</div>
						 	<div class="field">
							     <div class="label">
                                    <label for="input-large">State/Province:<strong style="font-size: 14px;color: red;">*</strong></label>
                                </div>
                                <div class="input">
                                    <input type="text" id="personInfoStateOrProvince" name="statex" value="" maxlength="100" class="large">
                                </div>
                                <div class="input">
                                    <input type="text" style="border: none;color:red;" value="Capitalize the first letter of each word without using acronyms." class="large" disabled="disabled">
                                </div>
							</div>
							<div class="field">
								<div class="label">
									<label for="select">Country/Region:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="select">
                                <?php include 'includes/register/country.php' ?>
								</div>
							</div>
							
							<div class="field">
								<div class="label label-checkbox">
									<label>Areas:<strong style="font-size: 14px;color: red;">*</strong></label>
								</div>
								<div class="checkboxes">
									<table id="pricetable" cellpadding="0" cellspacing="0" style="width:100%; line-height: 15px;margin-top:0px;padding:0px;  margin: 1em 0;border-collapse: collapse;font-size: 12px;color: #333333;"> 
						<tbody align="left">
						<?php  $mysub = getsubjects($pdb);  
						if (!empty($mysub)){
							foreach ($mysub as $sub){
						?>
						<tr> 
						<td> <input type="checkbox" name="research[]" value="<?php echo $sub['id']; ?>"> </td><td> <?php echo $sub['_name']; ?> </td>
						</tr>
						<?php } } ?>
						</tbody>
                                    </table>
                                </div>
							</div>
							
							
							
							
							
				       <div class="field">
			           	     <div class="label">
									<label for="input-large">Type the Code:<strong style="font-size: 14px;color: red;">*</strong></label>
							 </div>
								<div class="input">
                                <?php echo '<img src="' . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA code">';?>
                                <input type="text" id="" name="captcha" required="required" value="" size="30"  class="textField editor_field">
								</div>
					   </div>
					
					<div class="fields">
         			   <div class="buttons">
						<div class="highlight">
						 <input type="button" id="createacctbut" name="jregister" style="cursor: pointer;" value="Create My Account"  class="ui-button ui-state-default ui-corner-all">
		 		  	       <input type="reset" name="reset" value="Reset" style="cursor: pointer;" class="ui-button ui-widget ui-state-default ui-corner-all" role="button" aria-disabled="false">
						   <input style="cursor: pointer;" type="button" name="Button_Return" value="Return" id="Button_Return" onclick="window.location.href='index.php'" class="ui-button ui-widget ui-state-default ui-corner-all" role="button" aria-disabled="false">
						</div>
								</div>
							</div>
						</div>
					</div>
				</form>



			</div>
			<!-- end forms -->
		</div>
</div>
      
    
</div>
  


  </body>
  </html>