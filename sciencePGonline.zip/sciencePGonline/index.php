<?php include 'includes/general/header.php'; ?>
<?php include 'classes/connection.php'; ?>
<?php include 'functions/index.php'; ?>

    <?php include 'includes/general/topmenu.php'; ?>

        <div class="middle">
       
            <div class="m_top" style="margin-left: 10px;"><a>
                </a>
                <?php if (isset($_SESSION['success_reg'])) { ?>
				<div id="message" class="message message-success">
								
								<div class="text">
									<h6>Congrats!</h6>
									<span style="color:red;line-height: 10px;" > You have successfully registered.  </span>
								
								</div>
                </div>
                <?php } 
                unset($_SESSION['success_reg']);
                ?>
                
                <?php include 'includes/home/left_side.php'; ?>

                <div class="m_top_right">
                   
                    <?php include 'includes/home/slides.php'; ?>

                    <div class="clear"></div>
                   
                    <div class="middle_sci_text">
					<div class="latest_articles_title">Our Publishing System</div><hr>
					Science Publishing Group is an independent academic publisher with an editorial team comprising many of the world's leading researchers. Science Publishing Group provides journal publishing service, Special Issue publishing service, book publishing service and conference paper publishing service.
                    <hr>
                    </div>
                    
                    <div class="middle_container9" style="width:437px;height:300px;">
                        <div class="middle_about">About us</div>
                    
                        <div class="middle_sci2" style="width:375px;height:auto;">
                        <?php echo getpagecontent($pdb,'about_story'); ?>
                        </div>
                    </div>

                    <div class="middle_container9" style="width:435px;height:300px;">
                        <div class="middle_about">Our Mission</div>
                        
                        <div class="middle_sci2" style="width:375px;height:auto;">
                        <?php echo getpagecontent($pdb,'about_mission'); ?>
                        </div>
                    </div>
                   
                </div>
                <div class="clear"></div>
            </div>

         

            <div class="img_bg"></div>

          

            
        </div>
      
    
<?php include 'includes/general/footer.php'; ?>
