function img_over(id){
    $("#hidden_" + id).css("display","block");
}
function img_out(id){
    $("#hidden_" + id).css("display","none");
}

function autoPlayJournalList() {
    var firstPlace = $("#first_place_num").val();
    var lastPlace = $("#last_place_num").val();
    var firstPlaceNum = parseInt(firstPlace);
    var lastPlaceNum = parseInt(lastPlace);
    var nextPlaceNum = firstPlaceNum + 6;
    if (firstPlaceNum < 12) {
        $("#j_list_item_" + firstPlaceNum).css("display", "none");
        $("#j_list_item_" + nextPlaceNum).css("display", "block");
    } else {
        nextPlaceNum = nextPlaceNum - 18;
        $("#j_list_item_" + firstPlaceNum).css("display", "none");
        $("#j_list_item_" + nextPlaceNum).css("display", "block");
    }

    removeElement($("#j_list_item_" + firstPlaceNum));
    document.getElementById("journalsListItems").appendChild(document.getElementById("j_list_item_" + firstPlaceNum));

    if (firstPlaceNum < 17) {
        $("#first_place_num").val((firstPlaceNum + 1));
    } else {
        $("#first_place_num").val(0);
    }
    $("#six_place_num").val(nextPlaceNum);
    $("#last_place_num").val(firstPlaceNum);
}

function showNextJournals() {
    autoPlayJournalList();
    autoPlayJournalList();
    autoPlayJournalList();
    autoPlayJournalList();
    autoPlayJournalList();
    autoPlayJournalList();
}

function showPreJournalsItem() {
    var firstPlace = $("#first_place_num").val();
    var sixPlace = $("#six_place_num").val();
    var lastPlace = $("#last_place_num").val();
    var firstPlaceNum = parseInt(firstPlace);
    var sixPlaceNum = parseInt(sixPlace);
    var lastPlaceNum = parseInt(lastPlace);

    removeElement($("#j_list_item_" + lastPlaceNum));
    document.getElementById("journalsListItems").insertBefore(document.getElementById("j_list_item_" + lastPlaceNum), document.getElementById("j_list_item_" + firstPlaceNum));
    $("#j_list_item_" + sixPlaceNum).css("display", "none");
    $("#j_list_item_" + lastPlaceNum).css("display", "block");

    $("#first_place_num").val(lastPlaceNum);
    if (lastPlaceNum == 0) {
        $("#last_place_num").val(17);
    } else {
        $("#last_place_num").val(lastPlaceNum - 1);
    }
    if (sixPlaceNum == 0) {
        $("#six_place_num").val(17);
    } else {
        $("#six_place_num").val(sixPlaceNum - 1);
    }
}

function showPreJournals() {
    showPreJournalsItem();
    showPreJournalsItem();
    showPreJournalsItem();
    showPreJournalsItem();
    showPreJournalsItem();
    showPreJournalsItem();
}

function removeElement(_element){
    var _parentElement = _element.parentNode;
    if(_parentElement){
        _parentElement.removeChild(_element);
    }
}

$(function(){
    $("#hidden1,#hidden2,#hidden3,#hidden4,#hidden5").css("display","none");
    $('#cycle').cycle({ 
        fx: 'scrollHorz',
        speed:    600,
        timeout:  5500,
        startingSlide: 0,
        next: '.cycle_right',
        prev: '.cycle_left'
    });
})