
<?php

include "includes/header.php";?>

    <!--Side menu ends here-->
	
	<!--main content starts here-->
<?php include "pages/income/add_income.php";?>
	<!--main content ends  here-->
	
    
<?php include "includes/footer.php";?>