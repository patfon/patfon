﻿<?php include "includes/header.php";?>
    <!--Side menu ends here-->
	
	<!--main content starts here-->
        <div id="page-content-wrapper" >
            <div class="container-fluid">
             
            </div>
        </div>
		<!--main content ends  here-->
		
    </div>
    <?php include "includes/footer.php";?>