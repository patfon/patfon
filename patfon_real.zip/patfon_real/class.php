﻿<?php include "includes/header.php";?>
    <!--Side menu ends here-->
	
	<!--main content starts here-->
        <div id="page-content-wrapper" >
            <div class="container-fluid">
             
			 
			<br >
			
			 <div class="col-lg-3 col-xs-6 bg-dark" >
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-reorder " ></i> &nbsp; <a href="#" class="small-box-footer " ><b>Manage Arm </b><i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-eye"></i> &nbsp; <a href="#" class="small-box-footer"><b>View Class </b><i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
				<br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center center-block">
            <i class="fa fa-money"></i> &nbsp; <a href="#" class="small-box-footer"><b>Set Class Fee </b><i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
		<br>
		<style>
				.bg{background-color:#0b7285;}
				.fa-group{color:white;}
				 #colo a {color:white;font-weight:bolder;}
				 .bg-dark{
				 background-color:#e3e9ee;padding:5px;border-radius:6px;}
				 .fa-user-times{color:red}
			 .fa-reorder{color:orange}
			  .fa-money{color:green}
			  .fa-plus{color:green}
			  .fa-id-badge{color:orange;}
			.fa-eye{color:darkcyan;}
				 </style>		 
			 
			 
            </div>
        </div>
		<!--main content ends  here-->
    </div>
    <?php include "includes/footer.php";?>