<?php 
$firstterm = array(9,10,11,12);//months of 1st term
$secondterm = array(1,2,3,4);
$thirdterm = array(5,6,7,8);

function getsource($con){

  $query = ("SELECT id, name FROM source");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error());
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[$r['id']] = $r['name'];
      }
   }
  
   return $src;
  
  }

  function getclassname($con,$id){

    $query = ("SELECT name FROM class_ WHERE id = $id ");
    $src = "";
    $result = mysqli_query($con,$query) or die(mysqli_error());
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src = $r['name'];
        }
     }
    
     return $src;
    
    }

    function getclasscategory($con,$id){

      $query = ("SELECT category FROM class_ WHERE id = $id ");
      $src = "";
      $result = mysqli_query($con,$query) or die(mysqli_error());
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src = $r['category'];
          }
       }
      
       return $src;
      
      }



      function getclassfee($con,$id,$sch){

        $query = ("SELECT fee FROM class_fees WHERE category = $id and school = $sch");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error());
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src = $r['fee'];
            }
         }
        
         return $src;
        
        } 

        function getclassarm($con,$id){

          $query = (" SELECT name FROM arm WHERE id = $id ");
          $src = "";
          $result = mysqli_query($con,$query) or die(mysqli_error());
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src = $r['name'];
              }
           }
          
           return $src;
          
          } 

    function getusername($con,$id){

      $query = ("SELECT name FROM users WHERE id = $id ");
      $src = "";
      $result = mysqli_query($con,$query) or die(mysqli_error());
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src = $r['name'];
          }
       }
      
       return $src;
      
      }

      function getuserfeecollect($con,$id,$term,$year){

        $query = ("SELECT name FROM users WHERE id IN (SELECT user_collect FROM student_fees WHERE stu_id = $id AND year_ = '$year' AND term = $term) ");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error());
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src = $r['name'];
            }
         }
        
         return $src;
        
        }

        function getstudentpaid($con,$id,$term,$year){

          $query = (" SELECT amount FROM student_fees WHERE stu_id = $id AND year_ = '$year' AND term = $term ");
          $src = "";
          $result = mysqli_query($con,$query) or die(mysqli_error());
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src = $r['amount'];
              }
           }
          
           return $src;
          
          }

          function getstudentdatepaid($con,$id,$term,$year){

            $query = (" SELECT date_pay FROM student_fees WHERE stu_id = $id AND year_ = '$year' AND term = $term ");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error());
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['date_pay'];
                }
             }
            
             return $src;
            
            }

function getstudents($con){

    $query = ("SELECT * FROM student");
    $src = array();
    $result = mysqli_query($con,$query) or die(mysqli_error());
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src[] = $r;
        }
     }
    
     return $src;
    
}  

function getstudentname($con,$id){

  $query = ("SELECT CONCAT(fname,' ',lname) as fn FROM student WHERE id = $id ");
  $src = "";
  $result = mysqli_query($con,$query) or die(mysqli_error());
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src = $r['fn'];
      }
   }
  
   return $src;
  
  }



  function getstudentclass($con,$id){

    $query = ("SELECT name,arm FROM class_ WHERE id IN (SELECT class_ FROM student WHERE id = $id) ");
    $src = "";
    $result = mysqli_query($con,$query) or die(mysqli_error());
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src = $r['name'].";".$r['arm'];
        }
     }

     $srcx = explode(";",$src);
     $armname = getclassarm($con, intval($srcx[1]) );
     $final = $srcx[0]." ".$armname;

     return $final;
    
    }


function getschools($con){

$query = ("SELECT name,id FROM school");
$skools = array();
$result = mysqli_query($con,$query) or die(mysqli_error());
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $skools[$r['id']] = $r['name'];
    }
 }

 return $skools;

}

function getschoolname($con,$id){

$query = ("SELECT name FROM school WHERE id = $id ");
$skools = "";
$result = mysqli_query($con,$query) or die(mysqli_error());
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $skools = $r['name'];
    }
 }

 return $skools;

}

function getdistinctdates_income($con,$month,$year,$sch) {
  $query = ("SELECT DISTINCT date_pay FROM income WHERE mnt = $month AND date_pay LIKE '%$year%' AND school = $sch ORDER BY date_pay ");
$dates = array();
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $dates[] = $r['date_pay'];
    }
 }
 return $dates;

}

function getdistinctdates_expend($con,$month,$year,$sch) {
  $query = ("SELECT DISTINCT date_ FROM expenditure_ WHERE month_ = $month AND date_ LIKE '%$year%' AND sch_id = $sch ORDER BY date_ ");
$dates = array();
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $dates[] = $r['date_'];
    }
 }
 return $dates;

}

function getincomefee($con,$type,$month,$datex,$sch) {
$query = ("SELECT amount FROM income WHERE source = $type AND date_pay LIKE '%$datex%' AND mnt = $month AND school = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['amount'];
    }
 }
 return $fees;

}

function getincomefeeyear($con,$datex,$sch) {
  $query = ("SELECT SUM(amount) AS amt_ FROM income WHERE date_pay LIKE '%$datex%' AND school = $sch ");
  $fees = "";
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $fees = $r['amt_'];
      }
   }
   return $fees;
  
  }

function getexpendfee($con,$type,$month,$datex,$sch) {
$query = ("SELECT amount_ FROM expenditure_ WHERE category = $type AND date_ = '$datex' AND month_ = $month AND sch_id = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['amount_'];
    }
 }
 return $fees;

}

function getincomesum($con,$type,$month,$datex,$sch) {
$query = ("SELECT SUM(amount) as myamt FROM income WHERE source = $type AND date_pay LIKE '%$datex%' AND mnt = $month AND school = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['myamt'];
    }
 }
 return $fees;

}

function getexpendsum($con,$type,$month,$datex,$sch) {
$query = ("SELECT SUM(amount_) as myamt FROM expenditure_ WHERE sub_cat = $type AND date_ LIKE '%$datex%' AND month_ = $month AND sch_id = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['myamt'];
    }
 }
 return $fees;

}




?>