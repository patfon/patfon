<?php include "includes/header.php";?>
    <!--Side menu ends here-->
	
	<!--main content starts here-->
<?php include "pages/student/delete_stu_form.php";?>
	<!--main content ends  here-->
	
    
<?php include "includes/footer.php";?>