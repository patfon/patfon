<?php include "functions/index.php";?>
<?php 
  if (isset($_GET['page']))
  {
  $_SESSION['income_month'] = $_GET['month'];
  $_SESSION['income_sch'] = $_GET['sch'];  
  $_SESSION['income_year'] = $_GET['year'];
  $_SESSION['cur-page'] = "Income > Monthly Summary Report";
  }

  $month = array("1"=>"January","2"=>"February","3"=>"March","4"=>"April","5"=>"May","6"=>"June", 
  "7"=>"July","8"=>"August","9"=>"September","10"=>"October","11"=>"November","12"=>"December"
  );
  $dates_diff = getdistinctdates_income($pdb,$_SESSION['income_month'],$_SESSION['income_year'], $_SESSION['income_sch']);
  if (!empty($dates_diff)) { ?>

  <!-- 
        ================================================== 
            Patfon Daily Income List
        ================================================== -->
        <section id="daily-section">
            <div class="container">
                 <div class="row">
                    <div class="col-md-8">
                        <div ><a class="btn btn-block btn-success" href="index.php">Go back to Report Page</a></div>
                    </div>
                 </div>
                <div class="row">
                    <div class="col-md-8">
                        <div>
                        <h4 class="center-block col-xs-offset-4"><?php echo getschoolname($pdb,$_SESSION['income_sch']); ?></h4>
                        <p>Income Summary For the Month of <?php echo $month[$_SESSION['income_month']] ?> </p>
                        <table id="inc_table" class="table table-bordered table-responsive table-striped">
                        <thead>
                        <tr>
                        <th>Date</th><th>Fees</th> <th>Old Debts</th> <th>Bus</th><th>Uniform</th><th>Sport Wear</th>
                        <th>Pullover</th> <th>Car</th> <th>Total</th>
                        </tr>
                        
                        </thead>
                        <tbody>
                        <?php foreach ($dates_diff as $dd) { ?>
                        <tr >
                        <td><?php echo $dd; ?></td> 
                        <td class="pf_row_i"><?php echo getincomefee($pdb,1, $_SESSION['pfd']['mnt'],$dd,$_SESSION['pfd']['sch']); ?></td> 
                        <td class="pf_row_i"><?php echo getincomefee($pdb,2, $_SESSION['pfd']['mnt'],$dd,$_SESSION['pfd']['sch']); ?></td> 
                        <td class="pf_row_i"><?php echo getincomefee($pdb,3, $_SESSION['pfd']['mnt'],$dd,$_SESSION['pfd']['sch']); ?></td> 
                        <td class="pf_row_i"><?php echo getincomefee($pdb,4, $_SESSION['pfd']['mnt'],$dd,$_SESSION['pfd']['sch']); ?></td> 
                        <td class="pf_row_i"><?php echo getincomefee($pdb,5, $_SESSION['pfd']['mnt'],$dd,$_SESSION['pfd']['sch']); ?></td> 
                        <td class="pf_row_i"><?php echo getincomefee($pdb,6, $_SESSION['pfd']['mnt'],$dd,$_SESSION['pfd']['sch']); ?></td> 
                        <td class="pf_row_i"><?php echo getincomefee($pdb,7, $_SESSION['pfd']['mnt'],$dd,$_SESSION['pfd']['sch']); ?></td> 
                        <td class="pf_total_vi"></td>
                         </tr>
                        <?php  } ?>
                        </tbody>

                        </table>
                        </div>
                    </div>

                    <div class="col-md-4">
                        
                    </div>
                </div>
                
          </div>
    </section>
  <!-- 
        ================================================== 
            end Patfon Daily Income List
        ================================================== -->
     
        <?php } 
        else{
            $_SESSION['no-data'] = "1";
            header("Location: income.php");
        }

  


  ?>