<?php include "functions/index.php";?>
<?php 
  if (isset($_GET['page']))
  {
   
    $_SESSION['income_sch'] = $_GET['sch'];  
    $_SESSION['income_year'] = $_GET['year'];
    $_SESSION['cur-page'] = "Income > Yearly Summary Report";
  } 

  ?>
<br>
<h4> Yearly Status of proposed Income for <?php  echo "<b>".$_SESSION['income_year']."</b>"; ?> session </h4>
<section id="daily-section">
            <div class="container">
            <div class="row" > 

            <h2> School Name: 
            <?php echo getschoolname($pdb,$_SESSION['school_id']); ?> </h2>
            </div>
                 <div class="row">
                    <div class="col-md-5 text-center">
                        <div ><a class="btn btn-block btn-success" href="income.php">Go back</a></div>
                    </div>
                 </div>
                <div class="row">
                    <div class="col-md-12">
                  <!-- 1st term -->
                  <table id="example2" class="table table-bordered table-hover dataTable" role="grid" aria-describedby="example2_info">
                <thead>
                <tr role="row">
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending"></th>
				
                <th class="sorting_asc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending"></th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">2017</th>
                <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">2018</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">2019</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending">2020</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending">2021</th>
				
				</tr>
                </thead>
                <tbody>    

                <tr role="row" class="odd" style="background: #000; color: #fff;">
				<td></td>
                  <th class="sorting_1">INCOME</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
                <tr role="row" class="even">
				<td></td>
                  <th class="sorting_1">Balance BF</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr><tr role="row" class="odd">
				<td></td>
                  <th class="sorting_1">FEES</th>
                
                   <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				   <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                </tr><tr role="row" class="even">
				<td></td>
                  <th class="sorting_1">OLD DEPT</th>
                  <td></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                </tr><tr role="row" class="odd">
				<td></td>
                  <th class="sorting_1">BUS</th>
                  <td></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                <tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">CUSTOMISED UNIFORM</td>
                  <td></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                <tr role="row" class="odd">
				<td></td>
                  <td class="sorting_1">UNIFORM</td>
                  <td></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                <tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">SPORT WEAR</td>
                  <td></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                <tr role="row" class="odd">
				<td></td>
                  <td class="sorting_1">PULL OVER</td>
                  <td></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>

                <tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">CAR </td>
                  <td></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomefeeyear($pdb,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                </table>
                    
                    </div>
                </div>
            </div>
</section>
