<?php include "functions/index.php";?>
    <!--Side menu ends here-->
	
	<!--main content starts here-->
    <div id="page-content-wrapper" >
            <div class="container-fluid">
                          <div class="container">
<?php 
//My Income Add Logic is Done Here
if (isset($_GET['page']))
{
$_SESSION['cur-page'] = $_GET['page'];
echo "page".$_GET['page'];
}
$source = getsource($pdb);
$source2 = getschools($pdb);

?>
<div class="row">
    <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
						<?php  if(isset($_SESSION['add-data-income'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully added an Income data.
                            </div>                             
                        <?php unset($_SESSION['add-data-income']); } ?>
		<form role="form" >
		<div class="row"><div>
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="src"> Source of Income</label>
                        <select name = "src" class="form-control input-lg">
                        <option value="">Select....</option>
                        <?php foreach ($source as $k=>$v) { 
                        echo "<option value='$k'>$v</option>";  ?>
                        <?php } ?>
                        </select>
                    </div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="pay_t"> Type of Payment</label>
					    <select  name = "pay_t" class="form-control input-lg"> 
                        <option value="">Select....</option>
                        <option value="0">Bank</option>
                        <option value="1">Cash</option>
                        </select>
                    </div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="t_no"> Teller No. (If Bank is Used) </label>
						<input type="number" name="t_no"  class="form-control input-lg">
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="amt">Amount </label>
						<input type="number" name="amt" class="form-control input-lg" >
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="amt">Date Paid </label>
						<input type="date" name="date_pay" class="form-control input-lg" >
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
                    <label class="formlabel" for="amt">Comment </label>
						<input type="text" name="comment" class="form-control input-lg">
					</div>
				</div>
                <div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="src"> Choose School</label>
                        <select name = "school" class="form-control input-lg">
                        <option value="">Select....</option>
                        <?php foreach ($source2 as $k=>$v) { 
                        echo "<option value='$k'>$v</option>";  ?>
                        <?php } ?>
                        </select>
                    </div>
				</div>
			</div>
			
			<hr class="colorgraph">
			<div class="row">
				<div class="col-xs-12 col-md-12"><input type="submit" value="Add Income" name="addincome" class="btn btn-info btn-block btn-lg bbg" tabindex="7"></div>
				</div>
		</form>
		</div>
	</div>
			<style>
			.bbg{
			background-color:#0b7285}
			</style>

            </div>
        </div>
		<!--main content ends  here-->
		
    </div>
    
	<?php //get the PHP logic down here
	if (isset($_POST['addincome'])) {

		$src = $_POST['src'];
		$pay_t = $_POST['pay_t'];
		$t_no = $_POST['t_no'];
		$term = $_POST['term'];
		$amount = $_POST['amt'];
		$dp = $_POST['date_pay'];
		$com = $_POST['comment'];
		$sch = $_POST['school'];

		$query = ("SELECT id FROM income WHERE date_pay = '$dp' AND source = $src");
		$skools = "";
		$result = mysqli_query($pdb,$query) or die(mysqli_error());
		if (mysqli_num_rows($result) > 0){
		while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
			
			$skools = $r['id'];
			}
		}

		if (strlen($skools) <= 0){

		$query = ("INSERT INTO income (date_pay,pay_type,comment,amount,term,mnt,source,school) VALUES ('$dp',$pay_t,'$com',$amount,$term,$month,$src,$sch) ");
	   
		if (mysqli_query($pdb, $query)) {
			
		$_SESSION['add-data-income'] = "1";
		//  header("Location: add.php"); 
		} else {
			echo "Error: ". "<br>" . mysqli_error($pdb);
		} }

		else {

		$query = ("UPDATE income SET amount = amount + $amount WHERE date_pay = '$dp' and source = $src ");
	  
		if (mysqli_query($pdb, $query)) {
			
		$_SESSION['add-data-income'] = "1";
		//  header("Location: add.php"); 
		} else {
			echo "Error: ". "<br>" . mysqli_error($pdb);
		}

		}
	}


	
	
	?>