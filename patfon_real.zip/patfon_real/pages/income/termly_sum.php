<?php include "functions/index.php";?>
<?php 
  if (isset($_GET['page']))
  {
    $_SESSION['income_term'] = $_GET['term'];
    $_SESSION['income_sch'] = $_GET['sch'];  
    $_SESSION['income_year'] = $_GET['year'];
    $_SESSION['cur-page'] = "Income > Termly Summary Report";
  } 

  ?>
<br>
<h4> Monthly Status of Proposed Income for First term in <?php  echo $_SESSION['income_year']."/".(intval($_SESSION['income_year'])+1); ?> Session </h4>
<section id="daily-section">
            <div class="container">
            <div class="row" > 

            <h2> School Name: 
            <?php echo getschoolname($pdb,$_SESSION['school_id']); ?> </h2>
            </div>
                 <div class="row">
                    <div class="col-md-5 text-center">
                        <div ><a class="btn btn-block btn-success" href="income.php">Go back</a></div>
                    </div>
                 </div>
                <div class="row">
                    <div class="col-md-12">
                  <!-- 1st term -->
                  <table id="example2" class="table table-bordered table-hover dataTable" role="grid" aria-describedby="example2_info">
                <thead>
                <tr role="row">
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending"></th>
				
                <th class="sorting_asc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending"></th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">Proposed</th>
                <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">August</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">Sept</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending">October</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending">November</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending">December</th>
				
				</tr>
                </thead>
                <tbody>    

                <tr role="row" class="odd" style="background: #000; color: #fff;">
				<td></td>
                  <th class="sorting_1">INCOME</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
                <tr role="row" class="even">
				<td></td>
                  <th class="sorting_1">Balance BF</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr><tr role="row" class="odd">
				<td></td>
                  <th class="sorting_1">FEES</th>
                  <td></td>
                   <td><?php echo getincomesum($pdb,99,8,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,99,9,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,99,10,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,99,11,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				   <td><?php echo getincomesum($pdb,99,12,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                </tr><tr role="row" class="even">
				<td></td>
                  <th class="sorting_1">OLD DEPT</th>
                  <td></td>
                  <td><?php echo getincomesum($pdb,100,8,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,100,9,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,100,10,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,100,11,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomesum($pdb,100,12,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                </tr><tr role="row" class="odd">
				<td></td>
                  <th class="sorting_1">BUS</th>
                  <td></td>
                  <td><?php echo getincomesum($pdb,2,8,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,9,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,10,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,11,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomesum($pdb,2,12,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                <tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">CUSTOMISED UNIFORM</td>
                  <td></td>
                  <td><?php echo getincomesum($pdb,3,8,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,3,9,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,3,10,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,3,11,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomesum($pdb,3,12,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                <tr role="row" class="odd">
				<td></td>
                  <td class="sorting_1">UNIFORM</td>
                  <td></td>
                  <td><?php echo getincomesum($pdb,1,8,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,9,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,10,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,11,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomesum($pdb,1,12,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                <tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">SPORT WEAR</td>
                  <td></td>
                  <td><?php echo getincomesum($pdb,4,8,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,4,9,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,4,10,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,4,11,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomesum($pdb,4,12,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                <tr role="row" class="odd">
				<td></td>
                  <td class="sorting_1">PULL OVER</td>
                  <td></td>
                  <td><?php echo getincomesum($pdb,5,8,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,5,9,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,5,10,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,5,11,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomesum($pdb,5,12,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>

                <tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">CAR </td>
                  <td></td>
                  <td><?php echo getincomesum($pdb,6,8,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,6,9,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,6,10,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
                  <td><?php echo getincomesum($pdb,6,11,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
				  <td><?php echo getincomesum($pdb,6,12,$_SESSION['income_year'],$_SESSION['income_sch']); ?></td>
               
                </tr>
                </table>
                    
                    </div>
                </div>
            </div>
</section>
