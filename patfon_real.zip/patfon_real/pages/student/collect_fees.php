<?php include "functions/index.php";?>
    <!--Side menu ends here-->
	
	<!--main content starts here-->
    <div id="page-content-wrapper" >
            <div class="container-fluid">
                          <div class="container">
<?php 
//My Income Add Logic is Done Here
if (isset($_GET['page']))
{
$_SESSION['cur-page'] = "Student > Collect Fees";
$_SESSION['student_sch'] = $_GET['sch'];  
$_SESSION['student_year'] = $_GET['year'];
$_SESSION['student_term'] = $_GET['term'];

}
//use function variables here
$stu = getstudents($pdb);
$status = array(1=>"Active",2=>"Suspend",3=>"Left",4=>"Suspend");

$sesterm = $_SESSION['student_term'];
$sesyear = $_SESSION['student_year'];

?>
<div class="row">
    <div class="col-sm-8 col-md-12 col-sm-offset-2 col-md-offset-3">
						<?php  if(isset($_SESSION['add-data-schfee'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully added a Student School Fee.
                            </div>                             
                        <?php unset($_SESSION['add-data-schfee']); } ?>
	
		<div class="row">
        <table id="student_data" width="100%" class="table table-hover table-bordered" >
	<thead>
	<tr>
		<th class="title" >Student Name</th>
        <th class="title" >Class</th>
        <th class="title" >School</th>
        <th class="title" >Cashier</th>
        <th class="title" >Term</th>
		<th class="title" >Amount Paid</th>
		<th class="title" >Date Of Payment</th>
		<th class="title" >Balance</th>
		<th class="title" >Status</th>
		<th class="title" >Get Fees</th>
	</tr>
    </thead>
    <tbody>
	
    <?php
	if (!empty($stu)) {
    	foreach($stu as $s){
			
	?>
    	<tr>
        	<td id="center"><?php echo $s['fname']." ". $s['mname']." ".$s['lname']; ?></td>
            <td id="center"><?php echo getclassname($pdb,$s['class_']); ?></td>
            <td id="center">
			<?php 
			$school= $s['school'];
			echo getschoolname($pdb,$school);//calling function to rename school according to their respective IDs 1,2,3
			?></td> 
            <td id="center">
			
			<?php $cashier = getuserfeecollect($pdb,$s['id'],$sesterm,$sesyear);
			
			if ($cashier === "" || $cashier === null ){
				echo "<b style='font-color: blue;'> Not Paid(Cashier) </b>";
			}
			else{
				echo $cashier;
			}
			?>
			
			</td>
			<td id="center">
			<?php 
			$term = array(1=>"1st Term",2=>"2nd Term",3=>"3rd Term");
			//$t = $s['term']; 
			echo $term[$sesterm]; 
			
			?>
			</td>
			
            <td id="center">
			
			<?php $student_paid = getstudentpaid($pdb,$s['id'],$sesterm,$sesyear);
			
			if ($student_paid === "" || $student_paid === null ){
				echo "<b style='font-color: blue;'> Not Paid(Student) </b>";
			}
			else{
				echo $student_paid;
			}
			?>
			
			</td>
            <td id="center">
			<?php $date_paid = getstudentdatepaid($pdb,$s['id'],$sesterm,$sesyear);
			
			if ($date_paid === "" || $date_paid === null ){
				echo "<b style='font-color: blue;'> Not Paid(Date) </b>";
			}
			else{
				echo $date_paid;
			}
			?>
			
			</td>
            <td id="center">
			<?php

			$student_paid = intval(getstudentpaid($pdb,$s['id'],$sesterm,$sesyear));

			$category_class = intval(getclasscategory($pdb,$s['class_']));

			$class_pay = intval(getclassfee($pdb,$category_class,$s['school']));
//code to calculate amount owed  by student and amount school is owing student i.e Balance			
		
			
			if($student_paid > $class_pay){
			$balance=$student_paid-$class_pay;
			echo $balance;
			}else{
			echo $class_pay-$student_paid;
			}
			?>
			</td>
			<td id="center">
			<?php
			//code for status
			//global $student_paid,$class_pay;
			
		if( $student_paid == $class_pay &&  $class_pay !=0){
			echo "<b style='color:green'>Full Payment</b>";
		}	
		
		elseif( $student_paid  > $class_pay ){
			echo "<b style='color:skyblue'>Full Payment</b>";
		}
		
		elseif( $student_paid  > 0 && $student_paid < $class_pay ){
			echo"<b style='color:navy'>Part Payment</b>";
		}
		
		else{
			echo "<b style='color:red'>No Payment</b>";;
		}
		
			?>
			</td>
            <td id="center">
			<?php 
			
			if( $student_paid == $class_pay &&  $class_pay !=0){
				echo "<b style='color:green'>Fee Collected!</b>";
			}	
			
			elseif( $student_paid  > $class_pay ){
				echo "<b style='color:skyblue'>Fee Collected!</b>";
			}
			
			elseif( $student_paid  > 0 && $student_paid < $class_pay ){
				echo "<a name='yes' href=\"stu_col_fee_form.php?page=$s[id]&term=$sesterm&year=$sesyear&id=$s[id]\"><font color='green'>Collect fees</font></a>";
			
			}
			
			else{
				echo "<a name='yes' href=\"stu_col_fee_form.php?page=$s[id]&term=$sesterm&year=$sesyear&id=$s[id]\"><font color='green'>Collect fees</font></a>";
			
			}
			
			?>
			</td>
        </tr>
	<?php
		} } else { 
			echo "<tr><td colspan='10'> No data </td></tr>";
		}
	?>
    </tbody>
	
</table>
        </div>
		</div>
	</div>
			<style>
			.bbg{
			background-color:#0b7285}
			</style>

            </div>
        </div>
		<!--main content ends  here-->
		
    </div>
    
