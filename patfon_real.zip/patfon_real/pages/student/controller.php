<?php 
session_start();
$pdb = mysqli_connect ('localhost', 'root', 'loyboy', 'patfon_db');
mysqli_set_charset($pdb, 'utf8');


//get the PHP logic down here
if (isset($_POST['addschfee'])) {
    
    $hname = $_POST['hname'];
    $term = $_POST['term'];
    $sch = $_POST['sch'];
    $year = $_POST['year_'];$bal = $_POST['bal'];
    $ucol = $_POST['ucollect'];$dt = $_POST['date_'];
    $teller = $_POST['teller']; $amt = $_POST['amt'];

    if (isset($teller)){
        $pyt = 1;
    } 
    else{
        $pyt = 0;
        
    }

    if (!isset($teller)){
        $tel = 0;
    }
    else{
        $tel = intval($teller); 
    }

    $month = date("m", strtotime($dt));
    
    $query = ("INSERT INTO student_fees (stu_id,term,year_,amount,bal,user_collect,date_pay,school,teller) VALUES ($hname,$term,'$year',$amt,$bal,$ucol,'$dt',$sch,$tel) ");
    
    $query2 = (" INSERT INTO income (sourcex,pay_type,teller_no,amount,date_pay,commentx,term,mnt,school) VALUES (99,$pyt,$tel,$amt,'$dt','Paid school Fees',$term,$month,$sch) ");
   
   
    if (mysqli_query($pdb, $query)) {
        
        if (mysqli_query($pdb, $query2)) { 
            $_SESSION['add-data-schfee'] = "1";
            header("Location: ../../stu_col_fee.php");   
    
        }
        else { 
            echo "Error: ". "<br>" . mysqli_error($pdb);
        }
        
    } else {
        echo "Error: ". "<br>" . var_dump(mysqli_error($pdb));
    }
    
    /**
      if (mysqli_query($pdb, $query2)) { 
           
        }
        else { 
            echo "Error: ". "<br>" . mysqli_error($pdb);
        }
      **/

    


}