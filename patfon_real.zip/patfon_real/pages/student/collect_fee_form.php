<?php include "functions/index.php";?>
    <!--Side menu ends here-->
<?php 
        //My Income Add Logic is Done Here
        if (isset($_GET['page']))
        {
        $_SESSION['cur-page'] = "Student > Enter Student Fees";
        $_SESSION['student_id'] = $_GET['id'];  
        $_SESSION['student_f_year'] = $_GET['year'];
        $_SESSION['student_f_term'] = $_GET['term'];

        }
        //use function variables here
        $stu = getstudents($pdb);
        $status = array(1=>"Active",2=>"Suspend",3=>"Left",4=>"Suspend");
        $term = array(1=>"1st Term",2=>"2nd Term",3=>"3rd Term");
        $sch = $_SESSION['school_id'] ;
        $sesterm = $_SESSION['student_f_term'];
        $sesyear = $_SESSION['student_f_year'];
    ?>
    
  
	<!--main content starts here-->
    <div id="page-content-wrapper" >
            <div class="container-fluid">
                          <div class="container">
 
	<h4><b>Collect fees for <?php echo $term[$sesterm]; ?> in the Year <?php echo $_SESSION['student_f_year']; ?> </b></h4>	
    
    <div class="row">
	<div class="col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
                      
	<form id="" action="pages/student/controller.php"  method="post" >

    <div class="row">
    
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="src">Student Name *</label>
                    <input type="text" name="name" class="form-control input-lg" disabled="disabled" value="<?php echo getstudentname($pdb,$_SESSION['student_id']); ?>" required = 'required'> 
                    <input type="hidden" name="hname" value="<?php echo $_SESSION['student_id']; ?>"> 
                    <input type="hidden" name="term" value="<?php echo $sesterm; ?>"> 
                    <input type="hidden" name="year_" value="<?php echo $sesyear; ?>">  
                    <input type="hidden" name="sch" value="<?php echo $sch; ?>">  
                    <input type="hidden" name="bal" value="0"> 
                    <input type="hidden" name="ucollect" value="1">   
                    <input type="hidden" name="date_" value="<?php echo date("Y-m-d"); ?>">    
                    </div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="pay_t"> Bank Teller No. (If not Cash)</label>
					<input type="number" name="teller" class="form-control input-lg" placeholder="Input Teller No." >   
                   
                    </div>
				</div>
                <div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="pay_t"> Class </label>
					<input type="text" class="form-control input-lg" disabled="disabled" value="<?php echo getstudentclass($pdb,$_SESSION['student_id']); ?>"  >   
                   
                    </div>
				</div>
                <div class="col-xs-12 col-sm-6 col-md-12">
					<div class="form-group">
                    <label class="formlabel" for="pay_t"> Amount Paid </label>
					<input type="number" name="amt" class="form-control input-lg" required = 'required' placeholder="Amount Paid" >   
                   
                    </div>
				</div>
	</div>
    <hr class="colorgraph">
	<div class="row">
		<div class="col-xs-12 col-md-12"><input type="submit" value="Collect Fee" name="addschfee" class="btn btn-info btn-block btn-lg bbg" tabindex="7"></div>
		</div>
	</div>

    </form>

        </div>
    </div>    

			<style>
			.bbg{
			background-color:#0b7285}
			</style>

            </div>

        </div>
		<!--main content ends  here-->
		
    </div>
    
	