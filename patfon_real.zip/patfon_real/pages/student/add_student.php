﻿<?php include "functions/index.php";?>
    <!--Side menu ends here-->
	
	<!--main content starts here-->
    <div id="page-content-wrapper" >
            <div class="container-fluid">
                          <div class="container">
<?php 
//My Income Add Logic is Done Here
if (isset($_GET['page']))
{
$_SESSION['cur-page'] = $_GET['page'];
echo "page".$_GET['page'];
}
//use function variables here

?>
<div class="row">
    <div class="col-sm-8 col-md-12 col-sm-offset-2 col-md-offset-3">
						<?php  if(isset($_SESSION['add-data-student'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully added a Student Data.
                            </div>                             
                        <?php unset($_SESSION['add-data-student']); } ?>
		<form role="form" action="" >
		<div class="row"><div>
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-4">
					<div class="form-group">
                    <label class="formlabel" for="src">First Name *</label>
                    <input type="text" name="fname" class="form-control input-lg" required = 'required'>   
                    </div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-4">
					<div class="form-group">
                    <label class="formlabel" for="pay_t"> Middle Name</label>
					<input type="text" name="mname" class="form-control input-lg" >   
                   
                    </div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-4">
					<div class="form-group">
                    <label class="formlabel" for=""> Last Name *</label>
					<input type="text" name="lname" class="form-control input-lg" required = 'required'>   
                   
                    </div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-12">
					<div class="form-group">
                    <label class="formlabel" for=""> Address *</label>
						<input type="number" name="addr"  class="form-control input-lg" required = 'required'>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for=""> Date of Birth * </label>
						<input type="date" name="dob" class="form-control input-lg" required = 'required'>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for=""> Gender  *</label>
					<select name = "gender" class="form-control input-lg" required = 'required'>
					</select>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="">Place of Birth </label>
						<input type="text" name="pbirth" class="form-control input-lg" >
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6">
					<div class="form-group">
                    <label class="formlabel" for="amt">State of Origin *</label>
						<input type="text" name="sorigin" class="form-control input-lg" required='required' >
					</div>
				</div>
                
			</div>
			
			<hr class="colorgraph">
			<div class="row">
				<div class="col-xs-12 col-md-12"><input type="submit" value="Add Student" name="addincome" class="btn btn-info btn-block btn-lg bbg" tabindex="7"></div>
				</div>
		</form>
		</div>
	</div>
			<style>
			.bbg{
			background-color:#0b7285}
			</style>

            </div>
        </div>
		<!--main content ends  here-->
		
    </div>
    
	<?php //get the PHP logic down here
	if (isset($_POST['addincome'])) {

		$src = $_POST['src'];
		$pay_t = $_POST['pay_t'];
		$t_no = $_POST['t_no'];
		$term = $_POST['term'];
		$amount = $_POST['amt'];
		$dp = $_POST['date_pay'];
		$com = $_POST['comment'];
		$sch = $_POST['school'];

		$query = ("SELECT id FROM income WHERE date_pay = '$dp' AND source = $src");
		$skools = "";
		$result = mysqli_query($pdb,$query) or die(mysqli_error());
		if (mysqli_num_rows($result) > 0){
		while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
			
			$skools = $r['id'];
			}
		}

		if (strlen($skools) <= 0){

		$query = ("INSERT INTO income (date_pay,pay_type,comment,amount,term,mnt,source,school) VALUES ('$dp',$pay_t,'$com',$amount,$term,$month,$src,$sch) ");
	   
		if (mysqli_query($pdb, $query)) {
			
		$_SESSION['add-data-income'] = "1";
		//  header("Location: add.php"); 
		} else {
			echo "Error: ". "<br>" . mysqli_error($pdb);
		} }

		else {

		$query = ("UPDATE income SET amount = amount + $amount WHERE date_pay = '$dp' and source = $src ");
	  
		if (mysqli_query($pdb, $query)) {
			
		$_SESSION['add-data-income'] = "1";
		//  header("Location: add.php"); 
		} else {
			echo "Error: ". "<br>" . mysqli_error($pdb);
		}

		}
	}


	
	
	?>