﻿<?php include "includes/header.php";?>
    <div id="page-container">
	<!--Side menu starts here-->
        <aside id="side-menu">
            <nav class="sidebar-nav">
               <ul class="metismenu" id="menu1">
                   <li id="colo">
                        <a href="index.html" aria-expanded="false" ><span  class="fa fa-home"></span > &nbsp; <b>HOME</b></a>
                    </li>
                    <li>
                        <a href="income.html" aria-expanded="false"><span  class="fa fa-download"></span> &nbsp; <b>INCOME</b></a>
                    </li>
                    <li id="removable">
                        <a href="student.html" aria-expanded="false"><span  class="fa fa-group"></span> &nbsp; <b>STUDENT</b></a>
                    </li>
					 <li id="removable">
                        <a href="class.html" aria-expanded="false"><span  class="fa fa-graduation-cap"></span> &nbsp; <b>CLASS</b></a>
                    </li>
                     <li id="colo">
                        <a href="teacher.html" aria-expanded="false"  class="bg"><span  class="fa fa-briefcase"></span> &nbsp; <b>TEACHER</b></a>
                    </li>
					 <li>
                        <a href="expenditure.html" aria-expanded="false"><span  class="fa fa-upload"></span> &nbsp; <b>EXPENDITURE</b></a>
                    </li>
					 <li >
                        <a href="settings.html" aria-expanded="false" ><span  class="fa fa-gears"></span> &nbsp; <b> SETTINGS</b></a>
                    </li>
                </ul>
				<style>
				.bg{background-color:#0b7285;}
				.fa-briefcase{color:white;}
				 #colo a {color:white;}
				</style>	
            </nav>
        </aside>
    <!--Side menu ends here-->
	
	<!--main content starts here-->
        <div id="page-content-wrapper" >
            <div class="container-fluid">
             
            </div>
        </div>
		<!--main content ends  here-->
		
    </div>
   
    <?php include "includes/footer.php";?>