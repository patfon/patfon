<?php
DEFINE ('DB_USERX', 'root');
DEFINE ('DB_PASSWORDX', 'loyboy');
DEFINE ('DB_HOSTX', 'localhost');
DEFINE ('DB_NAMEX', 'patfon_db');
$pdb = mysqli_connect (DB_HOSTX, DB_USERX, DB_PASSWORDX, DB_NAMEX);
mysqli_set_charset($pdb, 'utf8');