
<?php

include "includes/header.php";?>

    <!--Side menu ends here-->
	<?php 
if (isset($_GET['add_income']))
{
$_SESSION['cur-page'] = "Income > Add Income";
}
?>
	<!--main content starts here-->
<?php include "pages/income/monthly_sum.php";?>
	<!--main content ends  here-->
	
    
<?php include "includes/footer.php";?>