﻿<?php include "includes/header.php";?>
    <!--Side menu ends here-->
	
	<!--main content starts here-->
        <div id="page-content-wrapper" >
            <div class="container-fluid">
             
			 <br >
			
		<div class="col-lg-3 col-xs-6 bg-dark" >
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-user-plus " ></i> &nbsp; <a href="#" onclick="sendredirect('stu_add.php','Student > Add New Student')" class="small-box-footer " ><b>Add Student </b><i class="fa fa-arrow-circle-right"></i></a>
          </div>
    </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-eye"></i> &nbsp; <a href="#"  onclick="" class="small-box-footer"><b>View Student </b><i class="fa fa-arrow-circle-right"></i></a>
          </div>
    </div>
		
		<br>

		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center center-block">
            <i class="fa fa-money"></i> &nbsp; <a href="#" onclick="dropdiv('#stu_collect')" class="small-box-footer"><b>Collect Fees </b><i class="fa fa-arrow-circle-right"></i></a>
            
            <div id="stu_collect" class="col-lg-6 col-xs-12 bg-warning">
              <div class="col-xs-2">
              <label class="">Choose Year: </label>
              <select name="" id="stucol_term_year">
              <option value="2017">2017</option>
              <option value="2018">2018</option>
              <option value="2019">2019</option>
              <option value="2020">2020</option>
              </select>
              </div>
              <br>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_col_fee.php','1','<?php echo $_SESSION['school_id']; ?>')">
              1st Term
              </a>
              </div> 
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_col_fee.php','2','<?php echo $_SESSION['school_id']; ?>')">
              2nd Term
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_col_fee.php','3','<?php echo $_SESSION['school_id']; ?>')">
              3rd Term
              </a>
              </div>      

            </div>

          </div>
    </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-pencil-square-o"></i> &nbsp; <a href="#"  onclick="dropdiv('#stu_discount')" class="small-box-footer"><b>Add Discount </b><i class="fa fa-arrow-circle-right"></i></a>
          
            <div id="stu_discount" class="col-lg-6 col-xs-12 bg-warning">
              <div class="col-xs-2">
              <label class="">Choose Year: </label>
              <select name="" id="studis_term_year">
              <option value="2017">2017</option>
              <option value="2018">2018</option>
              <option value="2019">2019</option>
              <option value="2020">2020</option>
              </select>
              </div>
              <br>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_dis_fee.php','1','<?php echo $_SESSION['school_id']; ?>')">
              1st Term
              </a>
              </div> 
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_dis_fee.php','2','<?php echo $_SESSION['school_id']; ?>')">
              2nd Term
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_dis_fee.php','3','<?php echo $_SESSION['school_id']; ?>')">
              3rd Term
              </a>
              </div>      

          </div>

        </div>
    </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-check-square-o"></i> &nbsp; <a href="#" class="small-box-footer"><b>Promote Students </b><i class="fa fa-arrow-circle-right"></i></a>
           <!-- <div id="stu_promote" class="col-lg-6 col-xs-12 bg-warning">  
            <label class="">From which class?: </label>
             

              <br>
            </div>  -->
          </div>
    </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-id-badge"></i> &nbsp; <a href="#"  onclick="dropdiv('#stu_change')" class="small-box-footer"><b>Change Status </b>
            <i class="fa fa-arrow-circle-right"></i></a>
            
            <div id="stu_change" class="col-lg-6 col-xs-12 bg-warning">
            <label class="">From which class?: </label>
            <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_change_fee.php','7','<?php echo $_SESSION['school_id']; ?>')">
              JS 1
              </a>
              </div> 
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_change_fee.php','8','<?php echo $_SESSION['school_id']; ?>')">
              JS 2
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_change_fee.php','9','<?php echo $_SESSION['school_id']; ?>')">
              JS 3
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_change_fee.php','10','<?php echo $_SESSION['school_id']; ?>')">
              SS 1
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_change_fee.php','11','<?php echo $_SESSION['school_id']; ?>')">
              SS 2
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_change_fee.php','12','<?php echo $_SESSION['school_id']; ?>')">
              SS 3
              </a>
              </div>

              <br>
 
            </div>

          </div>
    </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark ">
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-user-times"></i> &nbsp; <a href="#" onclick="dropdiv('#stu_delete')"  class="small-box-footer center">
            <b>Delete Student </b><i class="fa fa-arrow-circle-right"></i></a>
            
            <div id="stu_delete" class="col-lg-6 col-xs-12 bg-warning">
            <label class="">From which class?: </label>
            <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_delete.php','7','<?php echo $_SESSION['school_id']; ?>')">
              JS 1
              </a>
              </div> 
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_delete.php','8','<?php echo $_SESSION['school_id']; ?>')">
              JS 2
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_delete.php','9','<?php echo $_SESSION['school_id']; ?>')">
              JS 3
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_delete.php','10','<?php echo $_SESSION['school_id']; ?>')">
              SS 1
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_delete.php','11','<?php echo $_SESSION['school_id']; ?>')">
              SS 2
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_stufees('stu_delete.php','12','<?php echo $_SESSION['school_id']; ?>')">
              SS 3
              </a>
              </div>

              <br>
 
            </div>

        </div>
    </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark ">
          <!-- small box -->
          <div class="small-box bg-aqua text-center">
            <i class="fa fa-archive"></i> &nbsp; <a href="#" onclick="sendredirect('stu_delete.php','1')" class="small-box-footer center"><b>View Archive </b><i class="fa fa-arrow-circle-right"></i></a>
          </div>
    </div>
		
        <style>
				.bg{background-color:#0b7285;}
				.fa-group{color:white;}
				 #colo a {color:white;font-weight:bolder;}
				 .bg-dark{
				 background-color:#e3e9ee;padding:5px;border-radius:6px;}
				 </style>	
			 <style>
			 .fa-user-times{color:red}
			 .fa-user-plus{color:green}
			  .fa-money{color:green}
			  .fa-check-square-o{color:green}
			  .fa-id-badge{color:orange;}
			  .fa-eye{color:darkcyan;}
			  .fa-archive{color:#800000}
			 </style>
            </div>
        </div>
		<!--main content ends  here-->
		
    </div>
    <?php include "includes/footer.php";?>