function sendredirect(urlx,argx){

    $.ajax ({
        type: "GET",
        url: urlx,//
        data: {
            page:argx
        },
        success: function(data) { 
       
        location.href = urlx;     
               
            //location.reload();
        },
        error: function(xmlHttpRequest, textStatus, errorThrown)
        {
           
               alert('error ' + xmlHttpRequest);
        }
});

}
//monthly report of income
function sendredirect_inc(urlx,argx,argxx){
    var yearx = $('#inc_mth_year').val();
    $.ajax ({
        type: "GET",
        url: urlx,//
        data: {
            page:argx, month:argx, sch: argxx, year: yearx 
        },
        success: function(data) { 
       
        location.href = urlx;     
               
            //location.reload();
        },
        error: function(xmlHttpRequest, textStatus, errorThrown)
        {
           
               alert('error ' + xmlHttpRequest);
        }
});

}

//termly report of income
function sendredirect_inc2(urlx,argx,argxx){
    var yearx = $('#inc_term_year').val();
    $.ajax ({
        type: "GET",
        url: urlx,//
        data: {
            page:argx, term:argx, sch: argxx,  year: yearx 
        },
        success: function(data) { 
       
        location.href = urlx;     
               
            //location.reload();
        },
        error: function(xmlHttpRequest, textStatus, errorThrown)
        {
           
               alert('error ' + xmlHttpRequest);
        }
});

}

//yearly report of income
function sendredirect_inc3(urlx,argx,argxx){

    $.ajax ({
        type: "GET",
        url: urlx,//
        data: {
            page:argx, year:argx, sch: argxx
        },
        success: function(data) { 
       
        location.href = urlx;     
               
            //location.reload();
        },
        error: function(xmlHttpRequest, textStatus, errorThrown)
        {
           
               alert('error ' + xmlHttpRequest);
        }
});

}

function sendredirect_stufees(urlx,argx,argxx){
    var te = $('#stucol_term_year').val();
    $.ajax ({
        type: "GET",
        url: urlx,//
        data: {
            page:argx, year:te, term: argx, sch: argxx
        },
        success: function(data) { 
       
        location.href = urlx;     
               
            //location.reload();
        },
        error: function(xmlHttpRequest, textStatus, errorThrown)
        {
           
               alert('error ' + xmlHttpRequest);
        }
});

}

function dropdiv(argx){

    $(argx).toggle();
}

$(document).ready(function() { 

    $('#mnt_income').hide();
    $('#term_income').hide();
    $('#year_income').hide();
    $('#stu_collect').hide();
    $('#stu_discount').hide();
    $('#stu_change').hide();
    $('#stu_delete').hide();
   
    
});