﻿  <?php 
  
  if (isset($_GET['page']))
  {
  $_SESSION['cur-page'] = $_GET['page'];
  } 
  include "includes/header.php";?>

    <!--Side menu ends here-->
	<!--main content starts here-->
        <div id="page-content-wrapper" >
            <div class="container-fluid">
            <?php  if(isset($_SESSION['no-data'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.No data was found that matches that search. Please try again.
                            </div>                             
            <?php unset($_SESSION['no-data']); } ?>
             <br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center center-block">
            <i class="fa fa-plus"></i> &nbsp; <a href="#" onclick="sendredirect('income_add.php','Income > Add Income')" class="small-box-footer"><b>Add Income</b> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
		   <br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center center-block">
            <i class="fa fa-calendar"></i> &nbsp; <a href="#" onclick="dropdiv('#mnt_income')" class="small-box-footer"><b>Monthly Summary</b> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
         
          <div id="mnt_income" class="col-lg-6 col-xs-12 bg-warning">
          <div class="col-xs-2">
          <label class="">Choose Year: </label>
          <select name="" id="inc_mth_year">
          <option value="2017">2017</option>
          <option value="2018">2018</option>
          <option value="2019">2019</option>
          <option value="2020">2020</option>
          </select>
          </div>
          <br>
            <div class="col-xs-2">
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','1','<?php echo $_SESSION['school_id']; ?>')" >
            January
            </a>
            </div> 
            <div class="col-xs-2">
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','2','<?php echo $_SESSION['school_id']; ?>')" >
            February
            </a>
            </div>
            <div class="col-xs-2">
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','3','<?php echo $_SESSION['school_id']; ?>')">
            March
            </a>
            </div>
            <div class="col-xs-2">
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','4','<?php echo $_SESSION['school_id']; ?>')">
            April
            </a>
            </div>
            <div class="col-xs-2">
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','5','<?php echo $_SESSION['school_id']; ?>')" >
            May
            </a>
            </div>
            <div class="col-xs-2">
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','6','<?php echo $_SESSION['school_id']; ?>')" >
            June
            </a>
            </div>
            <div class="col-xs-2">
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','7','<?php echo $_SESSION['school_id']; ?>')" >
            July
            </a>
            </div>
            <div class="col-xs-2">
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','8','<?php echo $_SESSION['school_id']; ?>')" >
            August
            </a>
            </div>
            <div class="col-xs-2" >
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','9','<?php echo $_SESSION['school_id']; ?>')">
            September
            </a>
            </div>
            <div class="col-xs-2" >
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','10','<?php echo $_SESSION['school_id']; ?>')">
            October
            </a>
            </div>
            <div class="col-xs-2" >
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','11','<?php echo $_SESSION['school_id']; ?>')">
            November
            </a>
            </div>
            <div class="col-xs-2" >
            <a href = "#" onclick="sendredirect_inc('income_mnt_sum.php','12','<?php echo $_SESSION['school_id']; ?>')">
            December
            </a>
            </div>
            

          </div>
    </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center center-block">
            <i class="fa fa-exchange"></i> &nbsp; <a href="#" onclick="dropdiv('#term_income')"  class="small-box-footer"><b>Termly Summary</b> <i class="fa fa-arrow-circle-right"></i></a>
            <div id="term_income" class="col-lg-6 col-xs-12 bg-warning">
            <div class="col-xs-2">
              <label class="">Choose Year: </label>
              <select name="" id="inc_term_year">
              <option value="2017">2017</option>
              <option value="2018">2018</option>
              <option value="2019">2019</option>
              <option value="2020">2020</option>
              </select>
              </div>
              <br>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_inc2('income_ter_sum.php','1','<?php echo $_SESSION['school_id']; ?>')">
              1st Term
              </a>
              </div> 
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_inc2('income_ter_sum.php','2','<?php echo $_SESSION['school_id']; ?>')">
              2nd Term
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "#" onclick="sendredirect_inc2('income_ter_sum.php','3','<?php echo $_SESSION['school_id']; ?>')">
              3rd Term
              </a>
              </div>      

          </div>
          </div>
    </div>
		
		<br>
		<div class="col-lg-3 col-xs-6 bg-dark">
          <!-- small box -->
          <div class="small-box bg-aqua text-center center-block">
            <i class="fa fa-bar-chart"></i> &nbsp; <a href="#" onclick="dropdiv('#year_income')" class="small-box-footer"><b>Yearly Summary</b> <i class="fa fa-arrow-circle-right"></i></a>
          </div>

          <div id="year_income" class="col-lg-6 col-xs-12 bg-warning">
              <div class="col-xs-2">
              <a href = "" >
              2017
              </a>
              </div> 
              <div class="col-xs-2">
              <a href = "" >
              2018
              </a>
              </div>
              <div class="col-xs-2">
              <a href = "" >
              2019
              </a>
              </div> 
              <div class="col-xs-2">
              <a href = "" >
              2020
              </a>
              </div>      

          </div>

        </div>
		
            </div>
        </div>
		<!--main content ends  here-->
        <style>
				.bg{background-color:#0b7285;}
				.fa-download{color:white;}
				.fa-plus{color:green;}
				 #colo a {color:white;}
				 .bg-dark{
				 background-color:#e3e9ee;padding:5px;border-radius:6px;}
				 
				</style>	
    </div>
    
    <?php include "includes/footer.php";?>