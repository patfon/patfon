<!DOCTYPE HTML>
<?php session_start(); ?>
<?php include "config/connection.php";?>

<?php $_SESSION['school_id'] = 1; ?>
<html>
<head>
    <meta charset="utf-8">
    <title>Patfon - Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="assets/scripts/tether/tether.min.css" rel="stylesheet" />
    <link href="assets/css/bootstrap/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/css/hamburger/hamburgers.min.css" rel="stylesheet" />
    <link href="assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="assets/css/animation/animate.css" rel="stylesheet" />
    <link href="assets/scripts/metismenu/metisMenu.min.css" rel="stylesheet" />
    <link href="assets/scripts/metismenu/mm-vertical.css" rel="stylesheet" />
    <link href="assets/scripts/datatables/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="assets/css/site.css" rel="stylesheet" />
</head>
<body>


    <div id="page-header" class="fixed-top">
        <nav class="navbar navbar-light  bg-faded navbar-toggleable-md 1navbar-inverse 1bg-inverse">
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
			<div class="sidebar-toggler hamburger hamburger--arrowturn-r is-active"
			data-toggle="collapse" data-showTarget="#side-menu">
				<div class="hamburger-box">
				  <div class="hamburger-inner"></div>
				</div>
			  </div>
            <a class="navbar-brand" href="">
                <img src="" width="30" height="30" class="d-inline-block align-top" alt="">
                <b>Patfon Schools</b>
            </a>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" id="center" href=""><b>
                      <?php  
                      if (isset($_SESSION['cur-page']))
                       {
                        echo $_SESSION['cur-page'];
                       }
                      ?>
                        </b></a>
                    </li>
                </ul>
               
            </div><b>
			 <div class="logout-button">
                    <i class="fa fa-sign-out fa-lg"></i></b>
                </div>
        </nav>
    </div>
    <div id="page-container">
	<!--Side menu starts here-->
        <aside id="side-menu">
            <nav class="sidebar-nav">
                <ul class="metismenu" id="menu1">
                   <li id="colo">
                        <a href="index.php" aria-expanded="false" class="bg"><span  class="fa fa-home"></span > &nbsp; <b>HOME</b></a>
                    </li>
                    <li>
                        <a href="#" onclick="sendredirect('income.php','Income')" aria-expanded="false"><span  class="fa fa-download"></span> &nbsp; <b>INCOME</b></a>
                    </li>
                    <li id="removable">
                        <a href="student.php" aria-expanded="false"><span  class="fa fa-group"></span> &nbsp; <b>STUDENT</b></a>
                    </li>
					 <li id="removable">
                        <a href="class.php" aria-expanded="false"><span  class="fa fa-graduation-cap"></span> &nbsp; <b>CLASS</b></a>
                    </li>
                     <li id="removable">
                        <a href="teacher.php" aria-expanded="false"><span  class="fa fa-briefcase"></span> &nbsp; <b>TEACHER</b></a>
                    </li>
					 <li id="removable">
                        <a href="expenditure.php" aria-expanded="false"><span  class="fa fa-upload"></span> &nbsp; <b>EXPENDITURE</b></a>
                    </li>
					 <li id="removable" >
                        <a href="settings.php" aria-expanded="false"><span  class="fa fa-gears"></span> &nbsp; <b> SETTINGS</b></a>
                    </li>
                </ul>
				
            </nav>
        </aside>