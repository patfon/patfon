<div id="page-footer">

</div>

<div class="modal fade" id="confirm1" tabindex="2" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>    
                    </button>
                     
                    <h4 class="modal-title" id="mytitle">Confirm <i class="fa fa-fw fa-commenting"></i></h4>
                </div>
                <div class="modal-body">
                   
                <div class="form-group">
                    <p><b>Do you want to delete this student?</b></p>
                </div>          
                        
                </div>
                <div class="modal-footer">
                     <button type="button" class="btn btn-default" id="stu_del_confirm">Delete</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> 
                </div>
               
            </div>
        </div>
</div>  

<script src="assets/scripts/jquery/jquery-3.2.1.min.js"></script>
<script src="assets/scripts/tether/tether.min.js"></script>
<script src="assets/scripts/bootstrap/bootstrap.min.js"></script>
<script src="assets/scripts/metismenu/metisMenu.min.js"></script>
<script src="assets/scripts/datatables/jquery.dataTables.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('#student_data').dataTable({
		"scrollY":        "auto",
        "scrollCollapse": true,
        "paging":         true
	});
});
</script>
<script src="assets/scripts/main.js"></script>
<script src="assets/scripts/redirect.js"></script>
</body>
</html>