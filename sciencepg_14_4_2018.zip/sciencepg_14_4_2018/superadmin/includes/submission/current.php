<?php include '../../includes/general/header.php'; ?>
            
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>

<?php if (isset($_GET['confirmid'])){ 
      $myid = $_GET['confirmid'];
      $myid2 = $_GET['artid'];
      confirmarticle($pdb,$myid,$myid2);
}
    ?>
    <?php if (isset($_GET['rejid'])){ 
      $myid = $_GET['rejid'];
      $myid2 = $_GET['artid'];
      rejectarticle($pdb,$myid,$myid2);
}
    ?>

            <div id="content" style="height: 80%;">
                
            <?php include '../../includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                <div class="box">
            <!--Alert msg-->
            <?php if (isset( $_SESSION['msg']['sentnotify']) ) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples">Notification sent...please endeavour to check before sending another notification..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
<?php  } unset($_SESSION['msg']['sentnotify']); ?>
            <?php if (isset($_SESSION['msg']['addeditor'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples">Added a New Editor..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
<?php  } unset($_SESSION['msg']['addeditor']); ?>

<?php if (isset($_SESSION['msg']['removeeditor'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples">You just removed an editor..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
<?php  } unset($_SESSION['msg']['removeeditor']); ?>

<?php if (isset($_SESSION['msg']['addreviewer'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples">Added a New Reviewer..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
<?php  } unset($_SESSION['msg']['addreviewer']); ?>

<?php if (isset($_SESSION['msg']['removereviewer'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples">You just removed a Reviewer..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
<?php  } unset($_SESSION['msg']['removereviewer']); ?>
            <!--end Alert msg-->

<!-- First Header showing Example-->
                <div>

                <div id="box-tabs" class="box">
                    <!-- box / title -->
                            <div class="title">
                                        <h5>Current Manuscripts</h5>
                                    </div>
                                    <!-- box / title -->
                                    <div id="box-messages">
                                        <div class="messages">
                            <div id="ctl00_ContentPlaceHolder1_BoxMessage_Info_Panel_SuccessMessage">
                                <div id="message-success" class="message message-warning">
                                                <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                            <h6>Examples</h6>
                                            <span id="examples"> An article has been submitted and is yet to be given editors and reviewers. </span>
                                            </div>
                                </div>
                            </div>
                                        </div>
                                    </div>
                </div>
                </div>
<!-- end First Header showing Example-->
<!-- Second Header showing Table List-->
                        <div class="title">
                        <h5>List Manuscripts Information</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:16px;padding-right:16px;">
                               
                                    <?php $sub = getarticles($pdb); ?>
                                    <table class="mydatatables" width="100%">
                                        
                                       <thead  style="color: #fff; ">
                                       <tr>
                                       <td class="tablehead">S/N </td> <td class="tablehead"> Manuscript No. </td> 
                                       <td class="tablehead"> Manuscript Title</td> <td class="tablehead">  Date of Submission </td>  
                                       <td class="tablehead"> Journal Name </td>   
                                       <td class="tablehead">Action </td>
                                       </tr>
                                       </thead>

                                        <tbody>
                                      <?php  
                                      $i = 1;
                                      if (!empty($sub)) {
                                      foreach ($sub as $s){ ?>
                                            <tr> <td> <?php echo $i; ?></td> <td> <?php echo $s['_articleid']; ?></td> <td> <?php echo $s['_title']; ?></td> 
                                            <td> <?php echo $s['_submitdate']; ?></td> <td> <?php echo getjournalname($pdb,$s['_journalid']); ?></td> 
                                            <td> 
                                            <a href="current_editor.php?artid=<?php echo $s['_articleid']; ?>" target="_blank" >Editor Up. (<?php echo getnoofeditors($pdb,$s['_articleid']); ?>)</a>
                                          
                                            &nbsp;&nbsp;&nbsp;
                                            <a href="current_reviewer.php?artid=<?php echo $s['_articleid']; ?>" target="_blank" >Reviewer Up. (<?php echo getnoofreviewers($pdb,$s['_articleid']); ?>)</a>
                                           
                                            &nbsp;&nbsp;&nbsp;
                                            <a href="send_notify.php?artid=<?php echo $s['_articleid']; ?>&action=confirm" onclick="return confirm('Are you sure you want to send the mails?')" >Send All Mails. (<?php echo getnoofmails($pdb,$s['_articleid']); ?>)</a>
                                            </td></tr>
                                      <?php $i++;} } else { ?>
                                        <tr> <td colspan="7" style="text-align: center;"> No Article has been uploaded yet. </td></tr>

                                      <?php } ?>
                                        </tbody>
                                    </table>
                                   
                                
                            </div>             
<!-- end Second Header showing Table List-->                    
                            <!-- Add New Subjects to the Group-->
                                 
                            <!--   Add new Subjects end -->
                        </div> 
            
                </div>
            
            </div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include '../../includes/general/footer.php'; ?>