
<?php include '../includes/general/header.php'; ?>
<?php include '../functions/index.php'; ?>
<?php include '../classes/connection.php' ; ?>            

<?php if (isset($_GET['manuscript']))
{

   $artman = getarticleswithID($pdb,$_GET['manuscript']);
   foreach ($artman as $ar){
    $_SESSION['manuscript']['name'] = $ar['_title'];
    $_SESSION['manuscript']['articleid'] = $ar['_articleid'];
    $_SESSION['manuscript']['journal'] = getjournalname($pdb,$ar['_journalid']);
    $notify = getnotificationtype($pdb,$ar['_articleid'],'reviewing');
    $_SESSION['manuscript']['reviewing'] = date('M d, Y',$notify);
    $_SESSION['manuscript']['submit'] = $ar['_submitdate'];
    $_SESSION['manuscript']['accept'] = $ar['_acceptdate'];
    $_SESSION['manuscript']['reject'] = $ar['_revertdate'];
    $_SESSION['manuscript']['publish'] = $ar['_pubdate'];
   }
  

} ?>



            <div id="content" style="height: 80%;">
                
            <?php include '../includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                                <div id="right">
                                    
                                <div class="box">
                                
                                    <!-- box / title -->
                                            
                                            <?php 
                                                            $userid = $_SESSION['pubcouser']['id'];
                                                            $article = getanyarticles($pdb,$userid);  
                                             ?> 
                                            <div class="title" style="">
                                            
                                                <h5>Manuscript Title: <?php if (isset($_SESSION['manuscript']['name'])) {  
                                                    echo $_SESSION['manuscript']['name'];
                                                }?>  </h5>	 <br>
                                                
                                                
                                                <h5>Journal Title:  <?php if (isset($_SESSION['manuscript']['journal'])) {  
                                                    echo $_SESSION['manuscript']['journal'];
                                                }?> </h5>					
                                                
                                            </div>
                                            <!-- end box / title -->
                                            <div class="table">
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th class="center" width="15%">Manuscript Number</th>
                                                            <th class="center" width="20%">Status</th>
                                                            <th width="15%">Date</th>
                                                            <th width="50%">Operation</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <!-- Row One -->
                                                        <tr>
                                                            <td rowspan="7" valign="middle" align="center">  <font color="blue"><b>  
                                                            <select name = "" id="manuscriptid" onchange="getdatamanuscript()"> 
                                                            <option value=''>Choose--</option> 
                                                           <?php foreach ($article as $art){ ?>
                                                                <option value='<?php echo $art['_articleid']; ?>'> <?php echo $art['_articleid']; ?> </option>
                                                           <?php } ?>
                                                            </select>  </b> 
                                                            
                                                            <br><br>(Research Article) &nbsp; &nbsp; &nbsp; Number: <b style='color: red;'> <?php if (isset($_SESSION['manuscript']['articleid'])) {  echo $_SESSION['manuscript']['articleid'];  }  ?>  </b></font> </td>
                                                            
                                                            <td> <div style="color:Red">  <b> 1: New Submission </b></div> </td>
                                                            <td> <?php if (isset($_SESSION['manuscript']['submit'])) {  
                                                    echo date('M d, Y',strtotime($_SESSION['manuscript']['submit']));
                                                }?>  </td>
                                                            <td> 
                                                            
                                                            <a href="#">Update Manuscript Information</a> 
                                                            <br>  <br>
                                                            
                                                            <a href="#">Update Authors Information&nbsp;</a>
                                                            
                                                            <br>  <br><a href="#">Update Reviewers Information</a>
                                                            <br>  <br><a href="#">Reupload Manuscript File</a>
                                                            
                                                            <br>  <br><a href="#" onclick="javascript:return confirm('Are you sure to delete this paper？')">Delete This Manuscript</a>
                                                            
                                                            <br>  <br><a href="#">Download Manuscript File</a>   
                                                            </td>
                                                            
                                                            
                                                        </tr><!-- end Row One -->
                                                        <!-- Row Two -------- Composite Rows -->
                                                        <tr>  <td>  <i>2: Under Review </i> </td> <td> 
                                                        <?php if (isset($_SESSION['manuscript']['reviewing'])) {  
                                                    echo $_SESSION['manuscript']['reviewing'];
                                                        } else { echo '--';}?> </td>  <td> -- </td>         </tr>
                                                        <tr>  <td>  <i>3: Accepted</i> </td>    <td> <?php if (isset($_SESSION['manuscript']['accept']) && strtotime($_SESSION['manuscript']['accept']) !== '24361200') {  
                                                    echo  date('M d, Y',strtotime($_SESSION['manuscript']['accept']));
                                                } else { echo '--';}?> </td> 
                                                           <td> --  </td>       </tr>
                                                        <tr>  <td>  <i>4: Rejected</i> </td>  <td> <?php if (isset($_SESSION['manuscript']['reject']) && strtotime($_SESSION['manuscript']['reject']) !== '24361200') {  
                                                    echo  date('M d, Y',strtotime($_SESSION['manuscript']['reject']));
                                                } else { echo '--';}?>  </td>  <td> --  </td>  </tr>
                                                        <tr>  <td>  <i>5: In Press</i> </td> <td> --
                                                       </td>  <td> --   </td>           </tr>
                                                        <tr>  <td>  <i>6: Published</i> </td>   <td>  <?php if (isset($_SESSION['manuscript']['publish']) && strtotime($_SESSION['manuscript']['publish']) !== '24361200') {  
                                                    echo  date('M d, Y',strtotime($_SESSION['manuscript']['publish']));
                                                } else { echo '--';}?>  </td> 
                                                         <td> --   </td>        </tr>
                                                    </tbody>
                                                </table>
                            
                                            </div>
                                        </div>
                                        
                                        <br><br><br><br>
                                        
                                    </div>

            
            
            </div>

            </div>

              <!-- end content -->
              <?php include '../includes/general/footer.php'; ?>