function over5(obj){
    obj.style.cssText="color:#2F5BA6";
}
function out5(obj){
    obj.style.cssText="";
}