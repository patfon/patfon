$(document).ready(function(){
                 $("#q1_text,#q2_text,#q3_text,#q4_text,#q5_text,#q6_text,#q7_text,#q8_text,#q9_text,#q10_text,#q11_text,#q12_text,#q13_text,#q14_text,#q15_text,#q16_text,#q17_text,#q18_text,#q19_text,#q20_text").css("display","none");
    $("#black1,#black2,#black3,#black4,#black5,#black6,#black7,#black8,#black9,#black10,#black11,#black12,#black13,#black14,#black15,#black16,#black17,#black18,#black19,#black20").css("display","block");
    $("#white1,#white2,#white3,#white4,#white5,#white6,#white7,#white8,#white9,#white10,#white11,#white12,#white13,#white14,#white15,#white16,#white17,#white18,#white19,#white20").css("display","none");
    $("#lat_tit1").css({background:"#FFFFFF",color:"#333333"});
    $("#faq").css({background:"#FFFFFF",color:"#111111"});
    $("#reload1").css({background:"#2F5BA6",color:"#FFFFFF"});
    $("#down1,#down2,#up3,#content").css("display","block");
    $("#up1,#up2,#down3,#content3").css("display","none");
    $("#down1").click(function(){
        $("#down1").css("display","none");
        $("#up1").css("display","block");
        $("#content1").css("display","none");
    });
    $("#up1").click(function(){
        $("#down1").css("display","block");
        $("#up1").css("display","none");
        $("#content1").css("display","block");
    });
    $("#down2").click(function(){
        $("#down2").css("display","none");
        $("#up2").css("display","block");
        $("#content2").css("display","none");
    });
    $("#up2").click(function(){
        $("#down2").css("display","block");
        $("#up2").css("display","none");
        $("#content2").css("display","block");
    });
    $("#down3").click(function(){
        $("#down3").css("display","none");
        $("#up3").css("display","block");
        $("#content3").css("display","none");
    });
    $("#up3").click(function(){
        $("#down3").css("display","block");
        $("#up3").css("display","none");
        $("#content3").css("display","block");
    });
    $("#lat_tit1").click(function(){
        $(this).css({background:"#FFFFFF",color:"#333333"});
        $("#lat_tit2").css({background:"",color:""});
    });
    $("#lat_tit2").click(function(){
        $(this).css({background:"#FFFFFF",color:"#333333"});
        $("#lat_tit1").css({background:"",color:""});
    });
    $("#q1").click(function(){
        if($("#white1").css("display")=="none"){
            $("#q1_text").css("display","block");
            $("#black1").css("display","none");
            $("#white1").css("display","block");
            $("#q1").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black1").css("display")=="none"){
            $("#q1_text").css("display","none");
            $("#black1").css("display","block");
            $("#white1").css("display","none");
            $("#q1").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q2").click(function(){
        if($("#white2").css("display")=="none"){
            $("#q2_text").css("display","block");
            $("#black2").css("display","none");
            $("#white2").css("display","block");
            $("#q2").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black2").css("display")=="none"){
            $("#q2_text").css("display","none");
            $("#black2").css("display","block");
            $("#white2").css("display","none");
            $("#q2").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q3").click(function(){
        if($("#white3").css("display")=="none"){
            $("#q3_text").css("display","block");
            $("#black3").css("display","none");
            $("#white3").css("display","block");
            $("#q3").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black3").css("display")=="none"){
            $("#q3_text").css("display","none");
            $("#black3").css("display","block");
            $("#white3").css("display","none");
            $("#q3").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q4").click(function(){
        if($("#white4").css("display")=="none"){
            $("#q4_text").css("display","block");
            $("#black4").css("display","none");
            $("#white4").css("display","block");
            $("#q4").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black4").css("display")=="none"){
            $("#q4_text").css("display","none");
            $("#black4").css("display","block");
            $("#white4").css("display","none");
            $("#q4").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q5").click(function(){
        if($("#white5").css("display")=="none"){
            $("#q5_text").css("display","block");
            $("#black5").css("display","none");
            $("#white5").css("display","block");
            $("#q5").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black5").css("display")=="none"){
            $("#q5_text").css("display","none");
            $("#black5").css("display","block");
            $("#white5").css("display","none");
            $("#q5").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q6").click(function(){
        if($("#white6").css("display")=="none"){
            $("#q6_text").css("display","block");
            $("#black6").css("display","none");
            $("#white6").css("display","block");
            $("#q6").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black6").css("display")=="none"){
            $("#q6_text").css("display","none");
            $("#black6").css("display","block");
            $("#white6").css("display","none");
            $("#q6").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q7").click(function(){
        if($("#white7").css("display")=="none"){
            $("#q7_text").css("display","block");
            $("#black7").css("display","none");
            $("#white7").css("display","block");
            $("#q7").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black7").css("display")=="none"){
            $("#q7_text").css("display","none");
            $("#black7").css("display","block");
            $("#white7").css("display","none");
            $("#q7").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q8").click(function(){
        if($("#white8").css("display")=="none"){
            $("#q8_text").css("display","block");
            $("#black8").css("display","none");
            $("#white8").css("display","block");
            $("#q8").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black8").css("display")=="none"){
            $("#q8_text").css("display","none");
            $("#black8").css("display","block");
            $("#white8").css("display","none");
            $("#q8").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q9").click(function(){
        if($("#white9").css("display")=="none"){
            $("#q9_text").css("display","block");
            $("#black9").css("display","none");
            $("#white9").css("display","block");
            $("#q9").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black9").css("display")=="none"){
            $("#q9_text").css("display","none");
            $("#black9").css("display","block");
            $("#white9").css("display","none");
            $("#q9").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q10").click(function(){
        if($("#white10").css("display")=="none"){
            $("#q10_text").css("display","block");
            $("#black10").css("display","none");
            $("#white10").css("display","block");
            $("#q10").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black10").css("display")=="none"){
            $("#q10_text").css("display","none");
            $("#black10").css("display","block");
            $("#white10").css("display","none");
            $("#q10").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q11").click(function(){
        if($("#white11").css("display")=="none"){
            $("#q11_text").css("display","block");
            $("#black11").css("display","none");
            $("#white11").css("display","block");
            $("#q11").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black11").css("display")=="none"){
            $("#q11_text").css("display","none");
            $("#black11").css("display","block");
            $("#white11").css("display","none");
            $("#q11").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q12").click(function(){
        if($("#white12").css("display")=="none"){
            $("#q12_text").css("display","block");
            $("#black12").css("display","none");
            $("#white12").css("display","block");
            $("#q12").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black12").css("display")=="none"){
            $("#q12_text").css("display","none");
            $("#black12").css("display","block");
            $("#white12").css("display","none");
            $("#q12").css({background:"#F3F3F3",color:""});
        }
    });
    
    $("#q13").click(function(){
        if($("#white13").css("display")=="none"){
            $("#q13_text").css("display","block");
            $("#black13").css("display","none");
            $("#white13").css("display","block");
            $("#q13").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black13").css("display")=="none"){
            $("#q13_text").css("display","none");
            $("#black13").css("display","block");
            $("#white13").css("display","none");
            $("#q13").css({background:"#F3F3F3",color:""});
        }
    }); 

    $("#q14").click(function(){
        if($("#white14").css("display")=="none"){
            $("#q14_text").css("display","block");
            $("#black14").css("display","none");
            $("#white14").css("display","block");
            $("#q14").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black14").css("display")=="none"){
            $("#q14_text").css("display","none");
            $("#black14").css("display","block");
            $("#white14").css("display","none");
            $("#q14").css({background:"#F3F3F3",color:""});
        }
    }); 
    
    $("#q15").click(function(){
        if($("#white15").css("display")=="none"){
            $("#q15_text").css("display","block");
            $("#black15").css("display","none");
            $("#white15").css("display","block");
            $("#q15").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black15").css("display")=="none"){
            $("#q15_text").css("display","none");
            $("#black15").css("display","block");
            $("#white15").css("display","none");
            $("#q15").css({background:"#F3F3F3",color:""});
        }
    }); 
    
    $("#q16").click(function(){
        if($("#white16").css("display")=="none"){
            $("#q16_text").css("display","block");
            $("#black16").css("display","none");
            $("#white16").css("display","block");
            $("#q16").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black16").css("display")=="none"){
            $("#q16_text").css("display","none");
            $("#black16").css("display","block");
            $("#white16").css("display","none");
            $("#q16").css({background:"#F3F3F3",color:""});
        }
    }); 
    
    $("#q17").click(function(){
        if($("#white17").css("display")=="none"){
            $("#q17_text").css("display","block");
            $("#black17").css("display","none");
            $("#white17").css("display","block");
            $("#q17").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black17").css("display")=="none"){
            $("#q17_text").css("display","none");
            $("#black17").css("display","block");
            $("#white17").css("display","none");
            $("#q17").css({background:"#F3F3F3",color:""});
        }
    }); 
    
    $("#q18").click(function(){
        if($("#white18").css("display")=="none"){
            $("#q18_text").css("display","block");
            $("#black18").css("display","none");
            $("#white18").css("display","block");
            $("#q18").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black18").css("display")=="none"){
            $("#q18_text").css("display","none");
            $("#black18").css("display","block");
            $("#white18").css("display","none");
            $("#q18").css({background:"#F3F3F3",color:""});
        }
    }); 
    
    $("#q19").click(function(){
        if($("#white19").css("display")=="none"){
            $("#q19_text").css("display","block");
            $("#black19").css("display","none");
            $("#white19").css("display","block");
            $("#q19").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black19").css("display")=="none"){
            $("#q19_text").css("display","none");
            $("#black19").css("display","block");
            $("#white19").css("display","none");
            $("#q19").css({background:"#F3F3F3",color:""});
        }
    }); 
    
    $("#q20").click(function(){
        if($("#white20").css("display")=="none"){
            $("#q20_text").css("display","block");
            $("#black20").css("display","none");
            $("#white20").css("display","block");
            $("#q20").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black20").css("display")=="none"){
            $("#q20_text").css("display","none");
            $("#black20").css("display","block");
            $("#white20").css("display","none");
            $("#q20").css({background:"#F3F3F3",color:""});
        }
    }); 
    
    
    
    
    
    
    
    
    
    
    
    
});