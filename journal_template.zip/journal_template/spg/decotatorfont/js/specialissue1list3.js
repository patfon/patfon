function over2(obj){
    obj.style.cssText="color:#2F5BA6"
}
function out2(obj){
    obj.style.cssText="";
}
$(document).ready(function(){

    $("#q1_text,#q2_text,#q3_text,#q4_text,#q5_text,#q6_text,#q7_text,#q8_text,#q9_text,#q10_text,#q11_text,#q12_text,#q13_text").css("display","none");
    $("#black1,#black2,#black3,#black4,#black5,#black6,#black7,#black8,#black9,#black10,#black11,#black12,#black13").css("display","block");
    $("#white1,#white2,#white3,#white4,#white5,#white6,#white7,#white8,#white9,#white10,#white11,#white12,#white13").css("display","none");
    
    $("#le1").mouseover(function(){
        $("#le1_a").css("color","#FFFFFF");
        $("#le1").css("background","#E78C12");
        $("#w14").css("display","block");
        $("#y14").css("display","none");
    });
    $("#le1").mouseout(function(){
        $("#le1_a").css("color","");
        $("#le1").css("background","");
        $("#w14").css("display","none");
        $("#y14").css("display","block");
    });
    $("#le2").mouseover(function(){
        $("#le2_a").css("color","#FFFFFF");
        $("#le2").css("background","#E78C12");
        $("#w15").css("display","block");
        $("#y15").css("display","none");
    });
    $("#le2").mouseout(function(){
        $("#le2_a").css("color","");
        $("#le2").css("background","");
        $("#w15").css("display","none");
        $("#y15").css("display","block");
    });
    $("#propose").mouseover(function(){
        $("#propose").css("background-color","#FFFFFF");
        $("#a1").css("color","#111111");
    });
    $("#propose").mouseout(function(){
        $("#propose").css("background-color","");
        $("#a1").css("color","");
    });
    $("#special").mouseover(function(){
        $("#special").css("background-color","#FFFFFF");
        $("#a2").css("color","#111111");
    });
    $("#special").mouseout(function(){
        $("#special").css("background-color","");
        $("#a2").css("color","");
    });
    $("#faq").mouseover(function(){
        $("#faq").css("background-color","#FFFFFF");
        $("#a3").css("color","#111111");
    });
    $("#faq").mouseout(function(){
        $("#faq").css("background-color","");
        $("#a3").css("color","");
    });
    $("#issue").mouseover(function(){
        $("#issue").css("background-color","#FFFFFF");
        $("#a4").css("color","#111111");
    });
    $("#issue").mouseout(function(){
        $("#issue").css("background-color","");
        $("#a4").css("color","");
    });
    $("#submit").mouseover(function(){
        $("#submit").css("background-color","#FFFFFF");
        $("#a5").css("color","#111111");
    });
    $("#submit").mouseout(function(){
        $("#submit").css("background-color","");
        $("#a5").css("color","");
    });
    $("#bio").mouseover(function(){
        $("#bio").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w1").css("display","block");
        $("#y1").css("display","none");
    });
    $("#bio").mouseout(function(){
        $("#bio").css({background:"#F3F3F3",color:""});
        $("#w1").css("display","none");
        $("#y1").css("display","block");
    });
    $("#phy").mouseover(function(){
        $("#phy").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w2").css("display","block");
        $("#y2").css("display","none");
    });
    $("#phy").mouseout(function(){
        $("#phy").css({background:"#F3F3F3",color:""});
        $("#w2").css("display","none");
        $("#y2").css("display","block");
    });
    $("#mat").mouseover(function(){
        $("#mat").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w3").css("display","block");
        $("#y3").css("display","none");
    });
    $("#mat").mouseout(function(){
        $("#mat").css({background:"#F3F3F3",color:""});
        $("#w3").css("display","none");
        $("#y3").css("display","block");
    });
    $("#com").mouseover(function(){
        $("#com").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w4").css("display","block");
        $("#y4").css("display","none");
    });
    $("#com").mouseout(function(){
        $("#com").css({background:"#F3F3F3",color:""});
        $("#w4").css("display","none");
        $("#y4").css("display","block");
    });
    $("#mathe").mouseover(function(){
        $("#mathe").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w5").css("display","block");
        $("#y5").css("display","none");
    });
    $("#mathe").mouseout(function(){
        $("#mathe").css({background:"#F3F3F3",color:""});
        $("#w5").css("display","none");
        $("#y5").css("display","block");
    });
    $("#med").mouseover(function(){
        $("#med").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w6").css("display","block");
        $("#y6").css("display","none");
    });
    $("#med").mouseout(function(){
        $("#med").css({background:"#F3F3F3",color:""});
        $("#w6").css("display","none");
        $("#y6").css("display","block");
    });
    $("#ene").mouseover(function(){
        $("#ene").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w7").css("display","block");
        $("#y7").css("display","none");
    });
    $("#ene").mouseout(function(){
        $("#ene").css({background:"#F3F3F3",color:""});
        $("#w7").css("display","none");
        $("#y7").css("display","block");
    });
    $("#eco").mouseover(function(){
        $("#eco").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w8").css("display","block");
        $("#y8").css("display","none");
    });
    $("#eco").mouseout(function(){
        $("#eco").css({background:"#F3F3F3",color:""});
        $("#w8").css("display","none");
        $("#y8").css("display","block");
    });
    $("#science").mouseover(function(){
        $("#science").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w9").css("display","block");
        $("#y9").css("display","none");
    });
    $("#science").mouseout(function(){
        $("#science").css({background:"#F3F3F3",color:""});
        $("#w9").css("display","none");
        $("#y9").css("display","block");
    });
    $("#edu").mouseover(function(){
        $("#edu").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w10").css("display","block");
        $("#y10").css("display","none");
    });
    $("#edu").mouseout(function(){
        $("#edu").css({background:"#F3F3F3",color:""});
        $("#w10").css("display","none");
        $("#y10").css("display","block");
    });
    $("#soc").mouseover(function(){
        $("#soc").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w11").css("display","block");
        $("#y11").css("display","none");
    });
    $("#soc").mouseout(function(){
        $("#soc").css({background:"#F3F3F3",color:""});
        $("#w11").css("display","none");
        $("#y11").css("display","block");
    });
    $("#ast").mouseover(function(){
        $("#ast").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w12").css("display","block");
        $("#y12").css("display","none");
    });
    $("#ast").mouseout(function(){
        $("#ast").css({background:"#F3F3F3",color:""});
        $("#w12").css("display","none");
        $("#y12").css("display","block");
    });
    $("#art").mouseover(function(){
        $("#art").css({background:"#E78C12",color:"#FFFFFF"});
        $("#w13").css("display","block");
        $("#y13").css("display","none");
    });
    $("#art").mouseout(function(){
        $("#art").css({background:"#F3F3F3",color:""});
        $("#w13").css("display","none");
        $("#y13").css("display","block");
    });
    $("#w14").css("display","none")
    $("#y14").css("display","block")
    $("#w15").css("display","none")
    $("#y15").css("display","block")
    $("#q1").click(function(){
        if($("#white1").css("display")=="none"){
            $("#q1_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black1").css("display","none");
            $("#white1").css("display","block");
            $("#q1").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black1").css("display")=="none"){
            $("#q1_text").css("display","none");
            $("#black1").css("display","block");
            $("#white1").css("display","none");
            $("#q1").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q2").click(function(){
        if($("#white2").css("display")=="none"){
            $("#q2_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black2").css("display","none");
            $("#white2").css("display","block");
            $("#q2").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black2").css("display")=="none"){
            $("#q2_text").css("display","none");
            $("#black2").css("display","block");
            $("#white2").css("display","none");
            $("#q2").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q3").click(function(){
        if($("#white3").css("display")=="none"){
            $("#q3_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black3").css("display","none");
            $("#white3").css("display","block");
            $("#q3").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black3").css("display")=="none"){
            $("#q3_text").css("display","none");
            $("#black3").css("display","block");
            $("#white3").css("display","none");
            $("#q3").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q4").click(function(){
        if($("#white4").css("display")=="none"){
            $("#q4_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black4").css("display","none");
            $("#white4").css("display","block");
            $("#q4").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black4").css("display")=="none"){
            $("#q4_text").css("display","none");
            $("#black4").css("display","block");
            $("#white4").css("display","none");
            $("#q4").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q5").click(function(){
        if($("#white5").css("display")=="none"){
            $("#q5_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black5").css("display","none");
            $("#white5").css("display","block");
            $("#q5").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black5").css("display")=="none"){
            $("#q5_text").css("display","none");
            $("#black5").css("display","block");
            $("#white5").css("display","none");
            $("#q5").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q6").click(function(){
        if($("#white6").css("display")=="none"){
            $("#q6_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black6").css("display","none");
            $("#white6").css("display","block");
            $("#q6").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black6").css("display")=="none"){
            $("#q6_text").css("display","none");
            $("#black6").css("display","block");
            $("#white6").css("display","none");
            $("#q6").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q7").click(function(){
        if($("#white7").css("display")=="none"){
            $("#q7_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black7").css("display","none");
            $("#white7").css("display","block");
            $("#q7").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black7").css("display")=="none"){
            $("#q7_text").css("display","none");
            $("#black7").css("display","block");
            $("#white7").css("display","none");
            $("#q7").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q8").click(function(){
        if($("#white8").css("display")=="none"){
            $("#q8_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black8").css("display","none");
            $("#white8").css("display","block");
            $("#q8").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black8").css("display")=="none"){
            $("#q8_text").css("display","none");
            $("#black8").css("display","block");
            $("#white8").css("display","none");
            $("#q8").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q9").click(function(){
        if($("#white9").css("display")=="none"){
            $("#q9_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black9").css("display","none");
            $("#white9").css("display","block");
            $("#q9").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black9").css("display")=="none"){
            $("#q9_text").css("display","none");
            $("#black9").css("display","block");
            $("#white9").css("display","none");
            $("#q9").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q10").click(function(){
        if($("#white10").css("display")=="none"){
            $("#q10_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black10").css("display","none");
            $("#white10").css("display","block");
            $("#q10").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black10").css("display")=="none"){
            $("#q10_text").css("display","none");
            $("#black10").css("display","block");
            $("#white10").css("display","none");
            $("#q10").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q11").click(function(){
        if($("#white11").css("display")=="none"){
            $("#q11_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black11").css("display","none");
            $("#white11").css("display","block");
            $("#q11").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black11").css("display")=="none"){
            $("#q11_text").css("display","none");
            $("#black11").css("display","block");
            $("#white11").css("display","none");
            $("#q11").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q12").click(function(){
        if($("#white12").css("display")=="none"){
            $("#q12_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black12").css("display","none");
            $("#white12").css("display","block");
            $("#q12").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black12").css("display")=="none"){
            $("#q12_text").css("display","none");
            $("#black12").css("display","block");
            $("#white12").css("display","none");
            $("#q12").css({background:"#F3F3F3",color:""});
        }
    });
    $("#q13").click(function(){
        if($("#white13").css("display")=="none"){
            $("#q13_text").css("display","block");

            var height_right = $("#middle_right").height();
            var height_left = $("#middle_left").height();
            if(height_left < height_right){
                $("#middle_left").height($("#middle_right").height());
            }
            $("#black13").css("display","none");
            $("#white13").css("display","block");
            $("#q13").css({background:"#3A70AF",color:"#FFFFFF"});
        }else if($("#black13").css("display")=="none"){
            $("#q13_text").css("display","none");
            $("#black13").css("display","block");
            $("#white13").css("display","none");
            $("#q13").css({background:"#F3F3F3",color:""});
        }
    });
});