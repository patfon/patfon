function over4(obj){
    obj.style.cssText="background-color:#FFFFFF;color:#111111;";
}
function out4(obj){
    obj.style.cssText="";
}
function over5(obj){
    obj.style.cssText="color:#2F5BA6";
}
function out5(obj){
    obj.style.cssText="";
}

$(document).ready(function(){
    $("#archive").css({background:"#FFFFFF",color:"#111111"});
    $("#reload1").css({background:"#2F5BA6",color:"#FFFFFF"});
    $("#down1,#down2,#up3,#content").css("display","block");
    $("#up1,#up2,#down3,#content3").css("display","none");
    $("#down1").click(function(){
        $("#down1").css("display","none");
        $("#up1").css("display","block");
        $("#content1").css("display","none");
    });
    $("#up1").click(function(){
        $("#down1").css("display","block");
        $("#up1").css("display","none");
        $("#content1").css("display","block");
    });
    $("#down2").click(function(){
        $("#down2").css("display","none");
        $("#up2").css("display","block");
        $("#content2").css("display","none");
    });
    $("#up2").click(function(){
        $("#down2").css("display","block");
        $("#up2").css("display","none");
        $("#content2").css("display","block");
    });
    $("#down3").click(function(){
        $("#down3").css("display","none");
        $("#up3").css("display","block");
        $("#content3").css("display","none");
    });
    $("#up3").click(function(){
        $("#down3").css("display","block");
        $("#up3").css("display","none");
        $("#content3").css("display","block");
    });
});