<?php include 'includes/general/header.php'; ?>
<?php include 'classes/connection.php'; ?>
<?php include 'functions/index.php'; ?>

    <?php include 'includes/general/topmenu.php'; ?>

        <div class="middle"><a>
            </a>
            <div class="m_top" style="margin-left: 10px;"><a>
                </a>
                
                <?php include 'includes/home/left_side.php'; ?>

                <div class="m_top_right">
                   
                    <?php include 'includes/home/slides.php'; ?>

                    <div class="clear"></div>
                   
                    <?php include 'includes/home/articles.php'; ?>

                   
                </div>
                <div class="clear"></div>
            </div>

            <div class="img_bg"></div>           

            <?php include 'includes/home/journals.php'; ?>

            <div class="img_bg"></div>

            <?php include 'includes/home/about.php'; ?>
            <?php include 'includes/home/testimonials.php'; ?>

            
        </div>
      
    
<?php include 'includes/general/footer.php'; ?>
