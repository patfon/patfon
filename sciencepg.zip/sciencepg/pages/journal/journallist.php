<?php include '../../includes/general/header.php'; ?>

    <?php include '../../includes/general/topmenu.php'; ?>

        <div class="special_issue"><a>
            </a><div class="issue_title"><a></a><a href="javascript:void(0);">Journals</a></div>
            <div class="propose">
                <div class="tit" onmouseover="over2(this)" onmouseout="out2(this)"><a href="/journal/journallist" id="a1">Browse by Subject</a>
                    
                </div>

                <div class="separater">|</div>

                <div class="tit" onmouseover="over3(this)" onmouseout="out3(this)"><a href="/journal/journallistbytitle" id="a2">Browse by Title</a>
                </div>

            </div>
        </div>
        <div class="middle">
              
                <?php include '../../includes/journal/left_side.php'; ?>

                <?php include '../../includes/journal/journallist.php'; ?>
                
                <div class="clear"></div>
        </div>
      
    
<?php include '../../includes/general/footer.php'; ?>
