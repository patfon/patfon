function  checkJudgeName(){
	var name = $("#signUpInfologinName").val();
    if(name!=""){
        $.ajax({
            type: "POST",
            url: "controller/user/index.php",
            dataType: "html", //expect html to be returned  
            data: {
                check:name
            },
            success: function(data) { 
                if($.trim(data)=="0"){
                            console.log('Registered...');
                          $('#createacctbut').attr('disabled','disabled'); 
                          $("#box-tabs").show();
                          $("#waringMsg2").html("The user name has been registered, please choose another one.<br/>");
                          window.location.href='#top';
                          }else{
                              console.log('nothing...');
                            $("#waringMsg2").html("");
                            $("#box-tabs").hide();
                            $('#createacctbut').removeAttr('disabled');
                            
                           }
               console.log('Answer:'+data);
            }
   });
   	 
     }
   }

   function  checkJudgeMail(){
	var name = $("#personInfoemail1").val();
    if(name!=""){
        $.ajax({
            type: "POST",
            url: "controller/user/index.php",
            dataType: "html", //expect html to be returned  
            data: {
                checkmail:name
            },
            success: function(data) { 
                if($.trim(data)=="0"){
                         console.log('Registered mail...');
                          $('#createacctbut').attr('disabled','disabled'); 
                          $("#box-tabs").show();
                          $("#waringMsg3").html("The email has been registered, please choose another one.<br/>");
                          window.location.href='#top';
                          }else{
                              console.log('nothing in mail...');
                            $("#waringMsg3").html("");
                            $("#box-tabs").hide();
                            $('#createacctbut').removeAttr('disabled');
                            
                           }
               console.log('Answer:'+data);
            }
   });
   	 
     }
   }

     


$(document).on('keyup','#signUpInfologinName',function(e){ 
    checkJudgeName();
}); 

$(document).on('keyup','#personInfoemail1',function(e){ 
    checkJudgeMail();
}); 

$(document).ready(function() {
	$("#box-tabs").hide();
	
	//$("#signUpInfologinName").blur(checkJudgeName);
	
	$(document).on('click','#createacctbut',function(e){
		var msg = "";
		
		var name = $("#signUpInfologinName").val().trim();
	
		var pass1 = $("#signUpInfoplainPassword").val().trim();
		
		var repass = $("#rePassword").val().trim();
		
		var fist = $("#personInfofirstName").val().trim();
	
		var last = $("#personInfolastName").val().trim();
		
		var email = $("#personInfoemail1").val().trim();
		
		var email2 = $("#personInfoemail2").val().trim();
		
		var personInfoemail1 = $("#personInfoemail1").val().trim();
		var personInfotelephone1= $("#personInfotelephone1").val().trim();
		var country = $("#countryId").val().trim();
	
		//var verCode = $("#verCode").val().trim();
		var affiliation = $("#personInfoAffiliation").val().trim();
		var city = $("#personInfoCity").val();
		var stateOrProvince = $("#personInfoStateOrProvince").val().trim();

		if (name == "") {
			msg += "Username is required<br>";
		}
		if (pass1 == "") {
			msg += "Password is required <br>";
		}

		if (repass == "") {
			msg += "Re-enter password is required<br>";
		} else if (pass1 != repass) {
			msg += "Input the same password<br>";
		}
		if (fist == "") {
			msg += "First name is required <br>";
		}
		if (last == null || last == "") {
			msg += "Last name is required<br>";
		}


		var reg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (email == "") {
			msg += "Email is required <br>";
		} else {
			if (!reg.test(email)) {
				msg += "Email incorrect <br>";
			}
		}
		if (email2 == "") {
			msg += "Secondary Email is required <br>";
		} else {
			if (!reg.test(email2)) {
				msg += "Secondary Email incorrect <br>";
			}
		}
		if(personInfotelephone1=="")
			{
			msg +="Area Code + Mobile Phone: is required <br>";
			}

		if (affiliation == "") {
			msg += "Affiliation is required <br/>";
		}
		if (city == "") {
			msg += "City is required <br/>";
		}
		if (stateOrProvince == "") {
			msg += "State/Province is required <br/>";
		}
		if (country == 0) {
			msg += "Country is required <br/>";
		}
        
        /**
		var arr=document.getElementsByName("research");
		var j=0;
		var i=0;
		for( i=0;i<arr.length;i++){
		  if(arr[i].checked){
		   j=j+1;
		 }
		}
		if(j==0||j>3){
			msg += "You should select 1-3 Areas.<br/>";
		 }
		**/
		
		
		
	
		
		
		
		
		
		setTimeout(function(){subForm(msg);},400);
	 })
});

function subForm(s){
	console.log("clicked...");
	
	var waringMsg2=$("#waringMsg2").text();
	var waringMsg3=$("#waringMsg3").text();
	if(s.length > 0||waringMsg2.length>0||waringMsg3.length>0){
		$("#box-tabs").show();
		$("#waringMsg").html(s);
		window.location.href='#top';
		return false;
	}else{
		$("#form1").submit();
		return true;
	}
	
}





