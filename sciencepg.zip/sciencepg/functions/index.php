<?php 

/*** functions **/


function getsubjects($con){

  $query = (" SELECT * FROM subject ");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[] = $r;
      }
   }
  
   return $src;
  
  }

  function getsubjectname($con,$id){

    $query = (" SELECT _name FROM subject WHERE id = $id ");
    $src = '';
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
      $src = $r['_name'];
      }
     }
    
     return $src;
    
    }  

    function getjournals($con,$id){

      $query = (" SELECT * FROM journal WHERE _subject =  $id");
      $src = array();
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src[] = $r;
          }
       }
      
       return $src;
      
      }

      function getjournalname($con,$id){

        $query = (" SELECT _name FROM journal WHERE id = $id ");
        $src = '';
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
          $src = $r['_name'];
          }
         }
        
         return $src;
        
        }  

   

      function getslides($con){

        $query = (" SELECT * FROM slides ");
        $src = array();
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src[] = $r;
            }
         }
        
         return $src;
        
        }

        function gettestimonials($con){

          $query = (" SELECT * FROM testimonials ");
          $src = array();
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src[] = $r;
              }
           }
          
           return $src;
          
          }

          
        function getnews($con){

          $query = (" SELECT * FROM news ");
          $src = array();
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src[] = $r;
              }
           }
          
           return $src;
          
          }

      

          function getpagecontent($con,$page){

            $query = (" SELECT _content FROM page WHERE _metadata = '$page' ");
            $src = '';
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                $src = $r['_content'];
                }
             }
            
             return $src;
            
            }     
            function checkpagecontent($con,$page){

              $query = (" SELECT * FROM page WHERE _metadata = '$page' ");
              $src = array();
              $result = mysqli_query($con,$query) or die(mysqli_error($con));
               if (mysqli_num_rows($result) > 0){
                 while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                  
                  $src[] = $r;
                  }
               }
              
               return $src;
              
              }     
             
  