<?php 

/*** functions **/


function getsubjects($con){

  $query = (" SELECT * FROM subject ");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[] = $r;
      }
   }
  
   return $src;
  
  }

  function getsubjectname($con,$id){

    $query = (" SELECT _name FROM subject WHERE id = $id ");
    $src = '';
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
      $src = $r['_name'];
      }
     }
    
     return $src;
    
    }  

    function delsubject($con,$id){

      $query = (" DELETE FROM subject WHERE id = $id ");
      if (mysqli_query($con, $query)) {
       $src = true;
       $_SESSION['msg']['deletesubject'] = 1;
      } else {
        echo "Error deleting record: " . mysqli_error($con);
       $src = false;
      }
       return $src;
      
      }  

      function getslides($con){

        $query = (" SELECT * FROM slides ");
        $src = array();
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src[] = $r;
            }
         }
        
         return $src;
        
        }

        function delslide($con,$id){

          $query = (" DELETE FROM slides WHERE id = $id ");
          if (mysqli_query($con, $query)) {
           $src = true;
           $_SESSION['msg']['deleteslide'] = 1;
          } else {
            echo "Error deleting record: " . mysqli_error($con);
           $src = false;
          }
           return $src;
          
          }  

          function crypto_rand_secure($min, $max)
          {
              $range = $max - $min;
              if ($range < 1) return $min; // not so random...
              $log = ceil(log($range, 2));
              $bytes = (int) ($log / 8) + 1; // length in bytes
              $bits = (int) $log + 1; // length in bits
              $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
              do {
                  $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
                  $rnd = $rnd & $filter; // discard irrelevant bits
              } while ($rnd > $range);
              return $min + $rnd;
          }
          
          function getToken($length)
          {
              $token = "";
              $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
              $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
              $codeAlphabet.= "0123456789";
              $max = strlen($codeAlphabet); // edited
          
              for ($i=0; $i < $length; $i++) {
                  $token .= $codeAlphabet[crypto_rand_secure(0, $max-1)];
              }
          
              return $token;
          } 

          function getpagecontent($con,$page){

            $query = (" SELECT _content FROM page WHERE _metadata = '$page' ");
            $src = '';
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                $src = $r['_content'];
                }
             }
            
             return $src;
            
            }     
            function checkpagecontent($con,$page){

              $query = (" SELECT * FROM page WHERE _metadata = '$page' ");
              $src = array();
              $result = mysqli_query($con,$query) or die(mysqli_error($con));
               if (mysqli_num_rows($result) > 0){
                 while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                  
                  $src[] = $r;
                  }
               }
              
               return $src;
              
              }     
             
  