<div class="middle_left" id="middle_left" style="height: 9527px;">
            <div class="left_fw" style="margin-left: 10px; ">
                <div class="browse_by_cate_t">Browse by Subject</div>
                <div class="journal_cate_fw">

                <?php $mysubjects = getsubjects($pdb); 
                            foreach ($mysubjects as $sub){
                            ?>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="<?php echo $myurl."pages/journal/journallist.php?catid=".$sub['id']; ?>">
                        <?php echo $sub['_name']; ?>
                        </a>
                    
                <?php } ?>       
                    
                </div>
                <div class="launch_new_journal">
                    <a href="/login">
                        <img src="<?php echo $myurl.'images/submit_btn.jpg'; ?>">
                    </a>
                </div>
                <div class="submit_paper">
                    <a href="/info/joinasaneditorialmember">
                        <img src="<?php echo $myurl.'images/editorial_btn.jpg'; ?>" style="width:255px;height:50px;">
                    </a>
                </div>
                <div class="become_reviewer">
                    <a href="/info/becomeareviewer">
                        <img src="<?php echo $myurl.'images/become_btn.jpg'; ?>">
                    </a>
                </div>
            </div>
        </div>