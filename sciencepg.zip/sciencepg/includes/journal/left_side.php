<div class="middle_left" id="middle_left" style="height: 9527px;">
            <div class="left_fw" style="margin-left: 10px; ">
                <div class="browse_by_cate_t">Browse by Subject</div>
                <div class="journal_cate_fw">
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=11">Biology and Life Sciences</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=70">Chemistry &amp; Chemical Engineering</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=15">Medicine, Health &amp; Food</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=12">Physics</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=51">Materials Science</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=14">Mathematics &amp; Statistics</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=23">Electrical &amp; Computer Science</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=16">Earth, Energy &amp; Environment</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=60">Architecture &amp; Civil Engineering</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=30">Transportation &amp; Logistics</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=18">Engineering &amp; Technology</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=17">Economics &amp; Management</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=19">Education</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=20">Social Sciences &amp; Psychology</a>
                    
                        <a class="journal_cate_item" style="width: 276px;text-indent:5px;" href="/journal/journalbycategory?categoryid=50">Arts, Literature &amp; Linguistics</a>
                    
                </div>
                <div class="launch_new_journal">
                    <a href="/login">
                        <img src="<?php echo $myurl.'images/submit_btn.jpg'; ?>">
                    </a>
                </div>
                <div class="submit_paper">
                    <a href="/info/joinasaneditorialmember">
                        <img src="<?php echo $myurl.'images/editorial_btn.jpg'; ?>" style="width:255px;height:50px;">
                    </a>
                </div>
                <div class="become_reviewer">
                    <a href="/info/becomeareviewer">
                        <img src="<?php echo $myurl.'images/become_btn.jpg'; ?>">
                    </a>
                </div>
            </div>
        </div>