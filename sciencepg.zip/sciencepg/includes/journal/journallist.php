<div class="middle_right" id="middle_right">
            <div class="right_nav">
                <a href="/home/index">Home</a> / Journals
            </div>

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Biology and Life Sciences</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=387">Advances in Applied Physiology

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=110">Advances in Biochemistry

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=216">Advances in Bioscience and Bioengineering

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=119">Agriculture, Forestry and Fisheries

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=218">American Journal of Agriculture and Forestry

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=375">American Journal of Biological and Environmental Statistics

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=655">American Journal of Biomedical and Life Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=219">American Journal of BioScience 

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=217">American Journal of Bioscience and Bioengineering

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=547" class="new_flag">American Journal of Entomology
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=118">American Journal of Life Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=612" class="new_flag">American Journal of Plant Biology
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=212">Animal and Veterinary Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=244" class="new_flag">Biochemistry and Molecular Biology
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=362">Biomedical Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=275" class="new_flag">Biomedical Statistics and Informatics
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=535" class="new_flag">Bioprocess Engineering
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=111">Cell Biology

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=243" class="new_flag">Chemical and Biomolecular Engineering
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=112">Computational Biology and Bioinformatics

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=231" class="new_flag">Ecology and Evolutionary Biology
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=117">European Journal of Biophysics

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                        </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=352">European Journal of Clinical and Biomedical Sciences
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=384">Frontiers in Environmental Microbiology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=232" class="new_flag">International Journal of Agricultural Economics
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=307" class="new_flag">International Journal of Animal Science and Technology
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=343">International Journal of Applied Agricultural Sciences
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=246" class="new_flag">International Journal of Biochemistry, Biophysics &amp; Molecular Biology
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=345">International Journal of Biomedical Engineering and Clinical Science
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=221">International Journal of Biomedical Materials Research
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=259">International Journal of Biomedical Science and Engineering
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=609" class="new_flag">International Journal of Bioorganic Chemistry
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=516">International Journal of Ecotoxicology and Ecobiology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=614" class="new_flag">International Journal of Food Science and Biotechnology
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=116">International Journal of Genetics and Genomics
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=396" class="new_flag">International Journal of Microbiology and Biotechnology
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=207" class="new_flag">International Journal of Natural Resource Ecology and Management  
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=330">International Journal of Pharmacy and Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=170" class="new_flag">International Journal of Psychological and Brain Sciences
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=320">Journal of Diseases and Medicinal Plants
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=329">Journal of Drug Design and Medicinal Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=215">Journal of Plant Sciences
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=211">Plant
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=540" class="new_flag">World Journal of Food Science and Technology
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Chemistry &amp; Chemical Engineering</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=110">Advances in Biochemistry

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=227">American Journal of Applied Chemistry

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=224">American Journal of Chemical Engineering

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=341">American Journal of Heterocyclic Chemistry

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=128">American Journal of Physical Chemistry

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=316">American Journal of Polymer Science and Technology

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=244" class="new_flag">Biochemistry and Molecular Biology
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=243" class="new_flag">Chemical and Biomolecular Engineering
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=607" class="new_flag">Colloid and Surface Science
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=246" class="new_flag">International Journal of Biochemistry, Biophysics &amp; Molecular Biology
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=609" class="new_flag">International Journal of Bioorganic Chemistry
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=228">International Journal of Computational and Theoretical Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=330">International Journal of Pharmacy and Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=329">Journal of Drug Design and Medicinal Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=601" class="new_flag">Journal of Energy, Environmental &amp; Chemical Engineering 
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=121">Modern Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=223">Science Journal of Analytical Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=125">Science Journal of Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=206" class="new_flag">World Journal of Applied Chemistry
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=540" class="new_flag">World Journal of Food Science and Technology
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Medicine, Health &amp; Food</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=256">Advances in Surgical Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=655">American Journal of Biomedical and Life Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=254">American Journal of Clinical and Experimental Medicine

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=656">American Journal of Health Research

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=252">American Journal of Internal Medicine

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=235" class="new_flag">American Journal of Laboratory Medicine
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=152">American Journal of Nursing Science

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=380">American Journal of Pediatrics

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=653">American Journal of Psychiatry and Neuroscience 

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=362">Biomedical Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=275" class="new_flag">Biomedical Statistics and Informatics
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=158">Cancer Research Journal

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=279" class="new_flag">Cardiology and Cardiovascular Research
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=326">Central African Journal of Public Health

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=151">Clinical Medicine Research

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=271" class="new_flag">Clinical Neurology and Neuroscience
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=352">European Journal of Clinical and Biomedical Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=651">European Journal of Preventive Medicine

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=345">International Journal of Biomedical Engineering and Clinical Science

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=221">International Journal of Biomedical Materials Research

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=259">International Journal of Biomedical Science and Engineering

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=355">International Journal of Cardiovascular and Thoracic Surgery

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=283" class="new_flag">International Journal of Chinese Medicine
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=361">International Journal of Clinical and Developmental Anatomy

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=335" class="new_flag">International Journal of Clinical and Experimental Medical Sciences
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=273" class="new_flag">International Journal of Clinical Oncology and Cancer Research
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=368">International Journal of Clinical Oral and Maxillofacial Surgery

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=334">International Journal of Dental Medicine

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=278" class="new_flag">International Journal of Diabetes and Endocrinology
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=614" class="new_flag">International Journal of Food Science and Biotechnology
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=116">International Journal of Genetics and Genomics
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=288" class="new_flag">International Journal of Health Economics and Policy
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=327">International Journal of HIV/AIDS Prevention, Education and Behavioural Science
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=314">International Journal of Homeopathy &amp; Natural Medicines
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=115">International Journal of Immunology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=280" class="new_flag">International Journal of Infectious Diseases and Therapy
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=156">International Journal of Medical Imaging
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=391">International Journal of Neurologic Physical Therapy
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=153">International Journal of Nutrition and Food Sciences
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=230" class="new_flag">International Journal of Ophthalmology &amp; Visual Science
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=373">International Journal of Otorhinolaryngology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=330">International Journal of Pharmacy and Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=170" class="new_flag">International Journal of Psychological and Brain Sciences
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=257">Journal of Anesthesiology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=654">Journal of Cancer Treatment and Research
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=320">Journal of Diseases and Medicinal Plants
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=329">Journal of Drug Design and Medicinal Chemistry
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=378">Journal of Family Medicine and Health Care
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=154">Journal of Food and Nutrition Sciences
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=255">Journal of Gynecology and Obstetrics
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=344">Journal of Health and Environmental Research
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=253">Journal of Surgery
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=321">Radiation Science and Technology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=234" class="new_flag">Rehabilitation Sciences
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=159">Science Journal of Clinical Medicine
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=251">Science Journal of Public Health
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=540" class="new_flag">World Journal of Food Science and Technology
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=287" class="new_flag">World Journal of Public Health
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Physics</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=309">American Journal of Aerospace Engineering
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=301">American Journal of Astronomy and Astrophysics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=225">American Journal of Electromagnetics and Applications
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=248" class="new_flag">American Journal of Mechanical and Industrial Engineering
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=525" class="new_flag">American Journal of Mechanical and Materials Engineering
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=621">American Journal of Mechanics and Applications 
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=122">American Journal of Modern Physics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=226">American Journal of Nano Research and Applications
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=359">American Journal of Nanosciences
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=127">American Journal of Optics and Photonics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=622">American Journal of Physics and Applications
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=619" class="new_flag">Engineering Science
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=117">European Journal of Biophysics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=382">Fluid Mechanics
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=322">International Journal of Applied Mathematics and Theoretical Physics
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=302">International Journal of Astrophysics and Space Science
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=332">International Journal of Electrical Components and Energy Conversion
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=315">International Journal of Fluid Mechanics &amp; Thermal Sciences
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=124">International Journal of High Energy Physics
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=220">International Journal of Mechanical Engineering and Applications
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=356">Nanoscience and Nanometrology
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=300" class="new_flag">Nuclear Science
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=126">Optics
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=321">Radiation Science and Technology
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=200" class="new_flag">World Journal of Applied Physics
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Materials Science</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=129">Advances in Materials

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=150" class="new_flag">American Journal of Materials Synthesis and Processing
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=525" class="new_flag">American Journal of Mechanical and Materials Engineering
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=226">American Journal of Nano Research and Applications

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=359">American Journal of Nanosciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=619" class="new_flag">Engineering Science
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=221">International Journal of Biomedical Materials Research
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=123">International Journal of Materials Science and Applications
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=354">Journal of Photonic Materials and Technology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=356">Nanoscience and Nanometrology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Mathematics &amp; Statistics</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=148">American Journal of Applied Mathematics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=603" class="new_flag">American Journal of Data Mining and Knowledge Discovery 
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=616" class="new_flag">American Journal of Mathematical and Computer Modelling
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=146">American Journal of Theoretical and Applied Statistics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=147">Applied and Computational Mathematics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=275" class="new_flag">Biomedical Statistics and Informatics
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=322">International Journal of Applied Mathematics and Theoretical Physics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=367">International Journal of Data Science and Analysis
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=605" class="new_flag">International Journal of Discrete Mathematics
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=353">International Journal of Management and Fuzzy Systems
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=379">International Journal of Statistical Distributions and Applications
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=245" class="new_flag">International Journal of Systems Science and Applied Mathematics
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=347">International Journal of Theoretical and Applied Mathematics
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=390">International Journal on Data Science and Technology
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=389">Mathematical Modelling and Applications
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=247" class="new_flag">Mathematics and Computer Science
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=348">Mathematics Letters
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=141">Pure and Applied Mathematics Journal
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=149">Science Journal of Applied Mathematics and Statistics
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Electrical &amp; Computer Science</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=131">Advances in Networks

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=317">Advances in Wireless Communications and Networks

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=148">American Journal of Applied Mathematics

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=542" class="new_flag">American Journal of Artificial Intelligence
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=303" class="new_flag">American Journal of Computer Science and Technology
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=603" class="new_flag">American Journal of Data Mining and Knowledge Discovery 
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=165">American Journal of Electrical Power and Energy Systems

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=225">American Journal of Electromagnetics and Applications

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=236">American Journal of Embedded Systems and Applications

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=616" class="new_flag">American Journal of Mathematical and Computer Modelling
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=248" class="new_flag">American Journal of Mechanical and Industrial Engineering
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=621">American Journal of Mechanics and Applications 

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=132">American Journal of Networks and Communications

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=339">American Journal of Neural Networks and Applications

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=104" class="new_flag">American Journal of Operations Management and Information Systems
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=138">American Journal of Remote Sensing

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=137">American Journal of Software Engineering and Applications

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=147">Applied and Computational Mathematics

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=134">Automation, Control and Intelligent Systems

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=275" class="new_flag">Biomedical Statistics and Informatics
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=139">Communications

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=112">Computational Biology and Bioinformatics
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=619" class="new_flag">Engineering Science
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=367">International Journal of Data Science and Analysis
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=605" class="new_flag">International Journal of Discrete Mathematics
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=332">International Journal of Electrical Components and Energy Conversion
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=210" class="new_flag">International Journal of Industrial and Manufacturing Systems Engineering
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=517">International Journal of Information and Communication Sciences
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=135">International Journal of Intelligent Information Systems
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=156">International Journal of Medical Imaging
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=230" class="new_flag">International Journal of Ophthalmology &amp; Visual Science
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=130">International Journal of Sensors and Sensor Networks
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=346">International Journal of Sustainability Management and Information Technologies
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=245" class="new_flag">International Journal of Systems Science and Applied Mathematics
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=133">International Journal of Wireless Communications and Mobile Computing
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=390">International Journal on Data Science and Technology
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=238">Internet of Things and Cloud Computing
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=239">Journal of Electrical and Electronic Engineering
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=604" class="new_flag">Machine Learning Research
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=247" class="new_flag">Mathematics and Computer Science
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=136">Science Journal of Circuits, Systems and Signal Processing
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=237">Software Engineering
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Earth, Energy &amp; Environment</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=295" class="new_flag">American  Journal of Environmental and Resource Economics  
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=375">American Journal of Biological and Environmental Statistics

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=165">American Journal of Electrical Power and Energy Systems

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=168">American Journal of Energy Engineering

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=163">American Journal of Environmental Protection

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=529" class="new_flag">American Journal of Environmental Science and Engineering
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=363">American Journal of Modern Energy

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=369">American Journal of Water Science and Engineering

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=161">Earth Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=619" class="new_flag">Engineering Science
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=384">Frontiers in Environmental Microbiology

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=267">Hydrology

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=349">International Journal of Economy, Energy and Environment

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=516">International Journal of Ecotoxicology and Ecobiology

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=332">International Journal of Electrical Components and Energy Conversion
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=602" class="new_flag">International Journal of Energy and Environmental Science
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=164">International Journal of Energy and Power Engineering
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=162">International Journal of Environmental Monitoring and Analysis
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=266">International Journal of Environmental Protection and Policy
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=371">International Journal of Mineral Processing and Extractive Metallurgy
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=268">International Journal of Oil, Gas and Coal Engineering
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=169">International Journal of Sustainable and Green Energy
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=617" class="new_flag">Journal of Civil, Construction and Environmental Engineering
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=167">Journal of Energy and Natural Resources
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=601" class="new_flag">Journal of Energy, Environmental &amp; Chemical Engineering 
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=344">Journal of Health and Environmental Research
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=166">Journal of Water Resources and Ocean Science
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=269">Science Journal of Energy Engineering
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Architecture &amp; Civil Engineering</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=229">American Journal of Civil Engineering

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=619" class="new_flag">Engineering Science
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=383">International Journal of Architecture, Arts and Applications

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=617" class="new_flag">Journal of Civil, Construction and Environmental Engineering
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=241" class="new_flag">Landscape Architecture and Regional Planning
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=242" class="new_flag">Urban and Regional Planning
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Transportation &amp; Logistics</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=187" class="new_flag">American Journal of Traffic and Transportation Engineering
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=619" class="new_flag">Engineering Science
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=514">International Journal of Transportation Engineering and Technology
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Engineering &amp; Technology</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=109" class="new_flag">Advances in Applied Sciences
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=323" class="new_flag">Advances in Sciences and Humanities
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=395">American Journal of Applied Scientific Research
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=102" class="new_flag">American Journal of Engineering and Technology Management
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=248" class="new_flag">American Journal of Mechanical and Industrial Engineering
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=525" class="new_flag">American Journal of Mechanical and Materials Engineering
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=339">American Journal of Neural Networks and Applications
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=325" class="new_flag">American Journal of Science, Engineering and Technology
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=535" class="new_flag">Bioprocess Engineering
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=108" class="new_flag">Engineering and Applied Sciences
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=619" class="new_flag">Engineering Science
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=522" class="new_flag">International Journal of Engineering Management
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=210" class="new_flag">International Journal of Industrial and Manufacturing Systems Engineering
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=220">International Journal of Mechanical Engineering and Applications
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=371">International Journal of Mineral Processing and Extractive Metallurgy
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=358">International Journal of Science and Qualitative Analysis
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=183">International Journal of Science, Technology and Society
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=381">International Journal of Sustainable Development Research
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=514">International Journal of Transportation Engineering and Technology
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=617" class="new_flag">Journal of Civil, Construction and Environmental Engineering
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=182">Science Discovery
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=180">Science Innovation
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=181">Science Research
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Economics &amp; Management</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=295" class="new_flag">American  Journal of Environmental and Resource Economics  
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=101" class="new_flag">American Journal of Management Science and Engineering
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=104" class="new_flag">American Journal of Operations Management and Information Systems
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=328">American Journal of Theoretical and Applied Business
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=177">Economics
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=324">European Business &amp; Management
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=366" class="new_flag">International Journal of Accounting, Finance and Risk Management
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=232" class="new_flag">International Journal of Agricultural Economics
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=178">International Journal of Business and Economics Research
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=172">International Journal of Economic Behavior and Organization
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=173">International Journal of Economics, Finance and Management Sciences
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=522" class="new_flag">International Journal of Engineering Management
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=393">International Journal of Finance and Banking Research
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=288" class="new_flag">International Journal of Health Economics and Policy
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=306" class="new_flag">International Journal of Law and Society
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=353">International Journal of Management and Fuzzy Systems
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=207" class="new_flag">International Journal of Natural Resource Ecology and Management  
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=346">International Journal of Sustainability Management and Information Technologies
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=297" class="new_flag">Journal of Business and  Economic Development   
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=171">Journal of Finance and Accounting
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=176">Journal of Human Resource Management
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=179">Journal of Investment and Management
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=304" class="new_flag">Journal of Political Science and International Relations
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=174">Journal of World Economic Research
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=175">Science Journal of Business and Management
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Education</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=196">Education Journal
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=296" class="new_flag">Higher Education Research  
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                           <a target="_blank" href="/journal/index?journalid=214" class="new_flag">International Journal of Education, Culture and Society
                                             
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=192">International Journal of Elementary Education
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                         
                                         <a target="_blank" class="new_flag" href="/journal/index?journalid=327">International Journal of HIV/AIDS Prevention, Education and Behavioural Science
                                           </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                                                        
                            
                                
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=193">International Journal of Secondary Education
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=372">International Journal of Vocational Education and Training Research
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                       
	                                        <a target="_blank" href="/journal/index?journalid=197">Science Journal of Education
   
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                            
                        
                            
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                          
	                                        <a target="_blank" href="/journal/index?journalid=240" class="new_flag">Teacher Education and Curriculum Studies
        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Social Sciences &amp; Psychology</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=323" class="new_flag">Advances in Sciences and Humanities
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=203">American Journal of Applied Psychology

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=155">American Journal of Sports Science

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=205">History Research

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=208">Humanities and Social Sciences

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=546" class="new_flag">International and Public Affairs&nbsp;&nbsp;
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=209">International Journal of Archaeology

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=214" class="new_flag">International Journal of Education, Culture and Society
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=520" class="new_flag">International Journal of European Studies
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=327">International Journal of HIV/AIDS Prevention, Education and Behavioural Science

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=306" class="new_flag">International Journal of Law and Society
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=204">International Journal of Philosophy
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=170" class="new_flag">International Journal of Psychological and Brain Sciences
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=188" class="new_flag">International Journal of Sports Science and Physical Education
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=381">International Journal of Sustainable Development Research
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=176">Journal of Human Resource Management
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=304" class="new_flag">Journal of Political Science and International Relations
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=545" class="new_flag">Journal of Public Policy and Administration&nbsp;&nbsp;
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=201">Psychology and Behavioral Sciences
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=202">Social Sciences
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            
                <div class="part_bg"></div>
            

            
            <div class="journalsandcate_list_item">
                <div class="category_name">Arts, Literature &amp; Linguistics</div>
                <div class="journalsandcate_list_fw">
                   
                   
                   
                    <div class="journalsandcate_list_left">
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=106" class="new_flag">American Journal of Arts and Design
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=199" class="new_flag">Arabic Language, Literature &amp; Culture
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=357">Communication and Linguistics Studies

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=195" class="new_flag">English Language, Literature &amp; Culture
	                                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="/journal/index?journalid=340">International Journal of Applied Linguistics and Translation

	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                            
	                            
                                                        
                            
                        
                    </div>

                    <div class="journalsandcate_list_right">
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=383">International Journal of Architecture, Arts and Applications
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=214" class="new_flag">International Journal of Education, Culture and Society
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=520" class="new_flag">International Journal of European Studies
                                       
                                            </a>
                                            <div class="clear"></div>
                                        
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=501">International Journal of Language and Linguistics
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                            
                                
                                    <div class="journalsandcate_item">
                                        
                                        
                                           
                                            <a target="_blank" href="/journal/index?journalid=502">International Journal of Literature and Arts
                                           
                                            </a>
                                            <div class="clear"></div>
                                        
                                    </div>
                                
                            
                            
                        
                        </div>
                    <div class="clear"></div>
                </div>
            </div>

            

            
            
            
            
            
        </div>