<div class="middle_right" id="middle_right">
                <div class="middle_right_title">
                <a href="/home/index">Home</a>&nbsp;/&nbsp;<a href="#">Services</a>&nbsp;/&nbsp;Contact Us</div>
                <div id="vol">
                    <div class="economics">Contact Us</div>
                    <div class="line2"></div>
                    <div class="middle_right_container">
                    
                      <form action="/info/addcontactus" method="post" id="form1" name="form1">
                        <div class="middle_right_science" style="height: 185px;">
                            <div class="middle_right_science1">SciencePG Support Center Email Addresses</div>
                            <div class="middle_right_science2">Journal:  <a href="mailto:journal@sciencepublishinggroup.com" target="_blank">journal@sciencepublishinggroup.com</a><br>Book:  <a href="mailto:book@sciencepublishinggroup.com" style="color:#fff;">book@sciencepublishinggroup.com</a><br>Special Issue:  <a href="mailto:special.issues@sciencepublishinggroup.com" target="_blank">special.issues@sciencepublishinggroup.com</a></div>
                        </div>
                        <div class="middle_right_you">You can also use the form below to submit your questions/suggestions:</div>
                        <div class="middle_right_line"></div>
                        <div class="middle_right_item">Items marked with ( * ) are necessary
                         <p id="info1"></p>
			             <p id="info2"></p>
			             <p id="info3"></p>
			             <p id="info4"></p>
			             <p id="info5"></p>
                        
                        
                        
                        </div>
                        <div class="clear"></div>
                        <div class="middle_right_name">Full Name:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_inp"><input type="text" class="middle_inp" id="firstName" name="contactUsInfo.firstName"></div>
                        <div class="clear"></div>
                        <div class="middle_right_name">E-mail:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_inp"><input type="text" class="middle_inp" id="email" name="contactUsInfo.email"></div>
                        <div class="clear"></div>
                        <div class="middle_right_name">Subject:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_inp">
                             <select class="middle_select" name="contactUsInfo.subject" id="subject">
                                <option value="Journal Information">Journal Information</option>
								<option value="Book Information">Book Information</option>
								<option value="Special Issue Information">Special Issue Information</option>
								<option value="Conference Information">Conference Information</option>
								<option value="Indexing Information">Indexing Information</option>
								<option value="Website Errors">Website Errors</option>
								<option value="Others">Others</option>
                            </select></div>
                        <div class="clear"></div>
                        <div class="middle_right_name">Message:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_textarea"><textarea id="message" name="contactUsInfo.message" style="border-style:none;resize:none;width:474px;height:104px;overflow-y:hidden;padding-left:10px;border:1px solid #cccccc;"></textarea></div>
                        <div class="clear"></div>
                        <div class="middle_right_name">Type the Code:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_inp2"><input type="text" class="middle_inp2" id="verCode" name="verCode"></div>
                        
                        <div class="vcode">
                        <img src="../common/rand" id="Image1" onclick="changeValidateCode(this)" style="width: 95px;height: 25px;cursor:pointer;">
                        </div>
                        <div class="vcode_hint"><a href="javascript:nchangeImg();">Can't read the image? click here to refresh</a></div>
                        <div class="clear"></div>
                        <a href="#" class="download" onclick="CheckForm()">Submit</a>
                        </form>
                    </div>
                    <div class="middle_right_container2">
                        <div style="font-size:20px;color:#33333;font-weight:bold;line-height:22px;">Contact Information</div>
                        <div style="font-size:14px;color:#333333;line-height:20px;margin-top:10px;"><b>Address:</b><br>548 FASHION AVENUE
NEW YORK, NY 10018
U.S.A.</div>
                        <div style="border-top:1px solid #E0DEDE;width:200px;height:0;margin-top:5px;"></div>
                        <div style="font-size:14px;color:#333333;line-height:20px;margin-top:10px;"><b>Telephone:</b><br>(001)347-688-8931</div>
                        <div style="border-top:1px solid #E0DEDE;width:200px;height:0;margin-top:5px;"></div>
                        <div style="font-size:14px;color:#333333;line-height:20px;margin-top:10px;"><b>Skype ID:</b><br>sciencepg</div>
                        <div style="border-top:1px solid #E0DEDE;width:200px;height:0;margin-top:5px;"></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>