<div class="body">
        <div class="head" >
            <div class="logo_bg">
            <a href="index.php">
            <img src="<?php echo $myurl.'images/spg_logo.png';?> " width="190px" height="59px" class="logo" border="0"></a>
            </div>
      
         <!-- Top Advert DIV -->
        <div class="title2" id="advGif" style="position: relative; overflow: hidden;">
                 
                <div style="height: 80px; width: 580px; position: absolute; top: 0px; left: -580px; display: none; z-index: 3; opacity: 1;">
                    <a href="#"><img src="<?php echo $myurl.'images/pic-2.jpg'; ?>" width="580px" height="80px" border="0"></a>
                </div>
                
                 <div style="height: 80px; width: 580px; position: absolute; top: 0px; left: 0px; display: block; z-index: 4; opacity: 1;">
                    <a href="<?php echo $myurl.'pages/news/newsinfo?articleid=308'; ?>"><img src="<?php echo $myurl.'images/pic-1.jpg'; ?> " width="580px" height="80px" border="0"></a>
                </div>
     		
     		  <div style="height: 80px; width: 580px; position: absolute; top: 0px; left: -580px; display: none; z-index: 3; opacity: 1;">
                    <a href="<?php echo $myurl.'pages/info/joinasaneditorialmember'; ?>"><img src="<?php echo $myurl.'images/pic-3.jpg'; ?>" width="580px" height="80px" border="0"></a>
                </div>
                
                
        </div>
        <!-- END Top Advert DIV  -->
           
            <!-- Login Or Register -->
            <div class="form">
                <form theme="simple" validate="true" method="post" action="<?php echo $myurl.'controller/user/index.php'; ?>" id="form">
                    <input type="hidden" name="roleType" value="200">
                    <input type="text" placeholder="Username" class="inp" name="loginName" maxlength="60" id="username">
                    <div class="login" id="login"><span class="log"><a href="javascript:login(this);">Login</a></span></div>
                    <div class="clear"></div>
                    <input type="password" placeholder="Password" class="inp" name="plainPassword" maxlength="32" id="password">
                    <div class="clear"></div>
                    <div class="login" id="register" style="margin-right: 90px; width: 300px; height: 50px; padding: 5px 0px 5px 30px;">
                    <label> Not in our System? </label>
                    <span class="log"><a class="btn btn-danger" href="register.php">Register</a></span><br>
                    
                    </div>
                    <div class="clear"></div>
                </form>
            </div>
            <!-- END Login Or Register  -->

            <div class="clear"></div>

            <div class="line" style="margin-top: 10px;"></div>

            <!-- Top Menu with Links -->
            <div class="row" style="margin-top: 10px;">
            <div class="tab" id="home"><a href="<?php echo $myurl.'index.php'; ?>">Home</a></div>
            <div class="tab" onmouseover="over(this)" onmouseout="out(this)" style="">
                <a href="<?php echo $myurl.'pages/journal/journallist.php'; ?>">Journals</a>
            </div>
           
            <div class="tab" id="news" style=""><a href="<?php echo $myurl.'pages/news/newslist.php'; ?> ">News</a></div>
        
            <div class="tab" id="news" onmouseover="over(this)" onmouseout="out(this)" style=""><a href="<?php echo $myurl.'login.php'; ?>" target="_blank">Submission</a></div>
             
             <div class="tab" id="news" onmouseover="over(this)" onmouseout="out(this)" style=""><a href="<?php echo $myurl.'pages/info/service.php'; ?>" target="_blank">Services</a></div>
           
            <div class="tab" id="news" onmouseover="over(this)" onmouseout="out(this)" style=""><a href="<?php echo $myurl.'pages/info/contactus.php'; ?>">Contact Us</a></div>
           
             
            
            <div class="tab" style="margin-left: 98px;">
             <form theme="simple" validate="true" name="form2" method="post" action="<?php echo $myurl.'controller/search.php'; ?>" id="form2">
             <input type="hidden" name="searchtypeId" value="1">
            <input type="text" value="" name="searchtext" id="searchtext" style="width:295px;height: 26px;  border: 1px solid #E0DEDE;border-right:0px;float: left;margin-top: 10px;" placeholder="Article Title" class="inp" maxlength="500">
            
             <div style="height: 28px;width: 1px;background-color: #F9F9F9;float: left;margin-top: 10px;border-top: 1px solid #E0DEDE;border-bottom: 1px solid #E0DEDE;">
             <div style="height: 20px;width: 1px;border-left:1px solid #E0DEDE; margin-top: 4px;"></div>
             </div>
             
            <a href="javascript:search();">
            <div style="height: 28px;width: 40px;border: 1px solid #E0DEDE;border-left:0px; background-color: #F9F9F9;float: left;margin-top: 10px;">
                <img src="images/search.png" style="height: 16px;width: 16px;margin-bottom:10px;margin-left: 0px;" border="0">
             </div>
             </a>
             </form>
            </div>
            </div>    
            <!-- END Top Menu with Links -->
            <a><div class="clear"></div>
        </a></div>