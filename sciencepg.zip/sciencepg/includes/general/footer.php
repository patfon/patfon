<div class="foot">
          <div class="foot_img"></div>
            <div class="itatic_image2"></div>
            <div class="foot_body">
                <div class="foot_title1">
                    <div class="t1">PUBLICATION SERVICES</div>
                    <div class="link">
                        <div class="pj"><a href="#">Journals</a></div>
                   
                        <div class="pj"><a href="#">Copyright</a></div>
                    </div>
                </div>
                <div class="foot_title1">
                    <div class="t1">JOIN US</div>
                    <div class="link">
                        <div class="pj"><a href="#">Join as an Editor-in-Chief</a></div>
                        <div class="pj"><a href="#">Join as an Editorial Member</a></div>
                        <div class="pj"><a href="#">Become a Reviewer</a></div>
                        <div class="pj"><a href="#">Qualification &amp; Requirement</a></div>
                        <div class="pj"><a href="#">Benefits &amp; Responsibilities</a></div>
                    </div>
                </div>

                <div class="foot_title1">
                    <div class="t1">RESOURCES</div>
                    <div class="link">
                        <div class="pj"><a href="#">Open Access</a></div>
                        <div class="pj"><a href="#">For Authors</a></div>
                     
                        <div class="pj"><a href="#">Article Processing Charges</a></div>
                    </div>
                </div>

              
                <div class="foot_title2">
                    <div class="t1">ADDRESS</div>
                    <div class="link2">Nigeria Publishing <br>no. 310 Johnson Street<br>Calabar<br>Nigeria.<br>Tel: (234)805-332-9089</div>
                </div>
                <div class="clear"></div>

                <div class="foot_line1"></div>

                <a href="#"><img src="<?php echo $myurl.'images/spg_logo.png'; ?>" width="190px" height="59px" class="foot_logo" border="0"></a>

                <div class="foot_line2"></div>

                <div class="foot_link">
                    <div class="follow">FOLLOW NigeriaPG</div>
                    <a href="#" target="_blank"><img src="<?php echo $myurl.'images/icon_f.png'; ?>" class="img_logo" border="0"></a>
                    <a href="#" target="_blank"><img src="<?php echo $myurl.'images/icon_t.png'; ?>" class="img_logo" border="0"></a>
                    <a href="#" target="_blank"><img src="<?php echo $myurl.'images/icon_g.png'; ?>" class="img_logo" border="0"></a>
                    <a href="#" target="_blank"><img src="<?php echo $myurl.'images/icon_l.png'; ?>" class="img_logo" border="0"></a>
                    
                    <div class="clear"></div>

                    <div class="footer">
                       
                        <a href="#">Terms &amp; Conditions</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                        <a href="#">Privacy Policy</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                        <a href="#">Feedback</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                        <a href="#">Services</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                        <a href="#">Contact Us</a>
                        <br><p style="margin-top:5px;">Copyright � 2012 -- 2018 � All rights reserved. Use of this Web site signifies your agreement to the terms and conditions.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  


</body>
</html>