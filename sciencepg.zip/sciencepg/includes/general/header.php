<?php 
 session_start();
 $documentroot = "sciencepg";
 $GLOBALS['myurl'] = "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/";
?>
<!DOCTYPE html>
<html>
<head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Nigerian Publishing Group</title>
        <link href="<?php echo $myurl.'images/littlelogo.gif'; ?> " rel="shortcut icon">
    
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/common.css'; ?>">
        <?php if ($_SERVER['REQUEST_URI'] === '/sciencepg/'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/home_body.css';?>">
        <?php } ?>
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/journallist.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal_body.css';?>">
        <?php } ?>
       <!--   <meta name="google-site-verification" content="coJF3qkXwBNBu5idbbheQnYgIl4NuyKH4tXrilPQdu0"> -->
        <meta name="Keywords" content="Nigerian | scientific current events | academic journals | peer reviewed journals | peer reviewed journal articles">
        <meta name="description" content="EDIT">
        
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery-1.9.1.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'lib/bootstrap/js/bootstrap.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.cycle.all.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.placeholder.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/common.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.slides.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/home.js'; ?>"></script>
       
    
        <script type="text/javascript">
          ///the login for article in home page
            function login(obj) {
                var username = $("#username").val();
                var password = $("#password").val();

                if (username == null || username == '') {
                    alert("please enter your username");
                    return false;
                }
                if (password == null || password == '') {
                    alert("please enter your password");
                    return false;
                }

                $("#form").submit();
            }
           ///the search for article in home page
            function search(){
            	 var searchtext = $("#searchtext").val();
                 if (searchtext==null||searchtext== '') {
                     alert("Please enter what you want to search");
                     return false;
                 }
                 $("#form2").submit();
            }
        </script>
        <!-- The slide show in Home page-->
        <script type="text/javascript">
            $(function(){           
                $("#slides").slidesjs({
                    width: 918,
                    height: 240,
                    navigation: {
                    effect: "fade"
                    },
                    pagination: {
                    effect: "fade"
                    },
                    effect: {
                    fade: {
                        speed: 400
                    }
                    }
                });
                var mw = $(".mbox").width()+10;
                var ml = $(".mbox").length; 
                $(".themes").width(mw*ml);
                $(".t_menu li").mouseover(function(){
                    var index = $(this).index();
                    $(".themes").animate({left:-mw*index,opacity:1},500);
                })
            });
        </script>
<!-- Testimonials slideshow -->
        <script type="text/javascript">
            window.setInterval("autoPlayJournalList()", 10000);

            $(function(){
                $('#testimonials').cycle({ 
                    fx: 'scrollHorz',
                    speed:    500,
                    timeout:  12000,
                    startingSlide: 0,
                    next: '.right_btn',
                    prev: '.left_btn'
                });
            })
        </script>
        <!-- end Testimonials slideshow -->
        <!-- -->
        <script type="text/javascript">
                $("#secondAdvGif").css("display", "block");
                $('#advGif').cycle({ 
                    fx: 'scrollHorz',
                    speed:    800,
                    timeout:  8000,
                    startingSlide: 0
                });
        </script>
    </head>

<body>