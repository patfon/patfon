<div class="middle_container12">
                <div class="left">
                    <div>Testimonials</div>
                    <div style="margin-top:10px;"><img src="images/testinonials_img.png"></div>
                </div>

                <div class="right" id="testimonials" style="position: relative; width: 1068px; height: 119px; overflow: hidden;">
                   
                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1;">
                        <span style="font-size:14px;font-weight:bold;"> Ruhul Amin</span>
                        <p style="margin-top:5px;">
                          SciencePG is an excellent platform for researchers especially young researchers. All departments of SciencePG like manuscript submission, payment, review and editorial body are highly communicative to authors. Their page set-up, typesetting, and website are well developed. I hope one day Science PG will be one of the most qualified and quality oriented publishers in the world.
                        </p>
                    </div>
                   
                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 119px;">
                        <span style="font-size:14px;font-weight:bold;">Souhir Sghayar</span>
                        <p style="margin-top:5px;">
                            Science Publishing Group is the promising publisher for science generation to share knowledge in a fast and precise way. Thank you so much for Science Publishing Group. It�s a great honor that I am the editor/reviewer of SciencePG. Great appreciations to your effort for that the journals of SciencePG are in excellent scientific form. When I join SciencePG, I practice my life sciences skills, I increase these skills and I make them update when I review a new paper. Particularly pleased to be working with staff SciencePG. I wish them continued success in life and work! SciencePG is very effective and user-friendly journal publication site. I will recommend everyone to publish.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 79px;">
                        <span style="font-size:14px;font-weight:bold;">Eric Mutegoa</span>
                        <p style="margin-top:5px;">
                            Science Publishing Group is the promising publisher for science generation to share knowledge in a fast and precise way that brings together all scientists in the world. To authors, they will get quicker response and affordable publication fee. Hope SciencePG become the most successive and cited publishers in the world in the near future. 
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 119px;">
                        <span style="font-size:14px;font-weight:bold;">M.C. Lidianys Mar�a Lewis Luj�n</span>
                        <p style="margin-top:5px;">
                            Virtual publications have become a great opportunity for a person to have access to scientific articles in prestigious journals. In this regard, International Journal of Nutrition and Food Science of Science Publishing Group, is a great opportunity for scientific research in LIBAF- Rubio Pharma Mexico to be known anywhere in the world and to establish contacts with like-minded professionals. My experience is that SciencePG is an excellent publisher with high level of quality and professionalism. The challenge is to maintain the virtual publication, constantly renew and ensure that scientific articles soar higher scientific quality, so that the journal reaches a high standard in the very near future.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 99px;">
                        <span style="font-size:14px;font-weight:bold;">Branko Karad�ic</span>
                        <p style="margin-top:5px;">
                            SciencePG is a well-organized and very ambitious publishing house. The concept of journals is based on contemporary scientific problems in biology and life sciences, physics, mathematics and statistics,� Computational Biology and Bioinformatics is a promising journal for scientific computing problems. The Editorial board and competent referees assure high-quality publications.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 79px;">
                        <span style="font-size:14px;font-weight:bold;">Dessie Tarekegn</span>
                        <p style="margin-top:5px;">
                            SciencePG is a publisher with inspiring way of communication and timely response, depth professional comment and well organized activity considering the future. You are dedicated group striving for astonishing future. I hope I will see it one of the best top 5 publisher in the world within 2 years.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 79px;">
                        <span style="font-size:14px;font-weight:bold;">Katsuhiro Hitomi</span>
                        <p style="margin-top:5px;">
                            Publishing articles in SciencePG, reviews for a manuscript were returned to authors within several days, accurately pointing out the insufficiency and the distortion of interpretation of the results, and giving suggestions for better publishing in the journal. We expect that SciencePG would be widely recognized as one of the valuable journals for researchers.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 99px;">
                        <span style="font-size:14px;font-weight:bold;">Dr. Adil Jamal</span>
                        <p style="margin-top:5px;">
                            Overall SciencePG has numerous categories/ subjects disciplines which make authors to send and publish their manuscripts conveniently. The wonderful experience about SciencePG is that I got paper reviewed within shortest duration of 10 working days with valuable suggestions and recommendations. I expect that this journal will get high index/ citation in next few years with upsurge number of journal volumes per annum.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 59px;">
                        <span style="font-size:14px;font-weight:bold;">Siham Balla</span>
                        <p style="margin-top:5px;">
                            SciencePG is a promising group with feasible and flexible communication. Hope it has a promising future.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 99px;">
                        <span style="font-size:14px;font-weight:bold;">Zhanhui Wang</span>
                        <p style="margin-top:5px;">
                            SciencePG is very high efficient in publishing the papers within one month only. It is easier and faster for people to communicate their researches. It takes only about two weeks for us to get the feedbacks of the reviewers� results. It is the fastest magazine in publishing the papers. Please attract more and more people to submit their high quality manuscripts to you.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 79px;">
                        <span style="font-size:14px;font-weight:bold;">Wakene Tigre</span>
                        <p style="margin-top:5px;">
                            I appreciate the dedication of SciencePG, because your concerns are very high; your actions and responses are very quick. I believe you have experienced reviewers. With this nice work, I expect the group will have many members in the near future.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 59px;">
                        <span style="font-size:14px;font-weight:bold;">Mouaaz Nahas</span>
                        <p style="margin-top:5px;">
                            SciencePG is excellent. It has the very quick response and the easy, reliable manuscript submission/tracking system.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 79px;">
                        <span style="font-size:14px;font-weight:bold;">Agneta Grimby</span>
                        <p style="margin-top:5px;">
                            SciencePG is very good with quick, clear and personal responses/reactions. The editorial assistant has been of great help. We hope to be able to publish more papers in SciencePG journals!
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 99px;">
                        <span style="font-size:14px;font-weight:bold;">Mandeep Nathial</span>
                        <p style="margin-top:5px;">
                            Before sending my research work for publication, I always give a detailed look on the Publisher/organization. I went through the exited published work in journals and felt the stuff. I decided to go for the publication in this journal only. Apart from the quick publication I found it really valuably reviewed and that makes me learn also. Thanking the Org. for Great publications.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 79px;">
                        <span style="font-size:14px;font-weight:bold;">Vitaly Ovchinnikov</span>
                        <p style="margin-top:5px;">
                            I am a member of Editorial Board of AJPC journal, which is in SciencePG-structure. I believe it is full corresponds with my nice relation to SciencePG. I published four my paper in this Group and hope to follow this way in the future. I wish for SciencePG the best future!
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -1068px; display: none; z-index: 21; opacity: 1; height: 79px;">
                        <span style="font-size:14px;font-weight:bold;">Manobendo Sarker</span>
                        <p style="margin-top:5px;">
                            It's my first publishing in this journal site. It is a great site to publish research work without any confusion. Moreover, it is clear to me that overall evaluation of SciencePG is better than any other publishing sites.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: -998.678px; display: block; z-index: 21; opacity: 1; height: 99px;">
                        <span style="font-size:14px;font-weight:bold;">Muluken Mekuyie</span>
                        <p style="margin-top:5px;">
                            Every researcher, who needs to disseminate his knowledge across the world especially in developing countries, should prefer SciencePG because it is the fastest, cheapest for charging the publication handling fee and most importantly it is the open access model. I have got a number of experiences how to write research paper etc. I strongly believe that SciencePG would be the known publisher and preferable by every researcher to disseminate his knowledge across the world as the journal is open access model, fastest and cheap.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: 69.257px; display: block; z-index: 22; opacity: 1; height: 99px;">
                        <span style="font-size:14px;font-weight:bold;">Abiodun Adekunle Ogunola</span>
                        <p style="margin-top:5px;">
                            This is my first time of publishing with SciencePG but with the approach that they have adopted about getting feedbacks from authors. It is a welcome experience and I hope it is the beginning of a great relationship with the outfit. Hope it's the beginning of something wonderful. Keep up the good work. It's a timely, cost-efficient and cheap scholarly publisher.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: 0px; display: none; z-index: 3;">
                        <span style="font-size:14px;font-weight:bold;">Williams Chintem D.G</span>
                        <p style="margin-top:5px;">
                            SciencePG has made me to be courageous and fast in paper reading and review, which had changed my focus and habit toward publishing paper and article. SciencePG is really a good publishing group. SciencePG is very fast in replying mails and it was really a nice experience. My expectation is that when I graduate as a master holder in Biochemistry, I will love to be a reviewer with SciencePG. Thank you.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: 0px; display: none; z-index: 2;">
                        <span style="font-size:14px;font-weight:bold;">Tetsuro Yanaseko</span>
                        <p style="margin-top:5px;">
                            The advantages of the journals of SciencePG are quick response and fast peer review, so I think these journals are very significant for students and young researchers.
                        </p>
                    </div>

                    <div style="width: 1068px; position: absolute; top: 0px; left: 0px; display: none; z-index: 1;">
                        <span style="font-size:14px;font-weight:bold;">Loreto Mar�a Bravo Zanoguera</span>
                        <p style="margin-top:5px;">
                            The academic evaluation of the article was appropriate, the comments were relevant. Results of the evaluation were received quickly. In a short period of time, communication is agile. Publicize databases where the magazine is included in international catalogs. That the publication of the article be quick. That the form of payment is simple and we receive the invoice immediately.
                        </p>
                    </div>
                </div>
                <div class="clear"></div>
                <a href="javascript:void(0);"><div class="right_btn"><img src="images/right_arrow.png"></div></a>
                <a href="javascript:void(0);"><div class="left_btn"><img src="images/left_arrow.png"></div></a>
            </div>