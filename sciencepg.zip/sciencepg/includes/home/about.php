<div class="middle_sci">Science Publishing Group</div>
            <div class="middle_sci_text"><?php echo getpagecontent($pdb,'about_title'); ?></div>

            <div class="middle_container9" style="width:416px;height:300px;">
                <div class="middle_about">About us</div>
                <div class="middle_bg"></div>
                <div class="middle_sci2" style="width:375px;height:auto;">
                <?php echo getpagecontent($pdb,'about_story'); ?>
                  </div>
            </div>

            <div class="middle_container10" style="width:416px;height:300px;">
                <div class="middle_about">Our mission</div>
                <div class="middle_bg" style="width:110px;"></div>
                <div class="middle_sci2" style="width:377px;height:auto;">
                <?php echo getpagecontent($pdb,'about_mission'); ?>
                </div>
            </div>

            <div class="middle_container11">
                <div class="middle_tit">Advantages</div>
                <div class="middle_bg2">Fast Publication</div>
                <div class="middle_bg3">Open Access</div>
                <div class="clear"></div>
                <div class="middle_bg4">High Visibility</div>
                <div class="middle_bg5">Peer Review</div>
                <div class="clear"></div>
                <div class="middle_tit2">Useful Links</div>
                <div class="middle_tab"><a href="http://download.sciencepublishinggroup.com/SciencePublishingGroup_Manuscript_Template.pdf">Download Manuscript Template</a></div>
                <div class="middle_tab"><a href="/info/ordering">Order the Hard Copy</a></div>
                <div class="middle_tab"><a href="/news/newsinfo?articleid=43">Journal Indexing</a></div>
                <div class="middle_tab"><a href="/info/recommendtolibrary">Recommend to Library</a></div>
            </div>
            <div class="clear"></div>