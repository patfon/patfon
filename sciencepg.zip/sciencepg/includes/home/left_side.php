<div class="m_top_left" style="width: 300px;"><a>
                    </a><div class="journals_nav"><a>
                        <div class="journals_nav_title">Journals by Subject</div>
                        
                            </a><div class="journal_item" style="width: 268px;margin-left: 8px;"><a>
                                </a><a href="/journal/journalbycategory?categoryid=11">Biology and Life Sciences</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=70">Chemistry &amp; Chemical Engineering</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=15">Medicine, Health &amp; Food</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=12">Physics</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=51">Materials Science</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=14">Mathematics &amp; Statistics</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=23">Electrical &amp; Computer Science</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=16">Earth, Energy &amp; Environment</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=60">Architecture &amp; Civil Engineering</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=30">Transportation &amp; Logistics</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=18">Engineering &amp; Technology</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=17">Economics &amp; Management</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=19">Education</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=20">Social Sciences &amp; Psychology</a>
                            </div>
                        
                            <div class="journal_item" style="width: 268px;margin-left: 8px;">
                                <a href="/journal/journalbycategory?categoryid=50">Arts, Literature &amp; Linguistics</a>
                            </div>
                        
                    </div>
                    <div class="submit_btn">
                        <a href="/login">
                            <img src="images/submit_btn.jpg">
                        </a>
                    </div>
                    <div class="propose_btn">
                        <a href="/specialissue/proposal">
                            <img src="images/propose_btn.jpg">
                        </a>
                    </div>
                    <div class="reviewer_btn">
                        <a href="/info/becomeareviewer">
                            <img src="images/reviewer_btn.jpg">
                        </a>
                    </div>
                </div>