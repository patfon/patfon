<div class="m_top_left" style="width: 300px;"><a>
                    </a>
                    <div class="journals_nav"><a>
                        <div class="journals_nav_title">Journals by Subject</div>
                        
                            </a>
                            <?php $mysubjects = getsubjects($pdb); 
                            foreach ($mysubjects as $sub){
                            ?>
                            <div class="journal_item" style="width: 268px;margin-left: 8px;"><a>
                                </a><a href="<?php echo $myurl."pages/journal/journallist.php?catid=".$sub['id']; ?>"> 
                                <?php echo $sub['_name']; ?>
                                </a>
                            </div>
                            <?php } ?>
                            
                        
                    </div>
                    <div class="submit_btn">
                        <a href="<?php echo $myurl."login.php"; ?>">
                            <img src="images/submit_btn.jpg">
                        </a>
                    </div>
                   
                    <div class="reviewer_btn">
                        <a href="<?php echo $myurl."register.php"; ?>">
                            <img src="images/reviewer_btn.jpg">
                        </a>
                    </div>
                </div>