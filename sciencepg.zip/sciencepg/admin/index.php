<!DOCTYPE html>
<html>
<<head>
         <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
            <link href="../images/littlelogo.gif" rel="shortcut icon">
            <title>Science Publishing Group</title> 
            
    <script type="text/javascript">
        function change1(obj) {
        obj.style.backgroundImage="url(../spg/decorator/resources/images/define/btn02.jpg)";
        }
        
        function change2(obj) {
          obj.style.backgroundImage="url(../spg/decorator/resources/images/define/btn01.jpg)";
        }
        
        function change(){
            document.getElementById('shadow').style.width=0; 
            document.getElementById('shadow').style.height=0; 
            document.getElementById('advbox').style.display="none"; 
        }
        
    </script>
  
    <style type="text/css">
    .advbox{width:620px;position:fixed;display:none;left:50%;top:0;margin:-215px 0 0 -325px;}
    .advbox .advpic{position:relative;height:400px;overflow:hidden;}
    .advbox .advpic .closebtn{display:block;width:40px;border:1px solid #000; height:22px;line-height:26px;font-size:18px;font-weight:bold;color:#000;text-indent:12px;overflow:hidden;position:absolute;right:-5px;top:-5px;z-index:10000;}
    </style>
    
             <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
            <!-- stylesheets -->
            <link rel="stylesheet" type="text/css" href="css/reset.css">
            <link rel="stylesheet" type="text/css" href="css/style.css" media="screen">
            <link id="color" rel="stylesheet" type="text/css" href="css/colors/blue.css">
            <!-- scripts (jquery) -->
            <script src="js/jquery-1.6.4.min.js" type="text/javascript"></script>
            <!--[if IE]><script language="javascript" type="text/javascript" src="js/excanvas.min.js"></script><![endif]-->
            <script src="js/jquery-ui-1.8.16.custom.min.js" type="text/javascript"></script>
            <script src="js/jquery.ui.selectmenu.js" type="text/javascript"></script>
            <script src="js/jquery.flot.min.js" type="text/javascript"></script>
            <script src="js/tiny_mce/jquery.tinymce.js" type="text/javascript"></script>
            <!-- scripts (custom) -->
            <script src="js/smooth.js" type="text/javascript"></script>
            <script src="js/smooth.menu.js" type="text/javascript"></script>
            
            <script src="js/smooth.table.js" type="text/javascript"></script>
            <script src="js/smooth.form.js" type="text/javascript"></script>
            <script src="js/smooth.dialog.js" type="text/javascript"></script>
            <script src="js/smooth.autocomplete.js" type="text/javascript"></script>
        </head>
     <body>
            <div id="colors-switcher" class="color">
                <a href="" class="blue" title="Blue"></a>
                <a href="" class="green" title="Green"></a>
                <a href="" class="brown" title="Brown"></a>
                <a href="" class="purple" title="Purple"></a>
                <a href="" class="red" title="Red"></a>
                <a href="" class="greyblue" title="GreyBlue"></a>
            </div>
            <div id="header">
                <!-- logo -->
                <div id="logo">
                    <h1><a href="/home/index" target="_blank">
                        <font color="white" size="8">Science Publishing Group</font>
                    </a></h1>
                </div>
                <!-- end logo -->
                <ul id="user">
                    <li><a href="/common/signUp_logout">Logout</a></li>
                    <li class="highlight last"><a href="http://www.sciencepublishinggroup.com" target="_blank">View Site</a></li>
                </ul>
                <div id="header-inner">
                <div id="home">
                        <a href="/author/paper_myService"></a>
                    </div>
                    <div class="corner tl"></div>
                    <div class="corner tr"></div>
                </div>
            </div>
            <div id="content" style="height: 80%;">
                <div id="left">
                    <div id="menu">
                    
    
                        
                    
                    
                    
                    
                    
                    <h6 id="h-menu" class="selected"><a href="#products"><span>General Information</span></a></h6>
                      <ul id="menu-products" class="opened" style="display:block;">
                            <li><a href="../author/paper_myService">My Service</a></li>
                            
                       </ul>
                        <h6 id="h-menu" class="selected"><a href="#pages"><span>Submission</span></a></h6>
                        <ul id="menu-pages" class="opened" style="display:block;">
                         <li><a href="../author/paper_load_submitPaperCategoryOfJournal">Submit to Journal</a></li>
                         <li><a href="../author/paper_load_submitPaperCategory">Submit to Special Issue</a></li>
                         <li><a href="../author/paper_load_ListPapers">My Manuscripts</a></li>		
                         <li><a href="../author/paper_Load_myAccount">Pay for My Manuscripts</a></li>			
                        </ul>
                        <h6 id="h-menu" class="selected"><a href="#pages2"><span>Special Issues</span></a></h6>
                        <ul id="menu-pages" class="opened" style="display:block;">
                        
                         <li><a href="../author/paper_currentspecialissues">Current Special Issues </a></li>
                         <li><a href="../author/paper_proposespecialissue"> Propose a Special Issue</a></li>
                        </ul>
                       
                        <h6 id="h-menu" class="selected"><a href="#join"><span>Join Us</span></a></h6>
                        <ul id="menu-join" class="opened" style="display:block;">
                         <li><a href="../common/applyresult">Application Result</a></li>		
                         <li><a href="../common/joinaseditorialmember">Editorial Board</a></li>		
                         <li><a href="../common/joinasreviewer">Reviewer Members</a></li>
                         <li><a href="../common/joinasspecialeditorchief">Special Issue Lead Guest Editor</a></li>
                         <li><a href="../common/joinasspecialeditorialmember">Special Issue Editorial Board</a></li>
                    
                        </ul>
                       <h6 id="h-menu" class="selected"><a href="#links"><span>Personal Profile</span></a></h6>
                        <ul id="menu-links" class="opened" style="display:block;">
                           <li><a href="../common/load_loadUpdatePerson">Personal Information</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=11">Education Qualification</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=15">Work Experience</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=60">Speciality</a></li>
                           <li><a href="../common/profile_load_uploadpicture">Upload Your Photo</a></li>
                           <li><a href="../common/profile_Load_personalinformationwebsite">Personal Website</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=50">Projects</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=70">Books</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=80">Journal Articles</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=90">Conference Papers</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=100">Honors and Awards</a></li>
                           <li><a href="../common/profile_selectProfile?profileType=110">Invited Talks</a></li>
                           <li><a href="../common/person_selectPersonByPersonId"> Change Password</a></li>
                        </ul>
                       </div>
                    <div id="date-picker"></div>  
                   </div>
                   
                   
                <!-- end content / left -->
                
    <div id="content" style="min-height: 400px;">
        <div id="right">
        
                     <div class="box">
                              <div class="title">
                            <h5>My Service</h5>
                         </div>
                    <div class="messages" align="left">
                    
                    
                        <div id="message-warning" class="message message-warning" style="background:#f0f7e7;border-color:#F3E0E0;width: 800px;">
                            <div class="image">
                                    </div>
                                <div class="text" align="left">
                                    
                                      <a href="/author/paper_load_submitPaperCategoryOfJournal" target="_blank">
                                     <img src="../spg/decorator/resources/images/define/1.1.jpg" style="padding-left: 0px;">
                                     </a>
                                     <a href="/author/paper_load_submitPaperCategory" target="_blank">
                                      <img src="../spg/decorator/resources/images/define/1.2.jpg" style="padding-left: 33px;">
                                     </a>
                                     <div style="clear:both;"></div>
                                        </div>
                            </div>
                            
                    
                    
                    
                    
                            <div id="message-warning" class="message message-warning" style="background:#eaf6f8 ;border-color:#F3E0E0;width: auto; margin-bottom: 40px;">
                            <div class="image">
                                    </div>
                                <div class="text" align="left">
                                    
                                      <a href="/common/joinaseditorialmember" target="_blank">
                                     <img src="../spg/decorator/resources/images/define/2.1.jpg" style="padding-left: 0px;">
                                     </a>
                                     <a href="/common/joinasreviewer" target="_blank">
                                      <img src="../spg/decorator/resources/images/define/2.2.jpg" style="padding-left: 33px;">
                                     </a>
                                     <div style="clear:both;"></div>
                                        </div>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                         
                            
                            
                            
                                    
                            </div>
                    
                    
    
                    
                
                    
                    
                    
                    </div>
    
    
    
    
    </div></div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <!-- footer -->
            <div id="footer" style="bottom: 0px;margin-bottom: 0px;text-align:center;">
                <p style="text-align:center;">Copyright © 2012-2017 Science Publishing Group. All Rights Reserved. Use of this Web site signifies your agreement to the terms and conditions.</p>
            </div>
            <!-- end footert -->
        
    </body></html>