<?php include 'includes/general/header.php'; ?>
<?php include 'classes/connection.php'; ?>
<?php include 'functions/index.php'; ?>

<div id="header">
		<!-- logo -->
		<div id="logo">
			<h1>
				<a href="/home/index" target="_blank">
					<font color="white" size="8">Publishing App Nigeria</font> </a>
			</h1>
		</div>
		<!-- end logo -->

		<!-- user -->
		<ul id="user">
		</ul>
		<!-- end user -->
		<div id="header-inner">
			<div class="corner tl"></div>
			<div class="corner tr"></div>
		</div>
</div>   

<div id="login" style="display: block;">
		<div class="title">
			<h5>Log In </h5>
			<div class="corner tl"></div>
			<div class="corner tr"></div>
		</div>
		<?php if (isset($_SESSION['login_fail'])) { ?>
		<div class="messages">
			<div id="message-error" class="message message-error" style="padding-left:10%;color:red;line-height: 20px;"> 
			Your Login has Failed....
			</div>
		</div>
		<?php } unset($_SESSION['login_fail']); ?>
		<div class="inner">
			<form id="loginform" name="loginform" action="<?php echo $myurl.'controller/user/login.php'; ?>" method="post">
				
				<div class="form" style="width:410px;">
					<!-- fields -->
					<div class="fields" style="width:410px;">
						<div class="field" style="width:410px;">
							<div class="label">
								<label for="username">Username:</label>
							</div>
							<div class="input">
								<input name="username" maxlength="60" id="username" class="focus">
							</div>
							<div style="height:1px;clear: both;overflow: hidden;margin-top:-1px;"></div>
						</div> 
						<div class="field" style="padding:0 0 30px 0;">
							<div class="label">
								<label for="password">Password:</label>
							</div>
							<div class="input">
								<input name="password" type="password" maxlength="60" id="plainPassword" class="focus">
							</div>
						</div>
						<div class="buttons">
							<input type="submit" name="butlogin" value="Sign In" id="Button_SignIn" class="ui-button ui-widget ui-state-default ui-corner-all login_btn" style="cursor:pointer;margin-right: 20px;" role="button" aria-disabled="false">
						</div>
					</div>
					<!-- end fields -->
					<!-- links -->
					<div class="links">
						<a href="register.php" target="_blank"> <b> Create an account </b> </a>
						<h1>&nbsp;</h1>
						
						<a>Please use the latest version of your browser. </a>
					</div>
				</div>
			</form>



		</div>
	
	</div>
    
	</div>
  


  </body>
  </html>