<?php


//function to set status for each students
function status_rename($status){
	if($status==1){
		echo"<li class='green fa fa-star'></li> Active</td>";
	}elseif($status==2){
		echo"<li class='silver fa fa-star'></li> Transfered</td>";
	}elseif($status==3){
		echo"<li class='blue fa fa-star'></li> Suspended</td>";
	}elseif($status==4){
		echo"<li class='red fa fa-star'></li> Expelled</td>";
	}elseif($status==5){
		echo"<li class='orange fa fa-star'></li> Left</td>";
	}elseif($status==0){
		echo"<li class='orange fa fa-star'></li> Not set</td>";
	}
}

//function to rename status in class status changing
function statusR($status){
	if($status==1){
		echo" Active ";
	}elseif($status==2){
		echo" Transfered ";
	}elseif($status==3){
		echo" Suspended ";
	}elseif($status==4){
		echo" Expelled ";
	}elseif($status==5){
		echo" Left ";
	}
}

//function to set new or old student
function oldNew($new_){
	if($new_ == 0){
		echo"<strong> Old </strong>";
	}elseif($new_ == 1){
		echo"<strong  class='green'> New </strong>";
	}
}

//function to set new or old student in status changing
function oldN($new_){
	if($new_ == 0){
		echo" Old ";
	}elseif($new_ == 1){
		echo" New ";
	}
}


//function to rename clases according to their respective ids
function classRename($class){
	if(($class == 91) || ($class == 92) || ($class == 93) || ($class == 94) || ($class == 95)) {
		echo"<strong> LKG </strong>";
	}elseif(($class == 96) || ($class == 97) || ($class == 98) || ($class == 99) || ($class == 100)) {
		echo"<strong> UKG </strong>";
	}elseif(($class ==  101) || ($class == 102) || ($class == 103) || ($class == 104) || ($class == 105)){
		echo"<strong> NURSERY 1 </strong>";
	}elseif(($class ==106) || ($class == 107) || ($class == 108) || ($class == 109) || ($class == 110)){
		echo"<strong> NURSERY 2 </strong>";
	}elseif(($class == 116) || ($class == 117) || ($class == 118) || ($class == 119) || ($class == 120)){
		echo"<strong> PRIMARY 1  </strong>";
	}elseif(($class == 121) || ($class == 122) || ($class == 123) || ($class == 124) || ($class == 125)){
		echo"<strong> PRIMARY 2 </strong>";
	}elseif(($class == 126) || ($class == 127) || ($class == 128) || ($class == 129) || ($class == 130)){
		echo"<strong> PRIMARY 3 </strong>";
	}elseif(($class == 131)  || ($class == 132) || ($class == 133) || ($class == 134) || ($class == 135)){
		echo"<strong> PRIMARY 4 </strong>";
	}elseif(($class == 136) || ($class == 137) || ($class == 138) || ($class == 139) || ($class == 140)){
		echo"<strong> PRIMARY 5 </strong>";
	}
}

?>
<?php
//function to rename clases according to their respective ids
function classR($class){
	if(($class == 91) || ($class == 92) || ($class == 93) || ($class == 94) || ($class == 95)) {
		echo"LKG";
	}elseif(($class == 96) || ($class == 97) || ($class == 98) || ($class == 99) || ($class == 100)) {
		echo"UKG ";
	}elseif(($class ==  101) || ($class == 102) || ($class == 103) || ($class == 104) || ($class == 105)){
		echo"NURSERY 1";
	}elseif(($class ==106) || ($class == 107) || ($class == 108) || ($class == 109) || ($class == 110)){
		echo"NURSERY 2";
	}elseif(($class == 116) || ($class == 117) || ($class == 118) || ($class == 119) || ($class == 120)){
		echo" PRIMARY 1";
	}elseif(($class == 121) || ($class == 122) || ($class == 123) || ($class == 124) || ($class == 125)){
		echo" PRIMARY 2 ";
	}elseif(($class == 126) || ($class == 127) || ($class == 128) || ($class == 129) || ($class == 130)){
		echo" PRIMARY 3 ";
	}elseif(($class == 131)  || ($class == 132) || ($class == 133) || ($class == 134) || ($class == 135)){
		echo"PRIMARY 4 ";
	}elseif(($class == 136) || ($class == 137) || ($class == 138) || ($class == 139) || ($class == 140)){
		echo" PRIMARY 5 ";
	}
}
//function to rename Previous clases according to their respective ids
function preR($pr_class){
	if($pr_class == 7){
		echo" Js 1 ";
	}elseif($pr_class == 8){
		echo" Js 2";
	}elseif($pr_class == 9){
		echo" Js 3 ";
	}elseif($pr_class == 10){
		echo" SS 1 ";
	}elseif($pr_class == 11){
		echo" SS 2 ";
	}elseif($pr_class == 12){
		echo" SS 3 ";
	}
}



//function to set male or female student in Gender
function gender($gender){
	if($gender == 0){
		echo" Female ";
	}elseif($gender == 1){
		echo" Male ";
	}
}


?>
