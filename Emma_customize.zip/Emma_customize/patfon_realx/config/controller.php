<?php session_start(); ?>
<?php include '../classes/connection.php' ; 

	$id =  $_SESSION['patfonuser']['id'];
    $sk = $_SESSION['patfonuser']['school'];?>

<?php
	//class array to give arm
	$myclasses = array(
	13 => array(91,92,93,94,95),
	14 => array(96,97,98,99,100),
	15 => array(101,102,103,104,105),
	16 => array(106,107,108,109,110),
	1 => array(116,117,118,119,120),
	2 => array(121,122,123,124,125),
	3 => array(126,127,128,129,130),
	4 => array(131,132,133,134,135),
	5 => array(136,137,138,139,140)
	);
	$randF=rand(0,4);
	
	
if(isset($_POST['register'])){
	$fname=$_POST['fname'];
	$mname=$_POST['mname'];
	$lname=$_POST['lname'];
	$class_=$_POST['class_'];
	$armClass = $myclasses[$class_][$randF];
	$debt=$_POST['debt'];
	$extra=$_POST['extra'];
	$status=$_POST['status'];
	$new_=$_POST['new_'];
	$regno=$_POST['regno'];
	$archive=$_POST['archive'];
	$date_entry=$_POST['date_entry'];
	$school=$_POST['school'];
	$year_=$_POST['year_'];
	$stu_id=$_POST['stu_id'];
	$repeat_=$_POST['repeat_'];
	$dob=$_POST['dob'];
	$gender=$_POST['gender'];
	$lga=$_POST['lga'];
	$state=$_POST['state'];
$query="INSERT INTO student (fname,mname,lname,class_,debt,debt_bus,extra,status,new_,regno,archive,date_entry,school) 
					VALUES('$fname','$mname','$lname',$armClass,0,0,0,1,1,'$regno',0,'$date_entry',$sk)";
$sql=mysqli_query($pdb,$query);


//getting student id from student table to use for insert in student_bio table
	$query4="SELECT max(id) as stu_idx FROM student WHERE school = $sk";
	$sql4=mysqli_query($pdb,$query4);
	$row=mysqli_fetch_assoc($sql4);
    $stu_idc =$row['stu_idx'];

   
   //insert into enrollment
	$query2 = ("INSERT INTO enrollment (class_,year_,stu_id,repeat_)
			VALUES ($armClass,'$year_',$stu_idc,0)");
   $sql3=mysqli_query($pdb,$query2);
   
   //insert into student_bio
	$query1 = ("INSERT INTO student_bio (stu_id,dob,gender,lga,state)
			VALUES ($stu_idc,'$dob',$gender,'$lga','$state')");
			$sql2=mysqli_query($pdb,$query1);

/* condition to test if successfull or failed and set a session in the add.php page =1 so if sucess takes 1 and echo success message
   if fail takes 1 and echo failure message
 */		
if($sql && $row && $sql3 && $sql2){
	$_SESSION['success'] = 1;
 header("Location: ../add.php");
}
   else{

    $_SESSION['failed'] = 1;	
 header("Location: ../add.php ");
	
    }			
}




/*simple powerfull code for tsting error
 if($sql && $row && $sql3 && $sql2){
	echo"SUCCESS";
}elseif (!$sql) {
    printf("Error: %s\n", mysqli_error($pdb));
    exit();
	
} */
?>