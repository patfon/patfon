<?php session_start(); ?>
<?php include '../classes/connection.php' ; 
////
// CHANGE THE CURRENT SESSION OF THE SCHOOL
if (isset($_POST['setsessionbut'])) {
$s = $_POST['myses'];
$t = $_POST['myterm'];
$k = md5($_POST['token']);

if ($k === $_SESSION['patfonuser']['key']){
    $sk = $_SESSION['patfonuser']['school'];
    $query = ("UPDATE resume SET session = $s, term = $t WHERE school = $sk  ");
    mysqli_query($pdb, $query);
    $_SESSION['patfonuser']['ses'] = $s;
    $_SESSION['patfonuser']['term'] = $t;
    $_SESSION['success'] = 1;
    header("Location: ../settings_setSession.php "); 
}
else{
    $_SESSION['failed'] = 1;
    header("Location: ../settings_setSession.php "); 
}

}
////
// CHANGE THE CURRENT STATUS OF THE USERS OF THIS SYSTEM
if (isset($_POST['manage_userbut'])) {
    $k = md5( $_POST['modal_key'] );
    $st =  $_POST['modal_status'];
    $id =  $_POST['modal_id'];
    $sk = $_SESSION['patfonuser']['school'];
    if ($k === $_SESSION['patfonuser']['key']){
    $query = ("UPDATE users SET status = $st WHERE school = $sk and id = $id ");
    
   if (mysqli_query($pdb, $query)){
    $_SESSION['success'] = 1;
    header("Location: ../settings_blockuser.php ");
   }
   else{
    $_SESSION['failed'] = 1;
    header("Location: ../settings_blockuser.php "); 
    }
    }
    else{
        $_SESSION['failed'] = 1;
        header("Location: ../settings_blockuser.php "); 
    }
}
////
// DELETE THIS USER OF THE SYSTEM
if (isset($_POST['manage_deluserbut'])) {
    $k = md5( $_POST['modal_key'] );
    
    $id =  $_POST['modal_id'];
    $sk = $_SESSION['patfonuser']['school'];
    if ($k === $_SESSION['patfonuser']['key']){
    $query = ("DELETE FROM users WHERE school = $sk and id = $id ");
    
   if (mysqli_query($pdb, $query)){
    $_SESSION['success_del'] = 1;
    header("Location: ../settings_blockuser.php ");
   }
   else{
    $_SESSION['failed'] = 1;
    header("Location: ../settings_blockuser.php "); 
    }
    }
    else{
        $_SESSION['failed'] = 1;
        header("Location: ../settings_blockuser.php "); 
    }
}
////
// ADD A NEW USER OF THIS SYSTEM
if (isset($_POST['manage_adduserbut'])) {
    $mu =  $_POST['modalx_uname'];
    $mpx =  md5($_POST['modalx_pass']);
    $me =  $_POST['modalx_email'];
    $mp =  $_POST['modalx_phone'];
    $mf =  $_POST['modalx_fname'];
    $mr =  $_POST['modalx_role'];
    $sk = $_SESSION['patfonuser']['school'];

    $query = ("INSERT INTO users (uname,pass,status,email,pnum,name,role,school) 
    VALUES ('$mu','$mpx',1,'$me','$mp','$mf','$mr',$sk) ");
     if (mysqli_query($pdb, $query)){
        $_SESSION['success_add'] = 1;
        header("Location: ../settings_blockuser.php ");
    }
    else{
        $_SESSION['failed'] = 1;
        header("Location: ../settings_blockuser.php "); 
    }
}

if (isset($_POST['changepassbut'])) {
    $k = md5( $_POST['oldpass'] );
    $k2 = md5( $_POST['newpass2'] );
    $id =  $_SESSION['patfonuser']['id'];
    $sk = $_SESSION['patfonuser']['school'];

    if ($k === $_SESSION['patfonuser']['key']){
    
    $query = ("UPDATE users SET pass = '$k2' WHERE school = $sk and id = $id ");
    
   if (mysqli_query($pdb, $query)){
    $_SESSION['patfonuser']['key'] = $k2;
    $_SESSION['success'] = 1;
    header("Location: ../settings_changepass.php ");
   }
   else{

    $_SESSION['failed_'] = 1;
    header("Location: ../settings_changepass.php "); 
    }
    }
    else{
        $_SESSION['failed'] = 1;
        header("Location: ../settings_changepass.php "); 
    }
}
?>