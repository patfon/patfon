<?php session_start(); ?>
<?php include '../classes/connection.php' ; 

	$id =  $_SESSION['patfonuser']['id'];
    $sk = $_SESSION['patfonuser']['school'];?>
	
<?php

	//class array to give arm
	$myclasses = array(
	13 => array(91,92,93,94,95),
	14 => array(96,97,98,99,100),
	15 => array(101,102,103,104,105),
	16 => array(106,107,108,109,110),
	1 => array(116,117,118,119,120),
	2 => array(121,122,123,124,125),
	3 => array(126,127,128,129,130),
	4 => array(131,132,133,134,135),
	5 => array(136,137,138,139,140)
	);
	$randF=rand(0,4);
	
	
	if(isset($_POST['update'])){
		//$id=$_GET['id'];
	$fname=$_POST['fname'];
	$mname=$_POST['mname'];
	$lname=$_POST['lname'];
	$class_=$_POST['class_'];
	$armClass = $myclasses[$class_][$randF];
	$pob=$_POST['pob'];
	$stu_id=$_POST['stu_id'];
	$dob=$_POST['dob'];
	$gender=$_POST['gender'];
	$lga=$_POST['lga'];
	$state=$_POST['state'];
	
$query="UPDATE  student SET fname = '$fname' , mname='$mname',lname='$lname',class_ = $armClass WHERE id=$id"; 
$sql=mysqli_query($pdb,$query);

if($sql){
	$_SESSION['success'] = 1;
 header("Location: ../edit_personal.php");
}
   else{

    $_SESSION['failed'] = 1;	
 header("Location: ../edit_personal.php ");
	
    }			
}
?>