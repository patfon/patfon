<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php include 'functions/func.php' ; ?>
<?php include 'functions/index.php' ; ?>

<?php $_SESSION['cur-page'] = "Student  > View Student"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
include('includes/header.php');

$id=$_GET['id'];//getting id from url 
?>

<script></script>

<section id="main-content">
	<section class="wrapper">
		<div id="" class="">

		
<!--main content starts here -->
	
<section class="content" style="min-height: 297px;">

      <ul class="breadcrumb"><li><a href="index.php"><i></i> Home</a></li>
<li><a href="student.php">Student</a></li>
<li><a href="view.php">View Student</a></li>
<li class="active">Student Profile</li>
</ul>  

<section class="content-header">
<div class="row">
  <div class="col-xs-12">
	<h4 class="page-header">	
		<i class="fa fa-user"></i>  Student Profile	</h2>
     </h4>
  </div>
</div>
</section>


<section class="content edusec-user-profile" style="min-height: 297px;">
<div class="col-lg-9 profile-data">
		<ul class="nav nav-tabs responsive hidden-xs hidden-sm" id="profileTab">
			<li class="active" id="personal-tab"><a href="#personal" data-toggle="tab" aria-expanded="true"><i class="fa fa-street-view"></i> Personal</a></li>
			<li id="academic-tab" class=""><a href="#academic" data-toggle="tab" aria-expanded="false"><i class="fa fa-graduation-cap"></i> Academic</a></li>
			<li id="guardians-tab"><a href="#guardians" data-toggle="tab"><i class="fa fa-user"></i> Guardians</a></li>
			<li id="address-tab"><a href="#address" data-toggle="tab"><i class="fa fa-home"></i> Address</a></li>
			<li id="fees-tab"><a href="#fees" data-toggle="tab"><i class="fa fa-inr"></i> Fees</a></li>
		</ul>
		 <div id="content" class="tab-content responsive hidden-xs hidden-sm">
			<div class="tab-pane active" id="personal">
				
<?php
$id=$_GET['id'];//getting id from url
//retreiev records from student table
$student="SELECT * FROM student WHERE id='$id'";
$result=mysqli_query($pdb,$student);
$row=mysqli_fetch_assoc($result);
$fname=$row['fname'];
$mname=$row['mname'];
$lname=$row['lname'];
$class_=$row['class_'];
$regno=$row['regno'];
$date_entry=$row['date_entry'];
$status=$row['status'];
$new_=$row['new_'];


//bio-data
$bio="SELECT * FROM student_bio WHERE stu_id=$id";
$result=mysqli_query($pdb,$bio);
$row=mysqli_fetch_assoc($result);
$gender=$row['gender'];
$state=$row['state'];
$rel=$row['rel'];
$pob=$row['pob'];
$dob=$row['dob'];
$pr_sch=$row['pr_sch'];
$pr_class=$row['pr_class'];
$addr=$row['addr'];
$nation=$row['nation'];
//$city=$row['city'];
//$phone=$row['phone'];
//$house=$row['house'];
?>
<div class="row">
  <div class="col-xs-12">
	<h2 class="page-header">	
	<i class="fa fa-info-circle"></i> Personal Details	<div class="pull-right">
			<a id="edit-data" class="btn btn-primary btn-sm" href="<?php echo "edit_personal.php?id=$row[id]"; ?>"><i class="fa fa-pencil-square-o"></i> Edit</a>
			<a id="update-data" class="btn btn-info btn-sm" href="<?php echo "eupdate_personal.php?id=$row[id]"; ?>"><i class="fa fa-pencil-square-o"></i> Update</a>
			</div>
	</h2>
  </div><!-- /.col -->
</div>


<div class="row">
	<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">First Name:</div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $fname; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Middle Name:</div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $mname; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Last Name: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $lname; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Date Of Birth</div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $dob; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Gender: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo gender($gender); ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">State Of Origin: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $state; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Place Of Birth: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $pob; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Religion: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $rel; ?></div>
  </div>
</div>


<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Blood Group: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php ?></div>
  </div>
</div>

</div> <!---Main Row Div--->
	
			</div>
			<div class="tab-pane" id="academic">
				

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<h2 class="page-header">	
	<i class="fa fa-info-circle"></i> Academic Details	<div class="pull-right">
			<a id="update-data" class="btn-sm btn btn-primary text-warning" href="<?php echo "edit_Academic.php?id=$row[id]"; ?>"><i class="fa fa-pencil-square-o"></i>Edit</a></div>
	</h2>
  </div><!-- /.col -->
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Reg Number: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $regno; ?></div>
  </div>
</div>


<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Class: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo classR($class_) ;?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Admission Date: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $date_entry; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">New / Old: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo oldN($new_); ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Student Status: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo statusR($status); ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Previous Class: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo preR($pr_class); ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Previous School: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php  echo $pr_sch; ?></div>
  </div>
</div>
	
			</div>
			<div class="tab-pane" id="guardians">
				
<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<h2 class="page-header">
	<i class="fa fa-info-circle"></i> Guardians Details	<div class="pull-right">
	<a class="btn btn-primary btn-sm" href="<?php echo "edit_guardian.php?id=$row[id]"; ?>"><i class="fa fa-pencil-square-o"></i> Edit</a>
					
			</h2>
  </div><!-- /.col -->
</div>

<div class="row">
	<font color="red">Function Not Available Yet !</font>
</div>
	
			</div>
			<div class="tab-pane" id="address">
				
<div class="row">
  <div class="col-xs-12">
	<h2 class="page-header">	
	<i class="fa fa-info-circle"></i> Address Info	<div class="pull-right">
		    <a id="update-data" class="btn btn-primary btn-sm" href=""><i class="fa fa-pencil-square-o"></i>Edit</a>		</div>
	</h2>
  </div><!-- /.col -->
</div>

<!---Start Current Address Block--->
<div class="row">
  <div class="col-xs-12">
	<h4 class="edusec-border-bottom-warning page-header edusec-profile-title-1">	
		Current Address	</h4>
  </div><!-- /.col -->
</div>

<div class="row">
	 <div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Address: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $addr; ?></div>
  </div>
</div>


<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">State: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $state; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">City: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php //echo $City; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Country: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php echo $nation; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">House No: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php //echo $house; ?></div>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12 col-lg-12">
	<div class="col-md-4 col-xs-4 edusec-profile-label ">Phone: </div>
	<div class="col-md-8 col-xs-8 edusec-profile-text"><?php //echo $phone; ?></div>
  </div>
</div>
</div>

<!---Start Permenant Address Block--->
<div class="row">
  <div class="col-xs-12">
	<h4 class="edusec-border-bottom-warning page-header edusec-profile-title-1">	
		Permenant Address	</h4>
  </div><!-- /.col -->
</div>



<div class="row">
	<font color="red">Function Not Available Yet !</font>
</div>


	
			</div>

		 			<div class="tab-pane" id="fees">
				<!-----Start current batch fees details----->

<div class="row">
  <div class="col-xs-12">
	<h4 class="edusec-border-bottom-warning page-header edusec-profile-title-1">	
		<i class="fa fa-money"></i> Current Fees Details	</h4>
  </div><!-- /.col -->
</div>

<div class="box box-solid">
    <div class="box-body table-responsive no-padding">
<div id="w0" class="grid-view">
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>S/N</th>
<th>Name</th>
<th>Total Amount</th>

</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>Tuition Fees (13,300) </td>
<td>13300</td>
</tr>
<tr>
<td>2</td>
<td>Bus  (2,500) </td>
<td> 2500</td>
</tr>
<tr>
<td></td>
<th colspan="1">Total Amount Paid</th>
<th>15000</th>
</tr>
<tr>
<td colspan="3"></td>
</tr>
<tr>
<td></td>
<th colspan="1"> Dept owed By Student</th>
<th><font color="red">N 800</font> </th>
</tr>
<tr>
<td></td>
<th colspan="1"></th>
<th>N 15800</th>
</tr>
</tbody>
</table>
</div>  
  </div>
  </div>
<!-----End current batch fees details----->

<!-----Start student payment history block----->

<div class="row">
  <div class="col-xs-12">
	<h4 class="edusec-border-bottom-warning page-header edusec-profile-title-1">	
		<i class="fa fa-inr"></i> Student Payment History	</h4>
  </div>
</div>
<div class="row">
	<font color="red">Function Not Available Yet !</font>
	
</div>
 Payment History Table On comment
<div class="box box-solid">
     <div class="box-body table-responsive no-padding">
<div id="w1"><div id="w2" class="grid-view"><div class="summary">Showing <b>1-3</b> of <b>3</b> items.</div>
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>S/N</th>
<th>Payment Date</th>
<th>Fee Name</th>
<th>Payment Mode</th>
<th>Cheque No</th>
<th>Amount</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>

<td>02-11-2017</td>
<td>Tuition Fees</td>
<td>Cash</td>
<td>-</td>
<td>2500</td>
</tr>
<tr>
<td>2</td>

<td>11-11-2017</td>
<td>Transport</td>
<td>Cash</td>
<td>-</td>
<td>1500</td>
</tr>
<tr>
<td>3</td>

<td>02-11-2017</td>
<td>Tuition Fees</td>
<td>Cash</td>
<td>-</td>
<td>24000</td>
</tr>
</tbody>
</table>
</div>
</div> 
 </div>
</div> 
<!-----End student payment history block----->
	
			</div>
				</div><div class="panel-group responsive visible-xs visible-sm" id="collapse-profileTab"><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle" data-toggle="collapse" data-parent="#collapse-profileTab" href="#collapse-personal" aria-expanded="true"><i class="fa fa-street-view"></i> Personal</a></h4></div><div id="collapse-personal" class="panel-collapse collapse in" aria-expanded="true" style=""></div></div><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#collapse-profileTab" href="#collapse-academic" aria-expanded="false"><i class="fa fa-graduation-cap"></i> Academic</a></h4></div><div id="collapse-academic" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;"></div></div><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle" data-toggle="collapse" data-parent="#collapse-profileTab" href="#collapse-guardians"><i class="fa fa-user"></i> Guardians</a></h4></div><div id="collapse-guardians" class="panel-collapse collapse"></div></div><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle" data-toggle="collapse" data-parent="#collapse-profileTab" href="#collapse-address"><i class="fa fa-home"></i> Address</a></h4></div><div id="collapse-address" class="panel-collapse collapse"></div></div><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle" data-toggle="collapse" data-parent="#collapse-profileTab" href="#collapse-documents"><i class="fa fa-file-text"></i> Documents</a></h4></div><div id="collapse-documents" class="panel-collapse collapse"></div></div><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle" data-toggle="collapse" data-parent="#collapse-profileTab" href="#collapse-fees"><i class="fa fa-inr"></i> Fees</a></h4></div><div id="collapse-fees" class="panel-collapse collapse"></div></div></div>
	</div>
     </div> <!---End Row Div--->
</section>

<!--  POP UP Window for Photo Upload/Update -->
<div class="modal fade col-xs-12 col-lg-12" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="photoup">
  <div class="modal-dialog">
    <div class="modal-content row">
    </div>
  </div>
</div>



<!--  POP UP Window for Guardian -->

<div id="guardModal" class="fade modal" role="dialog" tabindex="-1">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h3>Update Guardian</h3>
</div>
<div class="modal-body">

</div>

</div>
</div>
</div>
    </section>	
		
<!--main content ends here -->		
		
		
		
		
		
		
		  </div>
		  </section>
		  </section>
		  
<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 
