<?php session_start(); ?>
<?php $_SESSION['cur-page'] = "student"; ?>
<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
require('includes/header.php');
?>


<?php
//header
require('includes/stu_menu.php');
?>



<?php
//footer
require('includes/footer2.php');
 ?>

<?php } else { 
    
    header("Location: login.php");
 } ?> 