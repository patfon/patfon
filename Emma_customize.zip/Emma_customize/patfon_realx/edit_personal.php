<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php include 'functions/func.php' ; ?>
<?php include 'functions/index.php' ; ?>

<?php $_SESSION['cur-page'] = "Student  > Edit Student Info"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header

include('includes/header.php');

?>

<section id="main-content">
	<section class="wrapper">
		<div class="">
		
<div class="col-md-12">
<ul class="breadcrumb"><li><a href="index.php"><i></i> Home</a></li>
<li><a href="student.php">Student</a></li>
<li><a href="view.php">View</a></li>
<!--<li><a href="student_profile.ph">Student Profile</a></li>p-->
<li class="active">Edit Student Information</li>

</ul>
                <div data-collapsed="0" class="panel">
				
                    
					
                        <h4 class="box-title panel-primary"><i class="fa fa-info-circle "></i> Edit Personal Info</h4>
	
                  <br>
<?php  if(isset($_SESSION['success'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;. Successfull.
                            </div>                             
                        <?php unset($_SESSION['success']); } ?>
                       
                       
                        <?php  if(isset($_SESSION['failed'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.There was an error in the last request. Please try again.
                            </div>                             
                        <?php unset($_SESSION['failed']); } ?>
                    <div class="panel-body">
<?php 
$id=$_GET['id'];//getting id from the URL;
echo $id;


//bio-data
$bio="SELECT * FROM student_bio WHERE stu_id=$id";
$result=mysqli_query($pdb,$bio);
$data_=mysqli_fetch_assoc($result);
$gender=$data_['gender'];
$state=$data_['state'];
$rel=$data_['rel'];
$pob=$data_['pob'];
$dob=$data_['dob'];
$htown=$data_['htown'];
$pr_sch=$data_['pr_sch'];
$pr_class=$data_['pr_class'];
$addr=$data_['addr'];
$lga=$data_['lga'];
$nation=$data_['nation'];
//$city=$row['city'];
//$phone=$row['phone'];
//$house=$row['house'];

//retreiev records from student table
$student="SELECT * FROM student WHERE id='$id'";
$result=mysqli_query($pdb,$student);
$row=mysqli_fetch_assoc($result);
$fname=$row['fname'];
$mname=$row['mname'];
$lname=$row['lname'];
$class_=$row['class_'];
$regno=$row['regno'];
$date_entry=$row['date_entry'];
$status=$row['status'];
$new_=$row['new_'];
		?>
                        <div class="row">
						<form role="form" action=<?php echo $myurl."config/edit_controller.php"; ?> method="post">
							<div class="col-md-4 form-group">
							<label for="name">First Name</label>
                                <input id="name" name="name" class="form-control" value="<?php echo $fname; ?>">
                            </div>
							
							<div class="col-md-4 form-group">
							<label for="name">Middle Name</label>
                                <input id="name" name="name" class="form-control" value="<?php echo $mname; ?>">
                            </div>
							
							<div class="col-md-4 form-group">
							<label for="name">Last Name</label>
                                <input id="name" name="name" class="form-control" value="<?php echo $lname;?>">
                            </div>
							
							<div class="col-md-4 form-group">
							<label for="oldnew">Date Of Birth</label>
                                <input id="oldnew" type="date" class="form-control" value="<?php echo $dob; ?>">
                            </div>
							
							<div class="col-md-2 form-group">
							<label for="gender">Change Gender</label>
							<select id="gender" name="gender" class="form-control ">
                    <option value=""> 
                    Choose...
                    </option>
                    <option value="1"> 
                    Male
                    </option>
                    <option value="0"> 
                    Female
                    </option>
                           </select>
					
                            </div>
							<div class="col-md-2 form-group">
							<label for="oldnew"> Gender</label>
                                <input id="oldnew" type="text" class="form-control" value="<?php  echo gender($gender); ?>" disabled>
                            </div>

							<div class="col-md-2 form-group">
							<label for="state">Change State</label>
							<select id="state" name="state" class="form-control " >
                    <option value=""> 
                    Choose State....
                    </option>
                    <option value="Abia"> 
                    Abia
                    </option>
                    <option value="Adamawa"> 
                    Adamawa
                    </option>
					<option value=" Akwa Ibom"> 
                    Akwa Ibom
                    </option>
					<option value="Anambra"> 
                    Anambra
                    </option>
					<option value=" Bauchi"> 
                    Bauchi
                    </option>
					<option value="Bayelsa"> 
                    Bayelsa
                    </option>
					<option value="Benue"> 
                    Benue
                    </option>
					<option value="Borno"> 
                    Borno
                    </option>
					<option value="Cross River "> 
                    Cross River 
                    </option>
					<option value=" Delta"> 
                    Delta
                    </option>
					<option value="Ebonyi"> 
                    Ebonyi
                    </option>
					<option value="Edo"> 
                    Edo
                    </option>
					<option value="Ekiti "> 
                    Ekiti 
                    </option>
					<option value="Enugu"> 
                    Enugu
                    </option>
					<option value="FCT"> 
                    FCT
                    </option>
					<option value="Gombe"> 
                    Gombe
                    </option>
					<option value="Imo"> 
                    Imo
                    </option>
					<option value="Jigawa "> 
                    Jigawa 
                    </option>
					<option value="Kaduna"> 
                    Kaduna
                    </option>
					<option value="Kano"> 
                    Kano
                    </option>
					<option value="Katsina"> 
                    Katsina
                    </option>
					<option value="Kebbi"> 
                    Kebbi
                    </option>
					<option value="Kogi"> 
                    Kogi
                    </option>
					<option value="Kwara"> 
                    Kwara
                    </option>
					<option value="Lagos"> 
                    Lagos
                    </option>
					<option value="Nasarawa"> 
                    Nasarawa
                    </option><option value="Niger"> 
                    Niger
                    </option><option value="Ogun"> 
                    Ogun
                    </option><option value="Ondo"> 
                    Ondo
                    </option><option value="Osun"> 
                    Osun
                    </option><option value="Oyo"> 
                    Oyo
                    </option><option value="Plateau"> 
                    Plateau
                    </option><option value="Rivers"> 
                    Rivers
                    </option><option value="Sokoto"> 
                    Sokoto
                    </option><option value="Taraba"> 
                    Taraba
                    </option><option value="Yobe"> 
                    Yobe
                    </option><option value="Zamfara"> 
                    Zamfara
                    </option>
                           </select>
					
                            </div>
							
							<div class="col-md-2 form-group">
							<label for="class">State Of Origin</label>
                                <input id="class" type="text" class="form-control" value="<?php echo $state; ?>" disabled >
                            </div>
							
							
							<div class="col-md-2 form-group">
							<label for="stat">Blood Group</label>
                                <input id="stat" type="text" class="form-control" value="">
                            </div>
							
							
							<div class="col-md-2 form-group">
							<label for="class">L.G.A</label>
                                <input id="class" type="text" class="form-control" value="<?php echo $lga; ?>">
                            </div>
							
							
							<div class="col-md-4 form-group">
							<label for="class">Place Of Birth</label>
                                <input id="class" type="text" class="form-control" value="<?php echo $pob; ?>" >
                            </div>
							
							
							

							<div class="col-md-2 form-group">
							<label for="class">Religion</label>
                                <input id="class" type="text" class="form-control" value="<?php echo $rel; ?>"disabled>
                            </div>
							
							<div class="col-md-2 form-group">
							<label for="gender">Change Religion</label>
							<select id="gender" name="gender" class="form-control " >
                    <option value=""> 
                    Choose...
                    </option>
                    <option value="Christianity"> 
                    Christianity
                    </option>
                    <option value="Muslim"> 
                    Muslim
                    </option>
					<option value="Muslim"> 
                    Other
                    </option>
                           </select>
					
                            </div>
						
						<div class="col-md-4 form-group">
                                <input type="submit" value="Update Info" name="update" class="btn btn-info " tabindex="9">
                            </div>
							
							</form>
                            
					</div>

                    </div>

                </div>

            </div>
			 </div>
</section>
</section>
<?php 
/* 
if(isset($_SESSION['patfonuser'])){
	$id=$_GET['id'];
	$stu= $_SESSION['studentid']=$id;	
 }*/


?>
<?php 
if(isset($_POST['ch_status'])){
$status=$_POST['status'];
$sql="UPDATE `student` SET status='$status' WHERE id='$id'";
$rel=mysqli_query($pdb,$sql);
if($rel){
	$_SESSION['success'] = 1;
	echo"<meta http-equiv='refresh' content='0'";
	
}else{
	 $_SESSION['failed'] = 1;	
}
}

?>
<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 