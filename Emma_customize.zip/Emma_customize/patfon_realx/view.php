<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php include 'functions/func.php' ; ?>
<?php include 'functions/index.php' ; ?>

<?php $_SESSION['cur-page'] = "Student  > View Student"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
include('includes/header.php');
?>

<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
<style>
td
{
	font-family:Verdana, Geneva, sans-serif;
}
.gold{
	color:gold;
}
.silver{
	color:silver;
}
.red{
	color:red;
}
.blue{
	color:blue;
}
.green{
	color:#5cb85c;
}
.orange{
	color:orange;
}

</style>                             
   

<section id="main-content">

	<section class="wrapper">
	<div class="col-md-12">
		<ul class="breadcrumb"><li><a href="index.php"><i></i> Home</a></li>
<li><a href="student.php">Student</a></li>
<li class="active">View Student</li>
</ul>
		<div class="">	
 <div class="panel panel-default">
 <!---728x90--->
    <h4 class="box-title panel-primary"><i class="fa fa-info-circle "></i> All Students PAU</h4>
	<br>
	
	<br>
    <div>
      <table id="example" class="table table-bordered table-hover">
        <thead>
          <tr>
		  <th>S / N</th>
            <th>Student Name</th>
            <th>Reg Number</th>
            <th>Old / New</th>
            <th>Class</th>
			<th>Date Admited</th>
			<th>Status</th>
          </tr>
        </thead>
        <tbody>
		<?php
	$query = mysqli_query($pdb, "SELECT * FROM student");	
    	while($row = mysqli_fetch_array($query)){
			
	?>
         <tr>
		 <td><?php echo $row['id']; ?></td>
        	<td id="center"><?php $name=$row['lname']." ". $row['fname']." ".$row['mname'];echo"<a 	href=\"student_profile.php?id=$row[id]\"><font color=''>"; echo $name; "</font></a>"; ?></td>
            <td id="center"><?php echo $row['regno']; ?></td>
            <td id="center"><?php $new_=$row['new_'];echo oldNew($new_); ?></td>
			<td id="center"><?php $class= $row['class_']; echo classRename($class) ?></td>
			<td id="center"><?php echo $row['date_entry']; ?></td>	
            <td id="center"><?php $status= $row['status']; echo "<a href=\"change_stat.php?id=$row[id]\">"; echo status_rename($status); "</a>"; ?></td>
			
	    </tr>
		<?php
		}
		
	?>
        </tbody>
      </table>
    </div>
	<!---728x90--->
	
  </div>
</div>
</div>
</section>
</section>   
               
         
<script type="text/javascript" src="datatables/datatables.min.js"></script>
<script type="text/javascript" charset="utf-8">
$(document).ready(function() 
{
	$('#example').dataTable();   
});
</script>
<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 