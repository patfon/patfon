<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php include 'functions/func.php' ; ?>
<?php include 'functions/index.php' ; ?>

<?php $_SESSION['cur-page'] = "Student  > Add Student"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
include('includes/header.php');
?>
<section id="main-content">
	<section class="wrapper">
    <div class="row">
	<div class="col-md-12">
<ul class="breadcrumb"><li><a href="index.php"><i></i> Home</a></li>
<li><a href="student.php">Student</a></li>
<li class="active">Add Student</li>
</ul>
            <div data-collapsed="0" class="panel">
				
                    
					
                        <h4 class="box-title panel-primary"><i class="fa fa-info-circle "></i>Student Details</h4>
	
                  <br>
                        <?php  if(isset($_SESSION['success'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.Student Added Successfully.
                            </div>                             
                        <?php unset($_SESSION['success']); } ?>
                       
                       
                        <?php  if(isset($_SESSION['failed'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.There was an error in the last request. Please try again.
                            </div>                             
                        <?php unset($_SESSION['failed']); } ?>
                    <div class="panel-body">
                        <div class="row">
						 <form role="form" action=<?php echo $myurl."config/controller.php"; ?> method="post">
							<div class="col-md-4 form-group">
							<label for="name">First Name</label>
                                <input type="text" name="fname" class="form-control" required="required">
                            </div>
							<div class="col-md-4 form-group">
							<label for="name">Middle Name</label>
                               <input type="text" name="mname" class="form-control" required="required">
                            </div>
							<div class="col-md-4 form-group">
							<label for="name">Last Name</label>
                                <input type="text" name="lname" class="form-control" required="required">
                            </div>

                            <div class="col-md-4 form-group">
							<label for="regno">Reg Number</label>
                                <input type="" name="regno" class="form-control" disabled>
                            </div>
							
							<div class="col-md-4 form-group">
							<label for="oldnew">Select Class</label>
							<select name="class_" class="form-control " required="required">
                    <option value=""> 
                    Choose class....
                    </option>
                    <option value="13"> 
                    LKG
                    </option>
                    <option value="14"> 
                   UKG
                    </option>
                    <option value="15"> 
                   NURSERY 1
                    </option>
                    <option value="16"> 
                    NURSERY 2
                    </option>
                    <option value="1"> 
                    PRIMARY 1
                    </option>
					<option value="2"> 
                   PRIMARY 2
                    </option>
					<option value="3"> 
                    PRIMARY 3
                    </option>
					<option value="4"> 
                   PRIMARY 4
                    </option>
					<option value="5"> 
                   PRIMARY 5
                    </option>
                    </select>
					
                            </div>

                           
							<div class="col-md-4 form-group">
							<label for="gender">Gender</label>
							<select id="gender" name="gender" class="form-control " required="required">
                    <option value=""> 
                    Choose Gender....
                    </option>
                    <option value="1"> 
                    Male
                    </option>
                    <option value="0"> 
                    Female
                    </option>
                           </select>
					
                            </div>
							<div class="col-md-4 form-group">
							<label for="state">State Of Origin</label>
							<select id="state" name="state" class="form-control " required="required">
                    <option value=""> 
                    Choose State....
                    </option>
                    <option value="Abia"> 
                    Abia
                    </option>
                    <option value="Adamawa"> 
                    Adamawa
                    </option>
					<option value=" Akwa Ibom"> 
                    Akwa Ibom
                    </option>
					<option value="Anambra"> 
                    Anambra
                    </option>
					<option value=" Bauchi"> 
                    Bauchi
                    </option>
					<option value="Bayelsa"> 
                    Bayelsa
                    </option>
					<option value="Benue"> 
                    Benue
                    </option>
					<option value="Borno"> 
                    Borno
                    </option>
					<option value="Cross River "> 
                    Cross River 
                    </option>
					<option value=" Delta"> 
                    Delta
                    </option>
					<option value="Ebonyi"> 
                    Ebonyi
                    </option>
					<option value="Edo"> 
                    Edo
                    </option>
					<option value="Ekiti "> 
                    Ekiti 
                    </option>
					<option value="Enugu"> 
                    Enugu
                    </option>
					<option value="FCT"> 
                    FCT
                    </option>
					<option value="Gombe"> 
                    Gombe
                    </option>
					<option value="Imo"> 
                    Imo
                    </option>
					<option value="Jigawa "> 
                    Jigawa 
                    </option>
					<option value="Kaduna"> 
                    Kaduna
                    </option>
					<option value="Kano"> 
                    Kano
                    </option>
					<option value="Katsina"> 
                    Katsina
                    </option>
					<option value="Kebbi"> 
                    Kebbi
                    </option>
					<option value="Kogi"> 
                    Kogi
                    </option>
					<option value="Kwara"> 
                    Kwara
                    </option>
					<option value="Lagos"> 
                    Lagos
                    </option>
					<option value="Nasarawa"> 
                    Nasarawa
                    </option><option value="Niger"> 
                    Niger
                    </option><option value="Ogun"> 
                    Ogun
                    </option><option value="Ondo"> 
                    Ondo
                    </option><option value="Osun"> 
                    Osun
                    </option><option value="Oyo"> 
                    Oyo
                    </option><option value="Plateau"> 
                    Plateau
                    </option><option value="Rivers"> 
                    Rivers
                    </option><option value="Sokoto"> 
                    Sokoto
                    </option><option value="Taraba"> 
                    Taraba
                    </option><option value="Yobe"> 
                    Yobe
                    </option><option value="Zamfara"> 
                    Zamfara
                    </option>
                           </select>
					
                            </div>
							
							<div class="col-md-4 form-group">
							<label for="date">Date Of Birth</label>
                                <input type="date" name="dob" class="form-control" >
                            </div>
							
							<div class="col-md-4 form-group">
							<label for="rreeg">L. G .A</label>
                                <input id="rreeg" name="lga" type="text" class="form-control" required="required" placeholder="local Government Area">
                            </div>
							<!-- submit button -->
							<div class="col-md-4 form-group">
                                <input type="submit" value="Add Student" name="register" class="btn btn-info " tabindex="9">
                            </div>
							<div class="col-md-4 form-group">
							<label for="class"><!-- Entry date --></label>
                               <input name="date_entry" value="<?php echo date('Y-m-d'); ?>" type="hidden" class="form-control">
                            </div>
							
							<div class="col-md-4 form-group">
							<label for="rreeg"><!-- year --></label>
                                <input name="year_" value="<?php echo date('Y'); ?>" type="hidden" class="form-control">
                            </div>
							
							</form></div>
                    </div>
                </div>
            </div>
        </div>
 </section>
</section>
<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 