<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php include 'functions/func.php' ; ?>
<?php include 'functions/index.php' ; ?>

<?php $_SESSION['cur-page'] = "Student  > Add Student"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
include('includes/header.php');
?>

<section id="main-content">
	<section class="wrapper">
		<div class="">
		
<div class="col-md-12">
<ul class="breadcrumb"><li><a href="index.php"><i></i> Home</a></li>
<li><a href="student.php">Student</a></li>
<li><a href="view.php">View</a></li>
<li class="active">Change Status</li>
</ul>
                <div data-collapsed="0" class="panel">
				
                    
					
                        <h4 class="box-title panel-primary"><i class="fa fa-info-circle "></i> Change Status</h4>
	
                  <br>
<?php  if(isset($_SESSION['success'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;. Successfull.
                            </div>                             
                        <?php unset($_SESSION['success']); } ?>
                       
                       
                        <?php  if(isset($_SESSION['failed'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.There was an error in the last request. Please try again.
                            </div>                             
                        <?php unset($_SESSION['failed']); } ?>
                    <div class="panel-body">
<?php 
$id=$_GET['id'];//getting id from the URL;
//show all students
$result = mysqli_query($pdb, "SELECT * FROM student WHERE id='$id'");

		while($res = mysqli_fetch_array($result)) {		
			$fname=$res['fname'];
			$mname=$res['mname'];
			$lname=$res['lname'];
			$regno=$res['regno'];
			$class= $res['class_'];
			$status= $res['status'];
			$new_=$res['new_'];
				}
		?>
                        <div class="row">
						<form method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">
							<div class="col-md-4 form-group">
							<label for="name">Student Name</label>
                                <input id="name" name="name" class="form-control" value="<?php echo $lname.' '.$fname.' '.$mname ?>" disabled>
                            </div>

                            <div class="col-md-4 form-group">
							<label for="reg">Reg Number</label>
                                <input id="reg" type="text"  class="form-control" value="<?php echo $regno; ?>" disabled>
                            </div>

                            <div class="col-md-4 form-group">
							<label for="class">Class</label>
                                <input id="class" type="text" class="form-control" value="<?php echo classR($class) ; ?>" disabled>
                            </div>
							<div class="col-md-4 form-group">
							<label for="stat">Present Status</label>
                                <input id="stat" type="text" class="form-control" value="<?php echo statusR($status);?>" disabled>
                            </div>
							<div class="col-md-4 form-group">
							<label for="oldnew">Old / New</label>
                                <input id="oldnew" type="text" class="form-control" value="<?php echo oldN($new_); ?>" disabled>
                            </div>
							<div class="col-md-4 form-group">
							<label for="oldnew">Select New Status</label>
							<select name="status" class="form-control " required>
                    <option value=""> 
                    Select....
                    </option>
                    <option value="1"> 
                    Active
                    </option>
                    <option value="2"> 
                    Transfered
                    </option>
                    <option value="3"> 
                    Suspended
                    </option>
                    <option value="4"> 
                    Expelled
                    </option>
                    <option value="5"> 
                    Left
                    </option>
                    </select>
					
                            </div>
							
							<div class="col-md-4 form-group">
                                <input type="submit" value="Change Status" name="ch_status" class="btn btn-info " tabindex="9">
                            </div>
							
							</form>
                            
					</div>

                    </div>

                </div>

            </div>
			 </div>
</section>
</section>
<?php 
if(isset($_POST['ch_status'])){
$status=$_POST['status'];
$sql="UPDATE `student` SET status='$status' WHERE id='$id'";
$rel=mysqli_query($pdb,$sql);
if($rel){
	$_SESSION['success'] = 1;
	echo"<meta http-equiv='refresh' content='0'";
	
}else{
	 $_SESSION['failed'] = 1;	
}
}

?>
<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 