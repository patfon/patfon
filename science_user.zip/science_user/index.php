﻿<?php 
include_once("classes/connection.php");
?>

		<?php include('includes/general/header.php'); ?>
	<body>

		<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<?php

				include('includes/general/menu.php');
				include('includes/general/date.php');
				 ?>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
			<!-- forms -->
				<div class="box">
				
				
				<!--content of website goes below -->
					<div class="title">
						<h5>Dashboard</h5>
					</div>
					
					<div class="switch_bar">
		<ul class="ui-sortable">
			<li>
			<a href="includes/submission/submitmanusacrpt.php"><span class="stats_icon current_work_sl"></span><span class="label">Submit Manuscript</span></a>
			</li>
			<li><a href="includes/submission/specialissues.php"><span class="stats_icon config_sl"></span><span class="label">Submit to special issues</span></a></li>
			<li><a href="includes/submission/editors.php"><span class="stats_icon administrative_docs_sl"></span><span class="label">Join Editors</span></a></li>
			<li><a href="includes/submission/reviewers.php"><span class="stats_icon finished_work_sl"></span><span class="label">Join Reviewers</span></a></li>
			
			</ul>
	</div>
	<style>
	ol, ul {
    list-style: none;
}
.switch_bar {
    text-align: center;
    margin: 0px;
    padding: 10px 0px;
    background: #eee;
    border-bottom: #ddd 1px solid;
    -moz-box-shadow: 0 0 3px #eee;
    -webkit-box-shadow: 0 0 3px #eee;
    box-shadow: 0 0 3px #eee;
}
.switch_bar li {
    display: inline-block;
    height: 70px;
    width: 70px;
    padding: 5px;
    position: relative;
    border: #c9c9c9 1px solid;
    margin: 2px 1px;
    -moz-box-shadow: 0 0 3px #ccc;
    -webkit-box-shadow: 0 0 3px #ccc;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    background: #f5f5f5 url(../images/layout-sprite.png) repeat-x 0 -751px;
}

.switch_bar li .stats_icon {
    position: relative !important;
    left: 13px;
    margin-bottom: 8px;
}
.user_sl {
    background-position: -800px -80px !important;
}
.stats_icon {
    height: 40px;
    width: 40px;
    display: block;
    position: absolute;
    left: 8px;
    top: 4px;
    background: url(../images/sprite-icons/icon_sl.png) no-repeat;
}
#content div.box li {
    padding: 4px 0 4px 0;
    font-size: 142%;
	width:40%;
	height:120px;
	font-weight: bold;
}
	</style>
					
				<!--content of website ends here -->
				</div>
				<!-- end forms -->
			</div>
			<!-- end content / right -->
		</div>
		<!-- end content -->
		
		<?php include('includes/general/footer.php'); ?>
	</body>
</html>