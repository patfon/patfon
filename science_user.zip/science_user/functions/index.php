<?php
include'../classes/connection.php';

//function to show old password for comparism
 function showOldPass($conn, $id){
	$sql = (" SELECT _pass FROM users WHERE id = '$id' ");
	$query = mysqli_query($conn,$sql);
	$row = mysqli_fetch_assoc($query);
	$password = $row['_pass'];
	return $password;
 }

 //function to update password
  function insertPass($conn, $id, $newPassword){
	$sql = (" UPDATE users SET _pass = '$newPassword' WHERE id = '$id'");
	$query = mysqli_query($conn,$sql);
	if($query){
		$_SESSION['success'] = 1;
		header('location:../includes/submission/password.php');
	}else{
		$_SESSION['failed'] = 1;
		header('location:../includes/submission/password.php');
	}
 }

 function updateProfile($conn, $id){
	  $fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email1 = $_POST['email1'];
	$email2 = $_POST['email2'];
	$pnum = $_POST['pnum'];
	$uni = $_POST['uni'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$areacode = $_POST['areacode'];
	$country = $_POST['country'];
	$website = $_POST['website'];
	$sql = (" UPDATE users SET _fname = '$fname',
							   _lname = '$lname',
							   _email = '$email1',
							   _email2  = '$email2',
							   _pnum = '$pnum',
							   _uni = '$uni',
							   _state = '$state',
							   _city = '$city',
							   _areacode = '$areacode',
							   _country = '$country',
							   _website = '$website'  WHERE id = '$id'");
	$query = mysqli_query($conn,$sql);
	if($query){
		$_SESSION['success'] = 1;
		header('location:../includes/submission/profile.php');
	}else{
		//$_SESSION['failed'] = 1;
		//header('location:../includes/submission/profile.php');
		echo mysqli_error($conn);
	}
 }
 
 

/* function showImage($conn, $id){
$query = $conn->query("SELECT _image FROM users WHERE id = '$id'");

if($query->num_rows > 0){
    while($row = $query->fetch_assoc()){
        $imageURL = '../../controller/images/'.$row["_image"];

    echo $imageURL;
}
}else{ 
     $errmsg = "<p>No image(s) found...</p>";
    echo $errmsg;
 }
}					
 */					
?>