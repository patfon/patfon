
$('#loads').click(function(e) {
    e.preventDefault();
    
	var pageToLoad = $('#loads').attr('href');
	
    
	$('.box').load(pageToLoad);
});


				