
			<!-- end content / left -->
				<div id="menu">
					<h6 id="h-menu-products" class="selected"><a href="#products"><span>General Info</span></a></h6>
					<ul id="menu-products" class="opened">
					<?php if($current_link === "localhost/science_user/index.php"){ ?>
						<li><a href="index.php">My Activities</a></li>
						<?php 
						}else{
						?>
						<li><a href="../../index.php">My Activities</a></li>
						<?php }?>
					</ul>
					
					<h6 id="h-menu-products" class="selected"><a href="#products"><span>Submission</span></a></h6>
					<ul id="menu-products" class="opened">
						<li><a href="#">Submit to Journal</a></li>
						<li><a href="#">Submit to Special Issues</a></li>
					</ul>
					
					<h6 id="h-menu-products" class="selected"><a href="#products"><span>Journal Activities</span></a></h6>
					<ul id="menu-products" class="opened">
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/manuscript.php';}else{echo'manuscript.php';}?>">My Manuscript</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/pay.php';}else{echo'pay.php';}?>">Pay for my Manuscript</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/app_result.php';}else{echo'app_result.php';}?>">Application result</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/reviewers.php';}else{echo'reviewers.php';}?>">Reviewer Members</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/result.php';}else{echo'result.php';}?>">Editorial result</a></li>
					</ul>
					
					<h6 id="h-menu-products" class="selected"><a href="#products"><span>My Profile</span></a></h6>
					<ul id="menu-products" class="opened" id="click">
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/profile.php';}else{echo'profile.php';}?>">Personal Info</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/image.php';}else{echo'image.php';}?>">Upload image</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/edu_qual.php';}else{echo'edu_qual.php';}?>">Educational Qualification</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/w_and_e.php';}else{echo'w_and_e.php';}?>">Work Experience</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/specialty.php';}else{echo'specialty.php';}?>">Specialty</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/books.php';}else{echo'books.php';}?>">Books</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/projects.php';}else{echo'projects.php';}?>">Projects</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/n_and_a.php';}else{echo'n_and_a.php';}?>">Honors and Awards</a></li>
						<li><a href="<?php if($current_link === "localhost/science_user/index.php"){echo'includes/submission/password.php';}else{echo'password.php';}?>" id="loads">Change Password</a></li>
					</ul>
					</div>
				<div id="date-picker"></div>
			<!-- end content / left -->