<!-- footer -->
		<div id="footer">
			<p>Copyright &copy; 2000-2010. Powered by SCHAI technologies.</p>
		</div>
		<!-- end footert -->
	