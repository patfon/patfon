<?php 
include_once("../../classes/connection.php");
?>

		<?php include('../../includes/general/header.php'); ?>
	<body>

		<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<?php

				include('../../includes/general/menu.php');
				include('../../includes/general/date.php');
				 ?>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
			<!-- forms -->
				<div class="box">
				
				
				<!--content of website goes below -->
					<div class="title">
						<h5>My Manuscript</h5>
					</div>
					
					<div class="table">
						<table>
							<thead>
								<tr>
								    <th class="center" width="15%">Manuscript Number</th>
									<th class="center" width="20%">Status</th>
									<th width="15%">Date</th>
									<th width="50%">Operation</th>
								</tr>
							</thead>
							<tbody>
							<?php
$id = 50;
	$query = mysqli_query($conn, "SELECT * FROM articles WHERE id = '$id'");
	while($row = mysqli_fetch_array($query)){
?>
								<tr>
								    <td rowspan="7" valign="middle" align="center">  <font color="blue"><b> <?php echo $mannum = $row['_articleid'];?>  </b> <br><br>(<?php echo $type = $row['_type'];?>)</font> </td>
									
								    <td> <div style="color:Red"> <b>1: New Submission (Under Processing)</b></div> </td>
									<td>  <?php echo $date = $row['_submitdate'];  /*  strtotime($date) */ ?> </td>
									<td> 
									 
									 <a href="../author/paper_load_updataAnthorOrReviewer?paperId=10029412&amp;roleTypeId2=300">Update Authors Information&nbsp;</a>
									
									 <br>  <br><a href="../author/paper_load_updataAnthorOrReviewer?paperId=10029412&amp;roleTypeId2=310">Update Reviewers Information</a>
									 
									 
									 <br>  <br><a href="../author/download?paperId=10029412&amp;stateId=1000&amp;fileType=1">Download Manuscript File</a>   
									 </td>
								    
									
								</tr>
								
								<tr>		
														   
								
								
								<td>  <i>2: Under Review </i> </td>
														   
						      <td> -- </td>
								
								<td> -- </td>
								
                               </tr>
							 
							 <tr>	
								
								
									<td>  <i>3: Revision</i> </td>
									
									<td> --  </td>
							
						
				         <td> --  </td>
					   		
								</tr>
								<tr>
								
									
							    	<td>  <i>4: Accepted/Rejected</i> </td>
									<td> --  </td>
									<td> --   </td>
								    
								</tr>
								<tr>		
										
									
									
									<td>  <i>5: In Press</i> </td>
										<td> --  </td>
									<td> --   </td>
									
								
								</tr>
								<tr>	
								
								
							    	<td>  <i>6: Published</i> </td>
									<td> --  </td>
									<td> --   </td>
								 
								</tr>
								
							
<?php
	}
?> 	
						  </tbody>
						</table>
	
					</div>
				<!--content of website ends here -->
				</div>
				<!-- end forms -->
			</div>
			<!-- end content / right -->
		</div>
		<!-- end content -->
		
		<?php include('../../includes/general/footer.php'); ?>
	</body>
</html>