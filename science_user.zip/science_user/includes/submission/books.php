<?php 
include_once("../../classes/connection.php");
?>

		<?php include('../../includes/general/header.php'); ?>
	<body>

		<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<?php

				include('../../includes/general/menu.php');
				include('../../includes/general/date.php');
				 ?>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
			<!-- forms -->
				<div class="box">
				
				
				<!--content of website goes below -->
				<div class="title">
						<h5>Message box</h5>
					</div>
					
					<div id="message-notice" class="message message-warning">
								<div class="image">
									<img src="../../resources/images/icons/notice.png" alt="Notice" height="32">
								</div>
								<div class="text">
									<h6>Example</h6>
									<span>Books:'Book title', Publisher name, ISBN: xxxxxxxxxxxxx, Book authors: name</span>
								</div>
								
					</div>
				
					<div class="title">
						<h5>Books</h5>
					</div>
					<form id="form" action="#" method="post">
					<div class="form">
						<div class="fields">
							<div class="field">
								<div class="label">
									<label for="input-large">Books:</label>
								</div>
								<div class="input">
									<input type="text" id="input-large" name="input.large" class="large">
								</div>
							</div>
							
							<div class="buttons">
								<input type="reset" name="reset" value="Reset" class="ui-button ui-widget ui-state-default ui-corner-all" role="button" aria-disabled="false"style="width:18%;">
								<div class="highlight">
									<input type="submit" name="submit.highlight" value="Submit" class="ui-button ui-widget ui-state-default ui-corner-all" role="button" aria-disabled="false" style="width:50%;">
									</div>
									<input type="submit" name="submit" value="Add" class="ui-button ui-widget ui-state-default ui-corner-all" role="button" aria-disabled="false"style="width:18%;">
								
								
							</div>
						</div>
					</div>
					</form>
				<!--content of website ends here -->
				</div>
				<!-- end forms -->
			</div>
			<!-- end content / right -->
		</div>
		<!-- end content -->
		
		<?php include('../../includes/general/footer.php'); ?>
	</body>
</html>