<?php 
include_once("../../classes/connection.php");
?>

		<?php include('../../includes/general/header.php'); ?>
	<body>

		<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<?php

				include('../../includes/general/menu.php');
				include('../../includes/general/date.php');
				 ?>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
			<!-- forms -->
				<div class="box">
				<div class="title">
						<h5>Message box</h5>
					</div>
					
					<div id="message-notice" class="message message-warning">
								<div class="image">
									<img src="../../resources/images/icons/notice.png" alt="Notice" height="32">
								</div>
								<div class="text">
									<h6>Notice!</h6>
									<span>All your manuscripts accepted are shown below. If there are some papers you haven't paid, <br><br>
										please click the corresponding "accepted" after the title to pay for your paper.<br><br></span>
								</div>
								
					</div>
				
				<!--content of website goes below -->
					<div class="title">
						<h5>Pay For Manuscript</h5>
					</div>
					<table style="font-family: Lucida Grande, Verdana, Lucida Sans Regular, Lucida Sans Unicode, Arial, sans-serif;line-height: 20px;text-align:center;">
							<thead>
								<tr>
										
									<th width="20%">Manuscript Number</th>
							<th>Manuscript Title</th>
									
									<th width="20%">Payment/status</th>
								</tr>
							</thead>
							<tbody>
							
<?php
$id = 50;
	$query = mysqli_query($conn, "SELECT * FROM articles WHERE id = '$id'");
	while($row = mysqli_fetch_array($query)){
?>
					<tr>
						<td><?php echo $mannum = $row['_articleid'];?></td>
						<td><?php echo $mantitle = $row['_title'];?> &nbsp; <a id="dialog-form-open" href="#">pay now</a></td>
						<td><?php //echo $pay = $row['gender'];?></td>
					</tr>
<?php
	}
?>               </tbody>
						</table>
				<!--content of website ends here -->
				</div>
				<!-- end forms -->
			</div>
			<!-- end content / right -->
		</div>
		<!-- end content -->
		<div id="dialog-form" title="Pay for Manuscript">
			<p>All form fields are required.</p>
			<form action="#" method="post">
			<div class="form">
				<div class="fields">
					<div class="field field-first">
						<div class="label">
							<label for="input">Comment:</label>
						</div>
						<div class="input">
							<input type="text" id="user-name" name="user.name" />
						</div>
					</div>
					<div class="field">
						<div class="label">
							<label for="date">Date</label>
						</div>
						<div class="input input-date">
							<input type="text" id="user-name" name="user.name"/>
						</div>
					</div>
					<div class="field">
						<div class="label">
							<label for="input">Upload payment Reciept:</label>
								<br>	<br>
							<div class="input">
							<input type="file" id="user-email" name="user.email" />
						
						</div>
						</div>
						
					</div>
					<div class="field">
						<div class="label">
							<label for="input">Password:</label>
						</div>
						<div class="input">
							<input type="text" id="user-password" name="user.password" />
						</div>
					</div>
				</div>
				
			</div>
			</form>
		</div>
		<?php include('../../includes/general/footer.php'); ?>
	</body>
</html>