<?php 
include_once("../../classes/connection.php");
?>

		<?php include('../../includes/general/header.php'); ?>
	<body>

		<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<?php

				include('../../includes/general/menu.php');
				include('../../includes/general/date.php');
				 ?>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
			<!-- forms -->
				<div class="box">
				
				<div class="title">
						<h5>Message box</h5>
					</div>
				<!--content of website goes below -->
				<blockquote>Manuscript reviewers are vital to the publication process,
				and as a reviewer you will gain valuable experience in scientific publishing. 
				We invite you to become a reviewer of our journal(s). 
				</blockquote>
				<h5>Some benefits of being a reviewer: </h5>
				<blockquote>1. Being a peer reviewer opens doors to incredible opportunities.
				Peer review services will enhance your knowledge of professional standards; 
				and quickly earn the respect of your peers. 
				<br>2. The reviewers who need financial support could enjoy 20% discount to 
				publish their articles in SciencePG.
				</blockquote>
				<p></p>
				<blockquote>
				In order to provide a good review, a thoughtful and well-balanced
				report with suggested improvements for our authors, Reviewers must be prepared
				to invest the necessary time to evaluate the manuscript thoroughly.
				</blockquote>
				<p></p>
				<blockquote>If you are interested in becoming the reviewer member, please fill out the following information.</blockquote>
				<p></p>
				<div id="message-notice" class="message message-warning">
								<div class="image">
									<img src="../../resources/images/icons/notice.png" alt="Notice" height="32">
								</div>
								<div class="text">
									<h6>Notice!</h6>
									<span>For the sake of your time arrangement, you can only choose one journal to be as an editorial member or a reviewer.<br><br>
										For the result of applying for Reviewer, please click goto <b>"Application result"</b> to see the application result.<br><br>
									</span>
								</div>
								
					</div>
					<div class="title">
						<h5>Upload your CV</h5>
					</div>
					<form id="form1" name="form1" action="../../controller/image.php" method="post" class="validate form-horizontal" enctype="multipart/form-data">
					<div class="form">
						<div class="fields">
		      	<div class="field">
								<div class="label">
									<label for="file">Upload Your cv : </label>
								</div>
								<div class="input input-file">
								<br>
         

            
             <div id="inputfile2" class="inputfile" style="  height:30px; background:url(../spg/decorator/resources/images/define/button.jpg);">
             <input type="file" class="file" id="upload" style="height:30px;border: 0px;" name="image" size="1" onchange="test5(this)">
          
             </div>
			  (Only accept .pdf, .doc and .docx file)
              <span class="error"></span> 
								</div>
			</div>
						</div>
					 <div class="form">
						<div class="fields">
							<div class="buttons">							
							   <div class="highlight">
							      
                  <input type="submit" name="Button_Submit" onclick="CheckForm();" value="Submit" onmouseover="change1(this)" onmouseout="change2(this)" style="cursor: pointer;color: #ffffff; width:100px;height:28px;background :#4e85bb url('../spg/decorator/resources/images/define/btn01.jpg') no-repeat;border-top: 0px solid #5c91a4;border-left: 0px solid #2a6f89;border-right: 1px solid #2b7089;border-bottom: 1px solid #1a6480;">
		           </div>							
							</div>
					</div>
					</div>	
					</div>
					</form>
					<div class="title">
						<h5>Choose Journal Titles</h5>
					</div>
					<div class="table">
       <table style="width: 110%;border-right: 0px;" valign="middle">
							<thead>
								<tr>
								    <th class="center" width="34%">Category </th>
<th align="left" width="" style="text-align: left;" class="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Journal Title</th>
							    
							    </tr>
							</thead>
							<tbody style="border-right: 0px; " valign="middle">
							
						  	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(0);" id="0" style="color: red;">Biology and Life Sciences 
								</a>
								</td>
							
							
									
								 <td id="first" rowspan="15" style="display: none;">
								  Please select a category.
								</td>
								
							
						      <td rowspan="15">
						      
					  		      
				<div style="display: block;" id="journal0">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="110"></span>
               <label for="radio-3" style="">Advances in Biochemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="293"></span>
               <label for="radio-3" style="">Journal of Chemical, Environmental and Biological Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="610"></span>
               <label for="radio-3" style="">International Journal of Photochemistry and Photobiology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="612"></span>
               <label for="radio-3" style="">American Journal of Plant Biology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="614"></span>
               <label for="radio-3" style="">International Journal of Food Science and Biotechnology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="609"></span>
               <label for="radio-3" style="">International Journal of Bioorganic Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="521"></span>
               <label for="radio-3" style="">International Journal of Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="535"></span>
               <label for="radio-3" style="">Bioprocess Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="539"></span>
               <label for="radio-3" style="">Journal of Biomaterials </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="540"></span>
               <label for="radio-3" style="">World Journal of Food Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="547"></span>
               <label for="radio-3" style="">American Journal of Entomology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="307"></span>
               <label for="radio-3" style="">International Journal of Animal Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="657"></span>
               <label for="radio-3" style="">American Journal of Zoology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="275"></span>
               <label for="radio-3" style="">Biomedical Statistics and Informatics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="111"></span>
               <label for="radio-3" style="">Cell Biology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="112"></span>
               <label for="radio-3" style="">Computational Biology and Bioinformatics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="116"></span>
               <label for="radio-3" style="">International Journal of Genetics and Genomics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="117"></span>
               <label for="radio-3" style="">European Journal of Biophysics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="118"></span>
               <label for="radio-3" style="">American Journal of Life Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="119"></span>
               <label for="radio-3" style="">Agriculture, Forestry and Fisheries</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="211"></span>
               <label for="radio-3" style="">Plant</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="212"></span>
               <label for="radio-3" style="">Animal and Veterinary Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="215"></span>
               <label for="radio-3" style="">Journal of Plant Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="216"></span>
               <label for="radio-3" style="">Advances in Bioscience and Bioengineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="217"></span>
               <label for="radio-3" style="">American Journal of Bioscience and Bioengineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="218"></span>
               <label for="radio-3" style="">American Journal of Agriculture and Forestry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="219"></span>
               <label for="radio-3" style="">American Journal of BioScience </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="221"></span>
               <label for="radio-3" style="">International Journal of Biomedical Materials Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="259"></span>
               <label for="radio-3" style="">International Journal of Biomedical Science and Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="320"></span>
               <label for="radio-3" style="">Journal of Diseases and Medicinal Plants</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="329"></span>
               <label for="radio-3" style="">Journal of Drug Design and Medicinal Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="330"></span>
               <label for="radio-3" style="">International Journal of Pharmacy and Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="343"></span>
               <label for="radio-3" style="">International Journal of Applied Agricultural Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="345"></span>
               <label for="radio-3" style="">International Journal of Biomedical Engineering and Clinical Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="352"></span>
               <label for="radio-3" style="">European Journal of Clinical and Biomedical Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="362"></span>
               <label for="radio-3" style="">Biomedical Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="365"></span>
               <label for="radio-3" style="">American Journal of Chemical and Biochemical Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="375"></span>
               <label for="radio-3" style="">American Journal of Biological and Environmental Statistics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="384"></span>
               <label for="radio-3" style="">Frontiers in Environmental Microbiology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="387"></span>
               <label for="radio-3" style="">Advances in Applied Physiology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="396"></span>
               <label for="radio-3" style="">International Journal of Microbiology and Biotechnology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="655"></span>
               <label for="radio-3" style="">American Journal of Biomedical and Life Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="170"></span>
               <label for="radio-3" style="">International Journal of Psychological and Brain Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="207"></span>
               <label for="radio-3" style="">International Journal of Natural Resource Ecology and Management  </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="231"></span>
               <label for="radio-3" style="">Ecology and Evolutionary Biology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="232"></span>
               <label for="radio-3" style="">International Journal of Agricultural Economics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="243"></span>
               <label for="radio-3" style="">Chemical and Biomolecular Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="244"></span>
               <label for="radio-3" style="">Biochemistry and Molecular Biology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="246"></span>
               <label for="radio-3" style="">International Journal of Biochemistry, Biophysics &amp; Molecular Biology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="516"></span>
               <label for="radio-3" style="">International Journal of Ecotoxicology and Ecobiology</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal1">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="110"></span>
               <label for="radio-3" style="">Advances in Biochemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="292"></span>
               <label for="radio-3" style="">International Journal of Environmental Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="608"></span>
               <label for="radio-3" style="">Petroleum Science and Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="601"></span>
               <label for="radio-3" style="">Journal of Energy, Environmental &amp; Chemical Engineering </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="607"></span>
               <label for="radio-3" style="">Colloid and Surface Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="610"></span>
               <label for="radio-3" style="">International Journal of Photochemistry and Photobiology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="609"></span>
               <label for="radio-3" style="">International Journal of Bioorganic Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="540"></span>
               <label for="radio-3" style="">World Journal of Food Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="293"></span>
               <label for="radio-3" style="">Journal of Chemical, Environmental and Biological Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="121"></span>
               <label for="radio-3" style="">Modern Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="125"></span>
               <label for="radio-3" style="">Science Journal of Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="298"></span>
               <label for="radio-3" style="">International Journal of Atmospheric and Oceanic Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="128"></span>
               <label for="radio-3" style="">American Journal of Physical Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="223"></span>
               <label for="radio-3" style="">Science Journal of Analytical Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="224"></span>
               <label for="radio-3" style="">American Journal of Chemical Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="227"></span>
               <label for="radio-3" style="">American Journal of Applied Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="228"></span>
               <label for="radio-3" style="">International Journal of Computational and Theoretical Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="316"></span>
               <label for="radio-3" style="">American Journal of Polymer Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="329"></span>
               <label for="radio-3" style="">Journal of Drug Design and Medicinal Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="330"></span>
               <label for="radio-3" style="">International Journal of Pharmacy and Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="521"></span>
               <label for="radio-3" style="">International Journal of Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="534"></span>
               <label for="radio-3" style="">Applied Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="341"></span>
               <label for="radio-3" style="">American Journal of Heterocyclic Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="365"></span>
               <label for="radio-3" style="">American Journal of Chemical and Biochemical Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="377"></span>
               <label for="radio-3" style="">American Journal of Applied and Industrial Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="398"></span>
               <label for="radio-3" style="">American Journal of Quantum Chemistry and Molecular Spectroscopy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="206"></span>
               <label for="radio-3" style="">World Journal of Applied Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="243"></span>
               <label for="radio-3" style="">Chemical and Biomolecular Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="244"></span>
               <label for="radio-3" style="">Biochemistry and Molecular Biology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="246"></span>
               <label for="radio-3" style="">International Journal of Biochemistry, Biophysics &amp; Molecular Biology</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal2">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="265"></span>
               <label for="radio-3" style="">International Journal of Clinical Dermatology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="271"></span>
               <label for="radio-3" style="">Clinical Neurology and Neuroscience</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="272"></span>
               <label for="radio-3" style="">International Journal of Clinical Urology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="273"></span>
               <label for="radio-3" style="">International Journal of Clinical Oncology and Cancer Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="274"></span>
               <label for="radio-3" style="">Pathology and Laboratory Medicine</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="275"></span>
               <label for="radio-3" style="">Biomedical Statistics and Informatics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="278"></span>
               <label for="radio-3" style="">International Journal of Diabetes and Endocrinology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="279"></span>
               <label for="radio-3" style="">Cardiology and Cardiovascular Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="280"></span>
               <label for="radio-3" style="">International Journal of Infectious Diseases and Therapy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="282"></span>
               <label for="radio-3" style="">International Journal of Gastroenterology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="283"></span>
               <label for="radio-3" style="">International Journal of Chinese Medicine</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="287"></span>
               <label for="radio-3" style="">World Journal of Public Health</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="288"></span>
               <label for="radio-3" style="">International Journal of Health Economics and Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="115"></span>
               <label for="radio-3" style="">International Journal of Immunology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="524"></span>
               <label for="radio-3" style="">International Journal of Neurosurgery</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="614"></span>
               <label for="radio-3" style="">International Journal of Food Science and Biotechnology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="116"></span>
               <label for="radio-3" style="">International Journal of Genetics and Genomics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="151"></span>
               <label for="radio-3" style="">Clinical Medicine Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="540"></span>
               <label for="radio-3" style="">World Journal of Food Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="521"></span>
               <label for="radio-3" style="">International Journal of Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="152"></span>
               <label for="radio-3" style="">American Journal of Nursing Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="153"></span>
               <label for="radio-3" style="">International Journal of Nutrition and Food Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="154"></span>
               <label for="radio-3" style="">Journal of Food and Nutrition Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="156"></span>
               <label for="radio-3" style="">International Journal of Medical Imaging</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="158"></span>
               <label for="radio-3" style="">Cancer Research Journal</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="159"></span>
               <label for="radio-3" style="">Science Journal of Clinical Medicine</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="221"></span>
               <label for="radio-3" style="">International Journal of Biomedical Materials Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="251"></span>
               <label for="radio-3" style="">Science Journal of Public Health</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="252"></span>
               <label for="radio-3" style="">American Journal of Internal Medicine</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="253"></span>
               <label for="radio-3" style="">Journal of Surgery</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="254"></span>
               <label for="radio-3" style="">American Journal of Clinical and Experimental Medicine</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="255"></span>
               <label for="radio-3" style="">Journal of Gynecology and Obstetrics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="256"></span>
               <label for="radio-3" style="">Advances in Surgical Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="257"></span>
               <label for="radio-3" style="">Journal of Anesthesiology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="259"></span>
               <label for="radio-3" style="">International Journal of Biomedical Science and Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="314"></span>
               <label for="radio-3" style="">International Journal of Homeopathy &amp; Natural Medicines</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="320"></span>
               <label for="radio-3" style="">Journal of Diseases and Medicinal Plants</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="321"></span>
               <label for="radio-3" style="">Radiation Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="326"></span>
               <label for="radio-3" style="">Central African Journal of Public Health</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="327"></span>
               <label for="radio-3" style="">International Journal of HIV/AIDS Prevention, Education and Behavioural Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="329"></span>
               <label for="radio-3" style="">Journal of Drug Design and Medicinal Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="330"></span>
               <label for="radio-3" style="">International Journal of Pharmacy and Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="334"></span>
               <label for="radio-3" style="">International Journal of Dental Medicine</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="335"></span>
               <label for="radio-3" style="">International Journal of Clinical and Experimental Medical Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="336"></span>
               <label for="radio-3" style="">International Journal of Food Engineering and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="344"></span>
               <label for="radio-3" style="">Journal of Health and Environmental Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="345"></span>
               <label for="radio-3" style="">International Journal of Biomedical Engineering and Clinical Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="352"></span>
               <label for="radio-3" style="">European Journal of Clinical and Biomedical Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="355"></span>
               <label for="radio-3" style="">International Journal of Cardiovascular and Thoracic Surgery</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="361"></span>
               <label for="radio-3" style="">International Journal of Clinical and Developmental Anatomy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="362"></span>
               <label for="radio-3" style="">Biomedical Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="368"></span>
               <label for="radio-3" style="">International Journal of Clinical Oral and Maxillofacial Surgery</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="373"></span>
               <label for="radio-3" style="">International Journal of Otorhinolaryngology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="378"></span>
               <label for="radio-3" style="">Journal of Family Medicine and Health Care</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="380"></span>
               <label for="radio-3" style="">American Journal of Pediatrics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="391"></span>
               <label for="radio-3" style="">International Journal of Neurologic Physical Therapy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="515"></span>
               <label for="radio-3" style="">Pharmaceutical Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="651"></span>
               <label for="radio-3" style="">European Journal of Preventive Medicine</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="653"></span>
               <label for="radio-3" style="">American Journal of Psychiatry and Neuroscience </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="654"></span>
               <label for="radio-3" style="">Journal of Cancer Treatment and Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="655"></span>
               <label for="radio-3" style="">American Journal of Biomedical and Life Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="656"></span>
               <label for="radio-3" style="">American Journal of Health Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="170"></span>
               <label for="radio-3" style="">International Journal of Psychological and Brain Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="230"></span>
               <label for="radio-3" style="">International Journal of Ophthalmology &amp; Visual Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="234"></span>
               <label for="radio-3" style="">Rehabilitation Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="235"></span>
               <label for="radio-3" style="">American Journal of Laboratory Medicine</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal3">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="117"></span>
               <label for="radio-3" style="">European Journal of Biophysics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="290"></span>
               <label for="radio-3" style="">Engineering Physics  </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="525"></span>
               <label for="radio-3" style="">American Journal of Mechanical and Materials Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="537"></span>
               <label for="radio-3" style="">Control Science and Engineering </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="300"></span>
               <label for="radio-3" style="">Nuclear Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="619"></span>
               <label for="radio-3" style="">Engineering Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="122"></span>
               <label for="radio-3" style="">American Journal of Modern Physics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="124"></span>
               <label for="radio-3" style="">International Journal of High Energy Physics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="610"></span>
               <label for="radio-3" style="">International Journal of Photochemistry and Photobiology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="126"></span>
               <label for="radio-3" style="">Optics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="127"></span>
               <label for="radio-3" style="">American Journal of Optics and Photonics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="220"></span>
               <label for="radio-3" style="">International Journal of Mechanical Engineering and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="225"></span>
               <label for="radio-3" style="">American Journal of Electromagnetics and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="226"></span>
               <label for="radio-3" style="">American Journal of Nano Research and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="301"></span>
               <label for="radio-3" style="">American Journal of Astronomy and Astrophysics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="302"></span>
               <label for="radio-3" style="">International Journal of Astrophysics and Space Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="309"></span>
               <label for="radio-3" style="">American Journal of Aerospace Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="315"></span>
               <label for="radio-3" style="">International Journal of Fluid Mechanics &amp; Thermal Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="321"></span>
               <label for="radio-3" style="">Radiation Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="322"></span>
               <label for="radio-3" style="">International Journal of Applied Mathematics and Theoretical Physics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="332"></span>
               <label for="radio-3" style="">International Journal of Electrical Components and Energy Conversion</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="356"></span>
               <label for="radio-3" style="">Nanoscience and Nanometrology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="359"></span>
               <label for="radio-3" style="">American Journal of Nanosciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="382"></span>
               <label for="radio-3" style="">Fluid Mechanics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="398"></span>
               <label for="radio-3" style="">American Journal of Quantum Chemistry and Molecular Spectroscopy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="621"></span>
               <label for="radio-3" style="">American Journal of Mechanics and Applications </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="622"></span>
               <label for="radio-3" style="">American Journal of Physics and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="200"></span>
               <label for="radio-3" style="">World Journal of Applied Physics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="248"></span>
               <label for="radio-3" style="">American Journal of Mechanical and Industrial Engineering</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal4">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="123"></span>
               <label for="radio-3" style="">International Journal of Materials Science and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="606"></span>
               <label for="radio-3" style="">Composite Materials</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="618"></span>
               <label for="radio-3" style="">American Journal of Construction and Building Materials</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="525"></span>
               <label for="radio-3" style="">American Journal of Mechanical and Materials Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="539"></span>
               <label for="radio-3" style="">Journal of Biomaterials </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="129"></span>
               <label for="radio-3" style="">Advances in Materials</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="221"></span>
               <label for="radio-3" style="">International Journal of Biomedical Materials Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="619"></span>
               <label for="radio-3" style="">Engineering Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="226"></span>
               <label for="radio-3" style="">American Journal of Nano Research and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="354"></span>
               <label for="radio-3" style="">Journal of Photonic Materials and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="356"></span>
               <label for="radio-3" style="">Nanoscience and Nanometrology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="359"></span>
               <label for="radio-3" style="">American Journal of Nanosciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="150"></span>
               <label for="radio-3" style="">American Journal of Materials Synthesis and Processing</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="534"></span>
               <label for="radio-3" style="">Applied Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal5">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="523"></span>
               <label for="radio-3" style="">American Journal of Electrical and Computer Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="616"></span>
               <label for="radio-3" style="">American Journal of Mathematical and Computer Modelling</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="603"></span>
               <label for="radio-3" style="">American Journal of Data Mining and Knowledge Discovery </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="605"></span>
               <label for="radio-3" style="">International Journal of Discrete Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="526"></span>
               <label for="radio-3" style="">American Journal of Information Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="289"></span>
               <label for="radio-3" style="">Engineering  Mathematics </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="141"></span>
               <label for="radio-3" style="">Pure and Applied Mathematics Journal</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="146"></span>
               <label for="radio-3" style="">American Journal of Theoretical and Applied Statistics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="537"></span>
               <label for="radio-3" style="">Control Science and Engineering </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="521"></span>
               <label for="radio-3" style="">International Journal of Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="147"></span>
               <label for="radio-3" style="">Applied and Computational Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="275"></span>
               <label for="radio-3" style="">Biomedical Statistics and Informatics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="148"></span>
               <label for="radio-3" style="">American Journal of Applied Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="149"></span>
               <label for="radio-3" style="">Science Journal of Applied Mathematics and Statistics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="322"></span>
               <label for="radio-3" style="">International Journal of Applied Mathematics and Theoretical Physics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="347"></span>
               <label for="radio-3" style="">International Journal of Theoretical and Applied Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="348"></span>
               <label for="radio-3" style="">Mathematics Letters</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="353"></span>
               <label for="radio-3" style="">International Journal of Management and Fuzzy Systems</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="367"></span>
               <label for="radio-3" style="">International Journal of Data Science and Analysis</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="390"></span>
               <label for="radio-3" style="">International Journal on Data Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="245"></span>
               <label for="radio-3" style="">International Journal of Systems Science and Applied Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="247"></span>
               <label for="radio-3" style="">Mathematics and Computer Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="389"></span>
               <label for="radio-3" style="">Mathematical Modelling and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="379"></span>
               <label for="radio-3" style="">International Journal of Statistical Distributions and Applications</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal6">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="112"></span>
               <label for="radio-3" style="">Computational Biology and Bioinformatics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="542"></span>
               <label for="radio-3" style="">American Journal of Artificial Intelligence</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="303"></span>
               <label for="radio-3" style="">American Journal of Computer Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="538"></span>
               <label for="radio-3" style="">American Journal of Education and Information Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="526"></span>
               <label for="radio-3" style="">American Journal of Information Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="523"></span>
               <label for="radio-3" style="">American Journal of Electrical and Computer Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="605"></span>
               <label for="radio-3" style="">International Journal of Discrete Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="603"></span>
               <label for="radio-3" style="">American Journal of Data Mining and Knowledge Discovery </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="604"></span>
               <label for="radio-3" style="">Machine Learning Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="616"></span>
               <label for="radio-3" style="">American Journal of Mathematical and Computer Modelling</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="130"></span>
               <label for="radio-3" style="">International Journal of Sensors and Sensor Networks</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="131"></span>
               <label for="radio-3" style="">Advances in Networks</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="537"></span>
               <label for="radio-3" style="">Control Science and Engineering </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="619"></span>
               <label for="radio-3" style="">Engineering Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="132"></span>
               <label for="radio-3" style="">American Journal of Networks and Communications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="275"></span>
               <label for="radio-3" style="">Biomedical Statistics and Informatics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="133"></span>
               <label for="radio-3" style="">International Journal of Wireless Communications and Mobile Computing</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="134"></span>
               <label for="radio-3" style="">Automation, Control and Intelligent Systems</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="135"></span>
               <label for="radio-3" style="">International Journal of Intelligent Information Systems</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="521"></span>
               <label for="radio-3" style="">International Journal of Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="534"></span>
               <label for="radio-3" style="">Applied Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="136"></span>
               <label for="radio-3" style="">Science Journal of Circuits, Systems and Signal Processing</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="137"></span>
               <label for="radio-3" style="">American Journal of Software Engineering and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="138"></span>
               <label for="radio-3" style="">American Journal of Remote Sensing</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="139"></span>
               <label for="radio-3" style="">Communications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="147"></span>
               <label for="radio-3" style="">Applied and Computational Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="148"></span>
               <label for="radio-3" style="">American Journal of Applied Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="156"></span>
               <label for="radio-3" style="">International Journal of Medical Imaging</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="165"></span>
               <label for="radio-3" style="">American Journal of Electrical Power and Energy Systems</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="225"></span>
               <label for="radio-3" style="">American Journal of Electromagnetics and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="236"></span>
               <label for="radio-3" style="">American Journal of Embedded Systems and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="237"></span>
               <label for="radio-3" style="">Software Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="238"></span>
               <label for="radio-3" style="">Internet of Things and Cloud Computing</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="239"></span>
               <label for="radio-3" style="">Journal of Electrical and Electronic Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="317"></span>
               <label for="radio-3" style="">Advances in Wireless Communications and Networks</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="332"></span>
               <label for="radio-3" style="">International Journal of Electrical Components and Energy Conversion</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="339"></span>
               <label for="radio-3" style="">American Journal of Neural Networks and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="346"></span>
               <label for="radio-3" style="">International Journal of Sustainability Management and Information Technologies</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="367"></span>
               <label for="radio-3" style="">International Journal of Data Science and Analysis</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="390"></span>
               <label for="radio-3" style="">International Journal on Data Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="621"></span>
               <label for="radio-3" style="">American Journal of Mechanics and Applications </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="104"></span>
               <label for="radio-3" style="">American Journal of Operations Management and Information Systems</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="210"></span>
               <label for="radio-3" style="">International Journal of Industrial and Manufacturing Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="230"></span>
               <label for="radio-3" style="">International Journal of Ophthalmology &amp; Visual Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="245"></span>
               <label for="radio-3" style="">International Journal of Systems Science and Applied Mathematics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="247"></span>
               <label for="radio-3" style="">Mathematics and Computer Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="517"></span>
               <label for="radio-3" style="">International Journal of Information and Communication Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="248"></span>
               <label for="radio-3" style="">American Journal of Mechanical and Industrial Engineering</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal7">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="295"></span>
               <label for="radio-3" style="">American  Journal of Environmental and Resource Economics  </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="161"></span>
               <label for="radio-3" style="">Earth Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="617"></span>
               <label for="radio-3" style="">Journal of Civil, Construction and Environmental Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="298"></span>
               <label for="radio-3" style="">International Journal of Atmospheric and Oceanic Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="602"></span>
               <label for="radio-3" style="">International Journal of Energy and Environmental Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="529"></span>
               <label for="radio-3" style="">American Journal of Environmental Science and Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="601"></span>
               <label for="radio-3" style="">Journal of Energy, Environmental &amp; Chemical Engineering </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="608"></span>
               <label for="radio-3" style="">Petroleum Science and Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="162"></span>
               <label for="radio-3" style="">International Journal of Environmental Monitoring and Analysis</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="292"></span>
               <label for="radio-3" style="">International Journal of Environmental Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="293"></span>
               <label for="radio-3" style="">Journal of Chemical, Environmental and Biological Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="163"></span>
               <label for="radio-3" style="">American Journal of Environmental Protection</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="164"></span>
               <label for="radio-3" style="">International Journal of Energy and Power Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="165"></span>
               <label for="radio-3" style="">American Journal of Electrical Power and Energy Systems</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="619"></span>
               <label for="radio-3" style="">Engineering Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="534"></span>
               <label for="radio-3" style="">Applied Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="166"></span>
               <label for="radio-3" style="">Journal of Water Resources and Ocean Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="167"></span>
               <label for="radio-3" style="">Journal of Energy and Natural Resources</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="168"></span>
               <label for="radio-3" style="">American Journal of Energy Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="169"></span>
               <label for="radio-3" style="">International Journal of Sustainable and Green Energy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="266"></span>
               <label for="radio-3" style="">International Journal of Environmental Protection and Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="267"></span>
               <label for="radio-3" style="">Hydrology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="268"></span>
               <label for="radio-3" style="">International Journal of Oil, Gas and Coal Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="269"></span>
               <label for="radio-3" style="">Science Journal of Energy Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="332"></span>
               <label for="radio-3" style="">International Journal of Electrical Components and Energy Conversion</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="344"></span>
               <label for="radio-3" style="">Journal of Health and Environmental Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="363"></span>
               <label for="radio-3" style="">American Journal of Modern Energy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="369"></span>
               <label for="radio-3" style="">American Journal of Water Science and Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="371"></span>
               <label for="radio-3" style="">International Journal of Mineral Processing and Extractive Metallurgy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="375"></span>
               <label for="radio-3" style="">American Journal of Biological and Environmental Statistics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="384"></span>
               <label for="radio-3" style="">Frontiers in Environmental Microbiology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="349"></span>
               <label for="radio-3" style="">International Journal of Economy, Energy and Environment</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="516"></span>
               <label for="radio-3" style="">International Journal of Ecotoxicology and Ecobiology</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal8">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="229"></span>
               <label for="radio-3" style="">American Journal of Civil Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="618"></span>
               <label for="radio-3" style="">American Journal of Construction and Building Materials</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="383"></span>
               <label for="radio-3" style="">International Journal of Architecture, Arts and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="241"></span>
               <label for="radio-3" style="">Landscape Architecture and Regional Planning</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="617"></span>
               <label for="radio-3" style="">Journal of Civil, Construction and Environmental Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="242"></span>
               <label for="radio-3" style="">Urban and Regional Planning</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="619"></span>
               <label for="radio-3" style="">Engineering Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="521"></span>
               <label for="radio-3" style="">International Journal of Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="534"></span>
               <label for="radio-3" style="">Applied Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal9">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="187"></span>
               <label for="radio-3" style="">American Journal of Traffic and Transportation Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="619"></span>
               <label for="radio-3" style="">Engineering Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="514"></span>
               <label for="radio-3" style="">International Journal of Transportation Engineering and Technology</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal10">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="180"></span>
               <label for="radio-3" style="">Science Innovation</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="619"></span>
               <label for="radio-3" style="">Engineering Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="535"></span>
               <label for="radio-3" style="">Bioprocess Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="522"></span>
               <label for="radio-3" style="">International Journal of Engineering Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="617"></span>
               <label for="radio-3" style="">Journal of Civil, Construction and Environmental Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="181"></span>
               <label for="radio-3" style="">Science Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="289"></span>
               <label for="radio-3" style="">Engineering  Mathematics </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="290"></span>
               <label for="radio-3" style="">Engineering Physics  </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="182"></span>
               <label for="radio-3" style="">Science Discovery</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="523"></span>
               <label for="radio-3" style="">American Journal of Electrical and Computer Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="525"></span>
               <label for="radio-3" style="">American Journal of Mechanical and Materials Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="183"></span>
               <label for="radio-3" style="">International Journal of Science, Technology and Society</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="220"></span>
               <label for="radio-3" style="">International Journal of Mechanical Engineering and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="323"></span>
               <label for="radio-3" style="">Advances in Sciences and Humanities</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="521"></span>
               <label for="radio-3" style="">International Journal of Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="534"></span>
               <label for="radio-3" style="">Applied Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="537"></span>
               <label for="radio-3" style="">Control Science and Engineering </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="325"></span>
               <label for="radio-3" style="">American Journal of Science, Engineering and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="339"></span>
               <label for="radio-3" style="">American Journal of Neural Networks and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="358"></span>
               <label for="radio-3" style="">International Journal of Science and Qualitative Analysis</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="371"></span>
               <label for="radio-3" style="">International Journal of Mineral Processing and Extractive Metallurgy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="377"></span>
               <label for="radio-3" style="">American Journal of Applied and Industrial Chemistry</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="381"></span>
               <label for="radio-3" style="">International Journal of Sustainable Development Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="395"></span>
               <label for="radio-3" style="">American Journal of Applied Scientific Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="102"></span>
               <label for="radio-3" style="">American Journal of Engineering and Technology Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="108"></span>
               <label for="radio-3" style="">Engineering and Applied Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="109"></span>
               <label for="radio-3" style="">Advances in Applied Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="210"></span>
               <label for="radio-3" style="">International Journal of Industrial and Manufacturing Systems Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="248"></span>
               <label for="radio-3" style="">American Journal of Mechanical and Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="514"></span>
               <label for="radio-3" style="">International Journal of Transportation Engineering and Technology</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal11">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="297"></span>
               <label for="radio-3" style="">Journal of Business and  Economic Development   </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="171"></span>
               <label for="radio-3" style="">Journal of Finance and Accounting</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="522"></span>
               <label for="radio-3" style="">International Journal of Engineering Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="306"></span>
               <label for="radio-3" style="">International Journal of Law and Society</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="304"></span>
               <label for="radio-3" style="">Journal of Political Science and International Relations</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="172"></span>
               <label for="radio-3" style="">International Journal of Economic Behavior and Organization</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="295"></span>
               <label for="radio-3" style="">American  Journal of Environmental and Resource Economics  </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="288"></span>
               <label for="radio-3" style="">International Journal of Health Economics and Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="173"></span>
               <label for="radio-3" style="">International Journal of Economics, Finance and Management Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="174"></span>
               <label for="radio-3" style="">Journal of World Economic Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="175"></span>
               <label for="radio-3" style="">Science Journal of Business and Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="176"></span>
               <label for="radio-3" style="">Journal of Human Resource Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="536"></span>
               <label for="radio-3" style="">Industrial Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="177"></span>
               <label for="radio-3" style="">Economics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="178"></span>
               <label for="radio-3" style="">International Journal of Business and Economics Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="179"></span>
               <label for="radio-3" style="">Journal of Investment and Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="324"></span>
               <label for="radio-3" style="">European Business &amp; Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="328"></span>
               <label for="radio-3" style="">American Journal of Theoretical and Applied Business</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="346"></span>
               <label for="radio-3" style="">International Journal of Sustainability Management and Information Technologies</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="353"></span>
               <label for="radio-3" style="">International Journal of Management and Fuzzy Systems</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="366"></span>
               <label for="radio-3" style="">International Journal of Accounting, Finance and Risk Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="393"></span>
               <label for="radio-3" style="">International Journal of Finance and Banking Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="101"></span>
               <label for="radio-3" style="">American Journal of Management Science and Engineering</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="104"></span>
               <label for="radio-3" style="">American Journal of Operations Management and Information Systems</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="207"></span>
               <label for="radio-3" style="">International Journal of Natural Resource Ecology and Management  </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="213"></span>
               <label for="radio-3" style="">International Journal of Hospitality &amp; Tourism Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="232"></span>
               <label for="radio-3" style="">International Journal of Agricultural Economics</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal12">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="296"></span>
               <label for="radio-3" style="">Higher Education Research  </label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="192"></span>
               <label for="radio-3" style="">International Journal of Elementary Education</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="538"></span>
               <label for="radio-3" style="">American Journal of Education and Information Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="193"></span>
               <label for="radio-3" style="">International Journal of Secondary Education</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="196"></span>
               <label for="radio-3" style="">Education Journal</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="526"></span>
               <label for="radio-3" style="">American Journal of Information Science and Technology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="197"></span>
               <label for="radio-3" style="">Science Journal of Education</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="327"></span>
               <label for="radio-3" style="">International Journal of HIV/AIDS Prevention, Education and Behavioural Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="214"></span>
               <label for="radio-3" style="">International Journal of Education, Culture and Society</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="240"></span>
               <label for="radio-3" style="">Teacher Education and Curriculum Studies</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="372"></span>
               <label for="radio-3" style="">International Journal of Vocational Education and Training Research</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal13">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="520"></span>
               <label for="radio-3" style="">International Journal of European Studies</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="304"></span>
               <label for="radio-3" style="">Journal of Political Science and International Relations</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="545"></span>
               <label for="radio-3" style="">Journal of Public Policy and Administration&nbsp;&nbsp;</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="546"></span>
               <label for="radio-3" style="">International and Public Affairs&nbsp;&nbsp;</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="306"></span>
               <label for="radio-3" style="">International Journal of Law and Society</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="155"></span>
               <label for="radio-3" style="">American Journal of Sports Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="176"></span>
               <label for="radio-3" style="">Journal of Human Resource Management</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="201"></span>
               <label for="radio-3" style="">Psychology and Behavioral Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="202"></span>
               <label for="radio-3" style="">Social Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="203"></span>
               <label for="radio-3" style="">American Journal of Applied Psychology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="204"></span>
               <label for="radio-3" style="">International Journal of Philosophy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="205"></span>
               <label for="radio-3" style="">History Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="208"></span>
               <label for="radio-3" style="">Humanities and Social Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="209"></span>
               <label for="radio-3" style="">International Journal of Archaeology</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="323"></span>
               <label for="radio-3" style="">Advances in Sciences and Humanities</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="327"></span>
               <label for="radio-3" style="">International Journal of HIV/AIDS Prevention, Education and Behavioural Science</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="381"></span>
               <label for="radio-3" style="">International Journal of Sustainable Development Research</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="170"></span>
               <label for="radio-3" style="">International Journal of Psychological and Brain Sciences</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="188"></span>
               <label for="radio-3" style="">International Journal of Sports Science and Physical Education</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="214"></span>
               <label for="radio-3" style="">International Journal of Education, Culture and Society</label>
               </div>  
				
				</div>
				    		      
				<div style="display: none;" id="journal14">
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="340"></span>
               <label for="radio-3" style="">International Journal of Applied Linguistics and Translation</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="357"></span>
               <label for="radio-3" style="">Communication and Linguistics Studies</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="520"></span>
               <label for="radio-3" style="">International Journal of European Studies</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="383"></span>
               <label for="radio-3" style="">International Journal of Architecture, Arts and Applications</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="501"></span>
               <label for="radio-3" style="">International Journal of Language and Linguistics</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="502"></span>
               <label for="radio-3" style="">International Journal of Literature and Arts</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="106"></span>
               <label for="radio-3" style="">American Journal of Art and Design</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="195"></span>
               <label for="radio-3" style="">English Language, Literature &amp; Culture</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="518"></span>
               <label for="radio-3" style="">Science, Technology &amp; Public Policy</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="199"></span>
               <label for="radio-3" style="">Arabic Language, Literature &amp; Culture</label>
               </div>  
				
				 <div class="radio" style="height:30px;">
 	           <span style="vertical-align:middle"><input type="checkbox" name="journalIdLists" id="journalIdLists" value="214"></span>
               <label for="radio-3" style="">International Journal of Education, Culture and Society</label>
               </div>  
				
				</div>
				   
				  </td>
				 
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(1);" id="1" style="color: rgb(0, 102, 204);">Chemistry &amp; Chemical Engineering 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(2);" id="2" style="color: rgb(0, 102, 204);">Medicine, Health &amp; Food 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(3);" id="3" style="color: rgb(0, 102, 204);">Physics 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(4);" id="4" style="color: rgb(0, 102, 204);">Materials Science 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(5);" id="5" style="color: rgb(0, 102, 204);">Mathematics &amp; Statistics 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(6);" id="6" style="color: rgb(0, 102, 204);">Electrical &amp; Computer Science 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(7);" id="7" style="color: rgb(0, 102, 204);">Earth, Energy &amp; Environment 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(8);" id="8" style="color: rgb(0, 102, 204);">Architecture &amp; Civil Engineering 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(9);" id="9" style="color: rgb(0, 102, 204);">Transportation &amp; Logistics 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(10);" id="10" style="color: rgb(0, 102, 204);">Engineering &amp; Technology 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(11);" id="11" style="color: rgb(0, 102, 204);">Economics &amp; Management 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(12);" id="12" style="color: rgb(0, 102, 204);">Education 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(13);" id="13" style="color: rgb(0, 102, 204);">Social Sciences &amp; Psychology 
								</a>
								</td>
							
							
								
						
				</tr>		
			    	
							
                               							
							<tr valign="middle">
								<td align="center" height="36px;" valign="middle">
								<br>
								<a href="javascript:void(0)" onclick="show(14);" id="14" style="color: rgb(0, 102, 204);">Arts, Literature &amp; Linguistics 
								</a>
								</td>
							
							
								
						
				</tr>		
			   	
			  </tbody>
			 </table>
			</div>
			<div class="form">
						<div class="fields">
							<div class="buttons">							
							   <div class="highlight">
							      
                  <input type="submit" name="Button_Submit" onclick="CheckForm();" value="Submit" onmouseover="change1(this)" onmouseout="change2(this)" style="cursor: pointer;color: #ffffff; width:100px;height:28px;background :#4e85bb url('../spg/decorator/resources/images/define/btn01.jpg') no-repeat;border-top: 0px solid #5c91a4;border-left: 0px solid #2a6f89;border-right: 1px solid #2b7089;border-bottom: 1px solid #1a6480;">
		           </div>							
							</div>
					</div>
					</div>
				<!--content of website ends here -->
				</div>
				<!-- end forms -->
			</div>
			<!-- end content / right -->
		</div>
		<!-- end content -->
		
		<?php include('../../includes/general/footer.php'); ?>
	</body>
</html>