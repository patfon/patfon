<?php 
session_start();
include_once("../../classes/connection.php");
?>

		<?php include('../../includes/general/header.php'); ?>
	<body>

		<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<?php

				include('../../includes/general/menu.php');
				include('../../includes/general/date.php');
				 ?>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
			<!-- forms -->
				<div class="box">
				
				
				<!--content of website goes below -->
					<div class="title">
						<h5>Message box</h5>
					</div>
					
					<div id="message-notice" class="message message-warning">
								<div class="image">
									<img src="../../resources/images/icons/notice.png" alt="Notice" height="32">
								</div>
								<div class="text">
									<h6>Notice!</h6>
									<span>You have already uploaded your photo.<br><br>

										If you want to change your photo, you can reupload it. The best display format:250 × 340 pixels. <br><br>

										You can only upload ".jpg", ".jpeg" and ".png" image format.</span>
								</div>
								
								
					</div>
					
					<?php 
					if(isset($_SESSION['success'])){
						?>
					
					<div id="message-success" class="message message-success">
								<div class="image">
									<img src="../../resources/images/icons/success.png" alt="Success" height="32">
								</div>
								<div class="text">
									<h6>Success Message</h6>
									<span>Image Upload successfully. <?php if(isset($_SESSION['filename'])){
										echo " <strong>File name:</strong> ".$_SESSION['filename'];
										unset($_SESSION['filename']);
									}  ?></span>
								</div>
								<div class="dismiss">
									<a href="#message-success"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['success']);
					?>
					
					<?php 
					if(isset($_SESSION['failed2'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>Sorry, there was an error uploading your file, Try again</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['failed2']);
					?>
					
					<?php 
					if(isset($_SESSION['empty'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>Image is empty, Please select a file to upload.</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['empty']);
					?>
					
					<?php 
					if(isset($_SESSION['invalid'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>Sorry, only JPG, JPEG, PNG, & GIF files are allowed to uploaded, Try again</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['invalid']);
					?>
					
					<?php 
					if(isset($_SESSION['failed'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>Failed to Upload file, Try again</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['failed']);
					?>
					
					<?php
$id = 56;
// Get images from the database
$query = $conn->query("SELECT * FROM users WHERE id = '$id'");

if($query->num_rows > 0){
    while($row = $query->fetch_assoc()){
        $imageURL = '../../controller/images/'.$row["_image"];
		$username = $row["_uname"];
   // return $imageURL;
}
}else{ 
    echo"<p>No image(s) found...</p>";
 }

 ?>
					
					<img align="middle" style="margin-left: 30%;border:2px solid green;max-width:210px ;max-height:270px;" src="<?php echo $imageURL; ?>">
					<p></p>
					<div class="title">
						<h5>Image Upload</h5>
					</div>
					<form id="form1" name="form1" action="../../controller/image.php" method="post" class="validate form-horizontal" enctype="multipart/form-data">
					<div class="form">
						<div class="fields">
							<div class="field  field-first">
								<div class="label">
									<label for="input-small">Username: </label>
								</div>
								
								<div class="input">
								    <input name="" type="text" value="<?php echo $username;?>" id="" disabled="disabled" class="large" style="border-style:None;">
							 	</div>
						     </div>
		      	<div class="field">
								<div class="label">
									<label for="file">Upload Your Photo : </label>
								</div>
								<div class="input input-file">
								<br>
          
            
             <div id="inputfile2" class="inputfile" style="  height:30px; background:url(../spg/decorator/resources/images/define/button.jpg);">
             <input type="file" class="file" id="upload" style="height:30px;border: 0px;" name="image" size="1" onchange="test5(this)">
          
             </div>
              <span class="error"></span> 
								</div>
			</div>
		 <div class="field">
							   <div class="label">
									<label for="input-large">Photo Release:</label>
								</div>
								<div class="input">
								<br>
								    <input id="template" type="checkbox" value="template"><label>   
								     &nbsp;&nbsp;I agree to release my photo to the website.</label> 
								</div>								
							</div>
						</div>
					 <div class="form">
						<div class="fields">
							<div class="buttons">							
							   <div class="highlight">
							      
                  <input type="submit" name="Button_Submit" onclick="CheckForm();" value="Submit" onmouseover="change1(this)" onmouseout="change2(this)" style="cursor: pointer;color: #ffffff; width:100px;height:28px;background :#4e85bb url('../spg/decorator/resources/images/define/btn01.jpg') no-repeat;border-top: 0px solid #5c91a4;border-left: 0px solid #2a6f89;border-right: 1px solid #2b7089;border-bottom: 1px solid #1a6480;">
		            <input type="reset" value="Reset" onmouseover="change1(this)" onmouseout="change2(this)" style="cursor: pointer;color: #ffffff; width:100px;height:28px;background :#4e85bb url('../spg/decorator/resources/images/define/btn01.jpg') no-repeat;border-top: 0px solid #5c91a4;border-left: 0px solid #2a6f89;border-right: 1px solid #2b7089;border-bottom: 1px solid #1a6480;" class="ui-button ui-widget ui-state-default ui-corner-all" role="button" aria-disabled="false">
		                    
							      
							       
							       
							       
							    </div>							
							</div>
					</div>
					</div>	
					</div>
					</form>
				<!--content of website ends here -->
				</div>
				<!-- end forms -->
			</div>
			<!-- end content / right -->
		</div>
		<!-- end content -->
		
		<?php include('../../includes/general/footer.php'); ?>
	</body>
</html>