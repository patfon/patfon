<?php 
session_start();
include_once("../../classes/connection.php");
?>

		<?php include('../../includes/general/header.php'); ?>
	<body>

		<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<?php

				include('../../includes/general/menu.php');
				include('../../includes/general/date.php');
				 ?>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
			<!-- forms -->
				<div class="box">
				
				
				
				<!--content of website goes below -->
				<?php 
					if(isset($_SESSION['success'])){
						?>
					
					<div id="message-success" class="message message-success">
								<div class="image">
									<img src="../../resources/images/icons/success.png" alt="Success" height="32">
								</div>
								<div class="text">
									<h6>Success Message</h6>
									<span>password changed successfully.</span>
								</div>
								<div class="dismiss">
									<a href="#message-success"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['success']);
					?>
					<?php 
					if(isset($_SESSION['oldmismatch'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>Your old password did not match or fields are empty</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['oldmismatch']);
					?>
					<?php 
					if(isset($_SESSION['empty'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>make sure you dont leave any field empty.</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					
					unset($_SESSION['empty']);
					?>
					<?php 
					if(isset($_SESSION['newmismatch'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>New password did not match.</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['newmismatch']);
					?>
					
					<div class="title">
						<h5>Change password</h5>
					</div>
					<!-- end box / title -->
					
					
					<form id="form1" name="form1" action="../../controller/password.php" method="post">
					<div class="form">
						<div class="fields">
							<div class="field  field-first">
								<div class="label">
									<label for="input-small">Current Password:</label>
								</div>
								<div class="input">
								<input type="password" id="oldPassword" maxlength="30" value="" name="oldPassword" class="small" onblur="checkPass()">
								<span class="error"></span>
								</div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-small">New Password:</label>
								</div>
								<div class="input">
									<input type="password" maxlength="30" id="plainPassword" value="" name="plainPassword" class="small">
								</div>
							</div>
							<div class="field">
								<div class="label">
									<label for="input-small">Confirm New Password:</label>
								</div>
								<div class="input">
									<input type="password" maxlength="30" name="rePass" value="" id="Re_enter_plainPassword" class="small">
								
								</div>
							</div>
							<div class="buttons">
								<div class="highlight">
									<input  type="submit" name="Button_Submit" style="cursor: pointer;" value="Submit" id="btn" class="ui-button ui-widget ui-state-default ui-corner-all" role="button">
									 <input type="reset" name="reset" value="Reset" style="cursor: pointer;" class="ui-button ui-widget ui-state-default ui-corner-all" role="button" aria-disabled="false">
								</div>
							</div>
						</div>
					</div>
				</form>			

				<!--content of website ends here -->
				</div>
				<!-- end forms -->
			</div>
			<!-- end content / right -->
		</div>
		<!-- end content -->
		
		<?php include('../../includes/general/footer.php'); ?>
	</body>
</html>