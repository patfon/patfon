<?php 
session_start();
include_once("../../classes/connection.php");
?>

		<?php include('../../includes/general/header.php'); ?>
	<body>

		<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<?php

				include('../../includes/general/menu.php');
				include('../../includes/general/date.php');
				 ?>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
			<!-- forms -->
				<div class="box">
				
				
				<!--content of website goes below -->
					<div class="title">
						<h5>Message box</h5>
					</div>
					
					<div id="message-notice" class="message message-warning">
								<div class="image">
									<img src="../../resources/images/icons/notice.png" alt="Notice" height="32">
								</div>
								<div class="text">
									<h6>Example</h6>
									<span>From:02/2001  To:06/2012<br><br>
										Position:Director<br><br>
										University/Company:Yale University,USA</span>
								</div>
								
					</div>
					<?php 
					if(isset($_SESSION['success'])){
						?>
					
					<div id="message-success" class="message message-success">
								<div class="image">
									<img src="../../resources/images/icons/success.png" alt="Success" height="32">
								</div>
								<div class="text">
									<h6>Success Message</h6>
									<span>Operation  successfull.</span>
								</div>
								<div class="dismiss">
									<a href="#message-success"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['success']);
					?>
					<?php 
					if(isset($_SESSION['failed'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>Failed, Try again</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['failed']);
					?>
					
					<?php 
					if(isset($_SESSION['empty'])){
						?>
					
					<div id="message-error" class="message message-error">
								<div class="image">
									<img src="../../resources/images/icons/error.png" alt="Error" height="32">
								</div>
								<div class="text">
									<h6>Error occured</h6>
									<span>some fields are empty, fill all and try again</span>
								</div>
								<div class="dismiss">
									<a href="#message-error"></a>
								</div>
							</div>
					
					<?php 
					} 
					unset($_SESSION['empty']);
					?>
					
					<div class="title">
						<h5>Work Experirnce</h5>
					</div>
					<div class="form" id="form1">
		   <form id="profilefrom" action="../../controller/w_and_e.php" method="post">
					<input type="hidden" name="profileType" value="50">
					<input type="hidden" name="isEditor" value="false">
						<div class="fields" id="1" style="border:1px solid #326395;margin-top: 2px;">
							<div class="field">

								<div class="label" style="width:10%">
									<label for="input-small">From:</label>
								</div>
								<div class="input" style="width:70%">
									<input type="date" name="from" id="date" class="date hasDatepicker" maxlength="30">
								</div>
							</div>
							<div class="field">
								<div class="label" style="width:10%">
									<label for="input-small">To:</label>
								</div>
								<div class="input" style="width:70%">
									<input type="date" name="to" id="EndDateTime0" class="small" maxlength="30">
								</div>
							</div>
							
							
							<div class="field">
								<div class="label">
									<label for="input-medium" id="qualifyTitle">Position</label>
								</div>
								<div class="input">
									<input type="text" name="position" id="Position0" class="medium" maxlength="1000">
								</div>
							</div>

							<div class="field">
								<div class="label">
									<label for="input-large" id="positionTitle">School / Company</label>
								</div>
								<div class="input">
									<input type="text" name="sch" id="ProfileContent1" class="medium" maxlength="1000">
                                </div>
								<!--<div class="highlight" style="float:left;margin-left:10%;">
									<input type="submit" value="Delete" class="ui-button ui-widget ui-state-default ui-corner-all" onclick="delAuthor(1)" style="cursor:pointer;">
								</div>-->
							</div>
					<!--<div id="beforeDiv" style="width:96%;padding:10px 2%;" class="highlight">
						<input type="button" value="Add" id="addRow" style="cursor:pointer;width:98%;" class="ui-button ui-widget ui-state-default ui-corner-all">
						
					</div>-->
					<div class="buttons" style="text-align:center;padding-top:10px;margin:0;padding-left:400px;x;border-top:1px solid #DDD;">
						<input type="reset" name="reset" value="Reset" class="ui-button ui-widget ui-state-default ui-corner-all ui-state-hover" style="float:left;cursor:pointer;" role="button" aria-disabled="false">
						<div class="highlight" style="float:left;margin-left:20px;">
							<input type="submit" name="Button_Submit" id="next1" value="Submit" class="ui-button ui-widget ui-state-default ui-corner-all" style="cursor:pointer;" role="button" aria-disabled="false">
						</div>
						<div class="reset" style="float:left;margin-left:20px;">
							<input type="submit" name="view" value="View" class="ui-button ui-widget ui-state-default ui-corner-all ui-state-hover" style="float:left;cursor:pointer;" role="button" aria-disabled="false">
						</div>
						<div style="clear:both;height:1px;margin-top:-1px;overflow: hidden;"></div>
					</div><p></p>
						</div>
					
					
					
				</form>
			</div>
			<p></p>
			<!--view work expp -->
			
			<?php
			if(isset($_SESSION['view'])){

			?>
					<div class="form" id="form1">
		   <form id="profilefrom" action="../../controller/w_and_e.php" method="post">
					<input type="hidden" name="profileType" value="50">
					<input type="hidden" name="isEditor" value="false">
						<div class="fields" id="1" style="border:1px solid #326395;margin-top: 2px;">
							<div class="field">

								<div class="label" style="width:10%">
									<label for="input-small">From:</label>
								</div>
								<div class="input" style="width:70%">
									<input type="date" name="from" id="date" class="date hasDatepicker" maxlength="30">
								</div>
							</div>
							<div class="field">
								<div class="label" style="width:10%">
									<label for="input-small">To:</label>
								</div>
								<div class="input" style="width:70%">
									<input type="date" name="to" id="EndDateTime0" class="small" maxlength="30">
								</div>
							</div>
							
							
							<div class="field">
								<div class="label">
									<label for="input-medium" id="qualifyTitle">Position</label>
								</div>
								<div class="input">
									<input type="text" name="position" id="Position0" class="medium" maxlength="1000">
								</div>
							</div>

							<div class="field">
								<div class="label">
									<label for="input-large" id="positionTitle">School / Company</label>
								</div>
								<div class="input">
									<input type="text" name="sch" id="ProfileContent1" class="medium" maxlength="1000">
                                </div>
								<!--<div class="highlight" style="float:left;margin-left:10%;">
									<input type="submit" value="Delete" class="ui-button ui-widget ui-state-default ui-corner-all" onclick="delAuthor(1)" style="cursor:pointer;">
								</div>-->
							</div>
					<!--<div id="beforeDiv" style="width:96%;padding:10px 2%;" class="highlight">
						<input type="button" value="Add" id="addRow" style="cursor:pointer;width:98%;" class="ui-button ui-widget ui-state-default ui-corner-all">
						
					</div>-->
					<div class="buttons" style="text-align:center;padding-top:10px;margin:0;padding-left:400px;x;border-top:1px solid #DDD;">
						<div class="highlight" style="float:left;margin-left:20px;">
							<input type="submit" name="close" id="next1" value="close" class="ui-button ui-widget ui-state-default ui-corner-all" style="cursor:pointer;" role="button" aria-disabled="false">
						</div>
						<div style="clear:both;height:1px;margin-top:-1px;overflow: hidden;"></div>
					</div><p></p>
						</div>
					
					
					
				</form>
			</div>
			<?php
			}
			?>
				<!--content of website ends here -->
				</div>
				<!-- end forms -->
			</div>
			<!-- end content / right -->
		</div>
		<!-- end content -->
		
		<?php include('../../includes/general/footer.php'); ?>
	</body>
</html>