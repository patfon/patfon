<?php 
session_start(); 
//include'../classes/connection.php';
include'../functions/index.php';

/* session started  for testing */
	if(isset($_SESSION['id'])){
		$id = 56;
	}


if(isset($_POST['Button_Submit'])){
   updateProfile($conn, $id);
}
?>