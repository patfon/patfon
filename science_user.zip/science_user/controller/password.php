<?php 
session_start(); 
//include'../classes/connection.php';
include'../functions/index.php';

/* session started  for testing */
	if(isset($_SESSION['id'])){
		$id = 56;
	}


if(isset($_POST['Button_Submit'])){
	
	$oldPass = '';
	$oldPass = $_POST['oldPassword'];
	$oldPassw = mysqli_real_escape_string($conn, $oldPass);
	$oldPassword = md5($oldPassw);
	
	$newPass = '';
	$newPass = $_POST['plainPassword'];
	$newPassw = mysqli_real_escape_string($conn, $newPass);
	$newPassword = md5($newPassw);

	$reP = '';
	$reP = $_POST['rePass'];
	$confirm = mysqli_real_escape_string($conn, $reP);
	$rePass = md5($confirm);
	
	if(showOldPass($conn, $id) !== $oldPassword ){
		$_SESSION['oldmismatch'] = 1;
		header('location:../includes/submission/password.php');
	}
	elseif( empty($oldPassword) || empty($newPassword) || empty($rePass)){
		$_SESSION['empty'] = 1;
		header('location:../includes/submission/password.php');
	}
	elseif($newPassword !== $rePass){
		$_SESSION['newmismatch'] = 1;
		header('location:../includes/submission/password.php');
	}else{
		insertPass($conn, $id, $newPassword);//functions/index.php
	}
}
?>