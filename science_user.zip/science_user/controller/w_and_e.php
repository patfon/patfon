<?php 
session_start(); 
//include'../classes/connection.php';
include'../functions/index.php';

/* session started  for testing */
	if(isset($_SESSION['id'])){
		$id = 56;
	}


if(isset($_POST['Button_Submit'])){
	$from = $_POST['from'];
	$to = $_POST['to'];
	$position = $_POST['position'];
	$sch = $_POST['sch'];
	
	if(!empty($from) || !empty($to) || !empty($position) || !empty($sch)){
		$sql = "INSERT INTO users_work (_to, _from, _position, _university, _userid)
								VALUES('$to', '$from', '$position', '$sch', '$id')";
		$query = mysqli_query($conn, $sql);
		if($query){
			$_SESSION['success'] = 1;
			header('location:../includes/submission/w_and_e.php');
		}else{
			$_SESSION['failed'] = 1;
			header('location:../includes/submission/w_and_e.php');
		}
	}else{
		$_SESSION['empty'] = 1;
		header('location:../includes/submission/w_and_e.php');
	}
}

if(isset($_POST['view'])){
	$_SESSION['view'] = 1;
	header('location:../includes/submission/w_and_e.php');
}

if(isset($_POST['close'])){
	unset($_SESSION['view']);
	header('location:../includes/submission/w_and_e.php');
}
?>