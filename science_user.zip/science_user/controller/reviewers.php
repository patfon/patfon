<?php 
session_start(); 
//include'../classes/connection.php';
include'../functions/index.php';

/* session started  for testing */
	if(isset($_SESSION['id'])){
		$id = 56;
	}


$targetDir = "images/";
$fileName = basename($_FILES["image"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

if(isset($_POST["Button_Submit"]) && !empty($_FILES["image"]["name"])){
	
    $allowTypes = array('jpg','png','jpeg','gif'/* ,'pdf' */);// used pdf to test if it worked also for it
   
   if(in_array($fileType, $allowTypes)){
        
        if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)){
            
            $insert = $conn->query("UPDATE users SET _image = '$fileName' WHERE id = '$id'");
            if($insert){
				$_SESSION['success'] = 1;
				$_SESSION['filename'] = $fileName;
				header('location:../includes/submission/image.php');
                
            }else{
                $_SESSION['failed'] = 1;
				header('location:../includes/submission/image.php');
    } 
        }else{
			$_SESSION['failed2'] = 1;
			header('location:../includes/submission/image.php');
        }
    }else{
				$_SESSION['invalid'] = 1;
				header('location:../includes/submission/image.php');
    }
}else{
				$_SESSION['empty'] = 1;
				header('location:../includes/submission/image.php');
}

// Display status message
//echo $statusMsg;
//emma it took me ages to make this code work pefertly 17/05/2018 01:02 am LOL... ;-)


?>