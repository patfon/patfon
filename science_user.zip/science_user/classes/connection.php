<?php
define('server', 'localhost');

define('user', 'root');

define('pass', '');

define('db', 'pubsg');

$conn = mysqli_connect(server, user, pass);

mysqli_select_db($conn, db) or die("failed to connect".mysqli_error($conn));

?>