<?php include '../../includes/general/header.php'; ?>
<?php include '../../classes/connection.php'; ?>
<?php include '../../functions/index.php'; ?>

    <?php include '../../includes/general/topmenu.php'; ?>

<?php if (isset($_GET['catid2'])) { ?>
<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo getjournalname($pdb,$_GET['catid2']); ?></a>
    </div>
    <div class="propose">
    <a href="<?php echo $myurl."pages/journal/journalbycat.php?catid2=".$_GET['catid2']; ?>" style="background-color:#FFFFFF;color:#111111;"><div class="tit">Home</div></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/archive.php?catid3=".$_GET['catid2']; ?>"><span class="tit">Archive</span></a>
    <div class="separater">|</div>
    
    <a href="<?php echo $myurl."pages/journal/pages/editorial.php?catid4=".$_GET['catid2']; ?>"><span class="tit" style="">Editorial Board</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/reviewers.php?catid5=".$_GET['catid2']; ?>"><span class="tit" style="">Reviewers</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/guidelines.php?catid6=".$_GET['catid2']; ?>"><span class="tit">Guidelines</span></a>
    <div class="separater">|</div>
    
    <a href="<?php echo $myurl."pages/journal/pages/apc.php?catid7=".$_GET['catid2']; ?>"><span class="tit" >Article Processing Charges</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/ethics.php?catid8=".$_GET['catid2']; ?>"><span class="tit">Publication Ethics</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/copyright.php?catid9=".$_GET['catid2']; ?>"><span class="tit">Copyright</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/faq.php?catid10=".$_GET['catid2']; ?>"><span class="tit">FAQ</span></a>
</div>
</div>

<div class="middle">
<div class="middle_title">
<a href="" class="title_link">Home</a>  /  <a href="<?php echo $myurl.'pages/journal/journallist.php'; ?>" class="title_link">Journals</a>  /  <a href="#" class="title_link"> <?php getsubjectnameInJournal($pdb,$_GET['catid2']); ?></a>  /  <?php echo getjournalname($pdb,$_GET['catid2']); ?>
</div>


<div class="middle_part2">

<div class="middle_part2_l">
<div class="img3">
<img src="http://image.sciencepublishinggroup.com/journal/110.gif"></div>
</div>

<div class="part2_vol">

<div class="part2_t1">
    <a href="#" class="vol_issue_info">Vol. 6, Issue 1, February 2018</a>
    <div class="clear"></div>
</div>


<div class="part2_t2">

    <div class="issn_print">
        ISSN Print: 2329-0870
    </div>

<div class="journal_frequency">
    
        
            
                Frequency: Bimonthly
            
</div>
<div class="clear"></div>
</div>

<div class="part2_t3">

    <div class="issn_online">
        ISSN Online: 2329-0862
    </div>

<div class="clear"></div>
</div>



<div class="lat">
<div class="lat_tit">

    <a href="javascript:choiceModel(1);"><div class="lat_tit1" id="lat_tit1" style="background-color:#FFFFFF;color:#333333;">Latest Articles</div></a>
    <a href="javascript:choiceModel(2);"><div class="lat_tit2" id="lat_tit2">About This Journal</div></a>


<div class="clear"></div>
</div>

<div style="width:100%;height:auto;display:block;" id="latestArticles">



    <div class="imp_img"><img src="<?php echo $myurl."images/articlelist_icon.jpg"; ?>"></div>
    <div class="imp">
       
        <div class="imp_1"><a href="<?php echo ""; ?>">The Effect of Vitamin D<sub>3</sub> on Bone Mineralization: Influence of Consciousness Energy Healing Treatment</a> </div>
       
       
       
        <div class="imp_2">
            
                Alan  Joseph Balmer, 
            
                Mahendra  Kumar Trivedi, 
            
                Alice  Branton, 
            
                Dahryn  Trivedi, 
            
                Gopal  Nayak, 
            
                Sambhu  Charan Mondal, 
            
                Snehasis  Jana
            
        </div>
        <div class="imp_3">Pages: 1-9&nbsp;&nbsp;&nbsp;Published Online: Feb. 24, 2018</div>
       
         <div class="imp_4"><a  href="#"> PDF (1361KB) </a>&nbsp;&nbsp;&nbsp;&nbsp;</div>
        
        
        
    </div>
    <div class="clear"></div>

   

</div>


<div style="width:100%;height:auto;display:none;" id="aboutThisJournal">


<div class="journal_intro_2">
<i> Advances in  Biochemistry (AB) </i> publishes papers in English in all fields of biochemistry
 and cellular and molecular biology, provided that they make a sufficient 
 contribution to knowledge in these fields. 
 Papers may include new results obtained experimentally, 
 descriptions of new experimental methods of biochemical importance, or
  new interpretations of existing results. Novel theoretical contributions will be considered, 
  although these papers should also contain some experimental testing of the theory. 
  All work presented should have as its aim the development of biochemical 
  concepts rather than the mere recording of facts. 
  The topics related to this journal include but are not limited to:</div>

   

</div>
</div>



</div>

<div class="clear"></div>
</div>


<div class="middle_part3">

<a href="<?php echo $myurl."login.php"; ?>" target="_blank"><img style="margin-top: 0px;" src="<?php echo $myurl.'images/journals_btn_r3_c1.jpg';  ?>" ></a>


<a href="<?php echo $myurl."login.php"; ?>" target="_blank"> <img src="<?php echo $myurl.'images/journals_btn_r1_c1.jpg'; ?>"  style="margin-top: 15px;" ></a>


<div class="clear"></div>


<div class="edito">
<div class="part3_rel3">Editorial Board</div>
<a href="/journal/editorialboard?journalid=110"><div class="part3_more3">More</div></a>
<div class="clear"></div>

<div class="adnan">


    
        <div style="width:100%;height:auto;">
    
    
        <div class="adnan_img">
         
                <a href="#" target="_blank">
        <img src="" style="width:75px;height:102px;">
        </a>
        
        
        </div>
        
        <div class="adnan_text">
            
                <a href="#" target="_blank">Ahmad  Ali</a>
            
            
            Department of Life Sciences, University of Mumbai <br>
            Mumbai, Maharashtra, India
        </div>
        <div class="clear"></div>
    </div>

    
    


</div>

<div class="part3_rel2">Peer Reviewers</div>
<a href="/journal/peerreviewers?journalid=110"><div class="part3_more2">More</div></a>
<div class="clear"></div>

<div class="adnan">


    
        <div style="width:100%;height:auto;">
    
    
        <div class="adnan_img">
           
        
        <img src="" style="width:75px;height:102px;">
        
        
        
        </div>
        <div class="adnan_text">
            
            
                <b>Yousif  Elhassaneen</b><br>
            
            Department of Nutrition and Food Science, Faculty of Home Economics, Minoufiya University <br>
            Shebin El-Kom, Egypt
        </div>
        <div class="clear"></div>
    </div>

    
    
</div>
</div>
</div>

<div class="clear"></div>
</div>
<?php } ?>
    
<?php include '../../includes/general/footer.php'; ?>