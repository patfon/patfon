<div class="journals_list_title">
                <div class="jlt_t">Recommended Journals</div>
                <div class="vm">
                    <a href="/journal/journallist">View more</a>
                </div>
                <div class="clear"></div>
</div>
<div class="journals_list_fw">
                <div class="next_btn" onclick="showNextJournals()">
                    <img src="images/left_arrow2.png">
                </div>
                <div style="width:20px;float:left;">&nbsp;</div>

                <div id="journalsListItems">
              
              
                
                     <div class="journals_list_item" id="j_list_item_2" style="display: block;">
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_2">
                                <a target="_blank" href="/journal/index?journalid=122"><img src="http://image.sciencepublishinggroup.com/journal/122.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=122">American Journal of Modern Physics</a>
                        </div>
                    </div><div class="journals_list_item" id="j_list_item_3" style="display: block;">
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_3">
                                <a target="_blank" href="/journal/index?journalid=123"><img src="http://image.sciencepublishinggroup.com/journal/123.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=123">International Journal of Materials Science and Applications</a>
                        </div>
                    </div><div class="journals_list_item" id="j_list_item_4" style="display: block;">
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_4">
                                <a target="_blank" href="/journal/index?journalid=146"><img src="http://image.sciencepublishinggroup.com/journal/146.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=146">American Journal of Theoretical and Applied Statistics</a>
                        </div>
                    </div><div class="journals_list_item" id="j_list_item_5" style="display: block;">
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_5">
                                <a target="_blank" href="/journal/index?journalid=147"><img src="http://image.sciencepublishinggroup.com/journal/147.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=147">Applied and Computational Mathematics</a>
                        </div>
                    </div><div class="journals_list_item" style="display: block;" id="j_list_item_6">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_6">
                                <a target="_blank" href="/journal/index?journalid=151"><img src="http://image.sciencepublishinggroup.com/journal/151.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=151">Clinical Medicine Research</a>
                        </div>
                    </div><div class="journals_list_item" style="display: block;" id="j_list_item_7">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_7">
                                <a target="_blank" href="/journal/index?journalid=153"><img src="http://image.sciencepublishinggroup.com/journal/153.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=153">International Journal of Nutrition and Food Sciences</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_8">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_8">
                                <a target="_blank" href="/journal/index?journalid=162"><img src="http://image.sciencepublishinggroup.com/journal/162.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=162">International Journal of Environmental Monitoring and Analysis</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_9">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_9">
                                <a target="_blank" href="/journal/index?journalid=163"><img src="http://image.sciencepublishinggroup.com/journal/163.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=163">American Journal of Environmental Protection</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_10">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_10">
                                <a target="_blank" href="/journal/index?journalid=164"><img src="http://image.sciencepublishinggroup.com/journal/164.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=164">International Journal of Energy and Power Engineering</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_11">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_11">
                                <a target="_blank" href="/journal/index?journalid=173"><img src="http://image.sciencepublishinggroup.com/journal/173.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=173">International Journal of Economics, Finance and Management Sciences</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_12">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_12">
                                <a target="_blank" href="/journal/index?journalid=196"><img src="http://image.sciencepublishinggroup.com/journal/196.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=196">Education Journal</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_13">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_13">
                                <a target="_blank" href="/journal/index?journalid=208"><img src="http://image.sciencepublishinggroup.com/journal/208.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=208">Humanities and Social Sciences</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_14">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_14">
                                <a target="_blank" href="/journal/index?journalid=229"><img src="http://image.sciencepublishinggroup.com/journal/229.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=229">American Journal of Civil Engineering</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_15">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_15">
                                <a target="_blank" href="/journal/index?journalid=251"><img src="http://image.sciencepublishinggroup.com/journal/251.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=251">Science Journal of Public Health</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_16">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_16">
                                <a target="_blank" href="/journal/index?journalid=254"><img src="http://image.sciencepublishinggroup.com/journal/254.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=254">American Journal of Clinical and Experimental Medicine</a>
                        </div>
                    </div><div class="journals_list_item" style="display: none;" id="j_list_item_17">
                    
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_17">
                                <a target="_blank" href="/journal/index?journalid=501"><img src="http://image.sciencepublishinggroup.com/journal/501.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=501">International Journal of Language and Linguistics</a>
                        </div>
                    </div><div class="journals_list_item" id="j_list_item_0" style="display: none;">
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_0">
                                <a target="_blank" href="/journal/index?journalid=118"><img src="http://image.sciencepublishinggroup.com/journal/118.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=118">American Journal of Life Sciences</a>
                        </div>
                    </div><div class="journals_list_item" id="j_list_item_1" style="display: none;">
                    
                        <div class="journal_image_contain">
                            <div class="journal_image" id="img_1">
                                <a target="_blank" href="/journal/index?journalid=119"><img src="http://image.sciencepublishinggroup.com/journal/119.gif" width="166px" height="224px"></a>
                            </div>
                           
                        </div>
                        <div class="journal_title">
                            <a target="_blank" href="/journal/index?journalid=119">Agriculture, Forestry and Fisheries</a>
                        </div>
                    </div></div>
                <input type="hidden" id="first_place_num" value="2">
                <input type="hidden" id="six_place_num" value="7">
                <input type="hidden" id="last_place_num" value="1">
                <div class="pre_btn" onclick="showPreJournals()">
                    <img src="images/right_arrow2.png">
                </div>
                <div class="clear"></div>
            </div>