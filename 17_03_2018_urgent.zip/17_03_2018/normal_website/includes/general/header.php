<?php 
 session_start();
 $documentroot = "sciencepg";
 $GLOBALS['myurl'] = "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/";

?>
<!DOCTYPE html>
<html>
<head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Nigerian Publishing Group</title>
        <link href="<?php echo $myurl.'images/littlelogo.gif'; ?> " rel="shortcut icon">
        <?php if ($_SERVER['REQUEST_URI'] !== '/sciencepg/register.php' && $_SERVER['REQUEST_URI'] !== '/sciencepg/login.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/common.css'; ?>">
        <?php } ?>
        
        <?php if ($_SERVER['REQUEST_URI'] === '/sciencepg/'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/home_body.css';?>">
        <?php } ?>
        <?php if ($_SERVER['REQUEST_URI'] === '/sciencepg/index.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/home_body.css';?>">
        <?php } ?>
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/journallist.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal_body.css';?>">
        <?php } ?>
        <?php if (preg_match('/catid=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal_body.css';?>">
        <?php } ?>

        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/journalbycat.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal3_body.css';?>">
        <?php } ?>
        <?php if (preg_match('/catid2=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/journal3_body.css';?>">
        <?php } ?>   

        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/pages/journal/pages/editorial.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jeditorial.css';?>">
        <?php } ?>
        <?php if (preg_match('/catid4=[0-9]*/',$_SERVER['REQUEST_URI'])){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/jeditorial.css';?>">
        <?php } ?>   

        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/register.php' || $_SERVER['REQUEST_URI'] == '/sciencepg/login.php' ){ ?>
       
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/style.css';?>">
        <?php } ?>
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/contactus.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/contactus.css';?>">
        <?php } ?>
        <?php if ($_SERVER['REQUEST_URI'] == '/sciencepg/news.php'){ ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/news.css';?>">
        <?php } ?>
       <!--   <meta name="google-site-verification" content="coJF3qkXwBNBu5idbbheQnYgIl4NuyKH4tXrilPQdu0"> -->
        <meta name="Keywords" content="Nigerian | scientific current events | academic journals | peer reviewed journals | peer reviewed journal articles">
        <meta name="description" content="EDIT">
        
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery-1.9.1.min.js'; ?>"></script>
      
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.cycle.all.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.placeholder.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/common.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo $myurl.'js/jquery.slides.min.js'; ?>"></script>
        <?php if ($_SERVER['REQUEST_URI'] !== '/sciencepg/register.php' || $_SERVER['REQUEST_URI'] !== '/sciencepg/login.php'){ ?>
       
        <script type="text/javascript" src="<?php echo $myurl.'js/register.js'; ?>"></script>
        <?php } ?>
       
    
        <script type="text/javascript">
          ///the login for article in home page
            function login(obj) {
                var username = $("#username").val();
                var password = $("#password").val();

                if (username == null || username == '') {
                    alert("please enter your username");
                    return false;
                }
                if (password == null || password == '') {
                    alert("please enter your password");
                    return false;
                }

                $("#form").submit();
            }

            function choiceModel(id) {
                    if (1 == id) {
                        $("#lat_tit1").css("background-color", "#FFFFFF");
                        $("#lat_tit1").css("color", "#333333");
                        $("#lat_tit2").css("background-color", "#4583C0");
                        $("#lat_tit2").css("color", "#FFFFFF");
                        $("#latestArticles").css("display", "block");
                        $("#aboutThisJournal").css("display", "none");
                    } else if (2 == id) {
                        $("#lat_tit1").css("background-color", "#4583C0");
                        $("#lat_tit1").css("color", "#FFFFFF");
                        $("#lat_tit2").css("background-color", "#FFFFFF");
                        $("#lat_tit2").css("color", "#333333");
                        $("#latestArticles").css("display", "none");
                        $("#aboutThisJournal").css("display", "block");
                    }
                }
           
        </script>
        <!-- The slide show in Home page-->
        <script type="text/javascript">
            $(function(){           
                $("#slides").slidesjs({
                    width: 918,
                    height: 240,
                    navigation: {
                    effect: "fade"
                    },
                    pagination: {
                    effect: "fade"
                    },
                    effect: {
                    fade: {
                        speed: 400
                    }
                    }
                });
                var mw = $(".mbox").width()+10;
                var ml = $(".mbox").length; 
                $(".themes").width(mw*ml);
                $(".t_menu li").mouseover(function(){
                    var index = $(this).index();
                    $(".themes").animate({left:-mw*index,opacity:1},500);
                })
            });
        </script>
<!-- Testimonials slideshow -->
        <script type="text/javascript">
            window.setInterval("autoPlayJournalList()", 10000);

            $(function(){
                $('#testimonials').cycle({ 
                    fx: 'scrollHorz',
                    speed:    500,
                    timeout:  12000,
                    startingSlide: 0,
                    next: '.right_btn',
                    prev: '.left_btn'
                });
            })
        </script>
        <!-- end Testimonials slideshow -->
        <!-- -->
        <script type="text/javascript">
                $("#secondAdvGif").css("display", "block");
                $('#advGif').cycle({ 
                    fx: 'scrollHorz',
                    speed:    800,
                    timeout:  8000,
                    startingSlide: 0
                });
        </script>
    </head>

<body>