<div id="left">
                    <div id="menu">
                        <h6 id="h-menu" class="selected"><a href="#products"><span>General Information</span></a></h6>
                        <ul id="menu-home" class="opened" style="display:block;">
                                <li><a href="#">My Activities</a></li>
                               
                             
                                
                        </ul>
                        <h6 id="h-menu" class="selected"><a href="#pages"><span>Submission</span></a></h6>
                        <ul id="menu-journal" class="opened" style="display:block;">
                         <li><a href="<?php echo $myurl.'includes/submission/submission.php'; ?>">Submit to Journal</a></li>
                        			
                        </ul>
                       
                       
                        <h6 id="h-menu" class="selected"><a href="#join"><span>Journal Activity</span></a></h6>
                        <ul id="menu-news" class="opened" style="display:block;">
                         <li><a href="#">Application Result</a></li>	
                         <li><a href="#">Editorial Result</a></li>
                         <li><a href="#">Reviewer Members</a></li>		
                     
                        </ul>
                       <h6 id="h-menu" class="selected"><a href="#links"><span>Personal Profile</span></a></h6>
                        <ul id="menu-sub" class="opened" style="display:block;">
                        <li><a href="#">Personal Information</a></li>	
                        <li><a href="#">Educational Qualification</a></li>
                        <li><a href="#">Work Experience</a></li>	
                          
                        </ul>
                      

                       </div>
        <div id="date-picker"></div>  
</div>