-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2018 at 12:15 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pubsg`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `_title` varchar(100) NOT NULL,
  `_keywords` varchar(300) NOT NULL,
  `_abstract` text NOT NULL,
  `_type` varchar(50) NOT NULL,
  `_image` varchar(150) DEFAULT NULL,
  `_file` varchar(100) DEFAULT NULL,
  `_filesize` int(11) DEFAULT NULL,
  `_paid` int(11) DEFAULT NULL,
  `_doi` varchar(300) DEFAULT NULL,
  `_pages` varchar(50) NOT NULL,
  `_pubdate` date DEFAULT '1970-10-10',
  `_viewcount` int(11) DEFAULT NULL,
  `_downcount` int(11) DEFAULT NULL,
  `_submitdate` datetime NOT NULL DEFAULT '1970-10-10 00:00:00',
  `_acceptdate` datetime DEFAULT '1970-10-10 00:00:00',
  `_articleid` int(11) NOT NULL,
  `_userid` int(11) NOT NULL,
  `_journalid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `_title`, `_keywords`, `_abstract`, `_type`, `_image`, `_file`, `_filesize`, `_paid`, `_doi`, `_pages`, `_pubdate`, `_viewcount`, `_downcount`, `_submitdate`, `_acceptdate`, `_articleid`, `_userid`, `_journalid`) VALUES
(1, 'This is a title that is worth it.', 'keyword1, keyword2, keyword3', 'lkjksk vvd;svlksdv sdvlsdvl;svkslk lslgjll;d;sldklk;lfkd fl;kd;lfks f;ldfkldkf l;dkf ;ldkf d;lf;ldk l;d', '\'\'', 'images/articles/RDjG4dgv.png', 'images/articles/RDjG4dgv.png', 210, 1, '\'\'', '18-25', '1970-10-10', 0, 0, '2018-03-12 11:17:22', '2018-03-13 01:25:08', 102323, 1, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
