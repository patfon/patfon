<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	<?php  if(isset($_SESSION['failed'])) { ?>
          <div class="alert  alert-warning alert-dismissable">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <i class="fa fa-anchor"></i>&nbsp;&nbsp;.No data exist for that daily report.
          </div>                             
  <?php unset($_SESSION['failed']); } ?>
		<!-- main content here -->
<div class="market-updates">
			<div class="col-md-3 market-update-gd">
				<div class="market-update-block clr-block-2">
					<a href=<?php echo $myurl."income_set_fee.php"; ?>> <div class="col-md-4 market-update-right">
						<i class="fa fa-plus"> </i>
					</div>
					 <div class="col-md-8 market-update-left">
					 <h4>Set Fee</h4>
					 </a>
                    </div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="#" onclick="getDailyReport()"> <div class="market-update-block clr-block-2">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-calendar"></i>
					</div>
					<div class="col-md-8 market-update-left">
					<h4>Daily Summary</h4>
					</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href=<?php echo $myurl."income_view.php"; ?>> <div class="market-update-block clr-block-2">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-search-plus"></i>
					</div>
					<div class="col-md-8 market-update-left">
					<h4>View Student Fee Status</h4>
					</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			
			
		   <div class="clearfix"> </div>
		   
		</div>
		
			<div class="col-md-3 market-update-gd">
				<a href=<?php echo $myurl."income_receive.php"; ?>> <div class="market-update-block clr-block-2">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-money"></i>
					</div>
					<div class="col-md-8 market-update-left">
						<h4>Receive Fees</h4>
						</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			
		   <div class="clearfix"> </div>
		<!-- main contents end -->
		
		
		<div class="col-md-6 w3agile-notifications">
			<div class="clearfix"> </div>
		</div>
	
</section>
 
</section>
<!--main content end-->