<section id="main-content">
	<section class="wrapper">
    <div class="row">
            <div class="col-md-6 col-md-offset-2" style="margin-top: 90px;">
                <?php
                if(isset($_SESSION['loginfailed'])){
                    echo '<div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your login attempt has failed.
                    </div>';
                    unset($_SESSION['loginfailed']);
                    }
                ?>
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Welcome, Please Sign to Access School Portal</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" action="config/login_controller.php" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="uname" type="text" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="passwx" type="password" required>
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                               <button id="login" type="submit" name="loginbut" class="btn btn-primary">Login</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </section>
</section>