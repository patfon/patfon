<?php session_start(); ?>
<?php
 if (!isset($_SESSION['patfonuser'])) { 
    include('includes/header2.php');
    include('pages/login.php');
    include('includes/footer2.php');
} else { 
header("Location: index.php");
exit;
} 
?>