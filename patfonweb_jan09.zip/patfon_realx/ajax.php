<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php ///get the keywords from the evalute textbox as you try to search
include('functions/index.php');
if (isset($_POST['feesreceive'])) {
 $arr = array();   
 $keywords = mysqli_real_escape_string($pdb,$_POST['feesreceive']);
 $sql = " SELECT * FROM student WHERE new_ = 0 AND CONCAT(fname, lname) REGEXP '$keywords' OR regno REGEXP '$keywords' ";
 $result = mysqli_query($pdb,$sql) or die(mysqli_error($pdb));
 if (mysqli_num_rows($result) > 0) {
 while ($rows = mysqli_fetch_array ($result, MYSQLI_ASSOC)) {
 echo '<div id="" class="evaluateoutput"> 
         <input id="evalid" type="hidden" value="'.getstudentclass($pdb,$rows['id']).'" >
         <input id="evalstu" type="hidden" value="'.$rows['id'].'" >
         <input id="evalcat" type="hidden" value="'.getstudentclasscat($pdb,getstudentclassonly($pdb,$rows['id'],$rows['school']),$rows['school']).'" >
         <input id="evalregno" type="hidden" value="'.$rows['regno'].'" >
         <div class="evalname"><strong class="evaltext">'.$rows['fname']."  ".$rows['lname']."  from ".getstudentclass($pdb,$rows['id']). '</strong></div>
       
        </div>';
 }
 }
 else{
 echo '<div id="" class="evaluateoutput form-group"> 
         <div class="name"><strong>'.'Nothing returned'.'</strong></div>&nbsp;&nbsp;
        </div>';
 }
 
}
//new students
if (isset($_POST['feesreceive2'])) {
        $arr = array();   
        $keywords = mysqli_real_escape_string($pdb,$_POST['feesreceive2']);
        $sql = "SELECT * FROM student WHERE new_ = 1 AND CONCAT(fname, lname) REGEXP '$keywords' OR regno REGEXP '$keywords' ";
        $result = mysqli_query($pdb,$sql) or die(mysqli_error($pdb));
        if (mysqli_num_rows($result) > 0) {
        while ($rows = mysqli_fetch_array ($result, MYSQLI_ASSOC)) {
        echo '<div id="" class="evaluateoutput2"> 
                <input id="evalid2" type="hidden" value="'.getstudentclass($pdb,$rows['id']).'" >
                <input id="evalstu2" type="hidden" value="'.$rows['id'].'" >
                <input id="evalcat2" type="hidden" value="'.getstudentclasscat($pdb,getstudentclassonly($pdb,$rows['id'],$rows['school']),$rows['school']).'" >
                <input id="evalregno2" type="hidden" value="'.$rows['regno'].'" >
                <div class="evalname"><strong class="evaltext">'.$rows['fname']."  ".$rows['lname']."  from ".getstudentclass($pdb,$rows['id']). '</strong></div>
              
               </div>';
        }
        }
        else{
        echo '<div id="" class="evaluateoutput2 form-group"> 
                <div class="name"><strong>'.'Nothing returned'.'</strong></div>&nbsp;&nbsp;
               </div>';
        }
        
       }

if (isset($_POST['setcategory']) && isset($_POST['setstudent'])) {

    $mycat = $_POST['setcategory'];
    $mystu= $_POST['setstudent'];
    $_SESSION['patfonuser']['studentid'] =  $mystu ;
    $mysch = $_SESSION['patfonuser']['school'];

   $clsfee =  getclassfee($pdb,$mycat,$mysch); 
   $studebt =  getstudentdebt($pdb,$mystu,$mysch);
   if ( $studebt > 0 ) {

        $_SESSION['patfonuser']['feedebt'] =  $studebt ;

   }
   else{
           unset($_SESSION['patfonuser']['feedebt']);
   }
   $othfee =  getclassfeeother($pdb,1,$mysch);
   $othfee2 =  getclassfeeother($pdb,2,$mysch);
   $othfee3 =  getclassfeeother($pdb,3,$mysch);
   $othfee4 =  getclassfeeother($pdb,4,$mysch);
   $othfee5 =  getclassfeeother($pdb,5,$mysch);
   $othfee6 =  getclassfeeother($pdb,6,$mysch);
   $othfee7 =  getclassfeeother($pdb,7,$mysch);
    $myarray = array('A'=>$clsfee, 'B'=>$studebt, 'C'=>$othfee, 'D'=>$othfee2, 'E'=>$othfee3, 
                     'F'=>$othfee4,'G'=>$othfee5, 'H'=>$othfee6,'I'=>$othfee7   
                        );    
    echo json_encode($myarray);


}