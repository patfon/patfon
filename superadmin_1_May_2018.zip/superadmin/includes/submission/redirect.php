<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>
<?php if (isset($_GET['delid'])){ 
    removereviewer($pdb,$_GET['delid']);// remove reviewer from the article
    removenotification($pdb,$_GET['delid'],$_GET['artid']);
    $artid = $_GET['artid'];
    $myurlx = "http://127.0.0.1/sciencepg/superadmin/includes/submission/current_reviewer.php?artid=$artid";
    //echo "deleted";
    echo "<meta http-equiv='refresh' content='0; url=$myurlx'>";
} ?>
<?php if (isset($_GET['delid2'])){ 
    removeeditor($pdb,$_GET['delid2']);// remove reviewer from the article
    removenotification($pdb,$_GET['delid2'],$_GET['artid']);
    $artid = $_GET['artid'];
    $myurlx = "http://127.0.0.1/sciencepg/superadmin/includes/submission/current_editor.php?artid=$artid";
    //echo "deleted";
    echo "<meta http-equiv='refresh' content='0; url=$myurlx'>";
} ?>