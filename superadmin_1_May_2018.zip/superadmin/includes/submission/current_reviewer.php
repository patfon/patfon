<?php include '../../includes/general/header.php'; ?>
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>

<?php if (isset($_GET['artid'])){ 
    $myid = $_GET['artid'];//get articleid
    $myj = getreviewersarticle($pdb,$myid);//get reiewers belonging to that manuscript
    $myreviewerssone = getreviewersbyjournal($pdb,getjournaltypearticle($pdb,$myid));// get reviewers in that journal category
    ?>



<div id="content" style="background: #fff; margin: 50px 20% 0px 20%; line-height: 20px; padding: 40px;">
<h3> Update Manuscript Reviewers </h3><br>
<?php 
if (!empty($myj)){ ?>
    <h3>Your Reviewers List</h3>
<label> Reviewer Name:  </label> <br><br>
<?php foreach ($myj as $m){?>

<div style="display: inline-block; width: 80%;">
<input type ="text" disabled="disabled" class="form2input" value="<?php echo getusername($pdb,$m['_userid']); ?> "> &nbsp;&nbsp;&nbsp;&nbsp; <a href="redirect.php?delid=<?php echo $m['id']; ?>&artid=<?php echo $myid; ?>" onclick="return confirm('Are you sure you want to remove this?')"> Remove This User </a> <br><br>
</div>

<?php } } else { ?>
<b style="color: red;"> No Reviewers Added Yet </b>
<?php } ?>
<div class="clearfix"></div>
<form action="<?php echo $myurl.'controller/Article/reviewers.php'; ?>" method="post">
<div style="display: inline-block; width: 400px;">
<label> Reviewers in this Journal:  </label> <br><br>
<input type="hidden" name="articleid" value="<?php echo $myid; ?>">
<select id="seljournal" name = "reviewersid" required="required"style="width: 300px;" >
                                               <option value=""> Select.... </option>
                                               
                                               <?php foreach ($myreviewerssone as $sx){
                                                    $idx = $sx['id'];
                                                   
                                            echo "<option value='$idx'>".getusername($pdb,$idx)."</option>";

                                                }?>
                                               </select> <br><br>
</div>

<div class="buttons" style="text-align:center;padding-top:10px;margin:0;padding-left:400px;x;border-top:1px solid #DDD;">
<input type="reset" name="reset" value="Reset" class="ui-button ui-widget ui-state-default ui-corner-all ui-state-hover" style="float:left;cursor:pointer;" role="button" aria-disabled="false">
<div class="highlight" style="float:left;margin-left:20px;">
<input type="submit" name="butadd" id="next1" value="Add Reviewers" class="ui-button ui-widget ui-state-default ui-corner-all" style="cursor:pointer;" role="button" aria-disabled="false">
</div>
<div style="clear:both;height:1px;margin-top:-1px;overflow: hidden;"></div>
</div>

</form>

</div>

<?php } ?>
<?php include '../../includes/general/footer.php'; ?>