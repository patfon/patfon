<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
      include '../../functions/index.php'; 
//add a new Editor

if (isset($_GET['artid']) && isset($_GET['action'])){

$myfield = $_GET['artid'];//get article id
$myfield2 = $_GET['action'];//get action of user id


    $myfield =  mysqli_real_escape_string($pdb,$myfield);
    $myfield2 =  mysqli_real_escape_string($pdb,$myfield2);

    $todaydate = date('Y-m-d H:i:s');
    $todaydatex = strtotime($todaydate);

    if ($myfield2 === "confirm"){
        $expecteddate = strtotime('+2 Weekday',$todaydatex);
    }
    else if ($myfield2 === "reviewing"){
        $expecteddate = strtotime('+3 Weekday',$todaydatex);
    }

    $noofeditors = geteditorsarticle($pdb,$myfield);
    $noofreviewers = getreviewersarticle($pdb,$myfield );
   
    foreach ($noofeditors as $nos) {
        $idx = $nos['_userid'];
    $query = ("INSERT INTO notifications (_userid,_action, _actual, _expected, _done, _articleid) 
    VALUES ( $idx,'confirm','$todaydatex','$expecteddate',0,$myfield ) ");

    mysqli_query($pdb, $query);

    }

    foreach ($noofreviewers as $nos) {
        $idx = $nos['_userid'];
    $query = ("INSERT INTO notifications (_userid,_action, _actual, _expected, _done, _articleid) 
    VALUES ( $idx,'confirm','$todaydatex','$expecteddate',0,$myfield ) ");

    mysqli_query($pdb, $query);//send notification to user

    }

$_SESSION['msg']['sentnotify'] = 1;
header('Location: current.php');

}

//could be used in future---------------
function getWorkingDays($startDate,$endDate){
    // do strtotime calculations just once
    $endDate = strtotime($endDate);
    $startDate = strtotime($startDate);


    //The total number of days between the two dates. We compute the no. of seconds and divide it to 60*60*24
    //We add one to inlude both dates in the interval.
    $days = ($endDate - $startDate) / 86400 + 1;

    $no_full_weeks = floor($days / 7);
    $no_remaining_days = fmod($days, 7);

    //It will return 1 if it's Monday,.. ,7 for Sunday
    $the_first_day_of_week = date("N", $startDate);
    $the_last_day_of_week = date("N", $endDate);

    //---->The two can be equal in leap years when february has 29 days, the equal sign is added here
    //In the first case the whole interval is within a week, in the second case the interval falls in two weeks.
    if ($the_first_day_of_week <= $the_last_day_of_week) {
        if ($the_first_day_of_week <= 6 && 6 <= $the_last_day_of_week) $no_remaining_days--;
        if ($the_first_day_of_week <= 7 && 7 <= $the_last_day_of_week) $no_remaining_days--;
    }
    else {
        // (edit by Tokes to fix an edge case where the start day was a Sunday
        // and the end day was NOT a Saturday)

        // the day of the week for start is later than the day of the week for end
        if ($the_first_day_of_week == 7) {
            // if the start date is a Sunday, then we definitely subtract 1 day
            $no_remaining_days--;

            if ($the_last_day_of_week == 6) {
                // if the end date is a Saturday, then we subtract another day
                $no_remaining_days--;
            }
        }
        else {
            // the start date was a Saturday (or earlier), and the end date was (Mon..Fri)
            // so we skip an entire weekend and subtract 2 days
            $no_remaining_days -= 2;
        }
    }

    //The no. of business days is: (number of weeks between the two dates) * (5 working days) + the remainder
//---->february in none leap years gave a remainder of 0 but still calculated weekends between first and last day, this is one way to fix it
   $workingDays = $no_full_weeks * 5;
    if ($no_remaining_days > 0 )
    {
      $workingDays += $no_remaining_days;
    }    


    return $workingDays;
}
