<?php include '../../includes/general/header.php'; ?>
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>

<?php if (isset($_GET['delid'])){ 
      $myid = $_GET['delid'];
      delreview($pdb,$myid);
}
    ?>

            <div id="content" style="height: 80%;">
                
            <?php include '../../includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                <div class="box">
                   <!--Alert msg-->
            <?php if (isset($_SESSION['msg']['addjournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> A Reviewer has been Added..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['addjournal']); ?>
            <?php if (isset($_SESSION['msg']['updatejournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> A reviewer has been Updated..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['updatejournal']); ?>
            <?php if (isset($_SESSION['msg']['deletejournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> A reviewer has been Deleted..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['deletejournal']); ?>   
            
             <!--end Alert msg-->

<!-- First Header showing Example-->
                <div>

                <div id="box-tabs" class="box">
                    <!-- box / title -->
                            <div class="title">
                                        <h5>Reviewers Example</h5>
                                    </div>
                                    <!-- box / title -->
                                    <div id="box-messages">
                                        <div class="messages">
                            <div id="ctl00_ContentPlaceHolder1_BoxMessage_Info_Panel_SuccessMessage">
                                <div id="message-success" class="message message-notice">
                                                <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                            <h6>Examples</h6>
                                            <span id="examples"> A reviewer is someone with the responsibility of screening a manuscript after corrections from the Editors. </span>
                                            </div>
                                </div>
                            </div>
                                        </div>
                                    </div>
                </div>
                </div>
<!-- end First Header showing Example-->
<!-- Second Header showing Table List-->
                        <div class="title">
                        <h5>List Reviewers</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:16px;padding-right:16px;">
                               
                                    <?php $sub = getreviewers($pdb); ?>
                                    <table class="mydatatables" width="100%" >
                                       <thead  style="color: #fff; ">
                                       <tr>
                                       <td class="tablehead">S/N </td> <td class="tablehead"> Journal Category</td> <td class="tablehead"> Reviewer Name  </td> <td class="tablehead">Action </td>
                                       </tr>
                                       </thead>

                                        <tbody>
                                      <?php  
                                      $i = 1;
                                      if (!empty($sub)) {
                                      foreach ($sub as $s){ ?>
                                            <tr> <td> <?php echo $i; ?></td> <td> <?php echo getjournalname($pdb,$s['_journalid']); ?></td> <td> <?php echo getusername($pdb,$s['_userid']); ?></td> 
                                            <td> <a href="editorial.php?delid=<?php echo $s['id']; ?>" onclick="return confirm('Are you sure you want to delete this?')">Delete</a>&nbsp;&nbsp;&nbsp;</td></tr>
                                      <?php $i++;} } else { ?>
                                        <tr> <td colspan="4" style="text-align: center;"> No Journal Reviewers added yet. </td></tr>

                                      <?php } ?>
                                        </tbody>
                                    </table>
                                   
                                
                            </div>             
<!-- end Second Header showing Table List-->                    
                            <!-- Add New Subjects to the Group-->
                            <!-- box / title -->
                        <div class="title">
                        <h5>Add Reviewers</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:16px;padding-right:16px;">
                                <form id="profilefrom2" action="<?php echo $myurl.'controller/Journal/reviewers.php'; ?>" method="post">
                                   
                                    <table id="author2" width="100%">
                                        <tbody class="journalwrapper">
                                        <tr>
                                            <td colspan="3">
                                            
                                            </td>
                                        </tr>
                                        <tr style="background:#999;">
                                            <td style="width:200px;text-align:center;font-weight: bold;">
                                                No.</td>
                                            <td id="detailTitle" style="text-align:center;font-weight: bold;">Journal Category</td>
                                            <td id="detailTitle" style="text-align:center;font-weight: bold;">User</td>
                                        </tr>
                                        
                                            <tr id="1">
                                                <td class='snsub' style="width:200px;" align="center">1</td>
                                                <?php $mysub = getjournals($pdb); $myuser = getusers($pdb);
                                                        
                                                ?>
                                               <td align="center" id="detailTitle">
                                               <select id="seljournal" name = "journal" required="required" >
                                               <option value=""> Select.... </option>
                                               
                                               <?php foreach ($mysub as $sx){
                                                    $idx = $sx['id'];
                                                    $nax = $sx['_name'];
                                            echo "<option value='$idx'>$nax</option>";

                                                }?>
                                               </select>
                                                </td>
                    <td align="center" id="detailTitle">
                                             <select id="seluser" name = "user" required="required" >
                                               <option value=""> Select.... </option>
                                               
                                               <?php foreach ($myuser as $sx){
                                                    $idx = $sx['id'];
                                                    $nax = $sx['_fname']." ".$sx['_lname']. ", ".$sx['_uni'] ;
                                            echo "<option value='$idx'>$nax</option>";

                                                }?>
                                               </select>
                   
                    </td>
                    </tr>
                    </tbody></table>
                                    <div id="beforeDiv" style="width:96%;padding:10px 2%;" class="highlight">
                                        <input type="button" value="Add" id="jouaddRow" style="cursor:pointer;width:98%; display: none;" class="ui-button ui-widget ui-state-default ui-corner-all">
                                    </div>
                                    <div class="buttons" style="text-align:center;padding-top:10px;margin:0;padding-left:400px;x;border-top:1px solid #DDD;">
                                        <input type="reset" name="reset" value="Reset" class="ui-button ui-widget ui-state-default ui-corner-all ui-state-hover" style="float:left;cursor:pointer;" role="button" aria-disabled="false">
                                        <div class="highlight" style="float:left;margin-left:20px;">
                                            <input type="submit" name="butadd" id="next1" value="Submit" class="ui-button ui-widget ui-state-default ui-corner-all" style="cursor:pointer;" role="button" aria-disabled="false">
                                        </div>
                                        <div style="clear:both;height:1px;margin-top:-1px;overflow: hidden;"></div>
                                    </div>
                                </form>
                                
                                
                            </div>            
                            <!--   Add new Subjects end -->
                        </div> 
            
                </div>
            
            </div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include '../../includes/general/footer.php'; ?>