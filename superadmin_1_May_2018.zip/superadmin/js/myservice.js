$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/home/subjects.php") > -1) {            
        
        $('#menu-home li:nth-child(1)').addClass('activeatt');
        $('#menu-home li:nth-child(2)').removeClass('activeatt');
        $('#menu-home li:nth-child(3)').removeClass('activeatt');
        $('#menu-home li:nth-child(5)').removeClass('activeatt');
        $('#menu-home li:nth-child(4)').removeClass('activeatt');
        $('#menu-home li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});
////Slides 
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/home/slide.php") > -1) {            
        
        $('#menu-home li:nth-child(2)').addClass('activeatt');
        $('#menu-home li:nth-child(1)').removeClass('activeatt');
        $('#menu-home li:nth-child(3)').removeClass('activeatt');
        $('#menu-home li:nth-child(5)').removeClass('activeatt');
        $('#menu-home li:nth-child(4)').removeClass('activeatt');
        $('#menu-home li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});
////About 
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/home/about.php") > -1) {            
        
        $('#menu-home li:nth-child(3)').addClass('activeatt');
        $('#menu-home li:nth-child(1)').removeClass('activeatt');
        $('#menu-home li:nth-child(2)').removeClass('activeatt');
        $('#menu-home li:nth-child(5)').removeClass('activeatt');
        $('#menu-home li:nth-child(4)').removeClass('activeatt');
        $('#menu-home li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////About 
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/home/testimonial.php") > -1) {            
        
        $('#menu-home li:nth-child(4)').addClass('activeatt');
        $('#menu-home li:nth-child(1)').removeClass('activeatt');
        $('#menu-home li:nth-child(2)').removeClass('activeatt');
        $('#menu-home li:nth-child(5)').removeClass('activeatt');
        $('#menu-home li:nth-child(3)').removeClass('activeatt');
        $('#menu-home li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Partners
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/home/partners.php") > -1) {            
        
        $('#menu-home li:nth-child(5)').addClass('activeatt');
        $('#menu-home li:nth-child(1)').removeClass('activeatt');
        $('#menu-home li:nth-child(2)').removeClass('activeatt');
        $('#menu-home li:nth-child(4)').removeClass('activeatt');
        $('#menu-home li:nth-child(3)').removeClass('activeatt');
        $('#menu-home li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---List
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/list.php") > -1) {            
        
        $('#menu-journal li:nth-child(1)').addClass('activeatt');
        $('#menu-journal li:nth-child(5)').removeClass('activeatt');
        $('#menu-journal li:nth-child(2)').removeClass('activeatt');
        $('#menu-journal li:nth-child(4)').removeClass('activeatt');
        $('#menu-journal li:nth-child(3)').removeClass('activeatt');
        $('#menu-journal li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---Volume
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/volume.php") > -1) {            
        
        $('#menu-journal li:nth-child(2)').addClass('activeatt');
        $('#menu-journal li:nth-child(5)').removeClass('activeatt');
        $('#menu-journal li:nth-child(1)').removeClass('activeatt');
        $('#menu-journal li:nth-child(4)').removeClass('activeatt');
        $('#menu-journal li:nth-child(3)').removeClass('activeatt');
        $('#menu-journal li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---Editorial
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/editorial.php") > -1) {            
        
        $('#menu-journal li:nth-child(3)').addClass('activeatt');
        $('#menu-journal li:nth-child(5)').removeClass('activeatt');
        $('#menu-journal li:nth-child(1)').removeClass('activeatt');
        $('#menu-journal li:nth-child(4)').removeClass('activeatt');
        $('#menu-journal li:nth-child(2)').removeClass('activeatt');
        $('#menu-journal li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---Reviewers
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/reviewers.php") > -1) {            
        
        $('#menu-journal li:nth-child(4)').addClass('activeatt');
        $('#menu-journal li:nth-child(5)').removeClass('activeatt');
        $('#menu-journal li:nth-child(1)').removeClass('activeatt');
        $('#menu-journal li:nth-child(3)').removeClass('activeatt');
        $('#menu-journal li:nth-child(2)').removeClass('activeatt');
        $('#menu-journal li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---Guideline
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/guidelines.php") > -1) {            
        
        $('#menu-journal li:nth-child(5)').addClass('activeatt');
        $('#menu-journal li:nth-child(4)').removeClass('activeatt');
        $('#menu-journal li:nth-child(1)').removeClass('activeatt');
        $('#menu-journal li:nth-child(3)').removeClass('activeatt');
        $('#menu-journal li:nth-child(2)').removeClass('activeatt');
        $('#menu-journal li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---APC
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/apc.php") > -1) {            
        
        $('#menu-journal li:nth-child(6)').addClass('activeatt');
        $('#menu-journal li:nth-child(4)').removeClass('activeatt');
        $('#menu-journal li:nth-child(1)').removeClass('activeatt');
        $('#menu-journal li:nth-child(3)').removeClass('activeatt');
        $('#menu-journal li:nth-child(2)').removeClass('activeatt');
        $('#menu-journal li:nth-child(5)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---ethics
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/ethics.php") > -1) {            
        
        $('#menu-journal li:nth-child(7)').addClass('activeatt');
        $('#menu-journal li:nth-child(4)').removeClass('activeatt');
        $('#menu-journal li:nth-child(1)').removeClass('activeatt');
        $('#menu-journal li:nth-child(3)').removeClass('activeatt');
        $('#menu-journal li:nth-child(2)').removeClass('activeatt');
        $('#menu-journal li:nth-child(5)').removeClass('activeatt');
        $('#menu-journal li:nth-child(6)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---copyright
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/copyright.php") > -1) {            
        
        $('#menu-journal li:nth-child(8)').addClass('activeatt');
        $('#menu-journal li:nth-child(4)').removeClass('activeatt');
        $('#menu-journal li:nth-child(1)').removeClass('activeatt');
        $('#menu-journal li:nth-child(3)').removeClass('activeatt');
        $('#menu-journal li:nth-child(2)').removeClass('activeatt');
        $('#menu-journal li:nth-child(5)').removeClass('activeatt');
        $('#menu-journal li:nth-child(6)').removeClass('activeatt');
        $('#menu-journal li:nth-child(7)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////Journal---faq
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/journal/copyright.php") > -1) {            
        
        $('#menu-journal li:nth-child(9)').addClass('activeatt');
        $('#menu-journal li:nth-child(4)').removeClass('activeatt');
        $('#menu-journal li:nth-child(1)').removeClass('activeatt');
        $('#menu-journal li:nth-child(3)').removeClass('activeatt');
        $('#menu-journal li:nth-child(2)').removeClass('activeatt');
        $('#menu-journal li:nth-child(5)').removeClass('activeatt');
        $('#menu-journal li:nth-child(6)').removeClass('activeatt');
        $('#menu-journal li:nth-child(7)').removeClass('activeatt');
        $('#menu-journal li:nth-child(8)').removeClass('activeatt');
        $('#menu-news li:nth-child(1)').removeClass('activeatt');
      
 }

});

////News---List
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/news/list.php") > -1) {            
        
        $('#menu-news li:nth-child(1)').addClass('activeatt');
        $('#menu-news li:nth-child(4)').removeClass('activeatt');
        
      
 }

});

////Submissions--Accept
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/submission/accept.php") > -1) {            
        
        $('#menu-sub li:nth-child(3)').addClass('activeatt');
        $('#menu-sub li:nth-child(4)').removeClass('activeatt');
        $('#menu-sub li:nth-child(1)').removeClass('activeatt');
        $('#menu-sub li:nth-child(2)').removeClass('activeatt');
        
      
 }

});

////Submissions--Verify
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/submission/verifypay.php") > -1) {            
        
        $('#menu-sub li:nth-child(2)').addClass('activeatt');
        $('#menu-sub li:nth-child(4)').removeClass('activeatt');
        $('#menu-sub li:nth-child(3)').removeClass('activeatt');
        $('#menu-sub li:nth-child(1)').removeClass('activeatt');
        
      
 }

});

////Submissions--Statistics
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/submission/statistics.php") > -1) {            
        
        $('#menu-sub li:nth-child(1)').addClass('activeatt');
        $('#menu-sub li:nth-child(4)').removeClass('activeatt');
        $('#menu-sub li:nth-child(3)').removeClass('activeatt');
        $('#menu-sub li:nth-child(2)').removeClass('activeatt');
        
      
 }

});

////Submissions--Publish
$(document).ready(function() {

    if (window.location.href.indexOf("superadmin/includes/submission/publish.php") > -1) {            
        
        $('#menu-sub li:nth-child(4)').addClass('activeatt');
        $('#menu-sub li:nth-child(2)').removeClass('activeatt');
        $('#menu-sub li:nth-child(3)').removeClass('activeatt');
        $('#menu-sub li:nth-child(1)').removeClass('activeatt');
        
      
 }

});


///SUBJECTS ADD NEW TEXTFIELD
$(document).ready(function(){
    var x = 1; //Initial field counter is 1
    
    var maxField = 10; //Input fields increment limitation
    var addButton = $('#subaddRow'); //Add button selector
    var wrapper = $('.subwrapper'); //Input field wrapper
  
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            var fieldHTML = '<tr id="'+x+'"><td class="snsub" style="width:200px;" align="center">'+x+'</td><td align="center" id="detailTitle"><input type="text" class="form2input" name="subject[]"  maxlength="1000"> <div class="highlight"><input type="button" value="Delete"  class="ui-button ui-widget ui-state-default delsubject" style="cursor:pointer;"></div></td></tr>'
   
            $(wrapper).append(fieldHTML); // Add field html
        }
    });
    $(wrapper).on('click', '.delsubject', function(e){ 
        e.preventDefault();
        console.log('clicked'+ x);
        $(this).parent().parent().parent().remove(); //Remove field html
        x--; //Decrement field counter
    });
});

///SLIDES ADD NEW FILE UPLOAD
$(document).ready(function(){
    var x = 1; //Initial field counter is 1
    
    var maxField = 5; //Input fields increment limitation
    var addButton = $('#slideddRow'); //Add button selector
    var wrapper2 = $('.subwrapper_slide'); //Input field wrapper
   
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
           
            var fieldHTML = '<tr id="'+x+'">'+
            '<td class="snsub" style="width:200px;" align="center">'+x+'<input type="hidden" value="<?php echo getToken(8); ?>" name="slideid[]" > </td>'+
            '<td align="center" id="detailTitle"><input type="file" class="form2input" name="slide[]" accept="image/jpeg, image/png" > <div class="highlight">'+
            '<input type="button" value="Delete"  class="ui-button ui-widget ui-state-default delsubject" style="cursor:pointer;"></div></td></tr>';
   
            $(wrapper2).append(fieldHTML); // Add field html
        }
    });
    $(wrapper2).on('click', '.delsubject', function(e){ 
        e.preventDefault();
        console.log('clicked'+ x);
        $(this).parent().parent().parent().remove(); //Remove field html
        x--; //Decrement field counter
    });
});

///Testimonials ADD NEW FILE UPLOAD
$(document).ready(function(){
    var x = 1; //Initial field counter is 1
    
    var maxField = 5; //Input fields increment limitation
    var addButton = $('#testaddRow'); //Add button selector
    var wrapper3 = $('.testwrapper'); //Input field wrapper
   
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            var fieldHTML = 
            '<tr id="'+x+'">'+
            '<td class="snsub" style="width:200px;" align="center">'+x+'</td>'+
            '<td align="center" id="detailTitle">'+ 
            '<input type="text" class="form2input" name="name[]"  maxlength="1000">'+
            '</td><td align="center" id="detailTitle"><textarea type="text" class="form2input" name="content[]" >  </textarea> <div class="highlight"><input type="button" value="Delete"  class="ui-button ui-widget ui-state-default delsubject" style="cursor:pointer;">' +
            '</div></td></tr>';

   
            $(wrapper3).append(fieldHTML); // Add field html
        }
    });
    $(wrapper3).on('click', '.delsubject', function(e){ 
        e.preventDefault();
        console.log('clicked'+ x);
        $(this).parent().parent().parent().remove(); //Remove field html
        x--; //Decrement field counter
    });
});

///Partners ADD NEW FILE UPLOAD
$(document).ready(function(){
    var x = 1; //Initial field counter is 1
    
    var maxField = 5; //Input fields increment limitation
    var addButton = $('#partneraddRow'); //Add button selector
    var wrapper4 = $('.partnerwrapper'); //Input field wrapper
   
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            var fieldHTML = '<tr id="'+x+'">'+
            '<td class="snsub" style="width:200px;" align="center">'+x+'</td>'+
            '<td align="center" id="detailTitle">'+
            '<input type="hidden" value="<?php echo getToken(8); ?>" name="partnerid[]" >'+
            '<input type="text" class="form2input" name="name[]" required="required" >'+ 
            '</td>'+
            '<td align="center" id="detailTitle"><input type="file" class="form2input" name="partner[]" accept="image/jpeg, image/png" > <div class="highlight">'+
            '<input type="button" value="Delete"  class="ui-button ui-widget ui-state-default delsubject" style="cursor:pointer;"></div></td></tr>';
            $(wrapper4).append(fieldHTML); // Add field html
        }
    });
    $(wrapper4).on('click', '.delsubject', function(e){ 
        e.preventDefault();
        console.log('clicked'+ x);
        $(this).parent().parent().parent().remove(); //Remove field html
        x--; //Decrement field counter
    });
});

///Journals ADD NEW TEXTFIELD
$(document).ready(function(){
    var x = 1; //Initial field counter is 1
    
    var maxField = 10; //Input fields increment limitation
    var addButton = $('#jouaddRow'); //Add button selector
    var wrapper5 = $('.journalwrapper'); //Input field wrapper
  
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            var fieldHTML = '<tr id="'+x+'"><td class="snsub" style="width:200px;" align="center">'+x+'</td><td align="center" id="detailTitle"><input type="text" class="form2input" name="journal[]"  maxlength="1000"> <div class="highlight"><input type="button" value="Delete"  class="ui-button ui-widget ui-state-default delsubject" style="cursor:pointer;"></div></td></tr>'
   
            $(wrapper5).append(fieldHTML); // Add field html
        }
    });
    $(wrapper5).on('click', '.delsubject', function(e){ 
        e.preventDefault();
        console.log('clicked'+ x);
        $(this).parent().parent().parent().remove(); //Remove field html
        x--; //Decrement field counter
    });
});

///FAQ ADD NEW TEXTFIELD
$(document).ready(function(){
    var x = 1; //Initial field counter is 1
    
    var maxField = 10; //Input fields increment limitation
    var addButton = $('#faqaddRow'); //Add button selector
    var wrapper = $('.faqwrapper'); //Input field wrapper
  
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            var fieldHTML = '<tr id="'+x+'">'+
            '<td class="snsub" style="width:200px;" align="center">'+x+'</td>'+
            '<td align="center" id="detailTitle">'+
            '<input type="text" class="form2input" name="question[]"  maxlength="1000">'+ 
            '</td>'+
            '<td align="center" id="detailTitle" style="padding : 0px;">'+
            ' <textarea  name="ans[]" rows="5" cols="55" wrap="soft"> </textarea>'+
            '<div class="highlight">'+
            '<input type="button" value="Delete"  class="ui-button ui-widget ui-state-default delsubject" style="cursor:pointer;">'+
            '</div></td></tr>';
            
            $(wrapper).append(fieldHTML); // Add field html
        }
    });
    $(wrapper).on('click', '.delsubject', function(e){ 
        e.preventDefault();
        console.log('clicked'+ x);
        $(this).parent().parent().parent().remove(); //Remove field html
        x--; //Decrement field counter
    });
});

$(document).ready(function(){

    $("#seluser").select2();
    $("#seljournal").select2();
    $('#iframe').contents().find('body').css('overflow-x', 'scroll');
});
