<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new testimonial

if (isset($_POST['butadd'])){

$myfields = $_POST['name'];

$myfields2 = $_POST['content'];

$myc = count ($_POST['name']);

for ($i = 0; $i < $myc; $i++){
    $myx =  mysqli_real_escape_string($pdb,$myfields[$i]);
    $myx2 =  mysqli_real_escape_string($pdb,$myfields2[$i]);

    $query = ("INSERT INTO testimonials (_name,_content) 
    VALUES (' $myx',' $myx2' ) ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addtestimonial'] = 1;
            header('Location: ../../includes/home/testimonial.php');
    }

}

}
//update a Testimonial
if (isset($_POST['butupdate'])){

    $myid = $_POST['testid'];
    $n =  mysqli_real_escape_string($pdb,$_POST['name']);
    $c =  mysqli_real_escape_string($pdb,$_POST['content']);
      
        $query = ("UPDATE testimonials SET _name = '$n' , _content = '$c'  WHERE id = $myid ");
    
        if (mysqli_query($pdb, $query)) {
                $_SESSION['msg']['updatetestimonial'] = 1;
                header('Location: ../../includes/home/testimonial.php');
        }
        else{
            echo  mysqli_error($pdb);
        }
    
    
    
    }