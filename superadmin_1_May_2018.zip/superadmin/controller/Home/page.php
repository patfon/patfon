<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
include '../../functions/index.php';
//add a new about section content
if (isset($_POST['butabout'])){

   $check_ =  checkpagecontent($pdb,'about_title');
   $check2_ =  checkpagecontent($pdb,'about_story');
   $check3_ =  checkpagecontent($pdb,'about_mission');

   if (isset($_POST['title'])){
    if (count($check_) <= 0 ){
     $myfield =  mysqli_real_escape_string($pdb,$_POST['title']);
 
     $query = ("INSERT INTO page (_metadata,_content) 
     VALUES ('about_title','$myfield' ) ");
 
     mysqli_query($pdb, $query);
     $_SESSION['msg']['addabout'] = 1;
     header('Location: ../../includes/home/about.php');
 
    }
    else{ 
     $myfield =  mysqli_real_escape_string($pdb,$_POST['title']);
 
     $query = ("UPDATE page SET _content = '$myfield' WHERE _metadata = 'about_title' ");
 
     mysqli_query($pdb, $query);
     $_SESSION['msg']['updateabout'] = 1;
     header('Location: ../../includes/home/about.php');
    }
 }
 
 if (isset($_POST['story'])){
    if (count($check2_) <= 0  ){
     $myfield =  mysqli_real_escape_string($pdb,$_POST['story']);
 
     $query = ("INSERT INTO page (_metadata,_content) 
     VALUES ('about_story','$myfield' ) ");
 
     mysqli_query($pdb, $query);
     $_SESSION['msg']['addabout'] = 1;
     header('Location: ../../includes/home/about.php');
 
    }
    else{ 
     $myfield =  mysqli_real_escape_string($pdb,$_POST['story']);
 
     $query = ("UPDATE page SET _content = '$myfield' WHERE _metadata = 'about_story' ");
 
     mysqli_query($pdb, $query);
     $_SESSION['msg']['updateabout'] = 1;
     header('Location: ../../includes/home/about.php');
    }
 }
 
 if (isset($_POST['mission'])){
    if (count($check3_) <= 0  ){
     $myfield =  mysqli_real_escape_string($pdb,$_POST['mission']);
 
     $query = ("INSERT INTO page (_metadata,_content) 
     VALUES ('about_mission','$myfield' ) ");
 
     mysqli_query($pdb, $query);
     $_SESSION['msg']['addabout'] = 1;
     header('Location: ../../includes/home/about.php');
 
    }
    else{ 
     $myfield =  mysqli_real_escape_string($pdb,$_POST['mission']);
 
     $query = ("UPDATE page SET _content = '$myfield' WHERE _metadata = 'about_mission' ");
 
     mysqli_query($pdb, $query);
     $_SESSION['msg']['updateabout'] = 1;
     header('Location: ../../includes/home/about.php');
    }
 }



}