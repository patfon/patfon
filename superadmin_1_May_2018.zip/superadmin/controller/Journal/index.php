<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Subject

if (isset($_POST['butadd'])){

$myfields = $_POST['journal'];
$myfield2s = $_POST['subject'];

foreach($myfields as $myf) {
    foreach($myfield2s  as $myf2){
    $myfield =  mysqli_real_escape_string($pdb,$myf);
    $myfield2 =  mysqli_real_escape_string($pdb,$myf2);

    $query = ("INSERT INTO journal (_name,_subject,_image,_about,_isbn_p,_isbn_o,_fee) 
    VALUES ('$myfield',$myfield2,'','','','',0) ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addjournal'] = 1;
            header('Location: ../../includes/journal/list.php');
    }
    else{
        if (mysqli_errno($pdb) == 1062){
            $_SESSION['msg']['username_exists'] = 1;
            header("Location:  ../../includes/journal/list.php ");
            return;
        }
        echo mysqli_error($pdb);
    }

    }
}

}
//update a new Subject
if (isset($_POST['butupdate'])){

    $myid = $_POST['jid'];
    
    $n = mysqli_real_escape_string($pdb,$_POST['jname']);
    $a = stripslashes($_POST['jabout']);
    $io = mysqli_real_escape_string($pdb,$_POST['jisbno']);
    $ip = mysqli_real_escape_string($pdb,$_POST['jisbnp']);
    $urlpath = "";

    $path = "../../images/journals/";
    
    if (isset($_FILES['jimage']) ) {

    $valid_formats = array("png","PNG","jpg","JPEG");
    $newname = $myid;
    
        $name = $_FILES['jimage']['name'];
        $size = $_FILES['jimage']['size'];
      
        if(strlen($name))
          {
          list($txt, $ext) = explode(".", $name);
          if(in_array($ext,$valid_formats))
          {
                                  //200KB limit     
          if($size<(1024*200))
          {
        
          $tmp = $_FILES['jimage']['tmp_name'];
          $canid = $newname .".".$ext;
        
          $urlpath = $path.$canid;

          move_uploaded_file($tmp, $urlpath);
          $urlpath = str_replace('../../','',$urlpath);

         }
          else{
            $_SESSION['msg']['error'] = "Journal Image Maximum size is 200 kilobytes.";
            header('Location: ../../includes/journal/list.php');	}					
          }
          else{
            $_SESSION['msg']['error'] = "Invalid Journal Image format.";
            header('Location: ../../includes/journal/list.php');	}
          }
    }
   
       $query = ("UPDATE journal SET _name = '$n',_image = '$urlpath', _about = '$a', _isbn_p = '$ip', _isbn_o = '$io'  WHERE id = $myid ");
    
        if (mysqli_query($pdb, $query)) {
                $_SESSION['msg']['updatejournal'] = 1;
                header('Location: ../../includes/journal/list.php');
        }
    
    
    
    }