<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Subject

if (isset($_POST['butadd'])){


    $myfield =  mysqli_real_escape_string($pdb,$_POST['journal']);
    $myfield2 =  mysqli_real_escape_string($pdb,$_POST['user']);
    $mydate = date('Y-m-d');

    $query = ("INSERT INTO reviewers (_userid,_journalid,_lastactivity) 
    VALUES ($myfield2,$myfield,'$mydate') ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addjournal'] = 1;
            header('Location: ../../includes/journal/reviewers.php');
    }
    else{
        if (mysqli_errno($pdb) == 1062){
            $_SESSION['msg']['username_exists'] = 1;
            header("Location:  ../../includes/journal/reviewers.php ");
            return;
        }
        echo mysqli_error($pdb);
    }

  

}