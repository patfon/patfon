<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Editor

if (isset($_POST['butadd'])){

$myfield = $_POST['editorsid'];//get editor id
$myfield2 = $_POST['articleid'];//get article id


    $myfield =  mysqli_real_escape_string($pdb,$myfield);
    $myfield2 =  mysqli_real_escape_string($pdb,$myfield2);

    $query = ("INSERT INTO articles_editors (_articleid,_userid) 
    VALUES (' $myfield2','$myfield' ) ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addeditor'] = 1;
            header('Location: ../../includes/submission/current.php');
    }



}
//update a new Editor
if (isset($_POST['butupdate'])){

    $myid = $_POST['subid'];
    $mysub = $_POST['subject'];
    
  
        $mysub =  mysqli_real_escape_string($pdb,$mysub);
    
        $query = ("UPDATE subject SET _name = '$mysub' WHERE id = $myid ");
    
        if (mysqli_query($pdb, $query)) {
                $_SESSION['msg']['updatesubject'] = 1;
                header('Location: ../../includes/home/subjects.php');
        }
    
    
    
    }