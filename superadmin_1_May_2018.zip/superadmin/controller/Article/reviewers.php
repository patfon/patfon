<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Editor

if (isset($_POST['butadd'])){

$myfield = $_POST['reviewersid'];//get editor id
$myfield2 = $_POST['articleid'];//get article id


    $myfield =  mysqli_real_escape_string($pdb,$myfield);
    $myfield2 =  mysqli_real_escape_string($pdb,$myfield2);

    $query = ("INSERT INTO articles_reviewers (_articleid,_userid) 
    VALUES (' $myfield2','$myfield' ) ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addreviewer'] = 1;
            header('Location: ../../includes/submission/current.php');
    }



}