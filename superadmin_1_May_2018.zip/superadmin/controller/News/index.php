<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Subject

if (isset($_POST['butadd'])){

    $myfield =  $_POST['jnews'];
    $myfield2 =  mysqli_real_escape_string($pdb,$_POST['title']);
    $mydate = date('y-m-d');

    $query = ("INSERT INTO news (_title,_content,_datesub) 
    VALUES ('$myfield2','$myfield','$mydate') ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addnews'] = 1;
            header('Location: ../../includes/news/list.php');
    }
    else{
      
        echo mysqli_error($pdb);
    }

  

}

if (isset($_POST['butupdate'])){

    $myid = $_POST['jid'];
    $myfield =  mysqli_real_escape_string($pdb,$_POST['title']);
    $myfield2 =  mysqli_real_escape_string($pdb,$_POST['jnews']);
    $mydate = date('y-m-d');
    
     $query = (" UPDATE news SET _title = '$myfield', _content = '$myfield2', _datesub = '$mydate'  WHERE id = $myid ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['updatenews'] = 1;
            header('Location: ../../includes/news/list.php');
    }
    else{
       
        echo mysqli_error($pdb);
    }

  

}