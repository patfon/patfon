<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php $_SESSION['cur-page'] = "Income > Set Fee"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
include('functions/index.php');
include('includes/header.php');
?>
<section id="main-content">
	<section class="wrapper">
    
    <div class="row">
                        <?php  if(isset($_SESSION['success'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully changed a Class Fee.
                            </div>                             
                        <?php unset($_SESSION['success']); } ?>
                        <?php  if(isset($_SESSION['success_i'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully changed one of the Other Fees.
                            </div>                             
                        <?php unset($_SESSION['success_i']); } ?>
                       
                        <?php  if(isset($_SESSION['failed'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.There was an error in the last request. Please try again.
                            </div>                             
                        <?php unset($_SESSION['failed']); } ?>
    <div class="col-md-6">
                       
<div class="table-agile-info">
 <div class="panel panel-default">
 <!---728x90 -->
    <div class="panel-heading">
    Set Class Fee
    </div>
    <div>
      <table class="table">
        <thead>
          <tr>
            <th >ID</th>
            <th>Name of Class</th>
            <th>Amount</th>
            <?php if ($_SESSION['patfonuser']['role'] == "super") { ?> 
            <th>Action</th>
            <?php } ?>
          </tr>
        </thead>
        <tbody>
        <?php 
        $i = 1;
        $cat = 7;
        $classes = array('JSS1',"JSS2","JSS3","SS1","SS2","SS3");
        $sch = $_SESSION['patfonuser']['school'];
        foreach ($classes as $c) {
        ?>
          <tr data-expanded="true">
            <td><?php echo $i; ?>  </td>
            <td><?php echo $c; ?>  </td>
            <td><?php echo getclassfee($pdb,$cat,$sch); ?></td>
            <?php if ($_SESSION['patfonuser']['role'] == "super") { ?> 
            <td>
            <button onclick="updateFee('<?php echo $cat; ?>','<?php echo $c; ?>')" class=" btn btn-danger">Update Fee</button>
            </td>
          
            <?php } ?>
          </tr>
        <?php $i++;$cat++; }  ?>  
         
        </tbody>
      </table>
    </div>
	<!-- 728x90 -->
  </div>
</div>
    </div>
    <div class="col-md-6"> 
    <div class="table-agile-info">
 <div class="panel panel-default">
 <!---728x90 -->
    <div class="panel-heading">
    Set Other Fees
    </div>
    <div>
      <table class="table">
        <thead>
          <tr>
            <th >ID</th>
            <th>Name of Class</th>
            <th>Amount</th>
            <?php if ($_SESSION['patfonuser']['role'] == "super") { ?> 
            <th>Action</th>
            <?php } ?>
          </tr>
        </thead>
        <tbody>
        <?php 
        $i = 1;
        $dcat = 1;
        $otherfees = array('BUS',"CARDIGAN (SWEATER)","PARTY FEE");
        $sch = $_SESSION['patfonuser']['school'];
        foreach ($otherfees as $c) {
        ?>
          <tr data-expanded="true">
            <td><?php echo $i; ?>  </td>
            <td><?php echo $c; ?>  </td>
            <td><?php echo getclassfeeother($pdb,$dcat,$sch); ?></td>
            <?php if ($_SESSION['patfonuser']['role'] == "super") { ?> 
            <td>
            <button onclick="updateFeeOther('<?php echo $dcat; ?>','<?php echo $c; ?>')" class=" btn btn-danger">Update Fee</button>
            </td>
            <?php } ?>
          </tr>
        <?php $i++;$dcat++; }  ?>  
         
        </tbody>
      </table>
    </div>
	<!-- 728x90 -->
  </div>
</div>
    </div>

    </div>
</section>
</section>
<?php
//modals
include('pages/income/modals.php');
 ?>

<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 