<?php session_start(); ?>
<?php if (isset($_SESSION['patfonuser'])) {

    unset($_SESSION['patfonuser']);
    header('Location: login.php');
    exit;
} ?>