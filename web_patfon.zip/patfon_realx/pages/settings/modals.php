
<!--Edit Status to Manage-->
<div class="modal fade" id="manageuser_modal" tabindex="2" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>    
                    </button>
                     
                    <h4 class="modal-title" id=""> Edit Status<i class="fa fa-fw fa-pencil"></i></h4>
                </div>
                 <div class="modal-body">
                                        <form role="form" action=<?php echo $myurl."config/settings_controller.php"; ?> method="POST">
                                            <div class="form-group">
                                                <label for="">Name</label>
                                                <input type="text" class="form-control" id="modal_name"  disabled = "disabled" >
                                            </div>

                                            <div class="form-group">
                                                <label for="">Email</label>
                                                <input type="text" class="form-control" id="modal_email" disabled = "disabled" >
                                                <input type="hidden" value="" name="modal_id" id="modal_id"   >
                                         
                                            </div>
                                            <div class="form-group">
                                                <label for="">Security Key</label>
                                                <input type="password" class="form-control" name="modal_key"  required='required' >
                                               
                                            </div>
                                            <div class="form-group">
                                                <label for="">Choose Status</label>
                                                <select name="modal_status" required='required'>
                                                <option value="">  </option>
                                                <option value="1"> Active </option>
                                                <option value="0"> Block </option>
                                                </select>
                                            </div>
                                           
                                            <button type="submit" name="manage_userbut" class="btn btn-default" value="Change Status">Submit</button>
                                        </form>
                    
                 </div>
               
                
            </div>
                
            </div>
    </div>
    <!--end Edit Status to Manage-->

    <!--Delete user to Manage-->

    <div class="modal fade" id="manageuser_delmodal" tabindex="2" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>    
                    </button>
                     
                    <h4 class="modal-title" id=""> Delete User ? <i class="fa fa-fw fa-pencil"></i></h4>
                </div>
                 <div class="modal-body">
                                        <form role="form" action=<?php echo $myurl."config/settings_controller.php"; ?> method="POST">
                                            <div class="form-group">
                                                <label for="">Name</label>
                                                <input type="text" class="form-control" id="modalxx_name"  disabled = "disabled" >
                                            </div>

                                            <div class="form-group">
                                                <label for="">Email</label>
                                                <input type="text" class="form-control" id="modalxx_email" disabled = "disabled" >
                                                <input type="hidden" value="" name="modal_id" id="modalxx_id"   >
                                         
                                            </div>
                                            <div class="form-group">
                                                <label for="">Security Key</label>
                                                <input type="password" class="form-control" name="modal_key"  required='required' >
                                               
                                            </div>
                                            
                                           
                                            <button type="submit" name="manage_deluserbut" class="btn btn-default" >Delete User</button>
                                            &nbsp;&nbsp;&nbsp;&nbsp;
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> 
                                        </form>
                    
                 </div>
               
                
            </div>
                
            </div>
    </div>
    <!---->

    <!--Add User to Manage-->
    <div class="modal fade" id="manageuseradd_modal" tabindex="2" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>    
                    </button>
                     
                    <h4 class="modal-title" id=""> Add New User<i class="fa fa-fw fa-pencil"></i></h4>
                </div>
                 <div class="modal-body">
                                        <form role="form" action=<?php echo $myurl."config/settings_controller.php"; ?> method="POST">
                                            <div class="form-group">
                                                <label for="">Username</label>
                                                <input type="text" class="form-control" name="modalx_uname" required='required' >
                                            </div>
                                            <div class="form-group">
                                                <label for="">Password</label>
                                                <input type="password" class="form-control" name="modalx_pass" required='required'  >
                                            </div>
                                            <div class="form-group">
                                                <label for="">Email</label>
                                                <input type="email" class="form-control" name="modalx_email" >
                                            </div>
                                            <div class="form-group">
                                                <label for="">Phone Number</label>
                                                <input type="number" class="form-control" name="modalx_phone" required='required' >
                                            </div>
                                            <div class="form-group">
                                                <label for="">Full Name</label>
                                                <input type="text" class="form-control" name="modalx_fname" required='required' >
                                            </div>
                                            <div class="form-group">
                                                <label for="">Role</label>
                                                <select name="modalx_role" required='required'>
                                                <option value="">  </option>
                                                <option value="super">Super Admin</option>
                                                <option value="admin">Normal Admin </option>
                                                </select>
                                            </div>
                                           
                                           
                                           
                                            <button type="submit" name="manage_adduserbut" class="btn btn-default" value="Change Status">Submit</button>
                                        </form>
                    
                 </div>
               
                
            </div>
                
            </div>
    </div>
    <!--end Add User to Manage-->