$(document).ready(function() {
//add up total income receive fees new
});

$('.schfeex2 , .pullfeex2 , .partyfeex2').keyup(newschval);

function newschval(){

var sf =  $('.schfeex2').val();
if (sf === 'undefined' || sf === 'NULL' || sf === '') {
sf = 0;
}
var pf =  $('.pullfeex2').val();
if (pf === 'undefined' || pf === 'NULL' || pf === '') {
    pf = 0;
    }
var paf =  $('.partyfeex2').val();
if (paf === 'undefined' || paf === 'NULL' || paf === '') {
    paf = 0;
    }
var fsf =  Number($('.tfees').html());
if (fsf === 'undefined' || fsf === 'NULL' || fsf === '') {
    fsf = 0;
    }
var fpf =  Number($('.pullfees').html());
if (fpf === 'undefined' || fpf === 'NULL' || fpf === '') {
    fpf = 0;
    }
var fpaf =  Number($('.partyfees').html());
if (fpaf === 'undefined' || fpaf === 'NULL' || fpaf === '') {
    fpaf = 0;
    }
    
if (sf < fsf){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete fees to Continue</p>");
}

if (pf < fpf){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete fees to Continue</p>");
}
if (paf < fpaf){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete fees to Continue</p>");
}

if (sf >= fsf && pf >= fpf && paf >= fpaf){
    $('#feebutnew').removeAttr('disabled');
    $('#alertdiv').html("<p style='color: green;'> You can now proceed to complete.... :-)  </p>");
}

}

$('#cnewpass').keyup(validatepass);

function validatepass(){

        var password = $("#newpass").val();
        var confirmPassword = $("#cnewpass").val();
    
        if (password !== confirmPassword) {
            $("#div_conpass").addClass("has-error");
            $("#div_conpass").removeClass("has-success");
            $("#div_conpass .help-block").html("The passwords do not match...");
        }
        else {
            $("#div_conpass .help-block").html("");
            $("#div_conpass").addClass("has-success");
            $("#div_conpass").removeClass("has-error");
        }
    
}


function assigntotal(){
    console.log('done...');
    var schfee= $(".schfeex").val();
    var debtfee= $(".debtfeex").val();
    var summ = Number(schfee) + Number(debtfee);
    $('#ota').val(summ);

    var a= $("#ota").val();
    if (a === 'undefined' || a === 'NULL')
    {
        a = 0;
    }
    var b= $("#outa").val();
    if (b === 'undefined' || b === 'NULL')
    {
        b = 0;
    }
    var totalx = Number(a) + Number(b);
    $('#otta').val(totalx);

}
$('.schfeex , .debtfeex').keyup(assigntotal);

function assigntotal2(){
    console.log('done2...');
    var a= $(".busfeex").val();
    var b= $(".pullfeex").val();
    var c= $(".partyfeex").val();
    var summ = Number(a) + Number(b) + Number(c);
    $('#outa').val(summ);

    var a= $("#ota").val();
    if (a === 'undefined' || a === 'NULL')
    {
        a = 0;
    }
    var b= $("#outa").val();
    if (b === 'undefined' || b === 'NULL')
    {
        b = 0;
    }
    var totalx = Number(a) + Number(b);
    $('#otta').val(totalx);

}
$('.busfeex , .pullfeex , .partyfeex ').keyup(assigntotal2);


function assigntotalnew(){
    console.log('done...');
    var schfee= $(".schfeex2").val();
    var b= $(".pullfeex2").val();
    var c= $(".partyfeex2").val();
    var summ = Number(schfee) + Number(b) + Number(c);
    $('#nta').val(summ);

    var a= $("#nta").val();
    if (a === 'undefined' || a === 'NULL')
    {
        a = 0;
    }
    var b= $("#nuta").val();
    if (b === 'undefined' || b === 'NULL')
    {
        b = 0;
    }
    var totalx = Number(a) + Number(b);
    $('#ntta').val(totalx);

}
$('.schfeex2 , .pullfeex2 , .partyfeex2').keyup(assigntotalnew);

function assigntotalnew2(){
    console.log('done2...');
    var a= $(".busfeex2").val();
   
    var summ = Number(a);
    $('#nuta').val(summ);

    var a= $("#nta").val();
    if (a === 'undefined' || a === 'NULL')
    {
        a = 0;
    }
    var b= $("#nuta").val();
    if (b === 'undefined' || b === 'NULL')
    {
        b = 0;
    }
    var totalx = Number(a) + Number(b);
    $('#ntta').val(totalx);

}
$('.busfeex2').keyup(assigntotal2);


/****Settings***** */
//function to Change status of user
function getManageUser(id) {

    var name = $('#mya'+id).val();
    var email = $('#myc'+id).val();
    var id = $('#myid'+id).val();
    $('#modal_id').val(id);
    $('#modal_name').val(name);
    $('#modal_email').val(email);

    $('#manageuser_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');

}
//function to Add user
function getManageUserAdd() {
    $('#manageuseradd_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');
}
//function to delete user form table
function getManageUserDel(id) {
    var name = $('#mya'+id).val();
    var email = $('#myc'+id).val();
    var id = $('#myid'+id).val();
    $('#modalxx_id').val(id);
    $('#modalxx_name').val(name);
    $('#modalxx_email').val(email);

    $('#manageuser_delmodal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');
}
/****Settings***** */


/***********Income Modals */
function updateFee(id,text) {
    
    $('.myinnerlabel').html(text);
    $('#modal_id').val(id);
    $('#incomesetfee_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');

}

function updateFeeOther(id,text) {
    
    $('.myinnerlabel').html(text);
    $('#modalx_id').val(id);
    $('#incomesetotherfee_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');

}

function recfees_old(){

$('#formreefeenew').addClass('myhide');
$('#formreefeeold').removeClass('myhide');
}

function recfees_new(){

    $('#formreefeeold').addClass('myhide');
    $('#formreefeenew').removeClass('myhide');
}

$('#inc_stname').keyup(function(e){ 
          
    /*get the given typed values in the textbox*/
    var n = document.getElementById("inc_stname").value; 
   
    /*set a variable for displaying the result*/ 
          if(n === ''){ 
              $(".feesbelow").html('')
             }else{
                $(".feesbelow").hide();
                $(".feesbelow").fadeIn(900,0);
              $.ajax({
                   type: "POST",
                   url: "ajax.php",
                   dataType: "html",//expect html to be returned  
                   data:  {
                    feesreceive:n
                    },
                   success: function(data) { 
                      $(".feesbelow").show();
                      $(".feesbelow").html(data);
                      
                   },
                   error: function(xmlHttpRequest, textStatus, errorThrown)
                  {
                  alert('error ' + xmlHttpRequest);
                  }

               }); 

             } 
    });

    $('#inc_stname2').keyup(function(e){ 
          
        /*get the given typed values in the textbox*/
        var n = document.getElementById("inc_stname2").value; 
       
        /*set a variable for displaying the result*/ 
              if(n === ''){ 
                  $(".feesbelow").html('')
                 }else{
                    $(".feesbelow").hide();
                    $(".feesbelow").fadeIn(900,0);
                  $.ajax({
                       type: "POST",
                       url: "ajax.php",
                       dataType: "html",//expect html to be returned  
                       data:  {
                        feesreceive:n
                        },
                       success: function(data) { 
                          $(".feesbelow").show();
                          $(".feesbelow").html(data);
                          
                       },
                       error: function(xmlHttpRequest, textStatus, errorThrown)
                      {
                      alert('error ' + xmlHttpRequest);
                      }
    
                   }); 
    
                 } 
        });

$(document).on('click','.evaluateoutput',function(e){

    var cat = $(this).find('#evalcat').val();
    var stu = $(this).find('#evalstu').val();
    $.ajax({
        type: "POST",
        url: "ajax.php",
        dataType: "json",//expect html to be returned  
        data:  {
         setcategory:cat,setstudent:stu
         },
        success: function(data) { 
           console.log(data);
          var fee = JSON.parse(JSON.stringify(data));
         
          $('.tfees').html(fee.A);
          $('.oldfees').html(fee.B);
          $('.busfees').html(fee.C);
          $('.pullfees').html(fee.D);
          $('.partyfees').html(fee.E);
          
           
        },
        error: function(xmlHttpRequest, textStatus, errorThrown)
       {
       alert('error ' + xmlHttpRequest);
       }

    });

    var id = $(this).find('#evalid').val();
    var reg = $(this).find('#evalregno').val();
    $('#inc_stname').val(reg);
    $('#stu_cls').val(id);
    $('.feesbelow').html('');

    $('#inc_stname2').val(reg);
    $('#stu_cls2').val(id);
    $('.feesbelow').html('');

    

});  



//change mode of payment
$(document).on('change','.modepay',function(e){
    var mode = $(this).val();

    if (mode == 'bank') {

        $('#modebank').removeClass('myhide');
        $('#modebank').attr('required','required');
    } else {
        $('#modebank').addClass('myhide');
        $('#modebank').removeAttr('required');
    }

});