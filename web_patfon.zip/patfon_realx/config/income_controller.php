<?php session_start(); ?>
<?php include '../classes/connection.php' ; 

if (isset($_POST['income_feebut'])) {
    $cat =  intval($_POST['myid']) ;
    $amt =  $_POST['amt'] ;

    $id =  $_SESSION['patfonuser']['id'];
    $sk = $_SESSION['patfonuser']['school'];

   
    $query = ("UPDATE class_fees SET fee = $amt WHERE school = $sk and category = $cat ");
   
    
   if (mysqli_query($pdb, $query)){
    
    $_SESSION['success'] = 1;
    header("Location: ../income_set_fee.php ");
   }
   else{

    $_SESSION['failed'] = 1;
    header("Location: ../income_set_fee.php "); 
    }
    
}

if (isset($_POST['income_feeotherbut'])) {
    $cat =  intval($_POST['myid']) ;
    $amt =  $_POST['amt'] ;

    $id =  $_SESSION['patfonuser']['id'];
    $sk = $_SESSION['patfonuser']['school'];

   if ($cat == 1) {
    $query = ("UPDATE class_fees SET bus = $amt WHERE school = $sk ");
   }
   else if ($cat == 2) {
    $query = ("UPDATE class_fees SET pullover = $amt WHERE school = $sk ");
   }
   else if ($cat == 3) {
    $query = ("UPDATE class_fees SET party = $amt WHERE school = $sk ");
   }
    
   if (mysqli_query($pdb, $query)){
    
    $_SESSION['success_i'] = 1;
    header("Location: ../income_set_fee.php ");
   }
   else{

    $_SESSION['failed'] = 1;
    header("Location: ../income_set_fee.php "); 
    }
    
}