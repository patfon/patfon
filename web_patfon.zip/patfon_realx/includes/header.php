<!DOCTYPE html>

<head>
<title>Patfon Schools</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<?php 
 $documentroot = "patfon_realx";
 $GLOBALS['myurl'] = "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/";
 $GLOBALS['myterm'] = array('1'=>"1ST TERM", '2' => "2ND TERM", '3' => "3RD TERM");
?>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."css/bootstrap.min.css"; ?>" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href=<?php echo $myurl."datatables/jquery.dataTables.min.css"; ?> rel="stylesheet" />
<link href=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."css/style.css"; ?> rel='stylesheet' type='text/css' />
<link href=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."css/style-responsive.css"; ?> rel="stylesheet"/>
<!-- font CSS -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."css/font.css"; ?> type="text/css"/>
<link href=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."css/font-awesome.css"; ?> rel="stylesheet"> 
<link rel="stylesheet" href=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."css/morris.css"; ?> type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."css/monthly.css";?> >
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
		<!-- script to change list menu to active -->
		<script type="text/javascript">
		$(document).ready(function() {
if (window.location.href.indexOf("settings.php") > -1) {      
           $('#settings').addClass('active');
           $('#home').removeClass('active'); 
		   $('#student').removeClass('active'); 		   
}
});

$(document).ready(function() {
if (window.location.href.indexOf("student.php") > -1) {           
		   $('#student').addClass('active');
           $('#home').removeClass('active');          
}
});

$(document).ready(function() {
if (window.location.href.indexOf("income.php") > -1) {           
		   $('#income').addClass('active');
           $('#home').removeClass('active');          
}
});

$(document).ready(function() {
if (window.location.href.indexOf("expenditure.php") > -1) {           
		   $('#expenditure').addClass('active');
           $('#home').removeClass('active');          
}
});

	</script>
		<!-- end of script to change list menu to active -->
		</script>
		<!-- end of script to change list menu to active -->
	
<script src=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."js/raphael-min.js"; ?>></script>
<script src=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."js/morris.js"; ?>></script>
</head>
<body>

<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
    <a href="index.php" class="logo">
       PATFON
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->

<div class="top-nav clearfix">

<ul class="nav pull-left top-menu " style="margin-left: 30px;">
    <?php if (isset($_SESSION['cur-page'])) { ?>
    <li class=" panel-title ">
    <h3 style="font-weight:bold;"><?php echo $_SESSION['cur-page']; ?></h3>
    </li>
    <?php } ?>
</ul>

    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <!-- user login dropdown start-->
        <?php $term ?>
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src=<?php echo "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/"."images/2.png"; ?>>
                <span class="username">Session: <?php echo $_SESSION['patfonuser']['ses']; ?></span><br>&nbsp;&nbsp;&nbsp;&nbsp;
                <span class="username">Term: <?php echo $myterm[$_SESSION['patfonuser']['term']]; ?></span>

                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
                <li><a href="#"><i class=" fa fa-suitcase"></i>Profile</a></li>
                <li><a href=<?php echo $myurl."settings.php"; ?>><i class="fa fa-cog"></i> Settings</a></li>
                <li><a href=<?php echo $myurl."logout.php"; ?>><i class="fa fa-key"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a id="home" class="active" href=<?php echo $myurl."index.php"; ?>>
                        <i class="fa fa-home"></i>
                        <span><strong>HOME</strong></span>
                    </a>
                </li>
                <li>
                    <a id="student" href=<?php echo $myurl."student.php"; ?>>
                        <i class="fa fa-group"></i>
                        <span><strong>STUDENT</strong></span>
                    </a>
                </li>
				
                    <li class="sub-menu">
                    <a href="javascript:;">
                        <i id="finance" class="fa fa-book"></i>
                        <span><strong>FINANCE</strong></span>
                    </a>
                    <ul class="sub">
						<li>
                    <a id="income" href=<?php echo $myurl."income.php"; ?>>
                        <i class="fa fa-download"></i>
                        <span><strong>INCOME</strong></span>
                    </a>
                </li>
						<li>
                    <a id="expenditure" href=<?php echo $myurl."expenditure.php"; ?>>
                        <i class="fa fa-upload"></i>
                        <span><strong>EXPENDITURE</strong></span>
                    </a>
                </li>
                    </ul>
                </li>
               
				
                <li>
                    <a id="settings" href=<?php echo $myurl."settings.php"; ?>>
                        <i class="fa fa-gears"></i>
                        <span><strong>SETTINGS</strong></span>
                    </a>
                </li>

               
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>