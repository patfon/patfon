<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php ///get the keywords from the evalute textbox as you try to search
include('functions/index.php');
if (isset($_POST['feesreceive'])) {
 $arr = array();   
 $keywords = mysqli_real_escape_string($pdb,$_POST['feesreceive']);
 $sql = "SELECT * FROM student WHERE regno LIKE '%".$keywords."%' ";
 $result = mysqli_query($pdb,$sql) or die(mysqli_error($pdb));
 if (mysqli_num_rows($result) > 0) {
 while ($rows = mysqli_fetch_array ($result, MYSQLI_ASSOC)) {
 echo '<div id="" class="evaluateoutput"> 
         <input id="evalid" type="hidden" value="'.getstudentclass($pdb,$rows['id']).'" >
         <input id="evalstu" type="hidden" value="'.$rows['id'].'" >
         <input id="evalcat" type="hidden" value="'.getstudentclasscat($pdb,getstudentclassonly($pdb,$rows['id'],$rows['school']),$rows['school']).'" >
         <input id="evalregno" type="hidden" value="'.$rows['regno'].'" >
         <div class="evalname"><strong class="evaltext">'.$rows['fname']."  ".$rows['lname']."from ".getstudentclass($pdb,$rows['id']). '</strong></div>
       
        </div>';
 }
 }
 else{
 echo '<div id="" class="evaluateoutput form-group"> 
         <div class="name"><strong>'.'Nothing returned'.'</strong></div>&nbsp;&nbsp;
        </div>';
 }
 
}

if (isset($_POST['setcategory']) && isset($_POST['setstudent'])) {

    $mycat = $_POST['setcategory'];
    $mystu= $_POST['setstudent'];
    $mysch = $_SESSION['patfonuser']['school'];

   $clsfee =  getclassfee($pdb,$mycat,$mysch); 
   $studebt =  getstudentdebt($pdb,$mystu,$mysch);
   if ( $studebt > 0 ) {

        $_SESSION['patfonuser']['feedebt'] =  $studebt ;

   }
   else{
           unset($_SESSION['patfonuser']['feedebt']);
   }
   $othfee =  getclassfeeother($pdb,1,$mysch);
   $othfee2 =  getclassfeeother($pdb,2,$mysch);
   $othfee3 =  getclassfeeother($pdb,3,$mysch);
    $myarray = array('A'=>$clsfee, 'B'=>$studebt, 'C'=>$othfee, 'D'=>$othfee2, 'E'=>$othfee3);    
    echo json_encode($myarray);


}