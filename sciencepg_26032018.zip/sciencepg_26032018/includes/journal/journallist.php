<div class="middle_right" id="middle_right">
            <div class="right_nav">
                <a href="<?php echo $myurl."index.php"; ?>">Home</a> / Journals
            </div>

            <?php if (!isset($_GET['catid'])) { ?>

            <?php $mysubjects = getsubjects($pdb); 
                foreach ($mysubjects as $sub){
             ?>
            <div class="journalsandcate_list_item">
                <div class="category_name"><?php echo getsubjectname($pdb,$sub['id']); ?></div>
                <div class="journalsandcate_list_fw">
                   
                   
                                <?php   $myjournals = getjournals($pdb,$sub['id']);
                                        foreach ($myjournals as $myj){
                                        ?>
                    <div class="journalsandcate_list_left">
                        
                            
                                      
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="<?php echo $myurl."pages/journal/journalbycat.php?catid2=".$myj['id']; ?>">
                                                
                                                <?php echo $myj['_name']; ?>
	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
                                        
	                            
                                                        
                            
           </div> <?php } ?> </div> </div>
           <div class="clear"></div>    
           <?php } } else if (isset($_GET['catid'])) { ?>

          
            <div class="journalsandcate_list_item">
                <div class="category_name"><?php echo getsubjectname($pdb,$_GET['catid']); ?></div>
                <div class="journalsandcate_list_fw">
                   
                   
                                <?php   $myjournals = getjournals($pdb,$_GET['catid']);
                                        foreach ($myjournals as $myj){
                                        ?>
                    <div class="journalsandcate_list_left">
                        
                            
                                      
	                                <div class="journalsandcate_item">
	                                    
	                                    
	                                        
	                                        <a target="_blank" href="<?php echo $myurl."pages/journal/journalbycat.php?catid2=".$myj['id']; ?>">
                                                
                                                <?php echo $myj['_name']; ?>
	                                      
	                                        </a>
	                                        <div class="clear"></div>
	                                    
	                                </div>
                                        
	                            
                                                        
                            
           </div> <?php } ?> </div> </div>
           <div class="clear"></div>  
           <?php }  ?>
                       
	                            
	                               

            
                <div class="part_bg"></div>
            
               
            
        </div>