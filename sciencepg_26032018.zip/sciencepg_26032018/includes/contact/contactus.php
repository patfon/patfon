<div class="middle">
            <div class="middle_left" id="middle_left" style="height: 800px;">
                
            </div>  
            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="index.php">Home</a>&nbsp;/&nbsp;<a href="#">Services</a>&nbsp;/&nbsp;Contact Us</div>
                <div id="vol">
                    <div class="economics">Contact Us</div>
                    <div class="line2"></div>
                    <div class="middle_right_container">
                    <?php $badcode = mt_rand(10000,19999); 
                    $_SESSION['concode'] = $badcode;
                    ?>
                      <form action="#" method="post" id="form1" name="form1">
                        <div class="middle_right_science" style="height: 185px;">
                            <div class="middle_right_science1">SciencePG Support Center Email Addresses</div>
                            <div class="middle_right_science2">Journal:  <a href="mailto:journal@sciencepublishinggroup.com" target="_blank">journal@sciencepublishinggroup.com</a>
                            <br>
                            <br></div>
                        </div>
                        <div class="middle_right_you">You can also use the form below to submit your questions/suggestions:</div>
                        <div class="middle_right_line"></div>
                        <div class="middle_right_item">Items marked with ( * ) are necessary
                        </div>
                        <div class="clear"></div>
                        <div class="middle_right_name">Full Name:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_inp"><input type="text" required="required" class="middle_inp" id="firstName" name="fname"></div>
                        <div class="clear"></div>
                        <div class="middle_right_name">E-mail:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_inp"><input type="text"  required="required" class="middle_inp" id="email" name="email"></div>
                        <div class="clear"></div>
                        <div class="middle_right_name">Subject:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_inp">
                             <select class="middle_select"  required="required" name="subject" id="subject">
                                <option value="Journal Information">Journal Information</option>
								<option value="Website Errors">Website Errors</option>
								<option value="Others">Others</option>
                            </select></div>
                        <div class="clear"></div>
                        <div class="middle_right_name">Message:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_textarea">
                        <textarea id="message" name="message"  required="required" style="border-style:none;resize:none;width:474px;height:104px;overflow-y:hidden;padding-left:10px;border:1px solid #cccccc;"></textarea></div>
                        <div class="clear"></div>
                        <div class="middle_right_name">Type the Code Below:<span style="color:#B60505;">*</span></div>
                        <div class="middle_right_inp2"><input type="text"  required="required" class="middle_inp2" id="verCode" name="code"> &nbsp; &nbsp; &nbsp; &nbsp;
                        <?php echo $badcode; ?>
                        </div>
                        
                        <div class="middle_right_name"> <input type="submit" name="contact" value='Submit'/></div>
                       

                        </form>
                    </div>

                    <div class="middle_right_container2">
                        <div style="font-size:20px;color:#33333;font-weight:bold;line-height:22px;">Contact Information</div>
                        <div style="font-size:14px;color:#333333;line-height:20px;margin-top:10px;"><b>Address:</b><br>Calabar, Nigeria
</div>
                        <div style="border-top:1px solid #E0DEDE;width:200px;height:0;margin-top:5px;"></div>
                        <div style="font-size:14px;color:#333333;line-height:20px;margin-top:10px;"><b>Telephone:</b><br>(234)903-688-8121</div>
                        <div style="border-top:1px solid #E0DEDE;width:200px;height:0;margin-top:5px;"></div>
                        <div style="font-size:14px;color:#333333;line-height:20px;margin-top:10px;"><b>Skype ID:</b><br>nigeriapg</div>
                        <div style="border-top:1px solid #E0DEDE;width:200px;height:0;margin-top:5px;"></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="clear"></div>
        </div>