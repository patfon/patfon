<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/publication/journal.php"; ?>" style=" background-color:#FFFFFF;color:#111111;"><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/join/editorinchief.php"; ?>"><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/resources/openaccess.php"; ?>" ><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">

            <div class="middle_left" id="middle_left" style="height: 1059px;">
                <div class="middle_left_title">Publication Services</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/publication/journal.php'; ?>" style="background:#2F5BA6;color:#FFFFFF;">Journals</a>
                  
                
                </div>
            </div>

            <div class="middle_right" id="middle_right">
                <div class="middle_right_title">
                <a href="#">Home</a>&nbsp;/&nbsp;<a href="#">Services</a>&nbsp;/&nbsp;<a href="#">Publication Services</a>&nbsp;/&nbsp;Journals</div>

                <div id="vol">
                    <div class="economics">Journals</div>
                    <div class="line2"></div>

                    <div class="middle_right_container" style="width:918px;">
<div class="middle_right_content_line">                  
  SciencePG journals contain 15 scientific fields. Each field is composed of its corresponding journals. Publishing in SciencePG journal starts with finding the right journal for your paper. You can find journals in different ways but here are some suggestions:
<br><br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Read the aims and scope of the each journal.
<br><img src=""<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Check if the journal is invitation-only as newly launched journal will only accept articles after inviting the author.
<br><img src=""<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Submit your article to only one journal at a time.
<br><img src=""<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Check the journal performance for the review and publication timelines.
<br><img src=""<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Read Guide for Authors
</div>


<div class="middle_right_title_line">Guide for Authors:</div>

<div class="middle_right_content_line">
 This guide describes how to prepare an article for submission and how to submit the article to SciencePG. You can read this in full if you have not previously submitted an article to SciencePG. Before submission, you should familiarize yourself with SciencePG’s manuscript template and content by reading the journal, either in print or online, particularly if you have not submitted to the journal recently.
</div>

<div class="middle_right_title_line">Online Submission System</div>
<div class="middle_right_content_line">
Publishing your research article in a SciencePG journal is simple and efficient. SciencePG journals use online submission system: <a href="/login" target="_blank" style="color: #2F5BA6;">http://www.sciencepublishinggroup.com/login</a>
</div>
<div class="middle_right_title_line">Manuscript Template</div>
<div class="middle_right_content_line">
Please&nbsp; <a href="#" style="color:#2F5BA6;">click here</a>&nbsp;to download the template to format your manuscript.
</div>

<div class="middle_right_title_line">Manuscript Checklist</div>
<div class="middle_right_content_line">
Please&nbsp;<a href="#" style="color:#2F5BA6;">click here</a>&nbsp;to download the Checklist to examine your manuscript.
</div>
<div class="middle_right_title_line">Manuscript Preparation</div>
<div class="middle_right_content_line">
Manuscript length should be 6 to 18 pages. SciencePG can exceptionally accept shorter or longer manuscripts, provided that the scientific content is of high value. No additional page charges are required if a manuscript is substantially longer than 17 pages.
All submitted manuscripts must include the following items:
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Title
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;List of authors, their affiliations and email addresses
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Abstract
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Keywords
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Introduction
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Main body
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Results and discussion
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Conclusions
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Acknowledgments (optional)
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;References
</div>

<div class="middle_right_title_line">Word Processing Formats</div>
<div class="middle_right_content_line">
Before submission, please ensure that your articles are in the form of Microsoft word 2000/2003(doc) or Microsoft word 2007/2010(docx). These two forms of the articles are acceptable for all of SciencePG journals in order to typeset the articles into SciencePG’s style.
</div>

<div class="middle_right_title_line">Publication Presentation</div>
<div class="middle_right_content_line">
After publishing in SciencePG, your article will be presented in the form of PDF and HTML. You can pay attention to SciencePG website to check the Online Version of your article.
</div>
                      
                      
                      
                      
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>


    
<?php include '../../../includes/general/footer.php'; ?>