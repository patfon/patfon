<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>"><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/join/joineditorinchief.php"; ?>" style=" background-color:#FFFFFF;color:#111111;"><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/resources/openaccess.php"; ?>" ><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
            <div class="middle_left" id="middle_left" style="height: 652px;">
                <div class="middle_left_title">Join Us</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/join/editorinchief.php'; ?>">Join as an Editor-in-Chief</a>
                    <a href="<?php echo $myurl.'pages/info/join/editor.php'; ?>" >Join as an Editorial Member</a>
                    <a href="<?php echo $myurl.'pages/info/join/reviewer.php'; ?>">Become a Reviewer</a>
                    <a href="<?php echo $myurl.'pages/info/join/qualification.php'; ?>" style="background:#2F5BA6;color:#FFFFFF;">Qualification &amp; Requirement</a>
                    <a href="<?php echo $myurl.'pages/info/join/benefits.php'; ?>">Benefits &amp; Responsibilities</a>
                </div>
            </div>
            
            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="/home/index">Home</a>&nbsp;/&nbsp;<a href="/info/journalsservice">Services</a>&nbsp;/&nbsp;<a href="/info/joinasaneditorinchief">Join Us</a>&nbsp;/&nbsp;Qualification</div>
               
                <div id="vol">
                    <div class="economics">Qualifications</div>
                    <div class="line2"></div>

                    <div class="middle_right_container" style="width:918px;">
<div class="middle_right_title_line">1. Requirements for a potential reviewer</div>
<div class="middle_right_content_line"> 
<img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant is requested to possess at least 2-year research or working experience in the related areas of the applied journal.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant with doctor degree or above will be given priority.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant should have no less than 2 publications in the same topic area of the applied journal.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant with relevant working experience is preferred.  
</div>
<div class="middle_right_title_line">2. Requirements for a potential editorial member</div>
<div class="middle_right_content_line"> 
<img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant is requested to possess at least 4-year research or working experience in the related areas of the applied journal.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant with professor title or above will be given priority.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant should have no less than 5 publications in the same topic area of the applied journal.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant with relevant working experience is preferred.
</div>
<div class="middle_right_title_line">3. Requirements for a potential Editor-in-Chief</div>
<div class="middle_right_content_line"> 
<img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant is requested to possess at least 5-year research or working experience in the related areas of the applied journal.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant with professor title or above will be given priority.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant should have no less than 10 publications in the same topic area of the applied journal.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The applicant with relevant working experience is preferred.
</div>



                      
                      
                      
                    </div>

                </div>
            </div>
            <div class="clear"></div>
        </div>
    
<?php include '../../../includes/general/footer.php'; ?>