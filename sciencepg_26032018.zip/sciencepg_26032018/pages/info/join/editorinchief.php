<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>" ><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/join/joineditorinchief.php"; ?>" style=" background-color:#FFFFFF;color:#111111;"><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/resources/openaccess.php"; ?>" ><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
            <div class="middle_left" id="middle_left" style="height: 652px;">
                <div class="middle_left_title">Join Us</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/join/editorinchief.php'; ?>" style="background:#2F5BA6;color:#FFFFFF;">Join as an Editor-in-Chief</a>
                    <a href="<?php echo $myurl.'pages/info/join/editor.php'; ?>">Join as an Editorial Member</a>
                    <a href="<?php echo $myurl.'pages/info/join/reviewer.php'; ?>">Become a Reviewer</a>
                    <a href="<?php echo $myurl.'pages/info/join/qualification.php'; ?>">Qualification &amp; Requirement</a>
                    <a href="<?php echo $myurl.'pages/info/join/benefits.php'; ?>">Benefits &amp; Responsibilities</a>
                </div>
            </div>
            
            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="/home/index">Home</a>&nbsp;/&nbsp;<a href="/info/journalsservice">Services</a>&nbsp;/&nbsp;<a href="/info/joinasaneditorinchief">Join Us</a>&nbsp;/&nbsp;Join as an Editor-in-Chief</div>
               
                <div id="vol">
                    <div class="economics">Join as an Editor-in-Chief</div>
                    <div class="line2"></div>

                    <div class="middle_right_container" style="width:918px;">


<div class="middle_right_title_line" style="margin-top: 10px;">Responsibilities of the Editor-in-Chief:</div><div class="middle_right_content_line">
<img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief should organize a review team to do the review work if there are manuscripts submitted to the journal;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief should post new hot topics about his/her proposed journal and invite authors to submit manuscripts;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief should make decisions on the acceptance or rejection of manuscripts;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief should cross-check the manuscripts and ensure their quality.
</div>
<div class="middle_right_title_line">Benefits of the Editor-in-Chief:</div>
<div class="middle_right_content_line">   
<img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief could get the latest information of SciencePG;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief could cooperate with a group of experienced researchers from all over the world;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief could get a certificate provided by SciencePG;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief could have his/her name and personal webpage displayed on the journal website.
</div>

<div class="middle_right_title_line">Agreement:</div>
<div class="middle_right_content_line">   
The acceptance of following terms and conditions confirms the appointment as an Editor-in-Chief of journals of Science Publishing Group;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The appointment of the Editor-in-Chief is initially for one year;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief is expected to observe carefully general policies, code of ethics and practices of the Science Publishing Group Publications which may change from time to time based on expansion plans for the improvement in quality of the journal system;
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The Editor-in-Chief agrees to display the name and photograph on the website of the site and journal cover.
</div>

<div class="middle_right_title_line">Termination:</div>
<div class="middle_right_content_line">   
It is expected that the Editor-in-Chief will complete the term as stated. This agreement may be terminated at any time based on following conditions.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Lack of mutual understanding on common aspects as per the policies of Science Publishing Group.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Repetitive unsatisfactory performance of the assigned work.
</div>

<div class="middle_right_content_line">  
If you have any question about Editor-in-Chief, please contact: <a href="mailto:EditorialMember@sciencepublishinggroup.com" target="_blank">EditorialMember@sciencepublishinggroup.com</a>
</div>                      
                      
                      
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    
<?php include '../../../includes/general/footer.php'; ?>