<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>" ><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/join/joineditorinchief.php"; ?>" style=" background-color:#FFFFFF;color:#111111;"><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/resources/openaccess.php"; ?>" ><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
            <div class="middle_left" id="middle_left" style="height: 652px;">
                <div class="middle_left_title">Join Us</div>
                <div class="middle_left_link">
                    <a href="<?php echo $myurl.'pages/info/join/editorinchief.php'; ?>">Join as an Editor-in-Chief</a>
                    <a href="<?php echo $myurl.'pages/info/join/editor.php'; ?>" >Join as an Editorial Member</a>
                    <a href="<?php echo $myurl.'pages/info/join/reviewer.php'; ?>" style="background:#2F5BA6;color:#FFFFFF;">Become a Reviewer</a>
                    <a href="<?php echo $myurl.'pages/info/join/qualification.php'; ?>">Qualification &amp; Requirement</a>
                    <a href="<?php echo $myurl.'pages/info/join/benefits.php'; ?>">Benefits &amp; Responsibilities</a>
                </div>
            </div>
            
            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="/home/index">Home</a>&nbsp;/&nbsp;<a href="/info/journalsservice">Services</a>&nbsp;/&nbsp;<a href="/info/joinasaneditorinchief">Join Us</a>&nbsp;/&nbsp;Join as a Reviewer</div>
               
                <div id="vol">
                    <div class="economics">Become A Reviewer</div>
                    <div class="line2"></div>

                    <div class="middle_right_container" style="width:918px;">
<div class="middle_right_content_line" style="line-height: 26px;">                  
Manuscript reviewers are vital to the publication process, and as a reviewer you will gain valuable experience in scientific publishing. We invite you to become a reviewer of our journals.
Some benefits of being a reviewer:
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;Being a reviewer opens doors to incredible opportunities. Review services will enhance your knowledge of professional standards; and quickly earn the respect of your peers.
<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The other potential benefit of being a reviewer is that you will be preferred considered to be an editorial board member.

<br><img src="<?php echo $myurl.'images/black_dot.png' ?>">&nbsp;&nbsp;&nbsp;&nbsp;The reviewers who need financial support could enjoy 20% discount to publish their articles in SciencePG.
</div>
<div class="middle_right_content_line"> 
In order to provide a good review, a thoughtful and well-balanced report with suggested improvements for our authors, reviewers must be prepared to invest the necessary time to evaluate the manuscript thoroughly.
</div>
<div class="middle_right_content_line" style="line-height: 26px;"> 

If you are interested in being a reviewer for the journal, please join us via SciencePG online system:
<br>Here are the procedures:
<br>Step 1: If you didn’t register before, please create an account first:
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.sciencepublishinggroup.com/common/signUp_loadRegister" target="_blank" style="color: #2F5BA6;">http://www.sciencepublishinggroup.com/common/signUp_loadRegister</a>

<br>Step 2: Login with your username and password.
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $myurl.'login.php'; ?>" target="_blank" style="color: #2F5BA6;">http://www.sciencepublishinggroup.com/login</a>

<br>Step 3: Click “Reviewer” on the left menu under the button “Join Us”.
<br>Step 4: Upload your CV and complete the necessary information and submit.
<br>Step 5: Perfect your “Personal Profile” on the left menu.

</div>
<div class="middle_right_content_line"> 
Any questions, please contact&nbsp;<a href="mailto:Reviewer@sciencepublishinggroup.com">Reviewer@sciencepublishinggroup.com</a>
</div>


</div>

                </div>
            </div>
            <div class="clear"></div>
        </div> </div>
    
<?php include '../../../includes/general/footer.php'; ?>