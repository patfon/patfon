<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>


<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo 'Services'; ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/info/publication/journal.php"; ?>" ><div class="tit">Publication Services</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/info/publication/joineditorinchief.php"; ?>" ><span class="tit">Join Us</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/info/publication/openaccess.php"; ?>" ><div class="tit" >Resources</div></a>
       

    </div>
</div>

<div class="middle">
            <div class="middle_left" id="middle_left">
               
            </div>

            <div class="middle_right" id="middle_right">
                <div class="middle_right_title"><a href="#">Home</a>&nbsp;/&nbsp;<a href="#">Services</a>&nbsp;/&nbsp;Terms &amp; Conditions</div>

                <div id="vol">
                    <div class="economics">Terms and Conditions</div>
                    <div class="line2"></div>

                    <div class="middle_right_container">
                        <div class="middle_right_content">
                            1. These terms and conditions ("the Terms") apply to this Science Publishing Group website. By using this website you agree to be bound by the Terms which form a binding contract between you and Science Publishing Group ("SciencePG"), a company registered in USA, without prejudice to any rights you or SciencePG may otherwise have at law. If you do not agree with any Terms contained herein you must immediately cease using the website.
                        </div>

                        <div class="middle_right_content">
                            2. Certain parts of this Web Site may be subject to registration and additional terms and conditions which will be made available for you to read at the time of registration.
                        </div>

                        <div class="middle_right_content">
                            3. Unless otherwise indicated, this website and its contents are the property of SciencePG. The copyright in the material contained on this website belongs to SciencePG or its licensors. The trademarks appearing on this website are protected by the laws of USA and international trademark laws.
                        </div>

                        <div class="middle_right_content">
                            4. All articles published by SciencePG on this website marked "Open Access" are licensed by the respective authors of such articles for use and distribution by SciencePG subject to citation of the original source in accordance with the Open Access license.
                        </div>

                        <div class="middle_right_content">
                            5. You confirm that you have read and accept our Privacy Policy.
                        </div>

                        <div class="middle_right_content">
                            6. All content contained on or accessed from the Site is owned by SciencePG or its licensors and is protected by copyright, trademark and other intellectual property and unfair competition laws.
                        </div>

                        <div class="middle_right_content">
                            7. We shall have the right, but not the obligation, to monitor Submissions to determine compliance with these Terms and Conditions and any operating rules we establish and to satisfy any law, regulation or authorized government request. We shall have the right in our sole discretion to edit, refuse to post, or remove any Submission.
                        </div>

                        <div class="middle_right_content">
                            8. SciencePG reserves the right to change, modify, add or remove portions of these Terms as it sees fit, without notice. You agree to be bound by such amendments from the time at which they are displayed on the website.
                        </div>

                        <div class="middle_right_content">
                            9. We are not liable or responsible for the third party content on the Site. Where the Site and/or applications contain links to other sites and resources, which are provided by third parties, these links and resources are provided for your information only and you access them at your own risk.
                        </div>

                        <div class="middle_right_content">
                            10. SciencePG is not responsible for the content of any advertising material or any errors or inaccuracy in any advertising or sponsorship. SciencePG partners with third-party advertising companies to serve ads and/or collect certain information when you visit the website.
                        </div>

                        <div class="middle_right_content">
                            11. These terms shall be governed by and construed in accordance with USA Law.
                        </div>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    
<?php include '../../../includes/general/footer.php'; ?>