<?php include '../../includes/general/header.php'; ?>
<?php include '../../classes/connection.php'; ?>
<?php include '../../functions/index.php'; ?>

    <?php include '../../includes/general/topmenu.php'; ?>

<?php if (isset($_GET['catid2'])) {  
    $mydata = getjournalbyID($pdb,$_GET['catid2']);
    $myarticles = getarticles($pdb,$_GET['catid2']);
    $myeditors = geteditors($pdb,$_GET['catid2']);
    $myreviewers = getreviewers($pdb,$_GET['catid2']);
    ?>
<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo getjournalname($pdb,$_GET['catid2']); ?></a>
    </div>
    <div class="propose">
    <a href="<?php echo $myurl."pages/journal/journalbycat.php?catid2=".$_GET['catid2']; ?>" style="background-color:#FFFFFF;color:#111111;"><div class="tit">Home</div></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/archive.php?catid3=".$_GET['catid2']; ?>"><span class="tit">Archive</span></a>
    <div class="separater">|</div>
    
    <a href="<?php echo $myurl."pages/journal/pages/editorial.php?catid4=".$_GET['catid2']; ?>"><span class="tit" style="">Editorial Board</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/reviewers.php?catid5=".$_GET['catid2']; ?>"><span class="tit" style="">Reviewers</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/guidelines.php?catid6=".$_GET['catid2']; ?>"><span class="tit">Guidelines</span></a>
    <div class="separater">|</div>
    
    <a href="<?php echo $myurl."pages/journal/pages/apc.php?catid7=".$_GET['catid2']; ?>"><span class="tit" >Article Processing Charges</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/ethics.php?catid8=".$_GET['catid2']; ?>"><span class="tit">Publication Ethics</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/copyright.php?catid9=".$_GET['catid2']; ?>"><span class="tit">Copyright</span></a>
    <div class="separater">|</div>

    <a href="<?php echo $myurl."pages/journal/pages/faq.php?catid10=".$_GET['catid2']; ?>"><span class="tit">FAQ</span></a>
</div>
</div>

<div class="middle">
<div class="middle_title">
<a href="" class="title_link">Home</a>  /  <a href="<?php echo $myurl.'pages/journal/journallist.php'; ?>" class="title_link">Journals</a>  /  <a href="#" class="title_link"> <?php echo getsubjectnameInJournal($pdb,$_GET['catid2']); ?></a>  /  <?php echo getjournalname($pdb,$_GET['catid2']); ?>
</div>


<div class="middle_part2">

<div class="middle_part2_l">
<div class="img3">
<img src="<?php echo $myurl.$mydata[0]['_image']; ?>"></div>
</div>

<div class="part2_vol">

<div class="part2_t1">
    <a href="#" class="vol_issue_info"> <?php echo getcurrentJournal($pdb,$_GET['catid2']) ?></a>
    <div class="clear"></div>
</div>


<div class="part2_t2">

    <div class="issn_print">
        ISSN Print: <?php echo $mydata[0]['_isbn_p']; ?>
    </div>

<div class="journal_frequency">
    
        
            
                Frequency: Bimonthly
            
</div>
<div class="clear"></div>
</div>

<div class="part2_t3">

    <div class="issn_online">
        ISSN Online: <?php echo $mydata[0]['_isbn_o']; ?>
    </div>

<div class="clear"></div>
</div>



<div class="lat">
<div class="lat_tit">

    <a href="javascript:choiceModel(1);"><div class="lat_tit1" id="lat_tit1" style="background-color:#FFFFFF;color:#333333;">Latest Articles</div></a>
    <a href="javascript:choiceModel(2);"><div class="lat_tit2" id="lat_tit2">About This Journal</div></a>


<div class="clear"></div>
</div>

<div style="width:100%;height:auto;display:block;" id="latestArticles">


    <?php foreach($myarticles as $art) { ?>
    <div class="imp_img"><img src="<?php echo $myurl."images/articlelist_icon.jpg" ?>"></div>
    <div class="imp">
       
        <div class="imp_1">
        <a href="<?php echo ""; ?>">
        <?php echo $art['_title']; ?>
     </a> 
        </div>
       
       
       
        <div class="imp_2">
            <?php echo getarticleauthors($pdb,$art['_articleid']); ?>
            
        </div>
        <div class="imp_3">Pages: <?php echo $art['_pages']; ?>&nbsp;&nbsp;&nbsp;Published Online: <?php echo date('F d, Y',strtotime($art['_pubdate'])); ?></div>
       
        <div class="imp_4"><a  href="<?php echo $myurl.'admin/'.$art['_file']; ?>"> DOC (<?php echo $art['_filesize'];  ?>) </a>&nbsp;&nbsp;&nbsp;&nbsp;</div>
        
        
        
    </div>
    <div class="clear"></div>
    <?php } ?>
   

</div>


<div style="width:100%;height:auto;display:none;" id="aboutThisJournal">


<div class="journal_intro_2">

<?php echo getjournalabout($pdb,$_GET['catid2']); ?>

</div>

   

</div>
</div>



</div>

<div class="clear"></div>
</div>


<div class="middle_part3">

<a href="<?php echo $myurl."login.php"; ?>" target="_blank"><img style="margin-top: 0px;" src="<?php echo $myurl.'images/journals_btn_r3_c1.jpg';  ?>" ></a>


<a href="<?php echo $myurl."login.php"; ?>" target="_blank"> <img src="<?php echo $myurl.'images/journals_btn_r1_c1.jpg'; ?>"  style="margin-top: 15px;" ></a>


<div class="clear"></div>


<div class="edito">
<div class="part3_rel3">Editorial Board</div>

<div class="clear"></div>

<div class="adnan">


    
    <div style="width:100%;height:auto;">
    
        <?php foreach ($myeditors as $ed){ ?>
        <div class="adnan_img">
         
                <a href="#" target="_blank">
        <img src="<?php 
        $editorpic = getuserpic($pdb,$ed['_userid']);
        if ($editorpic !== "" || $editorpic !== NULL || $editorpic !== 'NULL' ){
        echo $myurl.$editorpic; }
        else { 
        echo $myurl.'images/default.jpg';     
        }
        ?>" style="width:75px;height:102px;">
        </a>
        
        
        </div>
        
        <div class="adnan_text">
            
                <a href="#" target="_blank"><?php echo getusername($pdb,$ed['_userid']); ?></a>
            
            
           <?php echo getuseruni($pdb,$ed['_userid']); ?>
        </div>
        <div class="clear"></div>
        <?php } ?>
    </div>

    
    


</div>

<div class="part3_rel2">Peer Reviewers</div>

<div class="clear"></div>

<div class="adnan">


    
        <div style="width:100%;height:auto;">
    
    
        <?php foreach ($myreviewers as $ed){ ?>
            <div class="adnan_img">
             
                    <a href="#" target="_blank">
            <img src="<?php 
            $editorpic = getuserpic($pdb,$ed['_userid']);
            if ($editorpic !== "" || $editorpic !== NULL || $editorpic !== 'NULL' ){
                echo $myurl.$editorpic; }
                else { 
                echo $myurl.'images/default.jpg';     
                } ?>" style="width:75px;height:102px;">
            </a>
            
            
            </div>
            
            <div class="adnan_text">
                
                    <a href="#" target="_blank"><?php echo getusername($pdb,$ed['_userid']); ?></a>
                
                
               <?php echo getuseruni($pdb,$ed['_userid']); ?>
            </div>
            <div class="clear"></div>
            <?php } ?>
    </div>

    
    
</div>
</div>
</div>

<div class="clear"></div>
</div>
<?php } ?>
    
<?php include '../../includes/general/footer.php'; ?>