<?php include '../../../includes/general/header.php'; ?>
<?php include '../../../classes/connection.php'; ?>
<?php include '../../../functions/index.php'; ?>

    <?php include '../../../includes/general/topmenu.php'; ?>

<?php if (isset($_GET['catid10'])) { 
    $myfaq = getfaq($pdb,$_GET['catid10']);
    ?>
<div class="special_issue"><a>
    </a>
    <div class="issue_title"><a></a>
    <a href="javascript:void(0);"><?php echo getjournalname($pdb,$_GET['catid10']); ?></a>
    </div>
    <div class="propose">
        <a href="<?php echo $myurl."pages/journal/journalbycat.php?catid2=".$_GET['catid10']; ?>" style=""><div class="tit">Home</div></a>
        <div class="separater">|</div>
    
        <a  href="<?php echo $myurl."pages/journal/pages/archive.php?catid3=".$_GET['catid10']; ?>"><span class="tit">Archive</span></a>
        <div class="separater">|</div>
        
        <a href="<?php echo $myurl."pages/journal/pages/editorial.php?catid4=".$_GET['catid10']; ?>"  ><div class="tit" >Editorial Board</div></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/reviewers.php?catid5=".$_GET['catid10']; ?>"><span class="tit" style="">Reviewers</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/guidelines.php?catid6=".$_GET['catid10']; ?>" ><span class="tit">Guidelines</span></a>
        <div class="separater">|</div>
        
        <a  href="<?php echo $myurl."pages/journal/pages/apc.php?catid7=".$_GET['catid10']; ?>"><span class="tit" >Article Processing Charges</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/ethics.php?catid8=".$_GET['catid10']; ?>" ><span class="tit">Publication Ethics</span></a>
        <div class="separater">|</div>

        <a  href="<?php echo $myurl."pages/journal/pages/copyright.php?catid9=".$_GET['catid10']; ?>"><span class="tit">Copyright</span></a>
        <div class="separater">|</div>

        <a href="<?php echo $myurl."pages/journal/pages/faq.php?catid10=".$_GET['catid10']; ?>" style=" background-color:#FFFFFF;color:#111111;"><span class="tit">FAQ</span></a>
    </div>
</div>

<div class="middle">

<div class="middle_title">
<a href="#" class="title_link">Home</a>  /  <a href="<?php echo $myurl.'pages/journal/journallist.php'; ?>" class="title_link">Journals</a>  /  <a href="#" class="title_link"> <?php echo getsubjectnameInJournal($pdb,$_GET['catid10']); ?></a>  /  <?php echo getjournalname($pdb,$_GET['catid10']); ?>
</div> 
        <div class="middle_left">
            <div class="middle_title2">Frequently Asked Questions</div>
            <div class="middle_left_line"></div>
            <?php 
            $i = 1;
            $counter = 0;
            foreach ($myfaq as $fq){  ?>
            <a class="question" id="<?php echo 'q'.$i; ?>" >
                <?php echo 'Q'.$i; ?>: <?php echo $fq['_question']; ?><img src="<?php echo $myurl.'images/whiteminus_icon.png'; ?>" style="float: right; margin-right: 30px; margin-top: 15px; display: none;" id="<?php echo 'white'.$i; ?>">
                <img src="<?php echo $myurl.'images/blackadd_icon.png'; ?>" style="float: right; margin-right: 30px; margin-top: 15px; display: block;" id="<?php echo 'black'.$i; ?>">
            </a>
            <div id="<?php echo 'q'.$i.'_text'; ?>" class="q1_text" style="display: none;">
      <div style='word-wrap: break-word;'>  <?php echo $fq['_ans'];  ?> </div> </div>

            <?php $i++; } ?>
        </div>

        <div class="middle_right">
            <div class="middle_title2">Submit Your Question Online</div>
            <div class="middle_right_form">
                <div class="middle_right_form_tit">
                    If you couldn't find the answer you need in Frequently Asked Questions, please type your question below. Upon receiving your question a staff member will seek out the answers and respond via email. 
                </div>
                <form action="<?php $myurl.'controller/user/mail.php' ?>" method="post" id="addQuestionForm">
	                <div class="middle_right_form_name">Name</div>
	                <div class="form_input"><input type="text" required="required" style="width:340px;height:27px;border-style:none;padding-left:10px;border:1px solid #E0DEDE;" name="namex" maxlength="60" id="firstName"></div>
	                <div class="middle_right_form_name">Email</div>
	                <div class="form_input"><input type="text" required="required" style="width:340px;height:27px;border-style:none;padding-left:10px;border:1px solid #E0DEDE;" name="email" maxlength="120" id="email"></div>
	                <div class="middle_right_form_name">Question</div>
	                <div class="form_input2"><textarea required="required" style="width:340px;height:146px;border-style:none;overflow-y:hidden;resize:none;padding-left:10px;border:1px solid #E0DEDE;" name="msg" maxlength="3900" id="message"></textarea></div>
	               
	                <a href="#">
                        <input type='submit'  class="middle_right_submit" name='faqsubmit' >
                      
                    </a>
                </form>
            </div>
        </div>

        <div class="clear"></div>

    </div>
            <div class="clear"></div>

            <div class="clear"></div>

<?php } ?>
    
<?php include '../../../includes/general/footer.php'; ?>