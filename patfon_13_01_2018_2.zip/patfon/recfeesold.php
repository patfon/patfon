<form id="formreefeeold" class="form-horizontal bucket-form myhide" action=<?php echo $myurl."config/income_controller.php"; ?> method="POST">
                <header class="panel-heading">
                OLD STUDENTS 
                </header>
                <span id="alertolddiv" class=" bg-important"> </span>
                
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Student Name: <span style="color: red;">* </span> </label>
                        <div class="col-sm-6">
                            <input id="inc_stname" autocomplete="off" type="text" class="form-control" name="name" required = 'required'>
                            
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">Please type Name of Student</span>
                     
                        </div>
                        
                    </div>
                    <div class="feesbelow" style="width: 50%; margin-left: 60px;"></div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Student Class</label>
                        <div class="col-sm-6">
                        <input type="text" class="form-control" id="stu_cls" disabled='disabled'>
                        </div>
                    </div>
                    <hr>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Form of Payment <span style="color: red;">* </span></label>
                        <div class="col-sm-6">
                        <select class="modepay" name="modepay" required = 'required'>
                        <option value=""></option>
                        <option value="bank">Bank</option>
                        <option value="cash">Cash</option>
                        </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Bank Name</label>
                        <div class="col-sm-6">
                        <input type="text" class="form-control myhide" id="modebank" name="modebk">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">School Fees <span style="color: red;">* </span></label>
                        <div class="col-sm-8">

                        <span style="display: inline-block;" class="col-sm-12">
                        <div class="col-sm-9">
                            <input type="number" class="form-control schfeex" name="schfee" required = 'required'>
                            <input type="hidden" id="orischfee" name="schfeeori" value=''>
                        </div>    
                        <div class="col-sm-3">
                        <label style="font-size: 9px; display: inline; " >Click here if this fee is paid already</label>
                        <input type="checkbox" id="schchk" >
                        </div>
                        </span> 

                        <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">Compulsory</span> 

                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Old Debts <span style="color: red;">* </span></label>
                        <div class="col-sm-8">
                        <span style="display: inline-block;" class="col-sm-12">    
                        <div class="col-sm-9">
                        <input type="number" class="form-control debtfeex" name="debt" required = 'required'>
                        </div>
                        <div class="col-sm-3">
                        <label style="font-size: 9px; display: inline; " >Click here if this fee is paid already</label>
                        <input type="checkbox" id="debtchk" >
                        </div>
                        <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">Compulsory.</span>
                        </span>    
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Bus</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control busfeex" name="bus">
                            <span class="help-block" style="color: green; font-size: 10px; font-weight: bold;">Not compulsory</span>
                            <input type="hidden" id="oribusfee" name="busfeeori" value=''>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Pullover</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control pullfeex" name="pull">
                            <span class="help-block" style="color: green; font-size: 10px; font-weight: bold;">Not compulsory</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Party</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control partyfeex" name="party">
                            <span class="help-block" style="color: green; font-size: 10px; font-weight: bold;">Not compulsory</span>
                        </div>
                    </div>

                    <div class="form-group" id="uniformchoice">
                        <label class="col-sm-3 control-label">Choose type of uniform</label>
                        <div class="col-sm-6">
                        <select name="unichoice" id="unichoicez" >
                        <option value=""></option>
                        <option value="custom">Customised</option>
                        <option value="regular">Regular</option>
                        </select>   
                        </div>
                    </div>
                    <div class="form-group myhide" id="uniformdiv">
                        <label class="col-sm-3 control-label">Uniform</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control uniformfeex" name="uniform" >
                            <span class="help-block" style="color: green; font-size: 10px; font-weight: bold;">Not compulsory</span>
                      
                         </div>
                    </div>
                    <div class="form-group myhide" id="uniformdiv2">
                        <label class="col-sm-3 control-label">Customised Uniform</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control uniformfeexi" name="uniformcus" >
                            <span class="help-block" style="color: green; font-size: 10px; font-weight: bold;">Not compulsory</span>
                      
                         </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Sport Wear</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control spwearfeex" name="spwear">
                            <span class="help-block" style="color: green; font-size: 10px; font-weight: bold;">Not compulsory</span>
                      
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Continous Assessment </label>
                        <div class="col-sm-8">
                            <span style="display: inline-block;" class="col-sm-12">
                            <div class="col-sm-9">
                            <input type="number" class="form-control contassfeex" name="contass" >
                            </div>
                            <div class="col-sm-3">
                            <label style="font-size: 9px; display: inline; " >Click here if this fee is paid already</label>
                            <input type="checkbox" id="contasschk"  value = ""> 
                            </div>
                            </span>
                            <span class="help-block" style="color: green; font-size: 10px; font-weight: bold;">Not Compulsory</span>
                      
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Total Assigned</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control" id="ota" disabled='disabled' >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Total Unassigned</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control" id="outa" disabled='disabled' >
                        </div>
                    </div>
                    <div class="form-group has-success">
                        <label class="col-sm-3 control-label">Total</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control" id="otta" disabled='disabled' >
                            <input type="hidden" name="gtotal" id="ogtotal" >
                        </div>
                    </div>

                    <button type="submit" name="income_recfeeoldbut" id="feebutold" class="btn btn-success btn-block">Collect Fee(s)</button>

                   
</form>