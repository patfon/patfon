<?php session_start(); ?>
<?php include '../classes/connection.php' ;
$userx = mysqli_real_escape_string($pdb,$_POST['uname']);
$pass = mysqli_real_escape_string($pdb,$_POST['passwx']);
$q = "SELECT * FROM users WHERE uname='$userx' and status = 1 and pass='".md5($pass)."'";

$r = mysqli_query ($pdb,$q);
$rov = mysqli_fetch_array($r,MYSQLI_ASSOC);
$row = mysqli_num_rows($r);

if ($row > 0) {
    
    $_SESSION['patfonuser']['id'] = $rov['id'];
    $_SESSION['patfonuser']['school'] = $rov['school'];
    $_SESSION['patfonuser']['key'] = $rov['pass'];
    $_SESSION['patfonuser']['role'] = $rov['role'];
    
    $myskool = $rov['school'];
    
    $q2 = "SELECT * FROM resume WHERE school =  $myskool ";
    $rx = mysqli_query ($pdb,$q2);
    $rov2 = mysqli_fetch_array($rx,MYSQLI_ASSOC);
    $_SESSION['patfonuser']['ses'] = $rov2['session'];
    $_SESSION['patfonuser']['term'] = $rov2['term'];

    header('Location: ../index.php'); 
}
else {
    $_SESSION['loginfailed'] =  true;
    header("Location: ../login.php");
    exit;
}

/**
 * 
 $myskool = $rov['school'];
    $_SESSION['patfonuser']['id_'] = $rov['id'];
    $_SESSION['patfonuser']['school'] = $rov['school'];
   // $_SESSION['patfonuser']['in'] = time();
    header('Location: ../index.php'); 


$q2 = "SELECT * FROM resume WHERE school =  $myskool ";
    $rx = mysqli_query ($pdb,$q2);
    $rov2 = mysqli_fetch_array($rx,MYSQLI_ASSOC);

    $_SESSION['patfonuser']['ses'] = $rov2['session'];
    $_SESSION['patfonuser']['term'] = $rov2['term'];
**/    