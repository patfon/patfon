<form id="formreefeenew" class="form-horizontal bucket-form myhide" action=<?php echo $myurl."config/income_controller.php"; ?> method="POST">
                <header class="panel-heading">
                NEW STUDENTS 
                </header>
                <span id="alertdiv" class=" bg-important"> </span>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Student RegNo</label>
                        <div class="col-sm-6">
                            <input id="inc_stname2" type="text" class="form-control" name="name" required = 'required'>
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">Please type Registration Number</span>
                        </div>
                        
                    </div>
                    <div class="feesbelow" style="width: 50%; margin-left: 60px;"></div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Student Class</label>
                        <div class="col-sm-6">
                        <input type="text" class="form-control" id="stu_cls2" disabled='disabled'>
                        </div>
                    </div>
                    <hr>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Form of Payment</label>
                        <div class="col-sm-6">
                        <select class="modepay2" name="modepay" required = 'required'>
                        <option value=""></option>
                        <option value="bank">Bank</option>
                        <option value="cash">Cash</option>
                        </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Bank Name</label>
                        <div class="col-sm-6">
                        <input type="text" class="form-control myhide" id="modebank2" name="modebk">
                        </div>
                    </div>
                  
                    <hr>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">School Fees</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control schfeex2" name="schfee" required = 'required'>
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">compulsory</span>
                        </div>
                    </div>
                   
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Bus</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control busfeex2" name="bus">
                            <span class="help-block" style="color: green; font-size: 10px; font-weight: bold;">Not compulsory</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Pullover</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control  pullfeex2" name="pull" required = 'required'>
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">compulsory</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Party</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control partyfeex2" name="party" required = 'required'>
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">compulsory</span>
                        </div>
                    </div>
                    <div class="form-group" id="uniformchoice">
                        <label class="col-sm-3 control-label">Choose type of uniform</label>
                        <div class="col-sm-6">
                        <select name="unichoice" id="unichoice" required = 'required' >
                        <option value=""></option>
                        <option value="custom">Customised</option>
                        <option value="regular">Regular</option>
                        </select>   
                        </div>
                    </div>
                    <div class="form-group myhide" id="uniformdiv21">
                        <label class="col-sm-3 control-label">Uniform</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control uniformfeex2" name="uniform" >
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">compulsory</span>
                        
                         </div>
                    </div>
                    <div class="form-group myhide" id="uniformdiv22">
                        <label class="col-sm-3 control-label">Customised Uniform</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control uniformfeex2i" name="uniformcus" >
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">compulsory</span>
                      
                         </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Sport Wear</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control spwearfeex2" name="spwear" required = 'required'>
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">compulsory</span>
                      
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Continous Assessment</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control contassfeex2" name="contass" required = 'required'>
                            <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">compulsory</span>
                      
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Total Assigned</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control" id="nta"  disabled='disabled'>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Total Unassigned</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control" id="nuta"  disabled='disabled'>
                        </div>
                    </div>
                    <div class="form-group has-success">
                        <label class="col-sm-3 control-label">Total</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control" id="ntta"  disabled='disabled' >
                            <input type="hidden" name="gtotal" id="ngtotal" >
                        </div>
                    </div>

                    <button type="submit" name="income_recfeenewbut" id="feebutnew" class="btn btn-success btn-block">Collect Fee</button>

                   
</form>