<?php session_start(); ?>
<?php $_SESSION['cur-page'] = "Settings"; ?>
<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
require('includes/header.php');
?>

<?php
//settings menu
require('includes/set_menu.php');
?>



<?php
//footer
require('includes/footer2.php');
 ?>
 <?php } else { 
    
    header("Location: login.php");
 } ?> 