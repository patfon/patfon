<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php $_SESSION['cur-page'] = "Income > Receive Fee"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
include('functions/index.php');
include('includes/header.php');
?>
<section id="main-content">
	<section class="wrapper">
  <div class="row">
  <div class="col-sm-6"><button type="button" class="btn btn-success" onclick="recfees_old()"> Old Students </button></div>
  <div class="col-sm-6"><button type="button" class="btn btn-warning" onclick="recfees_new()">New Students </button></div>
  </div>
    <div class="row">
                        <?php  if(isset($_SESSION['success_add'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully collected all School Fees.
                            </div>                             
                        <?php unset($_SESSION['success_add']); } ?>
                       
                       
                        <?php  if(isset($_SESSION['failed'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.There was an error in the last request. Please try again.
                            </div>                             
                        <?php unset($_SESSION['failed']); } ?>
    <div class="col-md-8">
    <section class="panel">
            <header class="panel-heading">
                RECEIVE SCHOOL FEES  
            </header>
           
            <div id="receivefee_div" class="panel-body">
                <?php 
                //my different forms
                include('pages/income/recfeesold.php'); 
                include('pages/income/recfeesnew.php'); 
                ?>
            </div>
        </section>
    </div>
    <div class="col-md-4" style="margin-top: 50px;">
      <!--begin table -->
        <div class="table-agile-info">
            <div class="panel panel-default">
        <!---728x90 -->
            <div class="panel-heading">
        Expected Fees
            </div>
            <div>
            <table class="table">
            
                <thead>
                <tr>
                
                    <th>Fee Type</th>
                    <th>Amount</th>
                
                </tr>
                </thead>
                <tbody>
                <tr>
                <td>Tution Fees</td><td class="tfees"></td>
                </tr>
                <tr>
                <td>Old Debt </td> <td class="oldfees">
                
                </td>
                </tr>
                <tr>
                <td>Bus Fee</td> <td class="busfees"> 
                
                </td>
                </tr>
                <tr>
                <td>Pull Over Fee</td> <td class="pullfees">
               
                </td>
                </tr>
                <tr>
                <td> Party Fees</td> <td class="partyfees">
               
                </td>
                </tr>
                <tr>
                <td> Uniform Fees</td> <td class="uniformfees">
               
                </td>
                </tr>
                <tr>
                <td> Customised Uniform Fees</td> <td class="cuniformfees">
               
                </td>
                </tr>
                <tr>
                <td> Sport Wear Fees</td> <td class="spwearfees">
               
                </td>
                </tr>
                <tr>
                <td> Continous Assessment Fees</td> <td class="contassfees">
               
                </td>
                </tr>
                
                </tbody>
            </table>
            </div>
            <!-- 728x90 -->
        </div>
        </div> <!--end table -->

    </div>
    

    </div>
</section>
</section>


<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 