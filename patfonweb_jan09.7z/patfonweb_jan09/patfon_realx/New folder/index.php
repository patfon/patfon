<?php session_start(); ?>
<?php $_SESSION['cur-page'] = "Home"; ?>
<?php if (isset($_SESSION['patfonuser']) ) {  
    
//echo var_dump($_SESSION['patfonuser']);

?>
<?php
//header
include('includes/header.php');

//feature i.e calender & dashboard
include('includes/feature.php');
?>

<?php
//footer
include('includes/footer.php');
 ?>


<?php  }  else { 
    
    header("Location: login.php");
    exit;
  } 