<?php session_start(); ?>
<?php $_SESSION['cur-page'] = "Income"; ?>
<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
require('includes/header.php');
?>


<?php
//income menus
require('includes/inc_menu.php');
?>

<?php
//modals
include('pages/income/modals.php');
 ?>

 
<?php
//footer
require('includes/footer2.php');
 ?>

<?php } else { 
    
    header("Location: login.php");
 } ?> 