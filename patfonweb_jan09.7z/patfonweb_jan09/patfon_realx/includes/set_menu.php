<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		
		
		<!---main content here -->
<div class="market-updates">
			<div class="col-md-3 market-update-gd">
				<div class="market-update-block clr-block-2">
					<a href=<?php echo $myurl."settings_setSession.php"; ?> > 
					<div class="col-md-4 market-update-right">
						<i class="fa fa-external-link"> </i>
					</div>
					 <div class="col-md-8 market-update-left">
					 <h4>Set School Session</h4>
					 </a>
                    </div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="monthly.php"> <div class="market-update-block clr-block-1">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-calendar-check-o"></i>
					</div>
					<div class="col-md-8 market-update-left">
					<h4>Start Term</h4>
					</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="termly.php"> <div class="market-update-block clr-block-4">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-calendar-times-o"></i>
					</div>
					<div class="col-md-8 market-update-left">
						<h4>End Term</h4>
						</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="yearly.php"> <div class="market-update-block clr-block-4">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-bullhorn" aria-hidden="true"></i>
					</div>
					<div class="col-md-8 market-update-left">
						<h4>Write On Notice Board</h4>
						</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
		   <div class="clearfix"> </div>
		</div>
		<div class="col-md-3 market-update-gd">
				<div class="market-update-block clr-block-3">
					<a href=<?php echo $myurl."settings_blockuser.php"; ?>> 
					<div class="col-md-4 market-update-right">
						<i class="fa fa-lock"> </i>
					</div>
					 <div class="col-md-8 market-update-left">
					 <h4>Manage User</h4>
					 </a>
                    </div>
				  <div class="clearfix"> </div>
				</div>
			</div>
		<div class="col-md-3 market-update-gd">
				<div class="market-update-block clr-block-2">
					<a href=<?php echo $myurl."settings_changepass.php"; ?>> 
					<div class="col-md-4 market-update-right">
						<i class="fa fa-unlock"> </i>
					</div>
					 <div class="col-md-8 market-update-left">
					 <h4>Change Password</h4>
					 </a>
                    </div>
				  <div class="clearfix"> </div>
				</div>
			</div>
		   <div class="clearfix"> </div>
		<!--main contents end-->
		
		<div class="col-md-6 w3agile-notifications">
			<div class="clearfix"> </div>	
		</div>

</section>
</section>
<!--main content end-->