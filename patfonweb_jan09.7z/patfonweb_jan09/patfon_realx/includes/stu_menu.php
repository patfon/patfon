<!--main content start-->
<section id="main-content">


<section class="wrapper">

		<!---main content here -->
<div class="market-updates">
			<div class="col-md-3 market-update-gd">
				<div class="market-update-block clr-block-2">
					<a href="add.php"> <div class="col-md-4 market-update-right">
						<i class="fa fa-user-plus"> </i>
					</div>
					 <div class="col-md-8 market-update-left">
					 <h4>Add Student</h4>
					 </a>
                    </div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="view.php"> <div class="market-update-block clr-block-1">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-eye"></i>
					</div>
					<div class="col-md-8 market-update-left">
					<h4>View Student</h4>
					</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="ststus.php"> <div class="market-update-block clr-block-1">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-pencil-square"></i>
					</div>
					<div class="col-md-8 market-update-left">
					<h4>Change Status</h4>
					</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="assign.php"> <div class="market-update-block clr-block-2">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-bar-chart"></i>
					</div>
					<div class="col-md-8 market-update-left">
					<h4>Student Stat</h4>
					</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			 <div class="clearfix"> </div>
			
		</div>
		<div class="market-updates">
			<div class="col-md-3 market-update-gd">
				<div class="market-update-block clr-block-2">
					<a href="promote.php"> <div class="col-md-4 market-update-right">
						<i class="fa fa-check-square-o"> </i>
					</div>
					 <div class="col-md-8 market-update-left">
					 <h4>Promote Student</h4>
					</a>
				  </div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			
			<div class="col-md-3 market-update-gd">
				<a href="delete.php"> <div class="market-update-block clr-block-3">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-user-times"></i>
					</div>
					<div class="col-md-8 market-update-left">
						<h4>Delete Student</h4>
					</a>	
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="archiev.php"> <div class="market-update-block clr-block-4">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-archive" aria-hidden="true"></i>
					</div>
					<div class="col-md-8 market-update-left">
						<h4>View Archive</h4>
						</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			
		   <div class="clearfix"> </div>
		   
		</div>
		
		<!-- main content ends here -->
		<div class="col-md-6 w3agile-notifications">	
			<div class="clearfix"> </div>
		</div>	
</section>
 
</section>
<!--main content end-->