<?php 
$firstterm = array(9,10,11,12);//months of 1st term
$secondterm = array(1,2,3,4);
$thirdterm = array(5,6,7,8);

/*** Student functions **/
function getstudentpaid($con,$id,$term,$year,$sch){

  $query = (" SELECT amount FROM student_fees WHERE stu_id = $id AND year_ = '$year' AND type_ = 99 AND term = $term  AND school = $sch ");
  $src = "";
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src = $r['amount'];
      }
   }
  
   return $src;
  
  }

  function getstudentpaidx($con,$id,$ty,$year,$term,$sch){

    $query = (" SELECT amount FROM student_fees WHERE stu_id = $id AND date_pay = '$year' AND type_ = $ty AND term = $term  AND school = $sch ");
    $src = "";
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src = $r['amount'];
        }
     }
    
     return $src;
    
    }

    function getstudentpaymode($con,$id,$mode,$year,$term,$sch){

      $query = (" SELECT SUM(amount) as amt FROM student_fees WHERE stu_id = $id  AND modepay = '$mode' AND date_pay = '$year'  AND term = $term  AND school = $sch  ");
      $src = "";
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src = $r['amt'];
          }
       }
      
       return $src;
      
      }  

      function getstudentneworold($con,$id){

        $query = (" SELECT new_ FROM student WHERE id = $id ");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src = $r['new_'];
            }
         }
        
         return $src;
        
        }      
  
  function getstudentdatepaid($con,$id,$term,$year){

    $query = (" SELECT date_pay FROM student_fees WHERE stu_id = $id AND year_ = '$year' AND term = $term ");
    $src = "";
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src = $r['date_pay'];
        }
     }
    
     return $src;
    
    }

function getstudents($con){

$query = ("SELECT * FROM student WHERE status = 1");
$src = array();
$result = mysqli_query($con,$query) or die(mysqli_error($con));
if (mysqli_num_rows($result) > 0){
while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 

 $src[] = $r;
}
}

return $src;

}  

function getstudentname($con,$id){

  $query = ("SELECT CONCAT(fname,' ',lname) as fn FROM student WHERE id = $id ");
  $src = "";
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src = $r['fn'];
      }
   }
  
   return $src;
  
  }

  function getstudentfromarchive($con){

    $query = ("SELECT * FROM student WHERE archive != 0 ");
    $src = array();
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src[] = $r;
        }
     }
    
     return $src;
    
    }

    function getstudentclassonly($con,$st,$sch){

      $query = ("SELECT class_ FROM student WHERE id = $st and school = $sch ");
      $src = "";
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src = $r['class_'];
          }
       }
      
       return $src;
      
      }  

    function getstudentclasscat($con,$cls,$sch){

        $query = ("SELECT category FROM class_ WHERE id = $cls and school = $sch ");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src = $r['category'];
            }
         }
        
         return $src;
        
        }   

  function getstudentfromclass($con,$cat,$sch){

    $query = ("SELECT * FROM student WHERE  school = $sch AND archive = 0 AND class_ IN (SELECT id FROM class_ WHERE category = $cat)");
    $src = array();
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
        $src[] = $r;
        }
     }
return $src;
    
    }

  function getstudentclass($con,$id){

    $query = ("SELECT name,arm FROM class_ WHERE id IN (SELECT class_ FROM student WHERE id = $id) ");
    $src = "";
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src = $r['name'].";".$r['arm'];
        }
     }

     $srcx = explode(";",$src);
     $armname = getclassarm($con, intval($srcx[1]) );
     $final = trim($srcx[0]."".$armname);

     return $final;
    
    }

    function getstudentstatus($con,$sid,$sch){

      $query = ("SELECT status FROM student WHERE id = $sid AND school = $sch ");
      $src = "";
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src = $r['status'];
          }
       }
      return $src;
      
      }

      function getstudentdebt($con,$sid,$sch){

        $query = ("SELECT debt FROM student WHERE id = $sid AND school = $sch ");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src = $r['debt'];
            }
         }
        return $src;
        
        }


/**********************/

/*********Teacher***********/

function getteachers($con){

  $query = ("SELECT * FROM teacher");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[] = $r;
      }
   }
  
   return $src;
  
}  

function getteachername($con,$id){

  $query = ("SELECT CONCAT(fname,' ',lname) as fn FROM teacher WHERE id = $id ");
  $src = "";
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src = $r['fn'];
      }
   }
  
   return $src;
  
  }

function getteacherpaid($con,$id,$mnt,$year){

  $query = (" SELECT amount FROM teacher_fees WHERE tea_id = $id AND month_ = $mnt AND year_ = '$year' ");
  $src = "";
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src = $r['amount'];
      }
   }
  
   return $src;
  
  }

  function getteacherdatepaid($con,$id,$mnt,$year){
//getdeductionteacher
    $query = (" SELECT date_pay FROM teacher_fees WHERE tea_id = $id AND month_ = $mnt AND year_ = '$year' ");
    $src = "";
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src = $r['date_pay'];
        }
     }
    
     return $src;
    
    }

    function getdeductionteacher($con,$id,$mnt,$year){
      //getdeductionteacher
          $query = (" SELECT deduction FROM teacher_fees WHERE tea_id = $id AND month_ = $mnt AND year_ = '$year' ");
          $src = "";
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src = $r['deduction'];
              }
           }
          
           return $src;
          //getteachersalary
          }
    function getteachersalary($con,$id){
        
        $query = (" SELECT salary FROM teacher WHERE id = $id ");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
                 if (mysqli_num_rows($result) > 0){
                   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                    
                     $src = $r['salary'];
                    }
                 }
                
       return $src;
          
    }

    function getteacherfromcategory($con,$type,$sch){

      $query = (" SELECT * FROM teacher WHERE type = $type AND school = $sch ");
      $src = array();
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
               if (mysqli_num_rows($result) > 0){
                 while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                  
                  $src[] = $r;
                  }
               }
              
    return $src;
//getteacherstatus
    }

    function getteacherstatus($con,$id,$sch){
        
      $query = (" SELECT status FROM teacher WHERE id = $id AND school = $sch ");
      $src = "";
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
               if (mysqli_num_rows($result) > 0){
                 while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                  
                   $src = $r['status'];
                  }
               }
              
     return $src;
        
  }


/**************************/


/*********Schools************/
function getschools($con){

  $query = ("SELECT name,id FROM school");
  $skools = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $skools[$r['id']] = $r['name'];
      }
   }
  
   return $skools;
  
  }
  
function getschoolname($con,$id){
  
  $query = ("SELECT name FROM school WHERE id = $id ");
  $skools = "";
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $skools = $r['name'];
      }
   }
  
   return $skools;
  
  }
/***********************************/

/***************  ****************/
function getsession($con,$skool){

  $query = ("SELECT session, term FROM resume WHERE school = $skool");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[$r['session']] = $r['term'];
      }
   }
  
  return $src;
  
}

function getsource($con){

  $query = ("SELECT id, name FROM source");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[$r['id']] = $r['name'];
      }
   }
  
   return $src;
  
  }

  function getclassname($con,$id){

    $query = ("SELECT name FROM class_ WHERE id = $id ");
    $src = "";
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src = $r['name'];
        }
     }
    
     return $src;
    
    }

    function getclasscategory($con,$id){

      $query = ("SELECT category FROM class_ WHERE id = $id ");
      $src = "";
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src = $r['category'];
          }
       }
      
       return $src;
      
      }



      function getclassfee($con,$id,$sch){

        $query = ("SELECT fee FROM class_fees WHERE category = $id and school = $sch");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src = $r['fee'];
            }
         }
        
         return $src;
        
        } 

        function getclassfeeother($con,$id,$sch){
         
          if ($id == 1) {
            $query = ("SELECT bus FROM class_fees WHERE school = $sch");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['bus'];
                }
             }
          }
          else if ($id == 2) {
            $query = ("SELECT pullover FROM class_fees WHERE school = $sch");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['pullover'];
                }
             }
          }
          else if ($id == 3) {
            $query = ("SELECT party FROM class_fees WHERE school = $sch");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['party'];
                }
             }
          }
          else if ($id == 4) {
            $query = ("SELECT uniform FROM class_fees WHERE school = $sch");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['uniform'];
                }
             }
          }
          else if ($id == 5) {
            $query = ("SELECT c_uniform FROM class_fees WHERE school = $sch");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['c_uniform'];
                }
             }
          }
          else if ($id == 6) {
            $query = ("SELECT sp_wear FROM class_fees WHERE school = $sch");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['sp_wear'];
                }
             }
          }
          else if ($id == 7) {
            $query = ("SELECT ca FROM class_fees WHERE school = $sch");
            $src = "";
            $result = mysqli_query($con,$query) or die(mysqli_error($con));
             if (mysqli_num_rows($result) > 0){
               while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                 $src = $r['ca'];
                }
             }
          }

         
         
          
           return $src;
          
          } 

        function getclassarm($con,$id){

          $query = (" SELECT name FROM arm WHERE id = $id ");
          $src = "";
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src = $r['name'];
              }
           }
          
           return $src;
          
          } 

    function getusername($con,$id){

      $query = ("SELECT name FROM users WHERE id = $id ");
      $src = "";
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src = $r['name'];
          }
       }
      
       return $src;
      
      }

      function getusers($con,$id){

        $query = ("SELECT * FROM users WHERE id != $id");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src[] = $r;
            }
         }
        
         return $src;
        
      }
  
      function getuserfeecollect($con,$id,$term,$year){

        $query = ("SELECT name FROM users WHERE id IN (SELECT user_collect FROM student_fees WHERE stu_id = $id AND year_ = '$year' AND term = $term) ");
        $src = "";
        $result = mysqli_query($con,$query) or die(mysqli_error($con));
         if (mysqli_num_rows($result) > 0){
           while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
            
             $src = $r['name'];
            }
         }
        
         return $src;
        
        }

       







function getdistinctdates_income($con,$month,$year,$sch) {
  $query = ("SELECT DISTINCT date_pay FROM income WHERE mnt = $month AND date_pay LIKE '%$year%' AND school = $sch ORDER BY date_pay ");
$dates = array();
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $dates[] = $r['date_pay'];
    }
 }
 
    return $dates;


}

function getdistinctdates_expend($con,$month,$year,$sch) {
  $query = ("SELECT DISTINCT date_pay FROM expenditure WHERE mnt = $month AND date_pay LIKE '%$year%' AND school = $sch ORDER BY date_pay ");
$dates = array();
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $dates[] = $r['date_pay'];
    }
 }
 return $dates;

}

function getincomefee($con,$type,$month,$datex,$sch) {
$query = ("SELECT amount FROM income WHERE sourcex = $type AND date_pay LIKE '%$datex%' AND mnt = $month AND school = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['amount'];
    }
 }
 return $fees;

}

function getincomefeeyear($con,$cat,$datex,$sch) {
  $query = ("SELECT SUM(amount) AS amt_ FROM income WHERE sourcex = $cat AND date_pay LIKE '%$datex%' AND school = $sch ");
  $fees = "";
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $fees = $r['amt_'];
      }
   }
   return $fees;
  
  }

  function getexpendfeeyear($con,$cat,$datex,$sch) {
    $query = ("SELECT SUM(amount) AS amt_ FROM expenditure WHERE sub_source = $cat AND date_pay LIKE '%$datex%' AND school = $sch ");
    $fees = "";
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $fees = $r['amt_'];
        }
     }
     return $fees;
    
    }

  function getdiscountstudent($con,$stu,$term,$year,$sch) {
    $query = ("SELECT discount,extra FROM student_fees WHERE term = $term AND date_pay LIKE '%$year%' AND stu_id = $stu AND school = $sch ");
    $fees = 0;
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $fees = intval ( $r['discount'] + $r['extra'] );
        }
     }
     return $fees;
    
    }  

    function getoutstandstudent($con,$stu,$sch) {
      $query = ("SELECT SUM(bal) as mybal FROM student_fees WHERE stu_id = $stu AND school = $sch ");
      $fees = "";
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $fees = $r['mybal'];
          }
       }
       return $fees;
      
      }  

function getexpendfee($con,$type,$month,$datex,$sch) {
$query = ("SELECT amount FROM expenditure WHERE sourcex = $type AND date_pay = '$datex' AND mnt = $month AND school = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['amount'];
    }
 }
 return $fees;

}

function getincomesum($con,$type,$month,$datex,$sch) {
$query = ("SELECT SUM(amount) as myamt FROM income WHERE sourcex = $type AND date_pay LIKE '%$datex%' AND mnt = $month AND school = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['myamt'];
    }
 }
 return $fees;

}

function getexpendsum($con,$type,$month,$datex,$sch) {
$query = ("SELECT SUM(amount) as myamt FROM expenditure WHERE sub_source = $type AND date_pay LIKE '%$datex%' AND mnt = $month AND school = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['myamt'];
    }
 }
 return $fees;

}
