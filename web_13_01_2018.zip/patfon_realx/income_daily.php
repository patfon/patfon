<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php $_SESSION['cur-page'] = "Income > Daily Fee Report"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) {  
        //directly from income_controller..........
        $mydata = $_SESSION['patfonuser']['dailyfees'];
        $myterm = $_SESSION['patfonuser']['term'];
        $mysch = intval($_SESSION['patfonuser']['school']);
        $theyear = date("Y", strtotime($_SESSION['patfonuser']['dailydate']));
        $stu_st = array('0'=>"Old",'1'=>"New");

        $timestamp = strtotime($_SESSION['patfonuser']['dailydate'] );
        $new_date = date('M d', $timestamp);
      //
        ?>
<?php
include('functions/index.php');
include('includes/header.php');
?>
<section style="overflow-x: scroll; " id="main-content">
<section id="dailytableprint" class="wrapper">
        <div class= "row">
                <div class=" col-md-12">
                        <div>
                        <h4 class="center-block col-xs-offset-3"><?php echo getschoolname($pdb,$_SESSION['patfonuser']['school']); ?></h4>
                        <p>Daily Income Summary For the Day of <b><?php echo $new_date .", ".$theyear; ?> </b>
                         &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <input type="button" id="printdailybutton"   value="Print Table" class="btn btn-danger printButtonClass" ></p>
                        <table id="incdaily_table" class="table table-bordered table-responsive table-striped" border="1" cellspacing="2" cellpadding="2">
                        <thead>
                        <tr>
                        <th>S/N</th> <th>Old/New</th> <th>Name</th>  <th>Class</th>  <th>Date</th>     
                        <th>Fees</th> <th>Old Debts</th> <th>Bus</th> <th>C.Uniform</th> <th>Uniform</th> <th>Sport Wear</th>
                        <th>Pullover</th> <th>Continous Assessment</th> <th>Bank</th> <th>Cash</th> <th>Total</th>
                        </tr>
                        
                        </thead>
                        <tbody>
                        <?php
                        $i = 1;
                        //
                        //
                        foreach ($mydata as $dd) { ?>
                        <tr>
                        <td><?php echo $i; ?></td> 
                        <td><?php echo $stu_st[getstudentneworold($pdb,$dd['stu_id'])]; ?>  </td> <td><?php echo getstudentname($pdb,$dd['stu_id']); ?>  </td> <td> <?php echo getstudentclass($pdb,$dd['stu_id']); ?> </td> <td> <?php echo $new_date; ?>  </td> 
                        <td class="pf_row_if"><?php echo getstudentpaidx($pdb,$dd['stu_id'],99,$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_iod"><?php echo getstudentpaidx($pdb,$dd['stu_id'],100,$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_ib"><?php echo getstudentpaidx($pdb,$dd['stu_id'],2,$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_icu"><?php echo getstudentpaidx($pdb,$dd['stu_id'],3,$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_iu"><?php echo getstudentpaidx($pdb,$dd['stu_id'],1,$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_is"><?php echo getstudentpaidx($pdb,$dd['stu_id'],4,$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_ip"><?php echo getstudentpaidx($pdb,$dd['stu_id'],5,$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_ica"><?php echo getstudentpaidx($pdb,$dd['stu_id'],6,$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_sb"><?php echo getstudentpaymode($pdb,$dd['stu_id'],'bank',$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_c"><?php echo getstudentpaymode($pdb,$dd['stu_id'],'cash',$dd['date_pay'],intval($myterm),$mysch); ?></td> 
                      
                        <td class="pf_total_xx"><?php 
                        $cashmde = getstudentpaymode($pdb,$dd['stu_id'],'cash',$dd['date_pay'],intval($myterm),$mysch);
                        $bankmde = getstudentpaymode($pdb,$dd['stu_id'],'bank',$dd['date_pay'],intval($myterm),$mysch);
                        
                        if ($cashmde > 0 ) {
                                echo $cashmde;
                        }
                        else {
                                echo $bankmde;
                        } 
                       
                        ?> </td>
                         </tr>
                        <?php $i++; } ?>
                        <tr>
                        <td colspan="5" ></td>
                        <td class="pf_total_fees mybold"></td>
                        <td class="pf_total_old mybold"></td>
                        <td class="pf_total_bus mybold"></td>
                        <td class="pf_total_cus mybold"></td>
                        <td class="pf_total_uni mybold"></td>
                        <td class="pf_total_spo mybold"></td>
                        <td class="pf_total_pull mybold"></td>
                        <td class="pf_total_cont mybold"></td>
                        <td class="pf_total_bank mybold"></td>
                        <td class="pf_total_cash mybold"></td>

                        <td class="pf_total_grand mybold"></td>
                        </tr>
                        </tbody>
                        
                        </table>
                        </div>
                </div>
    </div>
</section>
</section>


<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 