<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php ///get the keywords from the evalute textbox as you try to search
include('functions/index.php');
if (isset($_POST['feesreceive'])) {
 $arr = array();   
 $keywords = mysqli_real_escape_string($pdb,$_POST['feesreceive']);
 $sql = " SELECT * FROM student WHERE new_ = 0 AND CONCAT(fname, lname) REGEXP '$keywords' OR regno REGEXP '$keywords' ";
 $result = mysqli_query($pdb,$sql) or die(mysqli_error($pdb));
 if (mysqli_num_rows($result) > 0) {
 while ($rows = mysqli_fetch_array ($result, MYSQLI_ASSOC)) {
 echo '<div id="" class="evaluateoutput"> 
         <input id="evalid" type="hidden" value="'.getstudentclass($pdb,$rows['id']).'" >
         <input id="evalstu" type="hidden" value="'.$rows['id'].'" >
         <input id="evalcat" type="hidden" value="'.getstudentclasscat($pdb,getstudentclassonly($pdb,$rows['id'],$rows['school']),$rows['school']).'" >
         <input id="evalregno" type="hidden" value="'.$rows['fname']." ".$rows['lname'].'" >
         <div class="evalname"><strong class="evaltext">'.$rows['fname']."  ".$rows['lname']."  from ".getstudentclass($pdb,$rows['id']). '</strong></div>
       
        </div>';
 }
 }
 else{
 echo '<div id="" class="evaluateoutput form-group"> 
         <div class="name"><strong>'.'Nothing returned'.'</strong></div>&nbsp;&nbsp;
        </div>';
 }
 
}
//new students
if (isset($_POST['feesreceive2'])) {
        $arr = array();   
        $keywords = mysqli_real_escape_string($pdb,$_POST['feesreceive2']);
        $sql = "SELECT * FROM student WHERE new_ = 1 AND CONCAT(fname, lname) REGEXP '$keywords' OR regno REGEXP '$keywords' ";
        $result = mysqli_query($pdb,$sql) or die(mysqli_error($pdb));
        if (mysqli_num_rows($result) > 0) {
        while ($rows = mysqli_fetch_array ($result, MYSQLI_ASSOC)) {
        echo '<div id="" class="evaluateoutput2"> 
                <input id="evalid2" type="hidden" value="'.getstudentclass($pdb,$rows['id']).'" >
                <input id="evalstu2" type="hidden" value="'.$rows['id'].'" >
                <input id="evalcat2" type="hidden" value="'.getstudentclasscat($pdb,getstudentclassonly($pdb,$rows['id'],$rows['school']),$rows['school']).'" >
                <input id="evalregno2" type="hidden" value="'.$rows['regno'].'" >
                <div class="evalname"><strong class="evaltext">'.$rows['fname']."  ".$rows['lname']."  from ".getstudentclass($pdb,$rows['id']). '</strong></div>
              
               </div>';
        }
        }
        else{
        echo '<div id="" class="evaluateoutput2 form-group"> 
                <div class="name"><strong>'.'Nothing returned'.'</strong></div>&nbsp;&nbsp;
               </div>';
        }
        
       }

if (isset($_POST['setcategory']) && isset($_POST['setstudent'])) {

    $mycat = $_POST['setcategory'];
    $mystu= $_POST['setstudent'];
  
    $_SESSION['patfonuser']['studentid'] =  $mystu ;
    $mysch = $_SESSION['patfonuser']['school'];

   $studebt =  getstudentdebt($pdb,$mystu,$mysch);
   $stubusdebt =  getstudentbusdebt($pdb,$mystu,$mysch);
  

   $stu = $_SESSION['patfonuser']['studentid'];
   $skool = $_SESSION['patfonuser']['school'];
   $term = $_SESSION['patfonuser']['term'];
   $thedate = date('Y');  

   $theamt = getstudentpaidclone($pdb,$stu,99,$thedate,$term,$skool);
   if ($theamt > 0) {
   $img = "<img src = '".""."images/paid_new.png' "." width='200' height='90' ><br>";
   $clsfee = 'PAID';
   }
   else{
           $clsfee =  getclassfee($pdb,$mycat,$mysch);
           $img = "";
   }
   $theamtuni = getstudentpaidclone($pdb,$stu,1,$thedate,$term,$skool);
   if ($theamtuni > 0) {
      
        $othfee = "PAID";
        }
        else{
                $othfee =  getclassfeeother($pdb,1,$mysch);
                
        }
   $theamtbus = getstudentpaidclone($pdb,$stu,2,$thedate,$term,$skool);
   if ($theamtbus > 0) {
           
             $othfee2 = "PAID";
             }
             else{
                     $othfee2 =  getclassfeeother($pdb,2,$mysch);
                     
             } 
  $theamtunicus = getstudentpaidclone($pdb,$stu,3,$thedate,$term,$skool);
             if ($theamtunicus > 0) {
                     
                       $othfee3 = "PAID";
                       }
                       else{
                               $othfee3 =  getclassfeeother($pdb,3,$mysch);
                               
                       }
  $theamtsp = getstudentpaidclone($pdb,$stu,4,$thedate,$term,$skool);
             if ($theamtsp > 0) {
                               
                     $othfee4 = "PAID";
                        }
                        else{
                                $othfee4 =  getclassfeeother($pdb,4,$mysch);
                                         
                        }
  $theamtpull = getstudentpaidclone($pdb,$stu,5,$thedate,$term,$skool);
             if ($theamtpull > 0) {
                                          
                                $othfee5 = "PAID";
                                   }
                else{
                                $othfee5 =  getclassfeeother($pdb,5,$mysch);
                                                 

   
                                   } 
  $theamtcont = getstudentpaidclone($pdb,$stu,6,$thedate,$term,$skool);
             if ($theamtcont > 0) {
                                                 
$othfee6 = "PAID";
                                   }
                 else{
                                $othfee6 =  getclassfeeother($pdb,6,$mysch);
                                                 

                         
                                  }
$theamtparty = getstudentpaidclone($pdb,$stu,7,$thedate,$term,$skool);
             if ($theamtparty > 0) {
                               $othfee7 = "PAID";
                                  }
                else{
                $othfee7 =  getclassfeeother

($pdb,7,$mysch);
                                                 

                                              
                   }
   

    $myarrayx = array('A'=>$clsfee, 'B'=>$studebt, 'C'=>$othfee, 'D'=>$othfee2, 'E'=>$othfee3, 
                     'F'=>$othfee4,'G'=>$othfee5, 'H'=>$othfee6,'I'=>$othfee7,'J'=>$img ,'K'=>$stubusdebt );


    $myarray = array('A'=>$othfee);
                           
    echo json_encode($myarrayx);


}