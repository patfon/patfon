<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php include 'functions/index.php' ; ?>

<?php $_SESSION['cur-page'] = "Settings > Set Session"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
include('includes/header.php');
?>
<section id="main-content">
	<section class="wrapper">
    <div class="row">
            <div class="col-md-8 col-md-offset-2" style="margin-top: 30px;">
                        <?php  if(isset($_SESSION['success'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully changed the session and term.
                            </div>                             
                        <?php unset($_SESSION['success']); } ?>
                        <?php  if(isset($_SESSION['failed'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.Your security key is not correct.
                            </div>                             
                        <?php unset($_SESSION['failed']); } ?>
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"> SET SESSION </h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" action=<?php echo $myurl."config/settings_controller.php"; ?> method="post">
                            <fieldset>
                                <div class="form-group">
                                    <label class="">Select Session</label>

                                    <select name="myses" required='required'> 
                                    <option value="">
                                    </option> 
                                    <option value="2017//2018">2017/2018
                                    </option> 
                                    <option value="2018//2019">2018/2019
                                    </option> 
                                    <option value="2019//2020">2019/2020
                                    </option> 
                                    <option value="2020//2021">2020/2021
                                    </option> 
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="">Select Term</label>
                                    <select name="myterm" required='required'> 
                                    <option value="">
                                    </option> 
                                    <option value="1">1st Term
                                    </option> 
                                    <option value="2">2nd Term
                                    </option> 
                                    <option value="3">3rd Term
                                    </option> 
                                  
                                    </select>
                                </div>
                                <div class="form-group">
                                <label class="">Security Key</label>
                                <input type="password" value="" class="form-control" name="token">
                                </div>
                                <div class="form-group">
                               
                                    <input class="btn btn-info" value="Set Session" name="setsessionbut" type="submit" >
                                </div>
                               
                                <!-- Change this to a button or input when using this as a form -->
                            
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </section>
</section>
<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 