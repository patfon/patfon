<!-- Update fee Class -->
<div class="modal fade" id="incomesetfee_modal" tabindex="2" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>    
                    </button>
                     
                    <h4 class="modal-title" id="">Edit Fee<i class="fa fa-fw fa-pencil"></i></h4>
                </div>
                 <div class="modal-body">
                                        <form role="form" action=<?php echo $myurl."config/income_controller.php"; ?> method="POST">
                                            <div class="form-group">
                                                <label for="">Type New Amount for <span class="myinnerlabel"> </span></label>
                                                <input type="number" class="form-control" id="modal_amt" name="amt"  >
                                                <input type="hidden" id="modal_id" name="myid" >
                                            </div>

                                          <button type="submit" name="income_feebut" class="btn btn-default">Set Fee</button>
                                        </form>
                                        </div>
               
              </div>
                
            </div>
    </div>

    <!-- Update other fees -->
<div class="modal fade" id="incomesetotherfee_modal" tabindex="2" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>    
                    </button>
                     
                    <h4 class="modal-title" id="">Edit Other Fees<i class="fa fa-fw fa-pencil"></i></h4>
                </div>
                 <div class="modal-body">
                                        <form role="form" action=<?php echo $myurl."config/income_controller.php"; ?> method="POST">
                                            <div class="form-group">
                                                <label for="">Type New Amount for <span class="myinnerlabel"> </span></label>
                                                <input type="number" class="form-control" id="modalx_amt" name="amt"  >
                                                <input type="hidden" id="modalx_id" name="myid" >
                                            </div>

                                          <button type="submit" name="income_feeotherbut" class="btn btn-default">Set Fee</button>
                                        </form>
                                        </div>
               
              </div>
                
            </div>
    </div>

    <!-- Find date of daily report fees -->
<div class="modal fade" id="incomegetdaily_modal" tabindex="2" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>    
                    </button>
                     
                    <h4 class="modal-title" id="">Daily Report ::: Select Date<i class="fa fa-fw fa-pencil"></i></h4>
                </div>
                 <div class="modal-body">
                                        <form role="form" action=<?php echo $myurl."config/income_controller.php"; ?> method="POST">
                                            <div class="form-group">
                                                <label for="">Select Date of Report</label>
                                                <input type="date" class="form-control" id="modal_incdate" name="thedate" required='required' >

                                            </div>

                                          <button type="submit" name="income_dailybut" class="btn btn-default">Get Daily Report</button>
                                        </form>
                                        </div>
               
              </div>
                
            </div>
    </div>

    