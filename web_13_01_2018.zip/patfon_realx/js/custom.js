

$(' .schfeex , .debtfeex , .busfeex , .pullfeex ,  .partyfeex , .spwearfeex, .uniformfeexi, .uniformfeex,  .contassfeex ').keyup(oldschval);

function oldschval(){
    if ($('#inc_stname').val() === ""){
        $('#feebutnew').attr('disabled','disabled');
        $('#alertolddiv').html("<p style='color: red;'> Please Select the Student First!</p>");
    }
    else{
        
        $('#alertolddiv').html("");
    var sf =  $('.schfeex').val();
    if (sf === 'undefined' || sf === 'NULL' || sf === '') {
    sf = 0;
        }
    var dbf =  $('.debtfeex').val();
    if (dbf === 'undefined' || dbf === 'NULL' || dbf === '') {
        dbf = 0;
        }
    var buf =  $('.busfeex').val();
        if (buf === 'undefined' || buf === 'NULL' || buf === '') {
            buf = 0;
            }    
    var pf =  $('.pullfeex').val();
    if (pf === 'undefined' || pf === 'NULL' || pf === '') {
        pf = 0;
        }
    var paf =  $('.partyfeex').val();
    if (paf === 'undefined' || paf === 'NULL' || paf === '') {
        paf = 0;
        }
    var isVis = $('.uniformfeex').is(':visible');
    var isVisc = $('.uniformfeexi').is(':visible');
    if (isVis) {
    var uni =  $('.uniformfeex').val();
    if (uni === 'undefined' || uni === 'NULL' || uni === '') {
        uni = 0;
        }
    }
    else if (isVisc){
    var uni =  $('.uniformfeexi').val();
    if (uni === 'undefined' || uni === 'NULL' || uni === '') {
            uni = 0;
        }
    }
    else{
        uni = 0;
    }     
    
    var spwear =  $('.spwearfeex').val();
    if (spwear === 'undefined' || spwear === 'NULL' || spwear === '') {
        spwear = 0;
        }
    var contass =  $('.contassfeex').val();
    if (contass === 'undefined' || contass === 'NULL' || contass === '') {
        contass = 0;
        }        

var fsf =  Number($('.tfees').html());
if (fsf === 'undefined' || fsf === 'NULL' || fsf === '') {
    fsf = 0;
    }
var olf =  Number($('.oldfees').html());
    if (olf === 'undefined' || olf === 'NULL' || olf === '') {
        olf = 0;
        }
var busf =  Number($('.busfees').html());
        if (busf === 'undefined' || busf === 'NULL' || busf === '') {
            busf = 0;
            }    
var fpf =  Number($('.pullfees').html());
if (fpf === 'undefined' || fpf === 'NULL' || fpf === '') {
    fpf = 0;
    }
var fpaf =  Number($('.partyfees').html());
if (fpaf === 'undefined' || fpaf === 'NULL' || fpaf === '') {
    fpaf = 0;
    }

    var isVisx = $('.uniformfeex').is(':visible');
    var isViscx = $('.uniformfeexi').is(':visible');
    if (isVisx) {
    var funi =  Number($('.uniformfees').html());
    if (funi === 'undefined' || funi === 'NULL' || funi === '') {
        funi = 0;
    } }
    else if (isViscx) {     
    var funi =  Number($('.cuniformfees').html());
    if (funi === 'undefined' || funi === 'NULL' || funi === '') {
        funi = 0;
    } }
    else {
        funi = 0;
    }
    var spwa =  Number($('.spwearfees').html());
    if (spwa === 'undefined' || spwa === 'NULL' || spwa === '') {
        spwa = 0;
    }  
    var conas =  Number($('.contassfees').html());
    if (conas === 'undefined' || conas === 'NULL' || conas === '') {
        conas = 0;
    }
   /** 
    if (buf > 0 && (buf < busf)){
        $('#feebutold').attr('disabled','disabled');
        $('#alertolddiv').html("<p style='color: red;'> Please pay COMPLETE Bus  fees to Continue</p>");   
        return; 
    }
    **/

    if (pf > 0 && (pf < fpf)){
        $('#feebutold').attr('disabled','disabled');
        $('#alertolddiv').html("<p style='color: red;'> Please pay COMPLETE Pull Over fees to Continue</p>");
         
        return;   
    }
    
    if (paf > 0 && (paf < fpaf)){
        $('#feebutold').attr('disabled','disabled');
        $('#alertolddiv').html("<p style='color: red;'> Please pay COMPLETE Party fees to Continue</p>"); 
        return;   
    }
    
    if (uni > 0 && (uni < funi)){
        $('#feebutold').attr('disabled','disabled');
        $('#alertolddiv').html("<p style='color: red;'> Please pay COMPLETE Uniform fees to Continue</p>"); 
        return;   
    }
    
    if (spwear > 0 && (spwear < spwa)){
        $('#feebutold').attr('disabled','disabled');
        $('#alertolddiv').html("<p style='color: red;'> Please pay COMPLETE Sport wear fees to Continue</p>"); 
        return;   
    }
   
    if (contass > 0 && (contass  < conas)){
        $('#feebutold').attr('disabled','disabled');
        $('#alertolddiv').html("<p style='color: red;'> Please pay COMPLETE Uniform fees to Continue</p>");   
        return; 
    }
    
    if (dbf > 0 && (dbf  < olf)){
        $('#feebutold').attr('disabled','disabled');
        $('#alertolddiv').html("<p style='color: red;'> Please pay COMPLETE Debt fees to Continue</p>");    
        return;
    }
    $('#feebutold').removeAttr('disabled');

    }

}



$('.schfeex2 , .pullfeex2 , .partyfeex2, .uniformfeex2, .uniformfeex2i, .spwearfeex2, .contassfeex2').keyup(newschval);

function newschval(){
console.log("pick student: "+ $('#inc_stname2').val());
if ($('#inc_stname2').val() === ""){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please Select the Student First!</p>");
}
else {
var sf =  $('.schfeex2').val();
if (sf === 'undefined' || sf === 'NULL' || sf === '') {
sf = 0;
}
var pf =  $('.pullfeex2').val();
if (pf === 'undefined' || pf === 'NULL' || pf === '') {
    pf = 0;
    }
var paf =  $('.partyfeex2').val();
if (paf === 'undefined' || paf === 'NULL' || paf === '') {
    paf = 0;
    }
    var isVis = $('.uniformfeex2').is(':visible');
    var isVisc = $('.uniformfeex2i').is(':visible');
    if (isVis) {
    var uni =  $('.uniformfeex2').val();
    if (uni === 'undefined' || uni === 'NULL' || uni === '') {
        uni = 0;
        }
    }
    else if (isVisc){
    var uni =  $('.uniformfeex2i').val();
    if (uni === 'undefined' || uni === 'NULL' || uni === '') {
            uni = 0;
        }
    }
    else{
        uni = 0;
    }     
    
    var spwear =  $('.spwearfeex2').val();
    if (spwear === 'undefined' || spwear === 'NULL' || spwear === '') {
        spwear = 0;
        }
    var contass =  $('.contassfeex2').val();
    if (contass === 'undefined' || contass === 'NULL' || contass === '') {
        contass = 0;
        }        

var fsf =  Number($('.tfees').html());
if (fsf === 'undefined' || fsf === 'NULL' || fsf === '') {
    fsf = 0;
    }
var fpf =  Number($('.pullfees').html());
if (fpf === 'undefined' || fpf === 'NULL' || fpf === '') {
    fpf = 0;
    }
var fpaf =  Number($('.partyfees').html());
if (fpaf === 'undefined' || fpaf === 'NULL' || fpaf === '') {
    fpaf = 0;
    }

    var isVisx = $('.uniformfeex2').is(':visible');
    var isViscx = $('.uniformfeex2i').is(':visible');
    if (isVisx) {
    var funi =  Number($('.uniformfees').html());
    if (funi === 'undefined' || funi === 'NULL' || funi === '') {
        funi = 0;
    } }
    else if (isViscx) {     
    var funi =  Number($('.cuniformfees').html());
    if (funi === 'undefined' || funi === 'NULL' || funi === '') {
        funi = 0;
    } }
    else {
        funi = 0;
    }
    var spwa =  Number($('.spwearfees').html());
    if (spwa === 'undefined' || spwa === 'NULL' || spwa === '') {
        spwa = 0;
    }  
    var conas =  Number($('.contassfees').html());
    if (conas === 'undefined' || conas === 'NULL' || conas === '') {
        conas = 0;
    }                
    

if (sf < fsf){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete school fees to Continue</p>");
}

if (pf < fpf){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete Pull Over fees to Continue</p>");
}
if (paf < fpaf){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete Party fees to Continue</p>");
}
if (uni < funi){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete Uniform fees to Continue</p>");
}
if (spwear < spwa){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete Sports Wear fees to Continue</p>");
}
if (contass < conas){
    $('#feebutnew').attr('disabled','disabled');
    $('#alertdiv').html("<p style='color: red;'> Please pay complete Continuous Assessment fees to Continue</p>");
}
//$('#inc_stname2').val() !== ""
if ( sf >= fsf && pf >= fpf && paf >= fpaf && uni >= funi && spwear >= spwa && contass >= conas){
    $('#feebutnew').removeAttr('disabled');
    $('#alertdiv').html("<p style='color: green;'> You can now proceed to complete.... :-)  </p>");
}

var ddtotal = Number(sf) + Number(uni) + Number(pf) + Number(paf) +  Number(spwear) + Number(contass);
var isVisz = $('.uniformfeex2').is(':visible');
console.log("changing total:" + ddtotal);
console.log("changing passkey:" + isVisz);
}

}
//daily ___summation done here
$(document).ready(function() {
   
    var sum = 0; 
    var sum2 = 0;
    var sum3 = 0;
    var sum4 = 0;
    var sum5 = 0;
    var sum6 = 0;
    var sum7 = 0;
    var sum8 = 0;
    var sum9 = 0;
    var sum10 = 0;
    var sum11 = 0;

    $('.pf_total_xx').each(function () {
        var _total = Number( $(this).text().trim() );
        sum = sum + _total;
        
    });
    $(".pf_total_grand").text(sum.toLocaleString());

    $('.pf_row_if').each(function () {
        var _total = Number( $(this).text().trim() );
        sum2 = sum2 + _total;
        
    });
    $(".pf_total_fees").text(sum2.toLocaleString());

    $('.pf_row_iod').each(function () {
        var _total = Number( $(this).text().trim() );
        sum3 = sum3 + _total;
        
    });
    $(".pf_total_old").text(sum3.toLocaleString());

    $('.pf_row_ib').each(function () {
        var _total = Number( $(this).text().trim() );
        sum4 = sum4 + _total;
        
    });
    $(".pf_total_bus").text(sum4.toLocaleString());

    $('.pf_row_icu').each(function () {
        var _total = Number( $(this).text().trim() );
        sum5 = sum5 + _total;
        
    });
    $(".pf_total_cus").text(sum5.toLocaleString());

    $('.pf_row_iu').each(function () {
        var _total = Number( $(this).text().trim() );
        sum6 = sum6 + _total;
        
    });
    $(".pf_total_uni").text(sum6.toLocaleString());

    $('.pf_row_is').each(function () {
        var _total = Number( $(this).text().trim() );
        sum7 = sum7 + _total;
        
    });
    $(".pf_total_spo").text(sum7.toLocaleString());

    $('.pf_row_ip').each(function () {
        var _total = Number( $(this).text().trim() );
        sum8 = sum8 + _total;
        
    });
    $(".pf_total_pull").text(sum8.toLocaleString());

    $('.pf_row_ica').each(function () {
        var _total = Number( $(this).text().trim() );
        sum9 = sum9 + _total;
        
    });
    $(".pf_total_cont").text(sum9.toLocaleString());

    $('.pf_row_sb').each(function () {
        var _total = Number( $(this).text().trim() );
        sum10 = sum10 + _total;
        
    });
    $(".pf_total_bank").text(sum10.toLocaleString());

    $('.pf_row_c').each(function () {
        var _total = Number( $(this).text().trim() );
        sum11 = sum11 + _total;
        
    });
    $(".pf_total_cash").text(sum11.toLocaleString());
});


$(document).on('change','#schchk',function(e){
if($("#schchk").is(':checked')) {
    $(".schfeex").attr('disabled','disabled'); }
else {
    $(".schfeex").removeAttr('disabled'); }

});
$(document).on('change','#debtchk',function(e){
    if($("#debtchk").is(':checked')) {
        $(".debtfeex").attr('disabled','disabled'); }
    else {
        $(".debtfeex").removeAttr('disabled'); }
    
    });
    $(document).on('change','#contasschk',function(e){
        if($("#contasschk").is(':checked')) {
            $(".contassfeex").attr('disabled','disabled'); }
        else {
            $(".contassfeex").removeAttr('disabled'); }
        
        });    



$('#cnewpass').keyup(validatepass);

function validatepass(){

        var password = $("#newpass").val();
        var confirmPassword = $("#cnewpass").val();
    
        if (password !== confirmPassword) {
            $("#div_conpass").addClass("has-error");
            $("#div_conpass").removeClass("has-success");
            $("#div_conpass .help-block").html("The passwords do not match...");
        }
        else {
            $("#div_conpass .help-block").html("");
            $("#div_conpass").addClass("has-success");
            $("#div_conpass").removeClass("has-error");
        }
    
}

//compulsory old students
function assigntotal(){
    console.log('done...');
    var schfee= $(".schfeex").val();
    var debtfee= $(".debtfeex").val();
    var contassfee= $(".contassfeex").val();
    var summ = Number(schfee) + Number(debtfee) + Number(contassfee);
    $('#ota').val(summ);

    var a= $("#ota").val();
    if (a === 'undefined' || a === 'NULL')
    {
        a = 0;
    }
    var b= $("#outa").val();
    if (b === 'undefined' || b === 'NULL')
    {
        b = 0;
    }
    var totalx = Number(a) + Number(b);
    $('#otta').val(totalx); $('#ogtotal').val(totalx);

}
$('.schfeex , .debtfeex, .contassfeex').keyup(assigntotal);
//not compulsory old students
function assigntotal2(){
    console.log('done2...');
    var a= $(".busfeex").val();
    var b= $(".pullfeex").val();
    var c= $(".partyfeex").val();
    
    var isVis = $('.uniformfeex').is(':visible');
    var isVisc = $('.uniformfeexi').is(':visible');
    if (isVis) {
        var d = $(".uniformfeex").val();
    }else if (isVisc) {
        var d = $(".uniformfeexi").val();
    }
    else{
        d = 0;
    }
    var e= $(".spwearfeex").val();
   

    var summ = Number(a) + Number(b) + Number(c) + Number(d) + Number(e) ;
    $('#outa').val(summ);

    var a= $("#ota").val();
    if (a === 'undefined' || a === 'NULL')
    {
        a = 0;
    }
    var b= $("#outa").val();
    if (b === 'undefined' || b === 'NULL')
    {
        b = 0;
    }
    var totalx = Number(a) + Number(b);
    $('#otta').val(totalx);
    $('#ogtotal').val(totalx);
    

}
$('.busfeex , .pullfeex , .partyfeex , .uniformfeex, .uniformfeexi, .spwearfeex ').keyup(assigntotal2);

//compulsory new students
function assigntotalnew(){
    console.log('done...');
    var schfee= $(".schfeex2").val();
    var b= $(".pullfeex2").val();
    var c= $(".partyfeex2").val();
    var isVis = $('.uniformfee2x').is(':visible');
    var isVisc = $('.uniformfee2xi').is(':visible');
    if (isVis) {
        var d = $(".uniformfee2x").val();
    }else if (isVisc) {
        var d = $(".uniformfee2xi").val();
    }
    else{
        d = 0;
    }
    var e= $(".spwearfeex2").val();
    var f= $(".contassfeex2").val();

    var summ = Number(schfee) + Number(b) + Number(c) + Number(d) + Number(e) + Number(f) ;
    $('#nta').val(summ);

    var a= $("#nta").val();
    if (a === 'undefined' || a === 'NULL')
    {
        a = 0;
    }
    var b= $("#nuta").val();
    if (b === 'undefined' || b === 'NULL')
    {
        b = 0;
    }
    var totalx = Number(a) + Number(b);
    $('#ntta').val(totalx);$('#ngtotal').val(totalx);

}
$('.schfeex2 , .pullfeex2 , .partyfeex2 , .uniformfee2x, .uniformfee2xi, .spwearfeex2, .contassfeex2').keyup(assigntotalnew);
//not compulsory new students
function assigntotalnew2(){
    console.log('done2...');
    var a= $(".busfeex2").val();
   
    var summ = Number(a);
    $('#nuta').val(summ);

    var a= $("#nta").val();
    if (a === 'undefined' || a === 'NULL')
    {
        a = 0;
    }
    var b= $("#nuta").val();
    if (b === 'undefined' || b === 'NULL')
    {
        b = 0;
    }
    var totalx = Number(a) + Number(b);
    $('#ntta').val(totalx);$('#ngtotal').val(totalx);

}
$('.busfeex2').keyup(assigntotalnew2);


/****Settings***** */
//function to Change status of user
function getManageUser(id) {

    var name = $('#mya'+id).val();
    var email = $('#myc'+id).val();
    var id = $('#myid'+id).val();
    $('#modal_id').val(id);
    $('#modal_name').val(name);
    $('#modal_email').val(email);

    $('#manageuser_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');

}
//function to Add user
function getManageUserAdd() {
    $('#manageuseradd_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');
}
//function to delete user form table
function getManageUserDel(id) {
    var name = $('#mya'+id).val();
    var email = $('#myc'+id).val();
    var id = $('#myid'+id).val();
    $('#modalxx_id').val(id);
    $('#modalxx_name').val(name);
    $('#modalxx_email').val(email);

    $('#manageuser_delmodal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');
}
/****Settings***** */


/***********Income Modals */
function updateFee(id,text) {
    
    $('.myinnerlabel').html(text);
    $('#modal_id').val(id);
    $('#incomesetfee_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');

}

function updateFeeOther(id,text) {
    
    $('.myinnerlabel').html(text);
    $('#modalx_id').val(id);
    $('#incomesetotherfee_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');

}
//Income daily modal...to get the date of report
//function to get 
function getDailyReport() {
    $('#incomegetdaily_modal').modal({
        backdrop: 'static',
        keyboard: false
    },'show');
}
//daily income of fees
function openPrintDialogue(){
    $('<iframe>', {
      name: 'myiframe',
      class: 'printFrame'
    })
    .appendTo('body')
    .contents().find('body')
    .append($('#dailytableprint'));
    $('#printdailybutton').remove();
    window.frames['myiframe'].focus();
    window.frames['myiframe'].print();
  
    //setTimeout(() => { $(".printFrame").remove(); }, 1000);
    location.reload();
    console.log('Print page clicked');
}
  
  $(document).on('click','#printdailybutton', openPrintDialogue);
//for iew of fee drive print
  function openPrintDialogue2(){
    $('<iframe>', {
      name: 'myiframe',
      class: 'printFrame'
    })
    .appendTo('body')
    .contents().find('body')
    .append($('#incfeedrive_table'));
    $('#printdailybutton2').addClass('hidden-print');
    window.frames['myiframe'].focus();
    window.frames['myiframe'].print();
  
    //setTimeout(() => { $(".printFrame").remove(); }, 1000);
    location.reload();
    console.log('Print page clicked');
}
  
  $(document).on('click','#printdailybutton2', openPrintDialogue2);

  function openPrintDialogue3(){
    $('<iframe>', {
      name: 'myiframe',
      class: 'printFrame'
    })
    .appendTo('body')
    .contents().find('body')
    .append($('#receipttableprint'));
  
    window.frames['myiframe'].focus();
    window.frames['myiframe'].print();
  
    //setTimeout(() => { $(".printFrame").remove(); }, 1000);
    location.reload();
    console.log('Print page clicked');
}
  
  $(document).on('click','#printdailybutton3', openPrintDialogue3);

  

function recfees_old(){

$('#formreefeenew').addClass('myhide');
$('#formreefeeold').removeClass('myhide');
}

function recfees_new(){

    $('#formreefeeold').addClass('myhide');
    $('#formreefeenew').removeClass('myhide');
}

$('#inc_stname').keyup(function(e){ 
          
    /*get the given typed values in the textbox*/
    var n = document.getElementById("inc_stname").value; 
   
    /*set a variable for displaying the result*/ 
          if(n === ''){ 
              $(".feesbelow").html('')
             }else{
                $(".feesbelow").hide();
                $(".feesbelow").fadeIn(900,0);
              $.ajax({
                   type: "POST",
                   url: "ajax.php",
                   dataType: "html",//expect html to be returned  
                   data:  {
                    feesreceive:n
                    },
                   success: function(data) { 
                      $(".feesbelow").show();
                      $(".feesbelow").html(data);
                      
                   },
                   error: function(xmlHttpRequest, textStatus, errorThrown)
                  {
                  alert('error ' + xmlHttpRequest);
                  }

               }); 

             } 
    });

    $('#inc_stname2').keyup(function(e){ 
          
        /*get the given typed values in the textbox*/
        var n = document.getElementById("inc_stname2").value; 
       
        /*set a variable for displaying the result*/ 
              if(n === ''){ 
                  $(".feesbelow").html('')
                 }else{
                    $(".feesbelow").hide();
                    $(".feesbelow").fadeIn(900,0);
                  $.ajax({
                       type: "POST",
                       url: "ajax.php",
                       dataType: "html",//expect html to be returned  
                       data:  {
                        feesreceive2:n
                        },
                       success: function(data) { 
                          $(".feesbelow").show();
                          $(".feesbelow").html(data);
                          
                       },
                       error: function(xmlHttpRequest, textStatus, errorThrown)
                      {
                      alert('error ' + xmlHttpRequest);
                      }
    
                   }); 
    
                 } 
        });
//on clikc for ajax field
$(document).on('click','.evaluateoutput',function(e){

    var cat = $(this).find('#evalcat').val();
    var stu = $(this).find('#evalstu').val();
    $.ajax({
        type: "POST",
        url: "ajax.php",
        dataType: "json",//expect html to be returned  
        data:  {
         setcategory:cat,setstudent:stu
         },
        success: function(data) { 
           console.log(data);
          var fee = JSON.parse(JSON.stringify(data));
          
          $('.paiddiv').html(fee.J);
          $('.tfees').html(fee.A);
        
          $('.oldfees').html(fee.B);
          $('.oldbusfees').html(fee.K);
          $('.busfees').html(fee.C);
          $('.pullfees').html(fee.D);
          $('.partyfees').html(fee.E);
          $('.uniformfees').html(fee.F);
          $('.cuniformfees').html(fee.G);
          $('.spwearfees').html(fee.H);
          $('.contassfees').html(fee.I);

          $('#orischfee').val(fee.A);
          $('#oribusfee').val(fee.C); 
        },
        error: function(xmlHttpRequest, textStatus, errorThrown)
       {
       alert('error ' + textStatus);
       }

    });
    

    var id = $(this).find('#evalid').val();
    var reg = $(this).find('#evalregno').val();
    $('#inc_stname').val(reg);
    $('#stu_cls').val(id);
    $('.feesbelow').html('');


});  


$(document).on('click','.evaluateoutput2',function(e){

    var cat = $(this).find('#evalcat2').val();
    var stu = $(this).find('#evalstu2').val();
    $.ajax({
        type: "POST",
        url: "ajax.php",
        dataType: "json",//expect html to be returned  
        data:  {
         setcategory:cat,setstudent:stu
         },
        success: function(data) { 
           console.log(data);
          var fee = JSON.parse(JSON.stringify(data));
         
          $('.tfees').html(fee.A);
          $('.oldfees').html(fee.B);
          $('.oldbusfees').html(fee.K);
          $('.busfees').html(fee.C);
          $('.pullfees').html(fee.D);
          $('.partyfees').html(fee.E);
          $('.uniformfees').html(fee.F);
          $('.cuniformfees').html(fee.G);
          $('.spwearfees').html(fee.H);
          $('.contassfees').html(fee.I);
          $('#oribusfee2').val(fee.C);
           
        },
        error: function(xmlHttpRequest, textStatus, errorThrown)
       {
       alert('error ' + xmlHttpRequest);
       }

    });
    

    var id = $(this).find('#evalid2').val();
    var reg = $(this).find('#evalregno2').val();
   

    $('#inc_stname2').val(reg);
    $('#stu_cls2').val(id);
    $('.feesbelow').html('');

});  

//change mode of payment
$(document).on('change','.modepay',function(e){
    var mode = $(this).val();

    if (mode == 'bank') {

        $('#modebank').removeClass('myhide');
        $('#modebank').attr('required','required');
    } else {
        $('#modebank').addClass('myhide');
        $('#modebank').removeAttr('required');
    }

});
//change mode of payment---new students
$(document).on('change','.modepay2',function(e){
    var mode = $(this).val();

    if (mode == 'bank') {

        $('#modebank2').removeClass('myhide');
        $('#modebank2').attr('required','required');
    } else {
        $('#modebank2').addClass('myhide');
        $('#modebank2').removeAttr('required');
    }

});
//change uniform type.....
$(document).on('change','#unichoice',function(e){
    var typpe = $(this).val();

    if (typpe == 'regular') {
        console.log('check change');
        $('#uniformdiv21').addClass('greatman');

        $('#uniformdiv21').removeClass('myhide');
        $('.uniformfeex2').attr('required','required');
        $('#uniformdiv22').addClass('myhide');

        $('.uniformfeex2i').removeAttr('required');

        $('.uniformfeex2').removeAttr('disabled','disabled');
        $('.uniformfeex2i').attr('disabled','disabled');
    } 
    else if (typpe == 'custom') {

        $('#uniformdiv22').removeClass('myhide');
        $('.uniformfeex2i').attr('required','required');
        $('#uniformdiv21').addClass('myhide');

        $('.uniformfeex2').removeAttr('required');

        $('.uniformfeex2i').removeAttr('disabled','disabled');
        $('.uniformfeex2').attr('disabled','disabled');
    } 
    else {
        $('#uniformdiv21').addClass('myhide');
        $('.uniformfeex2').removeAttr('required');
        $('#uniformdiv22').addClass('myhide');
        $('.uniformfeex2i').removeAttr('required');

       // $('.uniformfeex2').attr('disabled','disabled');
       // $('.uniformfeex2i').attr('disabled','disabled');
    }

});


//change uniform type.....old students
$(document).on('change','#unichoicez',function(e){
    var typpe = $(this).val();

    if (typpe == 'regular') {

        $('#uniformdiv').removeClass('myhide');
        $('.uniformfeex').attr('required','required');
        $('#uniformdiv2').addClass('myhide');
        $('.uniformfeexi').removeAttr('required');

        $('.uniformfeex').removeAttr('disabled','disabled');
        $('.uniformfeexi').attr('disabled','disabled');
    } 
    else if (typpe == 'custom') {

        $('#uniformdiv2').removeClass('myhide');
        $('.uniformfeexi').attr('required','required');
        $('#uniformdiv').addClass('myhide');

        $('.uniformfeex').removeAttr('required');

        $('.uniformfeexi').removeAttr('disabled','disabled');
        $('.uniformfeex').attr('disabled','disabled');
    } 
    else {
        $('#uniformdiv').addClass('myhide');
        $('.uniformfeex').removeAttr('required');
        $('#uniformdiv2').addClass('myhide');
        $('.uniformfeexi').removeAttr('required');

       // $('.uniformfeex2').attr('disabled','disabled');
       // $('.uniformfeex2i').attr('disabled','disabled');
    }

});