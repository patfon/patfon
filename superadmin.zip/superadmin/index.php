            <?php include 'includes/general/header.php'; ?>
            
            

            <div id="content" style="height: 80%;">
                
            <?php include 'includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
                
            <div id="content" style="min-height: 400px;">
                <div id="right">
                
                            <div class="box">
                                    <div class="title">
                                    <h5>My Service</h5>
                                </div>
                            <div class="messages" align="left">
                            
                            
                                <div id="message-warning" class="message message-warning" style="background:#f0f7e7;border-color:#F3E0E0;width: 800px;">
                                    <div class="image">
                                            </div>
                                        <div class="text" align="left">
                                            
                                            <a href="/author/paper_load_submitPaperCategoryOfJournal" target="_blank">
                                            <img src="../spg/decorator/resources/images/define/1.1.jpg" style="padding-left: 0px;">
                                            </a>
                                            <a href="/author/paper_load_submitPaperCategory" target="_blank">
                                            <img src="../spg/decorator/resources/images/define/1.2.jpg" style="padding-left: 33px;">
                                            </a>
                                            <div style="clear:both;"></div>
                                                </div>
                                    </div>
                                    
                            
                            
                            
                            
                                    <div id="message-warning" class="message message-warning" style="background:#eaf6f8 ;border-color:#F3E0E0;width: auto; margin-bottom: 40px;">
                                    <div class="image">
                                            </div>
                                        <div class="text" align="left">
                                            
                                            <a href="/common/joinaseditorialmember" target="_blank">
                                            <img src="../spg/decorator/resources/images/define/2.1.jpg" style="padding-left: 0px;">
                                            </a>
                                            <a href="/common/joinasreviewer" target="_blank">
                                            <img src="../spg/decorator/resources/images/define/2.2.jpg" style="padding-left: 33px;">
                                            </a>
                                            <div style="clear:both;"></div>
                                                </div>
                                    </div>
                                    
                            </div>
                            
                    </div>
            
            </div>
            
            </div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include 'includes/general/footer.php'; ?>