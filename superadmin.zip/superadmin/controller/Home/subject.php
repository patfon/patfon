<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Subject

if (isset($_POST['butadd'])){

$myfields = $_POST['subject'];

foreach($myfields as $myf){
    $myfield =  mysqli_real_escape_string($pdb,$myf);

    $query = ("INSERT INTO subject (_name,_category) 
    VALUES (' $myfield','' ) ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addsubject'] = 1;
            header('Location: ../../includes/home/subjects.php');
    }

}

}
//update a new Subject
if (isset($_POST['butupdate'])){

    $myid = $_POST['subid'];
    $mysub = $_POST['subject'];
    
  
        $mysub =  mysqli_real_escape_string($pdb,$mysub);
    
        $query = ("UPDATE subject SET _name = '$mysub' WHERE id = $myid ");
    
        if (mysqli_query($pdb, $query)) {
                $_SESSION['msg']['updatesubject'] = 1;
                header('Location: ../../includes/home/subjects.php');
        }
    
    
    
    }