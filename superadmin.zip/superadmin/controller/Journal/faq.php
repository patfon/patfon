<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new Subject

if (isset($_POST['butadd'])){

$myfields = $_POST['question'];
$myfield2s = $_POST['ans'];
$mycount = count($_POST['question']);
for($i = 0; $i < $mycount; $i++){
   
    $myfield =  mysqli_real_escape_string($pdb,$myfields[$i]);
    $myfield2 =  mysqli_real_escape_string($pdb,$myfield2s[$i]);

    $query = ("INSERT INTO faq (_question,_ans) 
    VALUES ('$myfield','$myfield2' ) ");

    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addjournal'] = 1;
            header('Location: ../../includes/journal/faq.php');
    }

    
}

}

//update a new faq
if (isset($_POST['butupdate'])){

    $myid = $_POST['faqid'];
    $myqu = $_POST['question'];
    $myans = $_POST['ans'];
    
  
        $myqu =  mysqli_real_escape_string($pdb,$myqu);
        $myans =  mysqli_real_escape_string($pdb,$myans);
    
        $query = ("UPDATE faq SET _question = '$myqu', _ans= '$myans' WHERE id = $myid ");
    
        if (mysqli_query($pdb, $query)) {
                $_SESSION['msg']['updatejournal'] = 1;
                header('Location: ../../includes/journal/faq.php');
        }
    
    
    
    }