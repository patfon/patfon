<?php include '../../includes/general/header.php'; ?>
            
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>

<?php if (isset($_GET['confirmid'])){ 
      $myid = $_GET['confirmid'];
      $myid2 = $_GET['artid'];
      publisharticle($pdb,$myid,$myid2);
}
    ?>
    <?php if (isset($_GET['rejid'])){ 
      $myid = $_GET['rejid'];
      $myid2 = $_GET['artid'];
      unpublisharticle($pdb,$myid,$myid2);
}
    ?>

            <div id="content" style="height: 80%;">
                
            <?php include '../../includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                <div class="box">
            <!--Alert msg-->
            <?php if (isset($_SESSION['msg']['confirmjournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> Article has been Published..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['confirmjournal']); ?>
            <?php if (isset($_SESSION['msg']['rejectjournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-error">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> Article has been Unpublished..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['rejectjournal']); ?>
             <!--end Alert msg-->

<!-- First Header showing Example-->
                <div>

                <div id="box-tabs" class="box">
                    <!-- box / title -->
                            <div class="title">
                                        <h5>Published Articles Example</h5>
                                    </div>
                                    <!-- box / title -->
                                    <div id="box-messages">
                                        <div class="messages">
                            <div id="ctl00_ContentPlaceHolder1_BoxMessage_Info_Panel_SuccessMessage">
                                <div id="message-success" class="message message-warning">
                                                <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                            <h6>Examples</h6>
                                            <span id="examples"> An article is published after payment has been confirmed and every thing is okay for presentation. </span>
                                            </div>
                                </div>
                            </div>
                                        </div>
                                    </div>
                </div>
                </div>
<!-- end First Header showing Example-->
<!-- Second Header showing Table List-->
                        <div class="title">
                        <h5>List Articles Information</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:16px;padding-right:16px;">
                               
                                    <?php $sub = getarticlesaccept($pdb); ?>
                                    <table class="mydatatables" width="100%">
                                        
                                       <thead  style="color: #fff; ">
                                       <tr>
                                       <td class="tablehead">S/N </td> <td class="tablehead">Name of Author </td> <td class="tablehead"> Article ID </td> 
                                       <td class="tablehead"> Title Of Article </td>  <td class="tablehead"> Journal Category </td>   
                                       <td class="tablehead"> Status</td>  
                                       <td class="tablehead">Action </td>
                                       </tr>
                                       </thead>

                                        <tbody>
                                      <?php  
                                      $i = 1;
                                      if (!empty($sub)) {
                                      foreach ($sub as $s){ ?>
                                            <tr> <td> <?php echo $i; ?></td> <td> <?php echo getusername($pdb,$s['_userid']); ?></td> <td> <?php echo $s['_articleid']; ?></td> 
                                            <td> <?php echo $s['_title']; ?></td> <td> <?php echo getjournalname($pdb,$s['_journalid']); ?></td> 
                                           <td> <?php if ($s['_pubdate'] === "1970-10-10") { echo 'UNPUBLISHED'; } else { echo 'PUBLISHED'; }  ?></td>
                                            <td> 
                                            <?php if ($s['_pubdate'] === "1970-10-10") { ?>
                                            <a href="publish.php?confirmid=<?php echo $s['id']; ?>&artid=<?php echo $s['_articleid']; ?>" onclick="return confirm('Are you sure you want to publish this?')">Publish Article</a>
                                            <?php } else { ?>
                                            &nbsp;&nbsp;&nbsp;<a href="publish.php?rejid=<?php echo $s['id']; ?>&artid=<?php echo $s['_articleid']; ?>" target="_blank" >Unpublish Article</a></td>
                                            <?php  } ?>
                                            </tr>
                                      <?php $i++;} } else { ?>
                                        <tr> <td colspan="6" style="text-align: center;"> No Article has been accepted yet. </td></tr>

                                      <?php } ?>
                                        </tbody>
                                    </table>
                                   
                                
                            </div>             
<!-- end Second Header showing Table List-->                    
                            <!-- Add New Subjects to the Group-->
                                 
                            <!--   Add new Subjects end -->
                        </div> 
            
                </div>
            
            </div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include '../../includes/general/footer.php'; ?>