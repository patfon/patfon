<div id="left">
                    <div id="menu">
                        <h6 id="h-menu" class="selected"><a href="#products"><span>Home</span></a></h6>
                        <ul id="menu-home" class="opened" style="display:block;">
                                <li><a href="<?php echo $myurl.'includes/home/subjects.php'; ?>">Subjects</a></li>
                               
                                <li><a href="<?php echo $myurl.'includes/home/slide.php'; ?>">Slides</a></li>
                                <li><a href="<?php echo $myurl.'includes/home/about.php'; ?>">About</a></li>
                                <li><a href="<?php echo $myurl.'includes/home/testimonial.php'; ?>">Testimonials</a></li>
                                <li><a href="<?php echo $myurl.'includes/home/partners.php'; ?>">Partners</a></li>
                                
                        </ul>
                        <h6 id="h-menu" class="selected"><a href="#pages"><span>Journal</span></a></h6>
                        <ul id="menu-journal" class="opened" style="display:block;">
                         <li><a href="<?php echo $myurl.'includes/journal/list.php'; ?>">Journal List</a></li>
                         <li><a href="<?php echo $myurl.'includes/journal/volume.php'; ?>">Volumes & Issues</a></li>
                         <li><a href="<?php echo $myurl.'includes/journal/editorial.php'; ?>">Editorial Board</a></li>		
                         <li><a href="<?php echo $myurl.'includes/journal/reviewers.php'; ?>">Peer Reviewers</a></li>		
                         <li><a href="<?php echo $myurl.'includes/journal/guidelines.php'; ?>">Journal Guidelines</a></li>
                         <li><a href="<?php echo $myurl.'includes/journal/apc.php'; ?>">Article Processing Fees</a></li>	
                         <li><a href="<?php echo $myurl.'includes/journal/ethics.php'; ?>">Publication Ethics</a></li>
                         <li><a href="<?php echo $myurl.'includes/journal/copyright.php'; ?>">Copy Right</a></li>		
                         <li><a href="<?php echo $myurl.'includes/journal/faq.php'; ?>">FAQ</a></li>			
                        </ul>
                       
                       
                        <h6 id="h-menu" class="selected"><a href="#join"><span>News</span></a></h6>
                        <ul id="menu-news" class="opened" style="display:block;">
                         <li><a href="<?php echo $myurl.'includes/news/list.php'; ?>">All News</a></li>		
                     
                        </ul>
                       <h6 id="h-menu" class="selected"><a href="#links"><span>Submissions</span></a></h6>
                        <ul id="menu-sub" class="opened" style="display:block;">
                           <li><a href="#">Statistics</a></li>
                           <li><a href="<?php echo $myurl.'includes/submission/verifypay.php'; ?>">Verify Payment</a></li>
                           <li><a href="<?php echo $myurl.'includes/submission/accept.php'; ?>">Accept/Reject Article </a></li>
                           <li><a href="<?php echo $myurl.'includes/submission/publish.php'; ?>">Publish Article</a></li>
                          
                        </ul>
                       <h6 id="h-menu" class="selected"><a href="#links"><span>Users</span></a></h6>
                        <ul id="menu-users" class="opened" style="display:block;">
                           <li><a href="#">Statistics</a></li>
                           <li><a href="#">Applications</a></li>
                           <li><a href="<?php echo $myurl.'includes/users/list.php'; ?>"> View Users </a></li>
                         
                          
                        </ul> 
                     
                        <h6 id="h-menu" class="selected"><a href="#links"><span>Company</span></a></h6>
                        <ul id="menu-company" class="opened" style="display:block;">
                           <li><a href="#">Website Profile</a></li>
                        </ul>    

                       </div>
        <div id="date-picker"></div>  
</div>