<?php include '../../includes/general/header.php'; ?>
            
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>



            <div id="content" style="height: 80%;">
                
            <?php include '../../includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                <div class="box">
                   <!--Alert msg-->
                   <?php if (isset($_SESSION['msg']['addjournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> A new guideline has been Added..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['addjournal']); ?>
            <?php if (isset($_SESSION['msg']['updatejournal'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> The previous guideline has been Updated..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['updatejournal']); ?>
                    <!--end Alert msg-->
<!-- First Header showing Example-->
                <div>

                <div id="box-tabs" class="box">
                    <!-- box / title -->
                            <div class="title">
                                        <h5>Guideline Example</h5>
                                    </div>
                                    <!-- box / title -->
                                    <div id="box-messages">
                                        <div class="messages">
                            <div id="ctl00_ContentPlaceHolder1_BoxMessage_Info_Panel_SuccessMessage">
                                <div id="message-success" class="message message-notice">
                                                <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                            <h6>Examples</h6>
                                            <span id="examples"> Please follow the template example in the Frame Below. </span>
                                            </div>
                                </div>
                            </div>
                                        </div>
                                    </div>
                </div>
                </div>
<!-- end First Header showing Example-->
<!-- Second Header showing Table List-->
                        <div class="title">
                        <h5>Sample Template</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:16px;padding-right:16px;">
                               
                            <iframe id="iframe" src="iframe/guidelines.html" height="500" width="100%"></iframe>
                                   
                           </div>             
<!-- end Second Header showing Table List-->                    
                            <!-- Add New Subjects to the Group-->
                            <!-- box / title -->
                        <div class="title">
                        <h5>Copy and Paste HTML Markup here!</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:35px;padding-right:35px;">
                            <form id="profilefrom2" action="<?php echo $myurl.'controller/Journal/guidelines.php'; ?>" method="post">
                            <textarea class="myeditarea" name="jguideline" > 
                            <?php $mycot = getpagecontent($pdb,'journal_guide'); ?>
                            <?php if (isset($mycot)){ 
                                echo $mycot;
                            } ?>
                            </textarea> <br><br>
                            <div class="buttons" style="text-align:center;padding-top:10px;margin:0;padding-left:400px;x;border-top:1px solid #DDD;">
                                          <div class="highlight" style="float:left;margin-left:20px;">
                                            <input type="submit" name="butadd" id="next1" value="Update GuideLines Page" class="ui-button ui-widget ui-state-default ui-corner-all" style="cursor:pointer;" role="button" aria-disabled="false">
                                        </div>
                                        <div style="clear:both;height:1px;margin-top:-1px;overflow: hidden;"></div>
                                    </div>
                        </form>  
                           </div>      
                            <!--   Add new Subjects end -->
                        </div> 
            
                </div>
            
            </div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include '../../includes/general/footer.php'; ?>