<?php include '../../includes/general/header.php'; ?>
            
<?php include '../../classes/connection.php' ; ?>            
<?php include '../../functions/index.php'; ?>



            <div id="content" style="height: 80%;">
                
            <?php include '../../includes/general/menu.php'; ?>
                   
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                <div class="box">
                   <!--Alert msg-->
                   <?php if (isset($_SESSION['msg']['addabout'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> The About Page has been Inserted..</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['addabout']); ?>
            <?php if (isset($_SESSION['msg']['updateabout'])) { ?>
            <div id="box-messages">
                    <div class="messages">
                            <div id="">
                                <div id="message-success" class="message message-success">
                                            <div class="image">
                                        <img src="<?php echo $myurl.'images/notice.png'; ?>" height="32">
                                            </div>
                                            <div class="text" style="line-height: 20px;">
                                           
                                            <span id="examples"> The About Page has been Updated.</span>
                                            </div>
                                </div>
                            </div>
                    </div>
            </div>
            <?php  } unset($_SESSION['msg']['updateabout']); ?>
              
             <!--end Alert msg-->

<!-- First Header showing Example-->
          
<!-- end First Header showing Example-->
<!-- Second Header showing Table List-->
                        <div class="title">
                        <h5>About Website</h5>
                        </div>
                        <!-- end box / title -->
                        
                            <div id="form2" style="padding-left:16px;padding-right:16px;">
                            <form id="profilefrom2" action="<?php echo $myurl.'controller/Home/page.php'; ?>" method="post">
                                    <?php $sub = getsubjects($pdb); ?>
                                    <table width="100%" cellspacing="5" cellpadding="10" height="400" >
                                      
                                        <tbody>
                                     
                                    
                 <tr> <td> <?php echo 'Title: '; ?></td>
                 <td> <input type="text" class="form2input" value="<?php echo getpagecontent($pdb,'about_title'); ?>" name="title" > </td>
                 </tr>
                 <tr> <td> <?php echo 'Story: '; ?></td>
                 <td> <textarea class="form2input" cols="10" rows="10" name="story" ><?php echo getpagecontent($pdb,'about_story'); ?> </textarea></td>
                 </tr> 
                 <tr> <td> <?php echo 'Mission: '; ?></td>
                 <td> <textarea class="form2input" cols="10" rows="10" name="mission" ><?php echo getpagecontent($pdb,'about_mission'); ?> </textarea></td>
                 </tr>                    
                                        
                                        </tbody>
                                    </table>
                                    <div class="buttons" style="text-align:center;padding-top:10px;margin:0;padding-left:400px;x;border-top:1px solid #DDD;">
                                        <input type="reset" name="reset" value="Reset" class="ui-button ui-widget ui-state-default ui-corner-all ui-state-hover" style="float:left;cursor:pointer;" role="button" aria-disabled="false">
                                        <div class="highlight" style="float:left;margin-left:20px;">
                                            <input type="submit" name="butabout" id="next1" value="Submit" class="ui-button ui-widget ui-state-default ui-corner-all" style="cursor:pointer;" role="button" aria-disabled="false">
                                        </div>
                                        <div style="clear:both;height:1px;margin-top:-1px;overflow: hidden;"></div>
                                    </div>
                                </form>
                                   
                                
                            </div>             
<!-- end Second Header showing Table List-->                    
                            <!-- Add New Subjects to the Group-->

                             <!-- end add New Subjects to the Group-->
                        </div> 
            
                </div>
            
            </div>
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include '../../includes/general/footer.php'; ?>