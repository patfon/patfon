<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php $_SESSION['cur-page'] = "Income > Daily Fee Report"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) {  
        //directly from income_controller..........
        $mydata = $_SESSION['patfonuser']['dailyfees'];
        $myterm = $_SESSION['patfonuser']['term'];
        $mysch = intval($_SESSION['patfonuser']['school']);
        $theyear = date("Y", strtotime($_SESSION['patfonuser']['dailydate']));
        $stu_st = array('0'=>"Old",'1'=>"New");

        $timestamp = strtotime($_SESSION['patfonuser']['dailydate'] );
        $new_date = date('M d', $timestamp);
      
        ?>
<?php
include('functions/index.php');
include('includes/header.php');
?>
<section style="overflow-x: scroll; " id="main-content">
<section id="dailytableprint" class="wrapper">
        <div class= "row">
                <div class=" col-md-12">
                        <div>
                        <h4 class="center-block col-xs-offset-3"><?php echo getschoolname($pdb,$_SESSION['patfonuser']['school']); ?></h4>
                        <p>Daily Income Summary For the Day of <b><?php echo $new_date .", ".$theyear; ?> </b> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <input type="button" id="printdailybutton" value="Print Table" class="btn btn-danger" ></p>
                        <table id="incdaily_table" class="table table-bordered table-responsive table-striped" border="1" cellspacing="2" cellpadding="2">
                        <thead>
                        <tr>
                        <th>S/N</th> <th>Old/New</th> <th>Name</th>  <th>Class</th>  <th>Date</th>     
                        <th>Fees</th> <th>Old Debts</th> <th>Bus</th> <th>C.Uniform</th> <th>Uniform</th> <th>Sport Wear</th>
                        <th>Pullover</th> <th>Continous Assessment</th> <th>Bank</th> <th>Cash</th> <th>Total</th>
                        </tr>
                        
                        </thead>
                        <tbody>
                        <?php
                        $i = 1;
                        //
                        //
                        foreach ($mydata as $dd) { ?>
                        <tr>
                        <td><?php echo $i; ?></td> 
                        <td><?php echo $stu_st[getstudentneworold($pdb,$dd)]; ?>  </td> <td><?php echo getstudentname($pdb,$dd); ?>  </td> <td> <?php echo getstudentclass($pdb,$dd); ?> </td> <td> <?php echo $new_date; ?>  </td> 
                        <td class="pf_row_i"><?php echo getstudentpaidx($pdb,$dd,99,$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_i"><?php echo getstudentpaidx($pdb,$dd,100,$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_i"><?php echo getstudentpaidx($pdb,$dd,2,$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_i"><?php echo getstudentpaidx($pdb,$dd,3,$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_i"><?php echo getstudentpaidx($pdb,$dd,1,$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_i"><?php echo getstudentpaidx($pdb,$dd,4,$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_i"><?php echo getstudentpaidx($pdb,$dd,5,$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_i"><?php echo getstudentpaidx($pdb,$dd,6,$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_b"><?php echo getstudentpaymode($pdb,$dd,'bank',$theyear,intval($myterm),$mysch); ?></td> 
                        <td class="pf_row_c"><?php echo getstudentpaymode($pdb,$dd,'cash',$theyear,intval($myterm),$mysch); ?></td> 
                      
                        <td class="pf_total_vi"><?php 
                        $cashmde = getstudentpaymode($pdb,$dd,'cash',$theyear,intval($myterm),$mysch);
                        $bankmde = getstudentpaymode($pdb,$dd,'bank',$theyear,intval($myterm),$mysch);

                        if ($cashmde > 0 ) {
                                echo number_format($cashmde);
                        }
                        else {
                                echo number_format($bankmde);
                        }
                        ?> </td>
                         </tr>
                        <?php  } ?>
                        </tbody>
                        
                        </table>
                        </div>
                </div>
    </div>
</section>
</section>


<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 