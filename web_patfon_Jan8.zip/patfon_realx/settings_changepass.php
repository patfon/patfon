<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php include 'functions/index.php' ; ?>

<?php $_SESSION['cur-page'] = "Settings > Change Password"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
include('includes/header.php');
?>
<section id="main-content">
	<section class="wrapper">

    <div class="row">
            <div class="col-md-8 col-md-offset-2" style="margin-top: 30px;">

                        <?php  if(isset($_SESSION['success'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;You have successfully changed your security key / login password.
                            </div>                             
                        <?php unset($_SESSION['success']); } ?>
                        <?php  if(isset($_SESSION['failed'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;Your previous security key is not correct.
                            </div>                             
                        <?php unset($_SESSION['failed']); } ?>
                        
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"> SET NEW PASSWORD </h3>
                    </div>
                    <div class="panel-body">
                    
                        <form role="form" action=<?php echo $myurl."config/settings_controller.php"; ?> method="post">
                            <fieldset>
                                <div class="form-group">
                                    <label class="">Old Password</label>

                                   <input type="password" class="form-control" name="oldpass" value="" required="required"> </input>
                                </div>
                                <div class="form-group">
                                <label class="">New Password</label>

                                <input type="password" id="newpass" class="form-control" name="newpass" required="required"> </input>
                                </div>
                                <div class="form-group" id="div_conpass">
                                   <label class="">Confirm New Password</label>

                                   <input type="password"  id="cnewpass"  class="form-control" name="newpass2"> </input>
                                   <span class="help-block" style="color: red; font-size: 10px; font-weight: bold;">.</span>
                                </div>
                                <div class="form-group">
                               
                                    <input class="btn btn-info" value="Change Password" name="changepassbut" type="submit" >
                                </div>
                               
                                <!-- Change this to a button or input when using this as a form -->
                            
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </section>
</section>
<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 