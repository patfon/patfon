<?php session_start(); ?>
<?php $_SESSION['cur-page'] = "Expenditure"; ?>
<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
//header
require('includes/header.php');
?>

<?php
//expenditure menus
require('includes/exp_menu.php');
?>
<?php
//footer
require('includes/footer2.php');
 ?>

<?php } else { 
    
    header("Location: login.php");
 } ?> 