<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php $_SESSION['cur-page'] = "Settings > Manage Users"; ?>

<?php if ( isset($_SESSION['patfonuser']) ) { ?>
<?php
include('functions/index.php');
include('includes/header.php');
?>
<section id="main-content">
	<section class="wrapper">
    <?php if ($_SESSION['patfonuser']['role'] == "super") { ?> 
    <div class="col-md-3" style="margin-bottom: 70px;">
    <button class="btn btn-block btn-info" onclick="getManageUserAdd()">Add A new User</button>
    </div>
    <?php } ?>
    <div class="row">
    
                        <?php  if(isset($_SESSION['success'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully changed the session and term.
                            </div>                             
                        <?php unset($_SESSION['success']); } ?>
                        <?php  if(isset($_SESSION['success_add'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully added a new User.
                            </div>                             
                        <?php unset($_SESSION['success_add']); } ?>
                        <?php  if(isset($_SESSION['success_del'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully deleted a existing User.
                            </div>                             
                        <?php unset($_SESSION['success_del']); } ?>
                        <?php  if(isset($_SESSION['failed'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.Your security key is not correct. Please try again.
                            </div>                             
                        <?php unset($_SESSION['failed']); } ?>
<div class="table-agile-info">
 <div class="panel panel-default">
 <!---728x90 -->
    <div class="panel-heading">
    Manage Users
    </div>
    <div>
      <table id="patfon_table" class="table">
        <thead>
          <tr>
            <th >ID</th>
            <th>Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>Status</th>
            <?php if ($_SESSION['patfonuser']['role'] == "super") { ?> 
            <th>Action</th>
            <th>Delete</th>
            <?php } ?>
          </tr>
        </thead>
        <tbody>
        <?php 
        $i = 1;
        $status = array('1'=>"ACTIVE",'0'=>"BLOCKED");
        $usx = getusers($pdb,$_SESSION['patfonuser']['id']); 
        foreach ($usx as $u) {
        ?>
          <tr data-expanded="true">
            <td><?php echo $i ?> <input id="<?php echo "myid$i" ?>" type="hidden" value="<?php echo $u['id']; ?>"> </td>
            <td><?php echo $u['name']; ?> <input id="<?php echo "mya$i" ?>" type="hidden" value="<?php echo $u['name']; ?>"></td>
            <td><?php echo $u['pnum']; ?> <input id="<?php echo "myb$i" ?>" type="hidden" value="<?php echo $u['pnum']; ?>"></td>
            <td><?php echo $u['email']; ?> <input id="<?php echo "myc$i" ?>" type="hidden" value="<?php echo $u['email']; ?>" </td>
            <td><?php echo $status[$u['status']]; ?>  <input id="<?php echo "myd$i" ?>" type="hidden" value="<?php echo $u['status']; ?>" </td>
            <?php if ($_SESSION['patfonuser']['role'] == "super") { ?> 
            <td>
             &nbsp; &nbsp;
            <button onclick="getManageUser('<?php echo $i; ?>')" class=" btn btn-danger">Change Status</button>
            </td>
            <td>
             &nbsp; &nbsp;
            <button onclick="getManageUserDel('<?php echo $i; ?>')" class=" btn btn-danger">Delete This User</button>
            </td>
            <?php } ?>
          </tr>
        <?php $i++; }  ?>  
         
        </tbody>
      </table>
    </div>
	<!-- 728x90 -->
  </div>
</div>
    </div>
</section>
</section>
<?php
//modals
include('pages/settings/modals.php');
 ?>

<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 