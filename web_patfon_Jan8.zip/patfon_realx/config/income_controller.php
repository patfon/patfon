<?php session_start(); ?>
<?php include '../classes/connection.php' ; 

if (isset($_POST['income_feebut'])) {
    $cat =  intval($_POST['myid']) ;
    $amt =  $_POST['amt'] ;

    $id =  $_SESSION['patfonuser']['id'];
    $sk = $_SESSION['patfonuser']['school'];

   
    $query = ("UPDATE class_fees SET fee = $amt WHERE school = $sk and category = $cat ");
   
    
   if (mysqli_query($pdb, $query)){
    
    $_SESSION['success'] = 1;
    header("Location: ../income_set_fee.php ");
   }
   else{

    $_SESSION['failed'] = 1;
    header("Location: ../income_set_fee.php "); 
    }
    
}

if (isset($_POST['income_feeotherbut'])) {
    $cat =  intval($_POST['myid']) ;
    $amt =  $_POST['amt'] ;

    $id =  $_SESSION['patfonuser']['id'];
    $sk = $_SESSION['patfonuser']['school'];

   if ($cat == 1) {
    $query = ("UPDATE class_fees SET bus = $amt WHERE school = $sk ");
   }
   else if ($cat == 2) {
    $query = ("UPDATE class_fees SET pullover = $amt WHERE school = $sk ");
   }
   else if ($cat == 3) {
    $query = ("UPDATE class_fees SET party = $amt WHERE school = $sk ");
   }
   else if ($cat == 4) {
    $query = ("UPDATE class_fees SET uniform = $amt WHERE school = $sk ");
   }
   else if ($cat == 5) {
    $query = ("UPDATE class_fees SET c_uniform = $amt WHERE school = $sk ");
   }
   else if ($cat == 6) {
    $query = ("UPDATE class_fees SET sp_wear = $amt WHERE school = $sk ");
   }
   else if ($cat == 7) {
    $query = ("UPDATE class_fees SET ca = $amt WHERE school = $sk ");
   }
    
   if (mysqli_query($pdb, $query)){
    
    $_SESSION['success_i'] = 1;
    header("Location: ../income_set_fee.php ");
   }
   else{

    $_SESSION['failed'] = 1;
    header("Location: ../income_set_fee.php "); 
    }
    
}

//get results for daily report
if (isset($_POST['income_dailybut'])) {
    $thedate = $_POST['thedate'];
    //$theyear = date("y", strtotime($thedate));
    $theschool = $_SESSION['patfonuser']['school'];
    $theterm = $_SESSION['patfonuser']['term'];
    $_SESSION['patfonuser']['dailydate'] = $thedate;

    $src = array();
    $sql = " SELECT distinct stu_id as st FROM student_fees WHERE date_pay = '$thedate' AND school = $theschool AND term = $theterm ";
    $result = mysqli_query($pdb,$sql) or die(mysqli_error($pdb));
    if (mysqli_num_rows($result) > 0) {
    while ($rows = mysqli_fetch_array ($result, MYSQLI_ASSOC)) {
        $src[] = $rows['st'];
    }
    $_SESSION['success'] = 1;
    $_SESSION['patfonuser']['dailyfees'] = $src;
    header("Location: ../income_daily.php ");
}
else{
    $_SESSION['failed'] = 1;
    header("Location: ../income.php "); 
}

}


if (isset($_POST['income_recfeeoldbut'])) {
//mysqli_real_escape_string(
    $stuid = $_SESSION['patfonuser']['studentid'];
    $te = $_SESSION['patfonuser']['term'];
    $userid = $_SESSION['patfonuser']['id'];
    $skool = $_SESSION['patfonuser']['school'];
   
        $modepay = $_POST['modepay'];

        if ($modepay === 'bank'){
            $bankname = $_POST['modebk'];
        }
        else{
            $bankname = "";
        }

        if (isset($_POST['schfee']) && ($_POST['schfee'] > 0) ) {
            $schfee = $_POST['schfee'];
            $schfeeori = $_POST['schfeeori'];  
            if ($schfee < $schfeeori){
            $bal = $schfeeori - $schfee;
            $querydebt = ("UPDATE student SET debt = debt + $bal WHERE id = $stuid ");
            mysqli_query($pdb, $querydebt);
            }
            else {
            $bal = 0;   
            }
            if ( $schfeeori < $schfee ){
            $extra = $schfee - $schfeeori;
            }
            else {
            $extra = 0;   
            }
        }
        else{
            $schfee = 0;
        }

        //
        
        //
        if (isset($_POST['contass'])) {
            $contfee =  $_POST['contass'];
        }
        else{
            $contfee = 0;
        }

        if (isset($_POST['debt']) && ($_POST['debt'] > 0) ) {
            $debt = $_POST['debt'];
            $querydebt = ("UPDATE student SET debt = debt - $debt WHERE id = $stuid ");
            mysqli_query($pdb, $querydebt);
        }
        else{
            $debt = 0;
        }


        if ($_POST['bus'] === "" ){
        $busfee = 0;
        }
        else{
        $busfee = $_POST['bus'];   
        }
        if ($_POST['pull'] === "" ){
            $pullfee = 0;
            }
        else{
            $pullfee =  $_POST['pull'];   
            }
        if ($_POST['party'] === "" ){
            $partyfee = 0;
        }
        else{
            $partyfee =  $_POST['party'];   
            }  
        
        if (isset($_POST['uniform']) && $_POST['uniform'] === "" ){
            $uniformfee = 0;
            }
        else if (isset($_POST['uniform']) && $_POST['uniform'] !== "" ) {
            $uniformfee =  $_POST['uniform'];   
            }
        else if (isset($_POST['uniformcus']) && $_POST['uniformcus'] === "" ) {
            $uniformfeecus = 0;   
            }
        else if (isset($_POST['uniformcus']) && $_POST['uniformcus'] !== "" ) {
                $uniformfeecus =  $_POST['uniformcus'];   
            }        
        else{
            $uniformfee = 0;
            $uniformfeecus = 0; 
        }
        
        
        if ($_POST['spwear'] === "" ){
            $spwearfee = 0;
            }
        else{
            $spwearfee =  $_POST['spwear'];   
            } 
            $myyear = date('Y');
          
        $thisdate = date('Y-m-d');
                    //    echo  $modepay."// ". $bankname."// ". $schfee . " ".$contfee. " ". $debt. " ". $busfee. " ". $pullfee. " ". $partyfee. " "
                    //    .$uniformfee." ". $spwearfee ; 
            
//for tution first
            $query = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                    VALUES ($stuid,$te,'$myyear',$schfee,99,$bal,$extra,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
            //for debt 
            $query2 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                    VALUES ($stuid,$te,'$myyear',$debt,100,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
             //for bus 
            $query3 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
             VALUES ($stuid,$te,'$myyear',$busfee,2,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
              //for pullover 
            $query4 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
              VALUES ($stuid,$te,'$myyear',$pullfee,5,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
              //for party 
              $query5 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
              VALUES ($stuid,$te,'$myyear',$partyfee,7,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
              if ($uniformfeecus > 0) {
             //for cuniform 
             $query6 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                 VALUES ($stuid,$te,'$myyear',$uniformfeecus,3,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                  }
            else if ($uniformfee > 0) { 
                 //for uniform 
                 $query6 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                 VALUES ($stuid,$te,'$myyear',$uniformfee,1,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                  }
                  else {
                    $query6 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                    VALUES ($stuid,$te,'$myyear',0,1,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                     
                  }
              $query7 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
              VALUES ($stuid,$te,'$myyear',$spwearfee,4,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
              $query8 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
               VALUES ($stuid,$te,'$myyear',$contfee,6,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                        /**
                         **/

                     if ( mysqli_query($pdb, $query) && 
                     mysqli_query($pdb, $query2) && mysqli_query($pdb, $query3) && 
                     mysqli_query($pdb, $query4) && mysqli_query($pdb, $query5) && 
                     mysqli_query($pdb, $query6) && mysqli_query($pdb, $query7) && 
                     mysqli_query($pdb, $query8) )
                      {
                        $_SESSION['success_add'] = 1;
                        unset($_SESSION['patfonuser']['studentid']);
                        header("Location: ../income_receive.php ");
                       }
                    else{
                        $_SESSION['failed'] = 1;
                        header("Location: ../income_receive.php ");
                       // echo mysqli_error($pdb);
                    }        
            


}
//new students
if (isset($_POST['income_recfeenewbut'])) {
    //mysqli_real_escape_string(
        $stuid = $_SESSION['patfonuser']['studentid'];
        $te = $_SESSION['patfonuser']['term'];
        $userid = $_SESSION['patfonuser']['id'];
        $skool = $_SESSION['patfonuser']['school'];
       
            $modepay = $_POST['modepay'];
    
            if ($modepay === 'bank'){
                $bankname = $_POST['modebk'];
            }
            else{
                $bankname = "";
            }
    
            if (isset($_POST['schfee']) && ($_POST['schfee'] > 0) ) {
                $schfee = $_POST['schfee'];
               
            }
            else{
                $schfee = 0;
            }
    
            //
            
            //
            if (isset($_POST['contass'])) {
                $contfee =  $_POST['contass'];
            }
            else{
                $contfee = 0;
            }
    
          
    
    
            if ($_POST['bus'] === "" ){
            $busfee = 0;
            }
            else{
            $busfee = $_POST['bus'];   
            }
            if ($_POST['pull'] === "" ){
                $pullfee = 0;
                }
            else{
                $pullfee =  $_POST['pull'];   
                }
            if ($_POST['party'] === "" ){
                $partyfee = 0;
            }
            else{
                $partyfee =  $_POST['party'];   
                }  
            
            if (isset($_POST['uniform']) && $_POST['uniform'] === "" ){
                $uniformfee = 0;
                }
            else if (isset($_POST['uniform']) && $_POST['uniform'] !== "" ) {
                $uniformfee =  $_POST['uniform'];   
                }
            else if (isset($_POST['uniformcus']) && $_POST['uniformcus'] === "" ) {
                $uniformfeecus = 0;   
                }
            else if (isset($_POST['uniformcus']) && $_POST['uniformcus'] !== "" ) {
                    $uniformfeecus =  $_POST['uniformcus'];   
                }        
            else{
                $uniformfee = 0;
                $uniformfeecus = 0; 
            }
            
            
            if ($_POST['spwear'] === "" ){
                $spwearfee = 0;
                }
            else{
                $spwearfee =  $_POST['spwear'];   
                } 
                $myyear = date('Y');
              
            $thisdate = date('Y-m-d');
                        //    echo  $modepay."// ". $bankname."// ". $schfee . " ".$contfee. " ". $debt. " ". $busfee. " ". $pullfee. " ". $partyfee. " "
                        //    .$uniformfee." ". $spwearfee ; 
                
    //for tution first
                $query = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                        VALUES ($stuid,$te,'$myyear',$schfee,99,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                //for debt 
                $query2 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                        VALUES ($stuid,$te,'$myyear',0,100,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                 //for bus 
                $query3 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                 VALUES ($stuid,$te,'$myyear',$busfee,2,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                  //for pullover 
                $query4 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                  VALUES ($stuid,$te,'$myyear',$pullfee,5,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                  //for party 
                  $query5 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                  VALUES ($stuid,$te,'$myyear',$partyfee,7,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                    if ($uniformfeecus > 0) {
                 //for cuniform 
                 $query6 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                 VALUES ($stuid,$te,'$myyear',$uniformfeecus,3,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                  }
                  else if ($uniformfee > 0) { 
                 //for uniform 
                 $query6 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                 VALUES ($stuid,$te,'$myyear',$uniformfee,1,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                  }
                  else{
                $query6 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                 VALUES ($stuid,$te,'$myyear',0,1,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                  
                  }
                  $query7 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                  VALUES ($stuid,$te,'$myyear',$spwearfee,4,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                  $query8 = ("INSERT INTO student_fees (stu_id,term,year_,amount,type_,bal,extra,user_collect,school,modepay,modebank,discount,date_pay) 
                   VALUES ($stuid,$te,'$myyear',$contfee,6,0,0,$userid,$skool,'$modepay','$bankname',0,'$thisdate') ");
                            /**
                             **/
    
                         if ( mysqli_query($pdb, $query) && 
                         mysqli_query($pdb, $query2) && mysqli_query($pdb, $query3) && 
                         mysqli_query($pdb, $query4) && mysqli_query($pdb, $query5) && 
                         mysqli_query($pdb, $query6) && mysqli_query($pdb, $query7) && 
                         mysqli_query($pdb, $query8) )
                          {
                            $_SESSION['success_add'] = 1;
                            unset($_SESSION['patfonuser']['studentid']);
                            header("Location: ../income_receive.php ");
                           }
                        else{
                            $_SESSION['failed'] = 1;
                          //  header("Location: ../income_receive.php ");
                            echo mysqli_error($pdb);
                        }        
                
    
    
    }
    
    

