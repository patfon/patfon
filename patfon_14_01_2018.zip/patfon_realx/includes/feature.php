<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<!-- //market-->
		

		<div class="agil-info-calendar">
		<!-- calendar -->
		<div class="col-md-6 agile-calendar">
			<div class="calendar-widget">
                <div class="panel-heading ui-sortable-handle">
					<span class="panel-icon">
                      <i class="fa fa-calendar-o"></i>
                    </span>
                    <span class="panel-title"> Calendar </span>
                </div>
				<!-- grids -->
					<div class="agile-calendar-grid">
						<div class="page">
							
							<div class="w3l-calendar-left">
								<div class="calendar-heading">
									
								</div>
								<div class="monthly" id="mycalendar"></div>
							</div>
							
							<div class="clearfix"> </div>
						</div>
					</div>
			</div>
		</div>
		<!-- //calendar -->
		<div class="col-md-6 w3agile-notifications">
			<div class="notifications">
				<!--notification start-->
				
					<header class="panel-heading">
						<i class="fa fa-bullhorn"> </i> Notice Board 
					</header>
					<div class="notify-w3ls">
						
						<div class="alert alert-danger">
							<span class="alert-icon"><i class=""></i></span>
							<div class="notification-info">
								<ul class="clearfix notification-meta">
									<li class="pull-left notification-sender"><span><a href="#">Labour Master:</a></span> meeting on friday </li>
									<li class="pull-right notification-time">7 Hours Ago</li>
								</ul>
								<p>
									Signed by: Labour master
								</p>
							</div>
							
						</div>
						
						
						
						
					</div>
				
				<!--notification end-->
				</div>
				
			<div class="clearfix"> </div>
			
		</div>
		<!---728x90--->
			
</section>