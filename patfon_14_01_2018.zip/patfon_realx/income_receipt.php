<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php $_SESSION['cur-page'] = "Patfon School Fees"; ?>

<?php 
include('functions/index.php');
if ( isset($_SESSION['patfonuser']) ) {  
       
?>

<?php include('includes/header.php'); ?>
<section id="main-content">
<section id="receipttableprint" class="wrapper">
<button class="btn btn-danger col-md-3 hidden-print" id="" onclick="window.print();">Print Page</button> &nbsp;&nbsp;&nbsp;&nbsp;

<div class="invoice-box" >
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td class="title">
                              
                            </td>
                            
                            <td>
                                School Fee Receipt #####: <br>
                                <?php echo date('M d, Y'); ?><br>
                                
                               
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="information">
                <td colspan="2">
                    <table>
                        <tr>
                            <td style="width: 40%;">
                            Name: <?php
                            $name = getstudentname($pdb,$_SESSION['patfonuser']['studentid']);
                            echo " ".$name."<br>"; ?>
                            Class: <?php
                            $theclass = getstudentclass($pdb,$_SESSION['patfonuser']['studentid']);
                            echo " ".$theclass."<br>"; ?>
                            Term: <?php
                            $myterm = array("1"=>"IST TERM", "2"=> "2ND TERM", "3"=>"3RD TERM");
                            echo $myterm[$_SESSION['patfonuser']['term']]."<br>"; ?>
                            Session: <?php
                            
                            echo $_SESSION['patfonuser']['ses']."<br>"; ?> 

                            </td>
                            
                            <td style="width: 60%;">
                               <?php echo getschoolname($pdb,$_SESSION['patfonuser']['school']); ?>
                                <br>
                                
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Payment Method
                </td>
                
                <td>
                <?php if (isset ( $_SESSION['patfonuser']['payment'] ) && $_SESSION['patfonuser']['payment'] === "bank" ) { 
                    echo "Bank (".$_SESSION['patfonuser']['paymentbank'] .") "; 
                } else if (isset ( $_SESSION['patfonuser']['payment'] ) && $_SESSION['patfonuser']['payment'] === "cash" ) { 
                    
                    echo "Cash";
                } ?>    
                
            </td>
            </tr>
            
            <tr class="details">
                <td>
                <?php if (isset ( $_SESSION['patfonuser']['payment'] ) && $_SESSION['patfonuser']['payment'] === "bank" ) {  
                echo "Bank";
                 } 
                else if (isset ( $_SESSION['patfonuser']['payment'] ) && $_SESSION['patfonuser']['payment'] === "cash" ) {  
                echo "Cash";
                 } ?>    
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['gtotal']; ?>
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    School Item
                </td>
                
                <td>
                    Amount
                </td>
            </tr>
            
            <tr class="item">
                <td>
                    School Tuition
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['schfee']; ?> 
                </td>
            </tr>
            <?php if (isset ( $_SESSION['patfonuser']['debtfee'] ) && $_SESSION['patfonuser']['debtfee'] > 0 ) { ?>    
            <tr class="item">
                <td>
                  Old Debt Fee
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['debtfee']; ?>
                </td>
            </tr>
            <?php } else { ?>
            <tr class="item">
                <td>
                Old Debt Fee
                </td>
                
                <td>
                 <?php echo "-----"; ?>
                </td>
            </tr>
            <?php } ?>

            <?php if (isset ( $_SESSION['patfonuser']['pullfee'] ) && $_SESSION['patfonuser']['pullfee'] > 0 ) { ?>    
            <tr class="item">
                <td>
                    Pull Over
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['pullfee']; ?>
                </td>
            </tr>
            <?php } else { ?>
            <tr class="item">
                <td>
                    Pull Over
                </td>
                
                <td>
                 <?php echo "-----"; ?>
                </td>
            </tr>
            <?php } ?>
            
            <?php if (isset ( $_SESSION['patfonuser']['partyfee'] ) && $_SESSION['patfonuser']['partyfee'] > 0 ) { ?>    
        
            <tr class="item">
                <td>
                    Party
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['partyfee']; ?>
                </td>
            </tr>
            <?php } else { ?>

            <tr class="item">
                <td>
                    Party
                </td>
                
                <td>
                 <?php echo "-----"; ?>
                </td>
            </tr>
            <?php } ?>
            <?php if (isset ( $_SESSION['patfonuser']['uniform'] ) && $_SESSION['patfonuser']['uniform'] > 0 ) { ?>    
        
            <tr class="item">
                <td>
                    Uniform (Regular)
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['uniform']; ?>
                </td>
            </tr>

            <?php } else { ?> 
            <tr class="item">
                <td>
                Uniform (Regular)
                </td>
                
                <td>
                 <?php echo "-----"; ?>
                </td>
            </tr>

            <?php } ?>
            <?php if (isset ( $_SESSION['patfonuser']['uniformcus'] ) && $_SESSION['patfonuser']['uniformcus'] > 0 ) { ?>    
        
            <tr class="item">
                <td>
                   Customised Uniform
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['uniformcus']; ?>
                </td>
            </tr>

            <?php } else  { ?>
            <tr class="item">
                <td>
                Customised Uniform
                </td>
                
                <td>
                 <?php echo "-----"; ?>
                </td>
            </tr>   

            <?php } ?>    
            <?php if (isset ( $_SESSION['patfonuser']['spwearfee'] ) && $_SESSION['patfonuser']['spwearfee'] > 0 ) { ?>    
        
            <tr class="item">
                <td>
                   Sports Wear
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['spwearfee']; ?>
                </td>
            </tr>
            <?php  } else { ?>
                <tr class="item">
                <td>
                Sports Wear
                </td>
                
                <td>
                 <?php echo "-----"; ?>
                </td>
            </tr> 
            <?php } ?>
            <?php if (isset ( $_SESSION['patfonuser']['busfee'] ) && $_SESSION['patfonuser']['busfee'] > 0 ) { ?>    
        
            <tr class="item">
                <td>
                    Bus
                </td>
                
                <td>
                &#8358; <?php echo $_SESSION['patfonuser']['busfee']; ?>
                </td>
            </tr>
            
            <?php } else { ?>
            <tr class="item">
                <td>
                Bus
                </td>
                
                <td>
                 <?php echo "-----"; ?>
                </td>
            </tr>  
            <?php } ?>    
        <?php if (isset ( $_SESSION['patfonuser']['contfee'] ) && $_SESSION['patfonuser']['contfee'] > 0 ) { ?>    
        
        <tr class="item">
            <td>
               Continous Assessment Fee
            </td>
            
            <td>
            &#8358; <?php echo $_SESSION['patfonuser']['contfee']; ?>
            </td>
        </tr>
        
        <?php } else { ?>
            <tr class="item">
                <td>
                Continous Assessment Fee
                </td>
                
                <td>
                 <?php echo "-----"; ?>
                </td>
            </tr> 
        <?php } ?>
            <tr class="total">
                <td></td>
                
                <td>
                   Total:  &#8358; <?php echo $_SESSION['patfonuser']['gtotal']; ?>
                </td>
            </tr>
        </table>
    </div>
</section>
</section>

<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 