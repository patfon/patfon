<?php session_start(); ?>
<?php include 'classes/connection.php' ; ?>
<?php $_SESSION['cur-page'] = "Income > View Fee Drive"; ?>

<?php 
include('functions/index.php');
if ( isset($_SESSION['patfonuser']) ) {  
        //directly from income_controller..........
        $mydata = getstudents($pdb);
        $myterm = $_SESSION['patfonuser']['term'];
        $mysch = $_SESSION['patfonuser']['school'];
        $thedate = date('Y');
        $stu_st = array('0'=>"Old",'1'=>"New");
//
        
        ?>
<?php

include('includes/header.php');
?>
<section style="padding-left: 70px; " id="main-content" >
<section  class="wrapper">
        <div class= "row">
                <div class=" invoice-box col-md-8" >
                        <div>
                        <h4 class="center-block col-xs-offset-3"><?php echo getschoolname($pdb,$_SESSION['patfonuser']['school']); ?></h4>
                        <p>View Students Owing The School  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <input type="button"  id="printdailybutton2" value="Print Table" class="btn btn-danger hidden-print" > </p>
                        <table style="scroll: overflow-y; max-height: 520px; " id="incfeedrive_table" class="table display table-bordered " cellspacing="12" cellpadding="5" >
                        <thead>
                        <tr>
                        <th>S/N</th> <th>Old/New</th> <th>Name</th>  <th>Class</th>      
                        <th>Paid</th><th>Debt</th>
                        </tr>
                        
                        </thead>
                        <tbody>
                        <?php
                        $i = 1;
                        foreach ($mydata as $dd) { ?>
                        <tr>
                        <td><?php echo $i; ?></td> 
                        <td><?php echo $stu_st[getstudentneworold($pdb,$dd['id'])]; ?>  </td> <td><?php echo getstudentname($pdb,$dd['id']); ?>  </td> <td> <?php echo getstudentclass($pdb,$dd['id']); ?> </td>
                        <td class="pf_row_i"><?php 
                        
                        $stupaid = getstudentpaid($pdb,$dd['id'],intval($myterm),$thedate,$mysch);
                        if (isset($stupaid) && $stupaid > 0){
                          echo "<b style='color: blue;'> PAID </b>";
                        }
                        else{ 
                                echo "<b style='color: red;'> NOT PAID </b>";
                        }
                        
                        ?></td> 

                        <td class="pf_row_i"><?php echo getstudentdebt($pdb,$dd['id'],$mysch); ?></td> 
                      
                         </tr>
                        <?php $i++; } ?>
                        </tbody>
                     
                        </table>
                        </div>
                </div>
    </div>
</section>
</section>


<?php
//footer
include('includes/footer2.php');
 ?>

<?php } else { 
    header("Location: login.php");
 } ?> 