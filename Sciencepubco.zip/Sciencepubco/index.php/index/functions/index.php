<?php 

/*** functions **/
function getconferences($con){

  $query = (" SELECT * FROM conference ");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[] = $r;
      }
   }
  
   return $src;
  
  }

function getcategories($con,$id){

  $query = (" SELECT cat FROM users_cat WHERE userid = $id ");
  $src = array();
  $result = mysqli_query($con,$query) or die(mysqli_error($con));
   if (mysqli_num_rows($result) > 0){
     while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
       $src[] = $r;
      }
   }
  
   return $src;
  
  }
  function gettotalsubmit($con,$cat,$id){

	$query = (" SELECT COUNT(id) as mid FROM submissions WHERE cat = '$cat' AND userid = $id ");
	$src = '';
	$result = mysqli_query($con,$query) or die(mysqli_error($con));
	 if (mysqli_num_rows($result) > 0){
	   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
		
		$src = $r['mid'];
		}
	 }
	
	 return intval($src);
	
  }  
  
  function gettotalcategory($con,$id,$cat,$sta){

    $query = (" SELECT * FROM submissions WHERE userid = $id AND cat = '$cat' AND _status = '$sta' ");
    $src = array();
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src[] = $r;
        }
     }
    
     return $src;
    
    }

    function getpaidjournal($con,$id){

      $query = (" SELECT paid FROM submissions WHERE id = $id ");
      $src = '';
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
        $src = $r['paid'];
        }
       }
      
       return intval($src);
      
      }  

      function changesubmission($con,$id,$sta){

        $query = (" UPDATE submissions SET _status = '$sta' WHERE id = $id ");
        
        $result = mysqli_query($con,$query) or die(mysqli_error($con));        
        return $result;
        
        }  

     

    function getpaidsubmission($con){

          $query = (" SELECT * FROM submissions WHERE _status = 'active' AND paid = 1 ");
          $src = array();
          $result = mysqli_query($con,$query) or die(mysqli_error($con));
           if (mysqli_num_rows($result) > 0){
             while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
              
               $src[] = $r;
              }
           }
          
           return $src;
          
   }

   function getuploader ($con,$user){
    $query = (" SELECT concat(fname,' ',lname) as fn FROM users WHERE id_ = $user ");
    $src = '';
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      
      $src = $r['fn'];
      }
     }
    
     return $src;
   }

   function showauthor ($con,$c){
    $query = (" SELECT school,id_,CONCAT(fname,' ',lname) as fn FROM users WHERE fname LIKE '$c%' ");

    $src = "<div id='$c'>
		<h3>$c</h3>
		</div>";
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
      $sch = strip_tags($r['school']) ;$fn = $r['fn']; $id = $r['id_'];
      $src .= "<a href='viewauthor.php?key=$id'>&nbsp;&nbsp;&nbsp;&nbsp;$fn</a>&nbsp;&nbsp;&nbsp;&nbsp;$sch <br/> ";
      }
     }
    
     return $src;
   }

   
   function explode_paragraph($str, &$part1, &$part2) {
    $s = $str;
    $first = strpos($s,"."); // tries to find the first dot
    if ($first>-1) {
        $s = substr($s, $first); // crop the paragraph after the first dot
        $second = strpos($s,"."); // tries to find the second dot
        if ($second>-1) { // a second one ?
            $part1 = substr($str, 9, $second); // 
            $part2 = substr($str, $second);
        } else { // only one dot : part1 will be everything, no part2
            $part1 = $str;
            $part2 = "";
        }
    } else { // no sentences at all.. put something in part1 ?
        $part1 = ""; // $part1 = $str;
        $part2 = "";
    }
  }

  