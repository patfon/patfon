
<?php include "../includes/header.php"; ?>
<body id="pkp-user-login">
<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="../about.php" class="hierarchyLink">About the Journal</a> 
			<a href="joinus.php" class="current">Join Us</a></div>
<h2><font color="#000046">Join Us To Promote Our Website </font></h2>


<div id="content">

</div>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
