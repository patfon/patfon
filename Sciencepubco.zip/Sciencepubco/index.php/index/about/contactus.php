
<?php include "../includes/header.php"; ?>
<body id="pkp-user-login">
<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="../about.php" class="hierarchyLink">About the Journal</a> 
			<a href="contactus.php" class="current">Contact Us</a></div>
<h2><font color="#000046">Contact Us For Further Information</font></h2>


<div id="content">
<div style="width:95%;box-shadow: 0 2px 20px #cbcbcb;-moz-box-shadow: 0 2px 20px #cbcbcb;-webkit-box-shadow: 0 2px 20px #cbcbcb;-webkit-border-radius: 15px 15px; 15px 15px;-moz-border-radius: 15px 15px; 15px 15px;border-radius: 15px 15px; 15px 15px;padding:12px;">
		<div id="mailingAddress">
		<h3>Mailing Address:</h3>
		<p>Science Publishing Corporation, RAK Free Trade Zone</p>
		<p>RAK FTZ Business Park, Business Centre 4,</p>
		<p>Al Mamourah Area, P.O. Box: 487447, UAE</p>
		<b>Principal Contact:</b>
		<a href=""></a><br clear="all"><br clear="all">
		<b>Support Contact:</b>
		<a href=""></a>
		</div><br clear="all">
	
	</div>
</div>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
