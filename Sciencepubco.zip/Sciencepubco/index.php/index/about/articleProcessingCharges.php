
<?php include "../includes/header.php"; ?>
<body id="pkp-user-login">
<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="../about.php" class="hierarchyLink">About the Journal</a> 
			<a href="articleProcessingCharges.php" class="current">Article Processing Charges</a></div>
<h2><font color="#000046">Article Processing Charges</font></h2>


<div id="content">
<div style="width:95%;box-shadow: 0 2px 20px #cbcbcb;-moz-box-shadow: 0 2px 20px #cbcbcb;-webkit-box-shadow: 0 2px 20px #cbcbcb;-webkit-border-radius: 15px 15px; 15px 15px;-moz-border-radius: 15px 15px; 15px 15px;border-radius: 15px 15px; 15px 15px;padding:12px;">
<div align="center">
	<table id="rounded-corner" class=" tableContainer" border="1" cellspacing="10">
		<tbody><tr>
			<th>Journal Title</th>
			<th>ISSN</th>
			<th>Publication Fee (NGN)</th>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=GJMA"; ?>" target="_top">Global Journal of Mathematical Analysis (GJMA)</a></td>
			<td>2307-9002</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJAMS"; ?>" target="_top">International Journal of Advanced Mathematical Sciences (IJAMS)</a></td>
			<td>2307-454X</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJAMR"; ?>" target="_top">International Journal of Applied Mathematical Research (IJAMR)</a></td>
			<td>2227-4324</td>
			<td>150</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJASP"; ?>" target="_top">International Journal of Advanced Statistics and Probability (IJASP)</a></td>
			<td>2307-9045</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJPR"; ?>" target="_top">International Journal of Physical Research (IJPR)</a></td>
			<td>2307-9010</td>
			<td>FREE</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJAC"; ?>" target="_top">International Journal of Advanced Chemistry (IJAC)</a></td>
			<td>2310-2977</td>
			<td>FREE</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJBR"; ?>" target="_top">International Journal of Biological Research (IJBR)</a></td>
			<td>2307-9029</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=JACST"; ?>" target="_top">Journal of Advanced Computer Science &amp; Technology (JACST)</a></td>
			<td>2227-4332</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJAG"; ?>" target="_top">International Journal of Advanced Geosciences (IJAG)</a></td>
			<td>2311-7044</td>
			<td>FREE</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJBAS"; ?>" target="_top">International Journal of Basic and Applied Sciences (IJBAS)</a></td>
			<td>2227-5053</td>
			<td>150</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJET"; ?>" target="_top">International Journal of Engineering &amp;Technology (IJET)</a></td>
			<td>2227-524X</td>
			<td>200</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJM"; ?>" target="_top">International Journal of Medicine (IJM)</a></td>
			<td>2309-1622</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJDR"; ?>" target="_top">International Journal of Dental Research (IJDR)</a></td>
			<td>2310-2993</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJPT"; ?>" target="_top">International Journal of Pharmacology and Toxicology (IJPT)</a></td>
			<td>2310-2985</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJANS"; ?>" target="_top">International Journal of Advanced Nursing Studies (IJANS)</a></td>
			<td>2227-488X</td>
			<td>150</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJH"; ?>" target="_top">International Journal of Health (IJH)</a></td>
			<td>2309-1630</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJAES"; ?>" target="_top">International Journal of Accounting and Economics Studies (IJAES)</a></td>
			<td>2309-4508</td>
			<td>100</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJAA"; ?>" target="_top">International Journal of Advanced Astronomy (IJAA)</a></td>
			<td>2312-7414</td>
			<td>FREE</td>
		</tr>
		<tr>
			<td style="text-align:left;font-weight:bold;"><a href="<?php echo $myurl.$myurlex."articles.php?keyword=IJSW"; ?>" target="_top">International Journal of Scientific World (IJSW)</a></td>
			<td>2307-9037</td>
			<td>100</td>
		</tr>
	</tbody></table>
</div>
</div>
</div>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
