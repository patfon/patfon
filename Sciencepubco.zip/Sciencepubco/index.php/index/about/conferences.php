
<?php include "../includes/header.php"; 
include "../classes/connection.php";
include "../functions/index.php";
?>
<body id="pkp-user-login">

<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="../about.php" class="hierarchyLink">About the Journal</a> 
			<a href="conferences.php" class="current"> Conferences</a></div>
<h2><font color="#000046">Latest Conferences</font></h2>

<?php $conf = getconferences($pdb); ?>
<div id="content">

<table style="text-align:left;" border="0" width="100%">
							<tbody>
				
				<?php foreach ( $conf as $con ){ ?>
				<?php $thedate = strtotime($con['s_date']); ?>
				<tr>
					<td class="col1">
						<div class="newsDate">
							<div class="newsMonth"><?php echo date('F',$thedate); ?></div>
							<div class="newsDay"><?php echo date('d',$thedate); ?></div>
							<div class="newsYear"><?php echo date('Y',$thedate); ?></div>
						</div>
					</td>
					<td class="col2" style="text-align:left; font-size:16px;">
					<a href="" target="_blank">
					<b><?php echo $con['title']; ?></b></a>
					<br>Start Date: <?php echo $con['s_date']; ?><br>End Date:  <?php echo $con['e_date']; ?> 
					<br>Country:  <?php echo $con['country']; ?>	<br>Website: <a href="#" target="_blank"> <?php echo $con['website']; ?></a></td>
				</tr>
				
				<tr><td colspan="3"><hr></td></tr>
				<?php } ?>
				
						</tbody>
</table>

</div>
</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
