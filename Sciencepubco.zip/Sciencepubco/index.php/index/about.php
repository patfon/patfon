
<?php include "includes/header.php"; 
unset($_SESSION['pubcouser']['join']);
?>
<body id="pkp-user-login">

<div id="container">
<?php include "includes/navheader.php"; ?>

<div id="body">
<div id="main">


<div id="breadcrumb">
	<a href="index.php">Home</a> 
			<a href="index.php" class="current">Science Publishing Corporation</a></div>
<h2><font color="#000046">Science Publishing Corporation</font></h2>


<div id="content">


<div style="text-align:justify; font: 16px 'Times New Roman';color:#fff;padding:2px 10px 2px 10px;background: #000046;-moz-border-radius: 5px;border-radius: 5px;border: 1px solid #C3C3E5;"><p class="Body">Science Publishing Corporation is a rapidly growing academic publisher which publishes peer-reviewed scholarly journals covering a wide range of academic disciplines. All articles published in Science Publishing Corporation are open access and distributed worldwide. <strong></strong></p><p class="Body">Here you can find information about our editions: descriptions, full tables of contents, instructions for authors, online editions and articles in press. Science Publishing Corporation provides open access to our editions as the readers can freely read, download and print the full text of the research articles, surveys and journals published by us.</p></div><div style="background:#fff;line-height: 20%;" class="clr"></div>
<table width="100%">	
<tr>
<td class="box_outer">
			
	<div class="boxx">

	<div class="box_div1" style="background: #800000;-moz-border-radius: 5px;border-radius: 5px;border: 1px solid #8C489F;"><h3 style="padding-left:10px; font-size: 16px;"><a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/GJMA" class="action1">Global Journal of Mathematical Analysis</a></h3></div>
		<div class="box_div2" style="text-align:justify;font: 14px 'Times New Roman'; line-height: 170%;">
		<a href="https://www.sciencepubco.com/index.php/GJMA" class="action"><img align="left" style="padding-right: 10px;" src="../../public/journals/28/homepageImage.png" width="100" height="128" alt="Page Header Logo" /></a>
		<p><strong>Title: </strong>Global Journal of Mathematical Analysis<br /><strong>ISSN: </strong>2307-9002<br /><strong>Publication Frequency: </strong>Two issues per year</p>
		</div>
	
	<div class="links_box">
		<a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/GJMA/issue/current" class="action1"><!-- img src="https://www.sciencepubco.com/templates/images/current.png" width="16" height="16" border=0 / -->Current Issue</a>
		<a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/GJMA/user/register" class="action1"><!-- img src="https://www.sciencepubco.com/templates/images/user-new.png" width="16" height="16" border=0 / -->Register</a>
		<a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/GJMA/about/joinus" class="action1"><!-- img src="https://www.sciencepubco.com/templates/images/join_us_icon.png" width="16" height="16" border=0 / -->Join Us</a>
	</div>
	</div>
</td>
<td class="box_outer">
			
	<div class="boxx">

	<div class="box_div1" style="background: #800000;-moz-border-radius: 5px;border-radius: 5px;border: 1px solid #8C489F;"><h3 style="padding-left:10px; font-size: 16px;"><a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/IJAMS" class="action1">International Journal of Advanced Mathematical Sciences</a></h3></div -->
			<div class="box_div2" style="text-align:justify;font: 14px 'Times New Roman'; line-height: 170%;">
		<a href="https://www.sciencepubco.com/index.php/IJAMS" class="action"><img align="left" style="padding-right: 10px;" src="../../public/journals/15/homepageImage.png" width="100" height="128" alt="Page Header Logo" /></a>
		<p><strong>Title: </strong>International Journal of Advanced Mathematical Sciences<br /><strong>ISSN: </strong>2307-454X<br /><strong>Publication Frequency: </strong>Two issues per year</p>
		</div>
	
	<div class="links_box">
		<a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/IJAMS/issue/current" class="action1"><!-- img src="https://www.sciencepubco.com/templates/images/current.png" width="16" height="16" border=0 / -->Current Issue</a>
		<a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/IJAMS/user/register" class="action1"><!-- img src="https://www.sciencepubco.com/templates/images/user-new.png" width="16" height="16" border=0 / -->Register</a>
		<a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/IJAMS/about/joinus" class="action1"><!-- img src="https://www.sciencepubco.com/templates/images/join_us_icon.png" width="16" height="16" border=0 / -->Join Us</a>
		<!--<a style="color: #ffffff;" href="https://www.sciencepubco.com/index.php/IJAMS/author/submit" class="action1"><!-- img src="https://www.sciencepubco.com/templates/images/submission.png" width="16" height="16" border=0 / --Submit Manuscript</a>-->
	</div>
	</div>
</td>
</tr>

</table>

<a name="journals"></a>



<div id="journalListPageInfo"></div>
<div id="journalListPageLinks"></div>

<!-- content -->
</div><!-- main -->
</div><!-- body -->
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "includes/footer.php"; ?>
