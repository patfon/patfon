<?php
//my first databsase prototype for  use in school comparison
$pdb = mysqli_connect ("localhost", "root", "loyboy", "pubco");
mysqli_set_charset($pdb, 'utf8');