
<?php include "includes/header.php";
unset($_SESSION['pubcouser']['join']);
?>
<body id="pkp-user-login">

<div id="container">
<?php include "includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="index.html">Home</a> 
			<a href="login.html" class="current">Login</a></div>
			<h2><font color="#000046">Login</font></h2>
			<?php if (isset($_SESSION['loginfailed'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your login attempt has failed. 
			</div>
			<?php } 
			unset($_SESSION['loginfailed']);
			?>
<div id="content">
<div style="width:95%;box-shadow: 0 2px 20px #cbcbcb;-moz-box-shadow: 0 2px 20px #cbcbcb;-webkit-box-shadow: 0 2px 20px #cbcbcb;-webkit-border-radius: 15px 15px; 15px 15px;-moz-border-radius: 15px 15px; 15px 15px;border-radius: 15px 15px; 15px 15px;padding:12px;">
	<form id="signinForm" method="post" action="<?php echo $myurl.$myurlex."controller/login.php" ?>">
	<input type="hidden" name="source" value="" />

	<div style="color:#000000; -webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;">
	<table align="center" id="signinTable" class="data">
	<tr style="background: #E8E8E8;">
		<td class="label" style="padding-left: 10px; font-size: 16px;"><label for="loginUsername">Username</label></td>
		<td class="value"><input style="-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;" type="text" id="loginUsername" name="username" value="" size="20" maxlength="32" class="textField" /></td>
	</tr>
	<tr style="background: #E8E8E8;">
		<td class="label" style="padding-left: 10px; font-size: 16px;"><label for="loginPassword">Password</label></td>
		<td class="value"><input style="-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;" type="password" id="loginPassword" name="password" value="" size="20" maxlength="32" class="textField" /></td>
	</tr>
		<tr style="background: #E8E8E8;" valign="middle">
		<td></td>
		<td class="value"><input type="checkbox" id="loginRemember" name="remember" value="1" /> <label style="font-size: 16px;" for="loginRemember">Remember my username and password</label></td>
	</tr>
		<tr style="background: #E8E8E8;">
		<td></td>
		<td><input type="submit" value="Login" class="button" /></td>
	</tr>
	</table>
	<p style="text-align: center; font-size: 16px; background: #E8E8E8;">
		&#187; <a href="user/register.php">Not a user? Register with this site</a><br />		&#187; <a href="login/lostPassword.html">Forgot your password?</a>
	</p>
	</div>

<script type="text/javascript">

	document.getElementById('loginUsername').focus();
// -->
</script>
</form>
</div>

</div>
</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "includes/footer.php"; ?>
