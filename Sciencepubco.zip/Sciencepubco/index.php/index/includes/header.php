 <?php 
 session_start();
 $documentroot = "Sciencepubco";
 $GLOBALS['myurl'] = "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/";
 $GLOBALS['myurlex'] = "index.php/index/";

 $GLOBALS['codes'] = array('GJMA'=>'2307-9002',"IJAMS"=>'2307-454X',
 "IJAMR"=>'2227-4324',"IJASP"=>'2307-9045',"IJPR"=>'2307-9010',"IJAC"=>'2310-2977',
 "IJBR"=>'2307-9029','JACST'=>'2227-4332','IJBAS'=>'2227-5053','IJET'=>'2227-524X','IJAG'=>'2311-7044',
 'IJM'=>'2309-1622','IJDR'=>'2310-2993','IJPT'=>'2310-2985','IJANS'=>'2227-488X','IJH'=>'2309-1630', 
 'IJAES'=>'2309-4508','IJAA'=>'2312-7414','IJSW'=>'2307-9037');

 $GLOBALS['codes2'] = array(
 'GJMA'=>'Global Journal of Mathematical Analysis (GJMA)',
 "IJAMS"=>'International Journal of Advanced Mathematical Sciences (IJAMS)',
 "IJAMR"=>'International Journal of Applied Mathematical Research (IJAMR)',
 "IJASP"=>'International Journal of Advanced Statistics and Probability (IJASP)',
 "IJPR"=>'International Journal of Physical Research (IJPR)',
 "IJAC"=>'International Journal of Advanced Chemistry (IJAC)',
 "IJBR"=>'International Journal of Biological Research (IJBR)',
 'JACST'=>'Journal of Advanced Computer Science & Technology (JACST)',
 'IJBAS'=>'International Journal of Basic and Applied Sciences (IJBAS)',
 'IJET'=>'International Journal of Engineering &Technology (IJET)',
 'IJAG'=>'International Journal of Advanced Geosciences (IJAG)',
 'IJM'=>'International Journal of Medicine (IJM)',
 'IJDR'=>'International Journal of Dental Research (IJDR)',
 'IJPT'=>'International Journal of Pharmacology and Toxicology (IJPT)',
 'IJANS'=>'International Journal of Advanced Nursing Studies (IJANS)',
 'IJH'=>'International Journal of Health (IJH)', 
 'IJAES'=>'International Journal of Accounting and Economics Studies (IJAES)',
 'IJAA'=>'International Journal of Advanced Astronomy (IJAA)',
 'IJSW'=>'International Journal of Scientific World (IJSW)');
 
//images
$GLOBALS['codes3'] = array(
 'GJMA'=>28,
 "IJAMS"=>15,
 "IJAMR"=>1,
 "IJASP"=>19,
 "IJPR"=>21,
 "IJAC"=>18,
 "IJBR"=>20,
 'JACST'=>6,
 'IJBAS'=>2,
 'IJET'=>3,
 'IJAG'=>24,
 'IJM'=>22,
 'IJDR'=>17,
 'IJPT'=>26,
 'IJANS'=>5,
 'IJH'=>25, 
 'IJAES'=>11,
 'IJAA'=>12,
 'IJSW'=>23 );
 ?>

<!DOCTYPE html>

<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Science Publication</title>
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	
<link rel="stylesheet" href=<?php echo $myurl."styles/common.css"; ?> type="text/css" /> 
<link rel="stylesheet" href=<?php echo $myurl."lib/pkp/css/styles.css"; ?> type="text/css" /> 
<link rel="stylesheet" href=<?php echo $myurl."plugins/blocks/languageToggle/styles/languageToggle.css"; ?> />
<link rel="icon" href=<?php echo $myurl."public/journals/28/journalFavicon_en_US.png"; ?>/>

<!-- Base Jquery -->


	<!-- Default global locale keys for JavaScript -->
	
<script type="text/javascript">
	jQuery.pkp = jQuery.pkp || { };
	jQuery.pkp.locale = { };
	jQuery.pkp.locale.form_dataHasChanged = 'The data on this form has changed. Continue anyway?';
</script>
	<!-- Compiled scripts -->

	<script type="text/javascript" defer>
	// This adds 'placeholder' to the items listed in the jQuery .support object. 
		
	jQuery(function() {
	   jQuery.support.placeholder = false;
	   test = document.createElement('input');
	   if('placeholder' in test) jQuery.support.placeholder = true;
	});
	// This adds placeholder support to browsers that wouldn't otherwise support it. 
	$(function() {
	   if(!$.support.placeholder) { 
		  var active = document.activeElement;
		  $(':text').focus(function () {
			 if ($(this).attr('placeholder') != '' && $(this).val() == $(this).attr('placeholder')) {
				$(this).val('').removeClass('hasPlaceholder');
			 }
		  }).blur(function () {
			 if ($(this).attr('placeholder') != '' && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
				$(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
			 }
		  });
		  $(':text').blur();
		  $(active).focus();
		  $('form:eq(0)').submit(function () {
			 $(':text.hasPlaceholder').val('');
		  });
	   }
	});
		
	</script>
	

<script type="text/javascript" defer>

function validateFileExtension(fld) {
	if(!/(\.pdf|\.doc|\.docx)$/i.test(fld.value)) {
		alert("The uploaded file type must be in (PDF or MS Word) format.");
		fld.form.reset();
		fld.focus();
		return false;
	}
	return true;
}

</script>

<script>
	
	function wopen(url, name, w, h)
	{
	// Fudge factors for window decoration space.
	 // In my tests these work well on all platforms & browsers.
	w += 32;
	h += 96;
	 var win = window.open(url,
	  name, 
	  'width=' + w + ', height=' + h + ', ' +
	  'location=no, menubar=no, ' +
	  'status=no, toolbar=no, scrollbars=no, resizable=no');
	 win.resizeTo(w, h);
	 win.focus();
	}
	
</script>

 <script type="text/javascript" src="<?php echo $myurl."js/jquery.1.11.0.min.js"; ?>"></script> 
 <script type="text/javascript" src="<?php echo $myurl."js/custom.js"; ?>"></script> 
 <script type="text/javascript" src="<?php echo $myurl."lib/bootstrap/js/bootstrap.min.js"; ?>"></script>
 <script type="text/javascript" src=<?php echo $myurl."lib/tinymce/tinymce.min.js"; ?>></script>
    <script>tinymce.init({ selector:'textarea',
                            height: 200,
							width: 600,
							
                            menubar: false,
							paste_filter_drop: false,
                            plugins: [
                              'autolink lists link charmap anchor textcolor',
                              
                              'insertdatetime table contextmenu paste'
                            ],
                            toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help' });</script> 
 <script type="text/javascript" src="<?php echo $myurl."js/responsive-nav.js"; ?>"></script> 
 <script>
      var navigation = responsiveNav(".nav-collapse");
 </script>

<script type="text/javascript" src="<?php echo $myurl."js/script.js";?>"></script> 
<link rel="stylesheet" href=<?php echo $myurl."lib/bootstrap/css/bootstrap.min.css"; ?> type="text/css" />

<link rel="stylesheet" href=<?php echo $myurl."lib/pkp/styles/lib/jqueryUi/jqueryUi.css"; ?> type="text/css" /> 
<link rel="stylesheet" href=<?php echo $myurl."lib/pkp/styles/lib/jquery.pnotify.default.css"; ?> type="text/css" />
<link rel="stylesheet" href=<?php echo $myurl."lib/pkp/styles/common.css"; ?> type="text/css" />
<link rel="stylesheet" href=<?php echo $myurl."styles/common.css"; ?> type="text/css" />
<link rel="stylesheet" href=<?php echo $myurl."styles/compiled.css"; ?> type="text/css" />
<link rel="stylesheet" href=<?php echo $myurl."styles/stylecontact.css"; ?> type="text/css" />
<link rel="stylesheet" href=<?php echo $myurl."styles/styles.css"; ?> type="text/css" />
<link rel="stylesheet" href=<?php echo $myurl."styles/responsive-nav.css"; ?> type="text/css" />



<!-- End Alexa Certify Javascript -->  
</head>