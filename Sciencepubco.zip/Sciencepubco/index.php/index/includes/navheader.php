<div id="header">
<div id="headerTitle">
<a href="" border="0">
	<img class="main_logo" src="<?php echo $myurl."styles/spc_new_logo.jpg"; ?>" style="padding-top: 2px; padding-left: 10px;" title="SPC Logo" align="left" border="0" width="90" height="90" alt="" />
</a>
 <div id="header2">
 <font style="font-family: Tahoma; font-size: 30px; color:#000046; padding-left:0px;">Science Publishing Corporation</font>
 <font style="font-weight: bold; font-size: 14px; letter-spacing: 0.1px; color:#B40404; padding-left:0px;float:left;width:100%;">Publisher of International Academic Journals</font>

	<div style="padding-top: 15px;" class="searchBox">	
	<table class="tableContainer">
	<tr>
	<td>
	<script>
			
	(function() {
		var cx = '015932511590741825049:trz9knph-6i';
		var gcse = document.createElement('script');
		gcse.type = 'text/javascript';
		gcse.async = true;
		gcse.src = '../../../cse.google.com/cse07b6.html?cx=' + cx;
		var s = document.getElementsByTagName('script')[0];
		s.parentNode.insertBefore(gcse, s);
	})();
	
	</script>

	<gcse:search></gcse:search>
	</td>
				<td>
				<form name="form" id="tfnewsearch" method="post">
				<input type="submit" value="Advanced Search" onclick="javascript: form.action='search/search.html';" class="tfbutton2">
				</form>
				</td>
	</tr>
	</table>
	</div>		
			<br />
				
					<div>
					
						<div class="tfclear"></div>
					</div>
				
				
			</div>

		<div id="header4">
		<div class="background">
		<div id='cssmenu' class="cssmenu">
		
			<ul class="semiopaquemenu">
				<li id="home"><a href="<?php echo $myurl.$myurlex."index.php"; ?>">Home</a></li>
				<li id="about"><a href="<?php echo $myurl.$myurlex."about.php"; ?>">About</a></li>
				<?php if (isset($_SESSION['pubcouser'])){ ?>
				<li id="userHome" class="has-sub">
				<span class="submenu-button"></span> <a href="#">User Home</a>
				<ul class="semiopaquemenu" style="margin-left: -60%;">
				<li><a href="<?php echo $myurl.$myurlex.'index.php'; ?>">Home</a></li><hr>
				<li><a href="<?php echo $myurl.$myurlex.'user/dashboard.php'; ?>">My Journals</a></li><hr>
				<li><a href="<?php echo $myurl.$myurlex.'profile.php'; ?>">My Profile</a></li><hr>
				<li><a href="#">Change Password</a></li><hr>
				<li><a href="<?php echo $myurl.$myurlex.'user/logout.php'; ?>">Log Out</a></li>
				</ul>			
				</li>	
				<?php } else { ?>
				<li id="login"> <a href="<?php echo $myurl.$myurlex."login.php"; ?>">Login</a></li>
				<li id="register"> <a href="<?php echo $myurl.$myurlex."user/choose.php"; ?>">Register</a></li>
				<?php } ?>				
			</ul>
		</div>
		</div>
		</div>
		<?php 
		  $myconstant = array('GJMA'=>1,"IJAMS"=>2,"IJAMR"=>3,"IJASP"=>4,"IJPR"=>5,"IJAC"=>6,
		 "IJBR"=>7,'JACST'=>8,'IJBAS'=>9,'IJET'=>10,'IJAG'=>11,
		 'IJM'=>12,'IJDR'=>13,'IJPT'=>14,'IJANS'=>15,'IJH'=>16, 
		 'IJAES'=>17,'IJAA'=>18,'IJSW'=>19,'JE'=>20,'JFNS'=>21,
		 'JPS'=>22,'JM'=>23,'JWR'=>24,'JES'=>25,'JAS'=>26,'JSC'=>27,
		 'JP'=>28,'JEDU'=>29); 

		if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 1 ){ ?>
		<img src="<?php echo $myurl."banner/1.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 2 ){ ?>
		<img src="<?php echo $myurl."banner/2.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 3 ){ ?>
		<img src="<?php echo $myurl."banner/3.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 4 ){ ?>
		<img src="<?php echo $myurl."banner/4.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 5 ){ ?>
		<img src="<?php echo $myurl."banner/5.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 6 ){ ?>
		<img src="<?php echo $myurl."banner/6.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 7 ){ ?>
		<img src="<?php echo $myurl."banner/7.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 8 ){ ?>
		<img src="<?php echo $myurl."banner/8.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 9 ){ ?>
		<img src="<?php echo $myurl."banner/9.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 10 ){ ?>
		<img src="<?php echo $myurl."banner/10.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 11 ){ ?>
		<img src="<?php echo $myurl."banner/11.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 12 ){ ?>
		<img src="<?php echo $myurl."banner/12.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 13 ){ ?>
		<img src="<?php echo $myurl."banner/13.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 14 ){ ?>
		<img src="<?php echo $myurl."banner/14.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 15 ){ ?>
		<img src="<?php echo $myurl."banner/15.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 16 ){ ?>
		<img src="<?php echo $myurl."banner/16.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 17 ){ ?>
		<img src="<?php echo $myurl."banner/17.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 18 ){ ?>
		<img src="<?php echo $myurl."banner/18.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 19 ){ ?>
		<img src="<?php echo $myurl."banner/19.PNG"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 20 ){ ?>
		<img src="<?php echo $myurl."banner/20.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 21 ){ ?>
		<img src="<?php echo $myurl."banner/21.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 22 ){ ?>
		<img src="<?php echo $myurl."banner/22.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 23 ){ ?>
		<img src="<?php echo $myurl."banner/23.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 24 ){ ?>
		<img src="<?php echo $myurl."banner/24.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 25 ){ ?>
		<img src="<?php echo $myurl."banner/25.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 26 ){ ?>
		<img src="<?php echo $myurl."banner/26.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 27 ){ ?>
		<img src="<?php echo $myurl."banner/27.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 28 ){ ?>
		<img src="<?php echo $myurl."banner/28.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		<?php }
		else if (isset($_SESSION['pubcouser_reg']['join']) && $myconstant[$_SESSION['pubcouser_reg']['join']] === 29 ){ ?>
		<img src="<?php echo $myurl."banner/29.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		
		<?php } else { ?>
			<img src="<?php echo $myurl."banner/MAIN.jpg"; ?>" alt="" align="left" border="0" width="100%" height="120" />
		
		<?php } ?>
		<div id="header3">

		<div id='cssmenu' class="cssmenu1">

			<ul class="semiopaquemenu2">
			<li class="has-sub">
			<span class="submenu-button"></span>
			<span class="submenu-button"></span>
			<a href="">Browse</a>
				<ul class="semiopaquemenu2">
				<li id="search"><a href="<?php echo $myurl.$myurlex."user/search_author.php"; ?>">By Author</a></li><hr>
				<li id="search"><a href="<?php echo $myurl.$myurlex."user/search_title.php"; ?>">By Title</a></li><hr>
			
				</ul>
			</li>
				<li id="about"> <a href="<?php echo $myurl.$myurlex."about/joinus.php"; ?>">Join Us</a></li>
				<li id="about"> <a href="<?php echo $myurl.$myurlex."about/articleProcessingCharges.php"; ?>">Fees</a></li>
				<li id="about"> <a href="<?php echo $myurl.$myurlex."about/conferences.php"; ?>">Conferences</a></li>
				<li id="about"> <a href="<?php echo $myurl.$myurlex."about/contactus.php"; ?>">Contact Us</a></li>
				
			</ul>
		</div>

		</div>
</div>
</div>