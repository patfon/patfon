<div style="
	
	max-width:1200px;
	background-color: #800000;
	color: #FFF;
	border-left: 1px solid #CCCCCC;
	border-right: 1px solid #CCCCCC;
	margin: 0px auto;
	padding: 0px;
	overflow: auto !important;
	#display:table;
	*display:table;
	_display: table;
	-moz-box-shadow:0 0 5px 5px #888;-webkit-box-shadow:0 0 5px 5px#888;box-shadow:0 0 5px 5px #888;
	
">
<div class="footer">

<div class="box_foot">
<h2>NAVIGATION</h2>

<li><a href="">Home</a></li>
<li><a href="about.php">About us</a></li>
<li><a href="">Journals</a></li>


</div>
<div class="box_foot">
<h2>PARTNERS</h2>

<li><a href="" target="_blank">Google Scholar</a></li>
<li><a href="" target="_blank">CrossRef</a></li>
<li><a href="" target="_blank">Open Journal Systems</a></li>
<li><a href="" target="_blank">Portico</a></li>
</div>

<div class="box_foot">
<h2>FOLLOW US ON</h2>

<li><a href="" target="_blank"><img src="<?php echo $myurl."templates/images/facebook.png"; ?>" alt="sciencepubco-Facebook-page" align="left" title="follow us on facebook" width="24" height="24" />Facebook</a></li>
<li><a href="" target="_blank"><img src="<?php echo $myurl."templates/images/twitter.png"; ?>" alt="twitter-page" align="left" title="follow us on twitter" width="24" height="24">Twitter</a></li>
<li><a href="" target="_blank"><img src="<?php echo $myurl."templates/images/linkedin.png"; ?>" alt="sciencepubco-lnkdin-page" align="left" title="follow us on linkedin" width="24" height="24">Linkedin</a></li>
<li><a href="" target="_blank"><img src="<?php echo $myurl."templates/images/gplus.png"; ?>" alt="sciencepubco-googleplus-page" align="left" title="follow us on google plus" width="24" height="24">Google +</a></li>
<li><a href="">.</a></li>
</div>
<div class="box_foot">
<h2>ADDRESS</h2>

<p>Science Publishing Corporation, RAK Free Trade Zone</p>

<p>RAK FTZ Business Park, Business Centre 4,</p>

<p>Al Mamourah Area, P.O. Box: 487447, UAE</p>

<p><a href="mailto:SPC@sciencepubco.com" style="float: right;"></a></p>

<p><a href="mailto:Support@sciencepubco.com" style="float: right;"></a></p>
</div>

</div>
 
<div style="
	max-height: 10%;
	max-width: 1200px;
	background-color: #000046;
	color: #FFCC00;
	border-bottom: 5px solid #C0C0C0;
	border-left: 1px solid #CCCCCC;
	border-right: 1px solid #CCCCCC;
	margin: 0px auto;
	padding: 0px;
	overflow: auto !important;
	#display:table;
	*display:table;
	_display: table;
	_height: 10%;
	-moz-box-shadow:0 0 5px 5px #888;-webkit-box-shadow:0 0 5px 5px#888;box-shadow:0 0 5px 5px #888;
">
<p style="font-weight: bold; background: #000046; font-family: Albertus, Georgia,'Times New Roman',Times,serif; font-size: 13px;text-align: center; padding-bottom:2px;padding-top:2px;">
Copyright &copy; 2018 . All rights reserved.</p>
</div>
</div>
</body>
</html>
