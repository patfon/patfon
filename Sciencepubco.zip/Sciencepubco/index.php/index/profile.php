
<?php include "includes/header.php";
unset($_SESSION['pubcouser']['join']);
?>
<body id="pkp-user-login">

<div id="container">
<?php include "includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="index.php">Home</a> 
			<a href="" class="current">Profile Edit</a></div>
			<h2><font color="#000046">Edit Your Profile</font></h2>

			<?php if (isset($_SESSION['success_pass'])) { ?>
			<div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your Profile has been Updated. 
			</div>
			<?php } 
			unset($_SESSION['success_pass']);
			?>
		<?php if (isset($_SESSION['pubcouser'])) { ?>	
<div id="content">
<div style="width:95%;box-shadow: 0 2px 20px #cbcbcb;-moz-box-shadow: 0 2px 20px #cbcbcb;-webkit-box-shadow: 0 2px 20px #cbcbcb;-webkit-border-radius: 15px 15px; 15px 15px;-moz-border-radius: 15px 15px; 15px 15px;border-radius: 15px 15px; 15px 15px;padding:12px;">
	<form id="signinForm" method="post" action="<?php echo $myurl.$myurlex."controller/login.php" ?>">
	<input type="hidden" name="source" value="" />

	<div style="color:#000000; -webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;">
	<table align="center" id="signinTable" class="data">
	
	<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Title:</td>
			<td class="value">
				<select name="salutation" required='required' id="salutation" class="selectMenu" >
				<?php $sal = array('Mr','Mrs','Ms','Dr.','Prof.'); ?>
				<option value=""></option>
				<?php foreach ($sal as $s) { ?>
					
					<?php if ($_SESSION['pubcouser']['title'] === $s) { ?>
					<option selected='selected' value="<?php echo $s; ?>"><?php echo $s; ?></option>
					<?php } else { ?>
					<option  value="<?php echo $s; ?>"><?php echo $s; ?></option>
					<?php } ?>
				<?php } ?>	
				</select>
			</td>
		</tr>
		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">First Name:</td>
			<td class="value">
			<input type="text" required='required' id="firstName" name="fname" 
			<?php if (isset($_SESSION['pubcouser']['firstname'])){ ?>
			value =	"<?php echo $_SESSION['pubcouser']['firstname']; ?>"
			<?php } ?>	
			size="20" maxlength="40" style="text-transform: capitalize;" class="textField editor_field"></td>
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Last Name:</td>
			<td class="value">
			<input type="text" required='required' id="lastName" name="lname" 
			<?php if (isset($_SESSION['pubcouser']['lastname'])){ ?>
			value =	"<?php echo $_SESSION['pubcouser']['lastname']; ?>"
			<?php } ?>
			 size="20" maxlength="90" style="text-transform: capitalize;" class="textField editor_field"></td>
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">
<label for="affiliation">
	Affiliation </label>
:</td>
			<td class="value">
				<textarea name="uni" id="affiliation" required='required' rows="5" cols="21" class="textArea">
				<?php if (isset( $_SESSION['pubcouser']['school'])){ ?>
			<?php echo $_SESSION['pubcouser']['school']; ?>
			<?php } ?>
				</textarea><br>
				<span style="color:#0000FF;font-size: 16px;" class="instruct">(Your institution, e.g. "Lagos State University")</span>
			</td>
		</tr>
		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Phone Number:</td>
			<td class="value">
				
			<input type="text" id="phone" required='required' name="phone"
			<?php if (isset( $_SESSION['pubcouser']['phone'])){ ?>
			value =	"<?php echo $_SESSION['pubcouser']['phone']; ?>"
			<?php } ?>
			 size="30" maxlength="90" class="textField editor_field"> </td>
		</tr>
		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Email:</td>
			<td class="value">
				
			<input type="email" id="email" required='required' name="email"
			<?php if (isset( $_SESSION['pubcouser']['email'])){ ?>
			value =	"<?php echo $_SESSION['pubcouser']['email']; ?>"
			<?php } ?>
			 size="30" maxlength="90" class="textField editor_field"> </td>
		</tr>
		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Address:</td>
			<td class="value">
				
			<input type="text" id="addr" required='required' name="addr"
			<?php if (isset( $_SESSION['pubcouser']['addr'])){ ?>
			value =	"<?php echo $_SESSION['pubcouser']['addr']; ?>"
			<?php } ?>
			 size="30" maxlength="90" class="textField editor_field"> </td>
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Gender:</td>
			<td class="value">
				<select name="gender" required='required' id="" class="selectMenu" >
				<?php $gen = array('male','female'); ?>
				<option value=""></option>
				<?php foreach ($gen as $s) { ?>
					
					<?php if (isset($_SESSION['pubcouser']['gender']) && $_SESSION['pubcouser']['gender'] === $s) { ?>
					<option selected='selected' value="<?php echo $s; ?>"><?php echo $s; ?></option>
					<?php } else { ?>
					<option  value="<?php echo $s; ?>"><?php echo $s; ?></option>
					<?php } ?>
				<?php } ?>	
				</select>
			</td>
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">
<label for="affiliation">
	Bio-Information </label>
:</td>
			<td class="value">
				<textarea name="bio" rows="5" cols="21" class="textArea">
				<?php if (isset( $_SESSION['pubcouser']['bio'])){ ?>
			<?php echo $_SESSION['pubcouser']['bio']; ?>
			<?php } ?>
				</textarea><br>
				<span style="color:#0000FF;font-size: 16px;" class="instruct">E.g Department and Rank</span>
			</td>
		</tr>
		
	<tr style="background: #E8E8E8;">
		<td></td>
		<td><input type="submit" value="Update Profile" name="butUpdateProfile" class="button" /></td>
	</tr>
	</table>
	
	</div>

<script type="text/javascript">

	document.getElementById('loginUsername').focus();
// -->
</script>
</form>
</div>

</div>
<?php } else {  ?>
	<meta http-equiv="refresh" content="0;url=<?php echo $myurl.$myurlex.'login.php' ?>">
<?php } ?>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "includes/footer.php"; ?>
