<?php session_start(); ?>
<?php include '../classes/connection.php' ;
if (isset($_POST['submitform'])) {

    $un =  mysqli_real_escape_string($pdb,$_POST['username']);
    $pass =  md5(mysqli_real_escape_string($pdb,$_POST['password']));
    $sal =  mysqli_real_escape_string($pdb,$_POST['salutation']);
    $fn =  mysqli_real_escape_string($pdb,$_POST['fname']);
    $ln =  mysqli_real_escape_string($pdb,$_POST['lname']);
    $uni =  mysqli_real_escape_string($pdb,$_POST['uni']);
    $email =  mysqli_real_escape_string($pdb,$_POST['email']);
    $country =  mysqli_real_escape_string($pdb,$_POST['country']);
   
    $cap =  strtolower(mysqli_real_escape_string($pdb,$_POST['captcha']));

    $code = strtolower($_SESSION['captcha']['code']);

    if (!isset($_POST['AsReader'])){
        $rea = 0;
    }
    else{
        $rea = $_POST['AsReader'];
    }

    if (!isset($_POST['AsAuthor'])){
        $aut = 0;
    }
    else{
        $aut = $_POST['AsAuthor'];
    }
    
    $cat =  $_SESSION['pubcouser_reg']['join'] ;

    $query = ("INSERT INTO users (username,passw,title,fname,lname,school,email,country,gender,phone,addr,bio_statement) 
              VALUES ('$un','$pass','$sal','$fn','$ln','$uni','$email','$country','','','','' ) ");
  
    $query2 = (" SELECT id_ FROM users WHERE username = '$un' ");
        
    if ($cap !== $code) {
       
        $_SESSION['captcha_fail'] = 1;
        header("Location:  ../user/register.php ");
        return;
    } 
    else {
    if (mysqli_query($pdb, $query)) {
        $re = mysqli_query ($pdb,$query2);
        $rov = mysqli_fetch_array($re,MYSQLI_ASSOC);
        $myid = $rov['id_'];

        $query3 = ("INSERT INTO users_cat (userid,cat,_reader,_author) 
        VALUES ($myid,'$cat', $rea, $aut ) ");    
        if (mysqli_query($pdb, $query3)) {
        $_SESSION['success_pass'] = 1;
     
        header("Location:  ../user/register.php ");
        }
        else{
            if (mysqli_errno($pdb) == 1062){
                $_SESSION['username_exists'] = 1;
                header("Location:  ../user/register.php ");
                return;
            }
            $_SESSION['failed_change'] = 1;
    
            echo mysqli_error($pdb);
        }
     }
     else {
  
            $_SESSION['failed_change'] = 1;
            
            echo mysqli_error($pdb);
      
      }

    }

  }

  if (isset($_POST['submitformreg'])) {

    $un =  mysqli_real_escape_string($pdb,$_POST['username']);
    $pass =  mysqli_real_escape_string($pdb,$_POST['password']);
    $cap =  strtolower(mysqli_real_escape_string($pdb,$_POST['captcha']));
    $code = strtolower($_SESSION['captcha']['code']);
    $cat =  $_SESSION['pubcouser_reg']['join'] ;
    $q = "SELECT * FROM users WHERE username='$un' and passw='".md5($pass)."'";

    if (!isset($_POST['AsReader'])){
        $rea = 0;
    }
    else{
        $rea = $_POST['AsReader'];
    }

    if (!isset($_POST['AsAuthor'])){
        $aut = 0;
    }
    else{
        $aut = $_POST['AsAuthor'];
    }
    if ($cap !== $code) {
       
        $_SESSION['captcha_fail'] = 1;
        header("Location:  ../user/register.php ");
        return;
    } 
    else{
       
    $r = mysqli_query ($pdb,$q);
    $rov = mysqli_fetch_array($r,MYSQLI_ASSOC);
    $row = mysqli_num_rows($r);

    if ($row > 0) { 
        $myid = $rov['id_'];
        
        $query4 = "SELECT * FROM users_cat WHERE userid=$myid and cat='$cat' ";
        $r4 = mysqli_query ($pdb,$query4);
        $row4 = mysqli_num_rows($r4);

        if ($row4 <= 0) {  

            $query3 = ("INSERT INTO users_cat (userid,cat,_reader,_author) 
        VALUES ($myid,'$cat', $rea, $aut ) ");    
        if (mysqli_query($pdb, $query3)) {
        $_SESSION['success_pass'] = 1;
     
        header("Location: ../user/register.php ");
        }
        else{
            if (mysqli_errno($pdb) == 1062){
                $_SESSION['username_exists'] = 1;
                header("Location:  ../user/register.php ");
                return;
            }
            $_SESSION['failed_change'] = 1;
    
            echo mysqli_error($pdb);
            }

        }
        else{
            $_SESSION['username_exists'] = 1;
            header("Location:  ../user/register.php ");
            return;
        }

        
    }
    else{
        $_SESSION['failed_change'] = 1;
        header("Location:  ../user/register.php ");
    }
}
    
  }