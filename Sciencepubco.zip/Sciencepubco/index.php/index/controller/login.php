<?php session_start(); ?>
<?php include '../classes/connection.php' ;

if (isset($_POST['butlogin'])){

$userx = mysqli_real_escape_string($pdb,$_POST['username']);
$pass = mysqli_real_escape_string($pdb,$_POST['password']);
$q = "SELECT * FROM users WHERE username='$userx' and passw='".md5($pass)."'";

$r = mysqli_query ($pdb,$q);
$rov = mysqli_fetch_array($r,MYSQLI_ASSOC);
$row = mysqli_num_rows($r);

if ($row > 0) {
    
    $_SESSION['pubcouser']['id'] = $rov['id_'];
    $_SESSION['pubcouser']['title'] = $rov['title'];
    $_SESSION['pubcouser']['firstname'] = $rov['fname'];
    $_SESSION['pubcouser']['lastname'] = $rov['lname'];
    $_SESSION['pubcouser']['school'] = $rov['school'];
    $_SESSION['pubcouser']['username'] = $rov['username'];
    $_SESSION['pubcouser']['name'] = $rov['fname']." ".$rov['lname'];
    $_SESSION['pubcouser']['email'] = $rov['email'];
    $_SESSION['pubcouser']['country'] = $rov['country'];
    $_SESSION['pubcouser']['addr'] = $rov['addr'];
    $_SESSION['pubcouser']['gender'] = $rov['gender'];
    $_SESSION['pubcouser']['phone'] = $rov['phone'];
    $_SESSION['pubcouser']['bio'] = $rov['bio_statement'];
    $myid = $rov['id_'];
    
    $q2 = "SELECT * FROM users_cat WHERE userid=$myid ";

    $r2 = mysqli_query ($pdb,$q2);
    $rov2 = mysqli_fetch_array($r2,MYSQLI_ASSOC);
 
    $_SESSION['pubcouser']['category'] = $rov2['cat'];
    $_SESSION['pubcouser']['author'] = $rov2['_author'];
    $_SESSION['pubcouser']['reader'] = $rov2['_reader'];
    $_SESSION['pubcouser']['reviewer'] = $rov2['_reviewer'];

    header('Location: ../index.php'); 
}
else {
    $_SESSION['loginfailed'] =  true;
    header("Location: ../login.php");
    exit;
} 

}

if (isset($_POST['butUpdateProfile'])){

    $sal =  mysqli_real_escape_string($pdb,$_POST['salutation']);
    $fn =  mysqli_real_escape_string($pdb,$_POST['fname']);
    $ln =  mysqli_real_escape_string($pdb,$_POST['lname']);
    $uni =  mysqli_real_escape_string($pdb,$_POST['uni']);
    $email =  mysqli_real_escape_string($pdb,$_POST['email']);
    $addr =  mysqli_real_escape_string($pdb,$_POST['addr']);
    $gen =  mysqli_real_escape_string($pdb,$_POST['gender']);
    $bio =  mysqli_real_escape_string($pdb,$_POST['bio']);
    $ph =  mysqli_real_escape_string($pdb,$_POST['phone']);

    $mystu = $_SESSION['pubcouser']['id'];

    $query = (" UPDATE users SET title = '$sal', 
        fname = '$fn', lname = '$ln', school = '$uni', email = '$email'  
        WHERE id_ = $mystu ");
        
        if (mysqli_query($pdb, $query)) {
          
            $_SESSION['pubcouser']['title'] = $sal;
            $_SESSION['pubcouser']['firstname'] = $fn;
            $_SESSION['pubcouser']['lastname'] = $ln;
            $_SESSION['pubcouser']['school'] = $uni;
            $_SESSION['pubcouser']['email'] = $email;
            $_SESSION['pubcouser']['addr'] = $addr;
            $_SESSION['pubcouser']['gender'] = $gen;
            $_SESSION['pubcouser']['phone'] = $ph;
            $_SESSION['pubcouser']['bio'] = $bio;
            
          $_SESSION['success_pass'] = 1;
         
          header("Location:  ../profile.php ");
         }
         else {
      
          $_SESSION['failed_change'] = 1;
      
          echo mysqli_error($pdb);
          
          }
}
