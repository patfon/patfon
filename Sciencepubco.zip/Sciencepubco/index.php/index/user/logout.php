<?php 
session_start();
if (isset($_SESSION['pubcouser']))
{

    unset($_SESSION['pubcouser']);
    header("Location: ../login.php");
}

?>