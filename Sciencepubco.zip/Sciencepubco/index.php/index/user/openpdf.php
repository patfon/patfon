<?php 
session_start();

if (isset($_GET['key']) && isset($_GET['name']))
{ 
  //  $newstrr = str_replace('_','/',$_GET['key']);
    $path = $_GET['key'];
    $na = $_GET['name'];

    $url = $myurl.$path;
    $content = file_get_contents($url);

    header('Content-Type: application/pdf');
    header('Content-Length: ' . strlen($content));
    header('Content-Disposition: inline; filename="' .$path.'/'.$na. '"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    ini_set('zlib.output_compression','0');
   


}