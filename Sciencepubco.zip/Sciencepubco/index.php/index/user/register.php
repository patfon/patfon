<?php include "../includes/header.php"; ?>

<body id="pkp-user-login">

<div id="container">
<?php include "../includes/navheader.php"; 
include "../../../simple-php-captcha/simple-php-captcha.php";
$_SESSION['captcha'] = simple_php_captcha();
?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			
			<a href="user/register.php" class="current">Register</a></div>
<h2><font color="#000046">Register to Post Journals</font></h2>

			<?php if (isset($_SESSION['captcha_fail'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your Validation captcha is wrong.
			</div>
			<?php } 
			unset($_SESSION['captcha_fail']);
			?>

			<?php if (isset($_SESSION['success_pass'])) { ?>
			<div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your Registration was Successfull, you can now Login.
			</div>
			<?php } 
			unset($_SESSION['success_pass']);
			?>
			<?php if (isset($_SESSION['username_exists'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;That username has been used already!!.
			</div>
			<?php } 
			unset($_SESSION['username_exists']);
			?>
			<?php if (isset($_SESSION['failed_change'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;That username does not exists on our platform.
			</div>
			<?php } 
			unset($_SESSION['failed_change']);
			?>
			<?php if (isset($_SESSION['pubcouser_reg']['join'])) { ?>
<div id="content">
<?php if (!isset($_GET['existing'])) { ?>
<div style="background-color: #a3b0b7; border: 5px double #000060; width:95%;box-shadow: 0 2px 20px #cbcbcb;-moz-box-shadow: 0 2px 20px #cbcbcb;-webkit-box-shadow: 0 2px 20px #cbcbcb;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;padding:12px;">
<form class="editor_form" id="registerForm" method="post" action="<?php echo $myurl.$myurlex."controller/register.php"; ?>">
<p>Fill in this form to register with this site.</p>

			
		<p><a href="<?php echo $myurl.$myurlex."user/register.php?existing=1"; ?>">Click here</a> if you are already registered with this or another journal on this site.</p>
	
	<h3>Profile</h3>

		<div style="background-color:transparent;color:#000;border-radius: 5px">
	<p><span class="formRequired" style="color: red;">All fields are compulsory</span></p>
<table class="data" width="100%">
	<tbody><tr valign="top">
		<td width="18%" style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Username:</td>
		<td width="82%" class="value">
			<input type="text" required='required' name="username" value="" id="username" size="20" maxlength="32" class="textField editor_field"></td>
	</tr>
		<tr valign="top">
		<td style="background:#ccdce5;"></td>
		</tr>
		<tr valign="top" class="divclass">
		<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Password:</td>
		<td class="value ">
		<input type="password" required='required' name="password" value="" id="passwordx" size="20" minlength="6" class="textField editor_field">
		</td>
	</tr>

			<tr valign="top">
			<td style="background:#ccdce5;"></td>
			<td style="color:#0000FF;font-size: 16px;width:60%;float: left;" class="instruct">The password must be at least 6 characters.</td>
		</tr>
		<tr valign="top" class="cdivclass">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Repeat Password:</td>
			<td class="value ">
			<input type="password" name="password2" required='required' id="passwordxx" size="20" minlength="6" class="textField editor_field">
			<span class="help-block" style="color: red; font-size: 12px; font-weight: bold;">.</span>
			</td>
			
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Title:</td>
			<td class="value">
				<select name="salutation" required='required' id="salutation" class="selectMenu" value="">
					<option value=""></option>
					<option value="Mr">Mr.</option>
					<option value="Mrs">Mrs.</option>
					<option value="Ms">Ms.</option>
					<option value="Dr">Dr.</option>
					<option value="Prof">Prof.</option>
				</select>
			</td>
		</tr>
		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">First Name:</td>
			<td class="value"><input type="text" required='required' id="firstName" name="fname" value="" size="20" maxlength="40" style="text-transform: capitalize;" class="textField editor_field"></td>
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Last Name:</td>
			<td class="value"><input type="text" required='required' id="lastName" name="lname" value="" size="20" maxlength="90" style="text-transform: capitalize;" class="textField editor_field"></td>
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">
<label for="affiliation">
	Affiliation </label>
:</td>
			<td class="value">
				<textarea name="uni" id="affiliation"  rows="5" cols="21" class="textArea" value=""></textarea><br>
				<span style="color:#0000FF;font-size: 16px;" class="instruct">(Your institution, e.g. "Lagos State University")</span>
			</td>
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Email:</td>
			<td class="value">
				
			<input type="email" id="email" required='required' name="email" value="" size="30" maxlength="90" class="textField editor_field"> </td>
		</tr>

		<tr valign="top" class="cdivclass2">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Confirm Email:</td>
			<td class="value">
			<input type="email" required='required' id="confirmEmail" name="confirmEmail" value="" size="30" maxlength="90" class="textField editor_field">
			<span class="help-block" style="color: red; font-size: 12px; font-weight: bold;">.</span>
		
			</td>
		</tr>

		<tr valign="top">
			<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">
<label for="country">
	Country </label>
:</td>
			<td class="value">
				<?php include "countries.php"; ?>
			</td>
		</tr>

				<tr valign="top">
		<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">
<label>
	Register as </label>
:</td>
		<td class="value">
        <input type="checkbox"  name="AsReader" id="registerAsReader" value="1" checked="checked"> 
        <label for="registerAsReader">Reader</label>: Notified by email on publication of an issue of the journal.<br>				
        <input type="checkbox"  name="AsAuthor" id="registerAsAuthor" value="1" checked="checked">
         <label for="registerAsAuthor">Author</label>: Able to submit items to the journal.<br>
		<!--<input type="checkbox" name="registerAsAuthor" id="registerAsAuthor" value="1" /> <label for="registerAsAuthor">Author</label>: Able to submit items to the journal.<br /> -->
		
		</td>
	</tr>

	<tr>
		<td width="18%" style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label" valign="top">Validation:</td>
		<td class="value">
		<?php echo '<img src="' . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA code">';?>
        <input type="text" id="" name="captcha" required="required" value="" size="30"  class="textField editor_field">
		</td>
	</tr>
</tbody></table>

<br>
<p><input type="submit" id="regsubmit" value="Register" name="submitform" class="button defaultButton"> 
<input type="reset" value="Cancel" class="button"> </p>

</div>



<div id="privacyStatement">
	<h3>Privacy Statement</h3>
	<p>The names and email addresses entered in this journal site will be used exclusively for the stated purposes of this journal and will not be made available for any other purpose or to any other party.</p>
</div>
</form>
</div>

<?php } else { ?>

<!--Existing User -->
<div style="background-color: #a3b0b7; border: 5px double #000060; width:95%;box-shadow: 0 2px 20px #cbcbcb;-moz-box-shadow: 0 2px 20px #cbcbcb;-webkit-box-shadow: 0 2px 20px #cbcbcb;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;padding:12px;">
<form class="editor_form" id="registerForm" method="post" action="<?php echo $myurl.$myurlex."controller/register.php"; ?>">
<p>Fill in this form to register with this site.</p>

			
		<p><a href="<?php echo $myurl.$myurlex."user/register.php"; ?>">Click here</a> if you are <strong>not</strong> already registered with this or another journal on this site.</p>
		<input type="hidden" name="existingUser" value="1">
	
	<h3>Profile</h3>

				<p>Enter your existing username and password to register with this journal.</p>
	<div style="background-color:transparent;color:#000;border-radius: 5px">
	<p><span class="formRequired" style="color: red;">All fields are compulsory</span></p>
<table class="data" width="100%">
	<tbody><tr valign="top">
		<td width="18%" style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Username:</td>
		<td width="82%" class="value"><input type="text" required='required' name="username" value="" id="username" size="20" maxlength="32" class="textField editor_field"></td>
	</tr>
		<tr valign="top">
		<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">Password:</td>
		<td class="value"><input type="password" name="password" required='required' value="" id="password" size="20" maxlength="32" class="textField editor_field"></td>
	</tr>

	<tr>
		<td width="18%" style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label" valign="top">Validation:</td>
		<td class="value">
		<?php echo '<img src="' . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA code">';?>
        <input type="text" id="" name="captcha" required="required" value="" size="30"  class="textField editor_field">
		</td>
	</tr>

		<tr valign="top">
		<td style="background:#ccdce5; font-weight: bold; padding-left:10px;font-size: 16px;" class="label">
<label>
	Register as </label>
:</td>
		<td class="value">
        <input type="checkbox" name="AsReader" id="registerAsReader" value="1" checked="checked"> <label for="registerAsReader">Reader</label>: Notified by email on publication of an issue of the journal.<br>				
        <input type="checkbox" name="AsAuthor" id="registerAsAuthor" value="1" checked="checked"> <label for="registerAsAuthor">Author</label>: Able to submit items to the journal.<br>
		<!--<input type="checkbox" name="registerAsAuthor" id="registerAsAuthor" value="1" /> <label for="registerAsAuthor">Author</label>: Able to submit items to the journal.<br /> -->
		
		</div>
		</td>
	</tr>

	
</tbody></table>

<br>
<p><input type="submit" value="Register" name="submitformreg" class="button defaultButton"> <input type="button" value="Cancel" class="button" onclick="document.location.href='https://www.sciencepubco.com/index.php/GJMA/index'"></p>

</div>

<div id="privacyStatement">
	<h3>Privacy Statement</h3>
	<p>The names and email addresses entered in this journal site will be used exclusively for the stated purposes of this journal and will not be made available for any other purpose or to any other party.</p>
</div>
</form>

<?php } ?>
</div>
<?php } else { //echo "<meta http-equiv='refresh' content='0;url=".$myurl." index.php' >"; ?>
	<meta http-equiv="refresh" content="0;url=<?php echo $myurl.$myurlex.'user/choose.php' ?>">
<?php }
	?>

<!---->


</div>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
