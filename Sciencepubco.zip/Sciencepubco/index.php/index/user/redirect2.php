<?php 
session_start();
include "../classes/connection.php";
include "../functions/index.php";
if (isset($_GET['key']))
{

    $k = $_GET['key'];

    if ($k === 'sub1'){
        $_SESSION['pubcouser']['sub1'] = 1; 
        unset ($_SESSION['pubcouser']['sub2']);
        unset ($_SESSION['pubcouser']['sub3']);
        unset ($_SESSION['pubcouser']['sub4']);
        unset ($_SESSION['pubcouser']['sub5']);
    }
    if ($k === 'sub2'){
        $_SESSION['pubcouser']['sub2'] = 1; 
        unset ($_SESSION['pubcouser']['sub1']);
        unset ($_SESSION['pubcouser']['sub3']);
        unset ($_SESSION['pubcouser']['sub4']);
        unset ($_SESSION['pubcouser']['sub5']);
    }
    if ($k === 'sub3'){
        $_SESSION['pubcouser']['sub3'] = 1; 
        unset ($_SESSION['pubcouser']['sub2']);
        unset ($_SESSION['pubcouser']['sub1']);
        unset ($_SESSION['pubcouser']['sub4']);
        unset ($_SESSION['pubcouser']['sub5']);
    }
    if ($k === 'sub4'){
        $_SESSION['pubcouser']['sub4'] = 1; 
        unset ($_SESSION['pubcouser']['sub2']);
        unset ($_SESSION['pubcouser']['sub3']);
        unset ($_SESSION['pubcouser']['sub1']);
        unset ($_SESSION['pubcouser']['sub5']);
    }
    if ($k === 'sub5'){
        $_SESSION['pubcouser']['sub5'] = 1; 
        unset ($_SESSION['pubcouser']['sub2']);
        unset ($_SESSION['pubcouser']['sub3']);
        unset ($_SESSION['pubcouser']['sub4']);
        unset ($_SESSION['pubcouser']['sub1']);
    }
   
    header("Location: submitjournal.php");
}


if (isset($_GET['key2']))
{

    $key = $_GET['key2'];
    if ($key === 'Active'){
        $_SESSION['pubcouser']['subjournal'] = 1; 
        header("Location: submitdashboard.php");
    }
    else{
        $_SESSION['pubcouser']['subjournal'] = 2;
        header("Location: submitdashboard.php");
    }

}

if (isset($_GET['archive']))
{
    $id = $_GET['archive'];
  
    $change = changesubmission($pdb,$id,'archive');
    header("Location: submitdashboard.php");
}

if (isset($_GET['active']))
{
    $id = $_GET['active'];
  
    $change = changesubmission($pdb,$id,'active');
    header("Location: submitdashboard.php");
}


?>