<?php 
session_start();
if (isset($_GET['keyword']))
{

    $kk = $_GET['keyword'];
    $_SESSION['pubcouser_reg']['join'] = $kk;
    header("Location: register.php");
}
else{
    header("Location: choose.php");
}

?>