<?php 
include "../includes/header.php";
include "../classes/connection.php";
include "../functions/index.php";

unset($_SESSION['pubcouser_reg']['join']);
unset($_SESSION['pubcouser_reg']['join2']);
?>
<body id="pkp-user-login">

<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="dashboard.php" class="current">Dashboard</a></div>
            <h2><font color="#000046">User Home Dashboard</font></h2>
            
			<?php if (isset($_SESSION['loginfailed'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your login attempt has failed. 
			</div>
			<?php } 
			unset($_SESSION['loginfailed']);
			?>
			<?php if (isset($_SESSION['success_pass'])) { ?>
			<div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;You have successfully logged in. 
			</div>
			<?php } 
			unset($_SESSION['success_pass']);
			?>
				<?php if (isset($_SESSION['submission'])) { ?>
			<div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your Submission of Journal has been sucessfull.
			</div>
			<?php } 
			unset($_SESSION['submission']);
			?>
			<?php if (isset($_SESSION['error_sub'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your Submission Has Failed. 
			</div>
			<?php } 
			unset($_SESSION['error_sub']);
			?>
<div id="content">
<div id="journals">
<div style="width:95%;box-shadow: 0 2px 20px #cbcbcb;-moz-box-shadow: 0 2px 20px #cbcbcb;-webkit-box-shadow: 0 2px 20px #cbcbcb;-webkit-border-radius: 15px 15px; 15px 15px;-moz-border-radius: 15px 15px; 15px 15px;border-radius: 15px 15px; 15px 15px;padding:12px;">
<hr>
<?php 
		$myid = $_SESSION['pubcouser']['id'];
		$mycat = getcategories($pdb,$myid);

?>
<div id="myJournals">
<?php  			$_SESSION['pubcouser']['sub1'] = 1; 
			   unset ($_SESSION['pubcouser']['sub2']);
			   unset ($_SESSION['pubcouser']['sub3']);
			   unset ($_SESSION['pubcouser']['sub4']);
			   unset ($_SESSION['pubcouser']['sub5']);
			   $_SESSION['pubcouser']['random'] =  mt_rand(1,10000);
			  
		?>

	<?php foreach ($mycat as $my) { ?>

	<div id="journal">
		<h3><?php echo $codes2[$my['cat']]; ?> </h3>			
        <table width="100%" class="info">
        <tbody>
        <tr>
        <td class="separator" width="100%" colspan="5">&nbsp;</td>
        </tr>
	
			<tr>
				<td>» <a href="#">Author</a></td>
				<td></td>
				<td></td>
				<td><a href='<?php echo "submitdashboard.php?key=".$my['cat']; ?>'>
				<?php echo gettotalsubmit($pdb,$my['cat'],$myid); ?> Submitted</a></td>
				<td align="right">
				<a href="<?php echo $myurl.$myurlex."user/submitjournal.php?key=".$my['cat']; ?>">
                <font style="color:white; font-family: Arial; font-weight: bold; background:#CC0000; padding: 5px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;">New Submission</font>
				</a></td>
			</tr>
		<tr>
			<td width="25%"></td>
			<td width="12%"></td>
			<td width="12%"></td>
			<td width="12%"></td>
			<td width="39%"></td>
		</tr>
			
	</tbody></table>
	
	</div>
	<?php } ?>

</div>	


<div id="myAccount">
<h3>My Account</h3>
<ul class="plain">
						<li>» <a href="">Show My Journals</a></li>
								<li>» <a href="<?php echo $myurl.$myurlex.'profile.php'; ?>">Edit My Profile</a></li>

			<li>» <a href="#">Change My Password</a></li>
	
					<li>» <a href="<?php echo $myurl.$myurlex.'logout.php'; ?>">Logout</a></li>
	
</ul>
</div>
</div>

</div>

</div>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
