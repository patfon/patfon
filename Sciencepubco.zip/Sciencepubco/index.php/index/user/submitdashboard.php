<?php include "../includes/header.php";
include "../classes/connection.php";
include "../functions/index.php";
if (isset($_GET['key'])){
	$_SESSION['pubcouser_reg']['join'] = $_GET['key'];
	
}
$myid = $_SESSION['pubcouser']['id'];
?>
<body id="pkp-user-login">

<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">

<div id="main">


<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="dashboard.php" class="hierarchyLink">User</a> 
			<a href="#" class="hierarchyLink">Author</a> 
			<a href="" class="current">Submissions</a></div>
<?php if (isset($_SESSION['pubcouser']['subjournal']) && $_SESSION['pubcouser']['subjournal'] === 1 ){ ?>
<h2><font color="#000046"> Active Submissions</font></h2>
<?php } ?>
<?php if (isset($_SESSION['pubcouser']['subjournal']) && $_SESSION['pubcouser']['subjournal'] === 2 ){ ?>
<h2><font color="#000046"> Archived Submissions</font></h2>
<?php } ?>

<div id="content">
<div style="width:95%;box-shadow: 0 2px 20px #cbcbcb;-moz-box-shadow: 0 2px 20px #cbcbcb;-webkit-box-shadow: 0 2px 20px #cbcbcb;-webkit-border-radius: 10px;-moz-border-radius: 10px;border-radius: 10px;padding:12px;">
<ul class="steplist">
	<li 
	<?php if (isset($_SESSION['pubcouser']['subjournal']) && $_SESSION['pubcouser']['subjournal'] === 1 ){
		echo 'class="current" ';
	} ?>
	>
    <a href="redirect2.php?key2=Active">Active</a></li>
	<li <?php if (isset($_SESSION['pubcouser']['subjournal']) && $_SESSION['pubcouser']['subjournal'] === 2 ){
		echo 'class="current" ';
	} ?> 
	><a href="redirect2.php?key2=Archive">Archive</a></li>
</ul>

<br>
<?php if (isset($_SESSION['pubcouser']['subjournal']) && $_SESSION['pubcouser']['subjournal'] === 1 ){ 
	$mytotal = gettotalcategory($pdb,$myid,$_SESSION['pubcouser_reg']['join'],'active');
	$mypaid = array (1=>'PAID',0=>'NOT PAID');
	?>
<div id="submissions" style="overflow-y: scroll; max-height: 400px; ">
<table class="listing" width="100%">
	<tbody><tr><td colspan="6" class="headseparator">&nbsp;</td></tr>
	<tr class="heading" valign="bottom">
		<td width="5%">ID</td>
		<td width="15%">Submit Date</td>
		<td width="15%">Sec</td>
		<td width="15%">Title</td>
		<td width="10%">Status</td>
        <td width="15%">Paid?</td>
		<td width="10%"></td>
	</tr>
	<tr><td colspan="6" class="headseparator">&nbsp;</td></tr>
	
	<?php foreach ($mytotal as $myt) { ?>
	<tr valign="top">	
	<td><?php echo $myt['id'];?></td>
	<td><?php echo $myt['_date'];?></td>
	<td><?php echo 'Article';?></td>
	<td><?php echo $myt['meta_title'];?></td>
	<td><?php echo 'Active';?></td>
	<td><?php echo $mypaid[getpaidjournal($pdb,$myt['id'])];?></td>	
	<td><a class='btn btn-warning btn-sm' href='redirect2.php?archive=<?php echo $myt['id'] ?>'>Make This Archived</a></td>	
	
	</tr>
	<?php } ?>
	<tr>
		<td colspan="6" class="separator">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="4" align="left">1 - <?php echo count($mytotal); ?> of <?php echo count($mytotal); ?> Items</td>
		<td colspan="2" align="right"></td>
	</tr>
</tbody>
</table>

</div>
<?php } ?>
<?php if (isset($_SESSION['pubcouser']['subjournal']) && $_SESSION['pubcouser']['subjournal'] === 2 ){ 
	$mytotal = gettotalcategory($pdb,$myid,$_SESSION['pubcouser_reg']['join'],'archive');
	$mypaid = array (1=>'PAID',0=>'NOT PAID');
	?>
<div id="submissions" style="overflow-y: scroll; max-height: 400px; ">
<table class="listing" width="100%">
	<tbody><tr><td colspan="6" class="headseparator">&nbsp;</td></tr>
	<tr class="heading" valign="bottom">
		<td width="5%">ID</td>
		<td width="15%">Submit Date</td>
		<td width="15%">Sec</td>
		<td width="15%">Title</td>
		<td width="15%">Status</td>
        <td width="15%">Paid?</td>
		<td width="10%"></td>
	</tr>
	<tr><td colspan="6" class="headseparator">&nbsp;</td></tr>
	
	<?php foreach ($mytotal as $myt) { ?>
	<tr valign="top">	
	<td><?php echo $myt['id'];?></td>
	<td><?php echo $myt['_date'];?></td>
	<td><?php echo 'Article';?></td>
	<td><?php echo $myt['meta_title'];?></td>
	<td><?php echo 'Active';?></td>
	<td><?php echo $mypaid[getpaidjournal($pdb,$myt['id'])];?></td>
	<td><a class='btn btn-warning btn-sm' href='redirect2.php?active=<?php echo $myt['id'] ?>'>Make This Active</a></td>	
	</tr>
	<?php } ?>
	<tr>
		<td colspan="6" class="separator">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="4" align="left">1 - <?php echo count($mytotal); ?> of <?php echo count($mytotal); ?> Items</td>
		<td colspan="2" align="right"></td>
	</tr>
</tbody>
</table>

</div>
<?php } ?>

<div id="submitStart">
<h4>Start a New Submission</h4>

<a href="submitjournal.php" class="action">Click here</a> to go to step one of the five-step submission process.<br>
</div>

</div>

</div><!-- content -->

</div>

</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
