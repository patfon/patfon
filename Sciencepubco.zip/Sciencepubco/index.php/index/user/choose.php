<?php include "../includes/header.php";
unset($_SESSION['pubcouser_reg']['join']);
?>
<body id="pkp-user-login">

<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="choose.php" class="current">Choose Category to Join</a></div>
            <h2><font color="#000046">Choose Category</font></h2>
<div id="content">
<div id="journals">
			Select a journal to register with:
		<ul>
            <?php $myconstant = array('GJMA'=>1,"IJAMS"=>2,"IJAMR"=>3,"IJASP"=>4,"IJPR"=>5,"IJAC"=>6,
                                     "IJBR"=>7,'JACST'=>8,'IJBAS'=>9,'IJET'=>10,'IJAG'=>11,
                                     'IJM'=>12,'IJDR'=>13,'IJPT'=>14,'IJANS'=>15,'IJH'=>16, 
                                     'IJAES'=>17,'IJAA'=>18,'IJSW'=>19,'JE'=>20,'JFNS'=>21,
                                     'JPS'=>22,'JM'=>23,'JWR'=>24,'JES'=>25,'JAS'=>26,'JSC'=>27,
                                     'JP'=>28,'JEDU'=>29); ?>

		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=GJMA"; ?>">Global Journal of Mathematical Analysis</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJAMS"; ?>">International Journal of Advanced Mathematical Sciences</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJAMR"; ?>">International Journal of Applied Mathematical Research</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJASP"; ?>">International Journal of Advanced Statistics and Probability</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJPR"; ?>">International Journal of Physical Research</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJAC"; ?>">International Journal of Advanced Chemistry</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJBR"; ?>">International Journal of Biological Research</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=JACST"; ?>">Journal of Advanced Computer Science &amp; Technology</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJBAS"; ?>">International Journal of Basic and Applied Sciences</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJET"; ?>">International Journal of Engineering &amp; Technology</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJAG"; ?>">International Journal of Advanced Geosciences</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJM"; ?>">International Journal of Medicine</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJDR"; ?>">International Journal of Dental Research</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJPT"; ?>">International Journal of Pharmacology and Toxicology</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJANS"; ?>">International Journal of Advanced Nursing Studies</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJH"; ?>">International Journal of Health</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJAES"; ?>">International Journal of Accounting and Economics Studies</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJAA"; ?>">International Journal of Advanced Astronomy</a></li>
		<li><a href="<?php echo $myurl.$myurlex."user/redirect.php?keyword=IJSW"; ?>">International Journal of Scientific World</a></li>
		
		<!--<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JE"; ?>">SPC Journal of Energy</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JFNS"; ?>">SPC Journal of Food and Nutrition Sciences</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JPS"; ?>">SPC Journal of Plant Sciences</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JM"; ?>">SPC Journal of Materials</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JWR"; ?>">SPC Journal of Water Research</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JES"; ?>">SPC Journal of Environmental Sciences</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JAS"; ?>">SPC Journal of Agricultural Sciences</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JSC"; ?>">SPC Journal of Social Sciences</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JP"; ?>">SPC Journal of Psychology</a></li>
		<li><a href="<?php //echo $myurl.$myurlex."user/redirect.php?keyword=JEDU"; ?>">SPC Journal of Education</a></li>
		-->
	</ul>
</div>

</div>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
