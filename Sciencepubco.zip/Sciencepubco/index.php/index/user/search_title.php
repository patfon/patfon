<?php 
include "../includes/header.php";
include "../classes/connection.php";
include "../functions/index.php";

unset($_SESSION['pubcouser_reg']['join']);
unset($_SESSION['pubcouser_reg']['join2']);
?>
<body id="pkp-user-login">

<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="search_title.php" class="current">Search</a></div>
            <h2><font color="#000046">Browse Title Index</font></h2>
            
		
<div id="content">

<div id="results" style="overflow-y: scroll; max-height: 500px; ">

<table width="100%" class="listing">
<tbody>

<tr>
<td colspan="3" class="headseparator">&nbsp;</td>
</tr>
<tr class="heading" valign="bottom">
        <td width="20%">S/N</td>
		<td width="40%">Category</td>
	<td width="40%" colspan="2">Title</td>
</tr>
<tr><td colspan="3" class="headseparator">&nbsp;</td></tr>
<?php $submission = getpaidsubmission($pdb); $i = 1; $p1 = ''; $p2 = ''; ?>
<?php foreach ($submission as $sub) {   ?>
<tr valign="top">
	<td><a href=""><?php echo $i; ?></a></td>
	<td width="25%"><?php echo $codes2[$sub['cat']]; ?></td>
    <td width="25%"><?php echo $sub['meta_title']; ?></td>
	<td width="25%" align="right">
			
							&nbsp;
			<a href="" class="file">PDF</a>
	</td>
</tr>
<tr>
	                <td colspan="3" style="padding-left: 30px;font-style: italic;">
                    <?php //explode_paragraph(strip_tags($sub['meta_abstract']),$p1,$p2);
                    
                    echo $sub['meta_abstract'];  ?>
                    </td>
</tr>
<tr><td colspan="4" class="separator">&nbsp;</td></tr>

<?php $i++; } ?>
</tbody><table>
</div>

</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>
</div>
</div><!-- container -->

<?php include "../includes/footer.php"; ?>
