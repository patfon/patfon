<?php include "../includes/header.php";
if (isset($_GET['key'])){
	$_SESSION['pubcouser_reg']['join'] = $_GET['key'];
	unset($_SESSION['pubcouser_reg']['join2']);
}?>
<body id="pkp-user-login">

<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">

            
			<?php if (isset($_SESSION['loginfailed'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your login attempt has failed. 
			</div>
			<?php } 
			unset($_SESSION['loginfailed']);
			?>
			<?php if (isset($_SESSION['error_sub'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your submission attempt has failed. 
			</div>
			<?php } 
			unset($_SESSION['error_sub']);
			?>
			<?php if (isset($_SESSION['error_sub_inner'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your submission attempt has failed inside. 
			</div>
			<?php } 
			unset($_SESSION['error_sub_inner']);
			?>
			<?php if (isset($_SESSION['data_format'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;Your submission in either Metadata Abstract, Metadata References or Supplementary Description boxes are not in plain text.<br> Avoid Pasting text directly from PDF. 
			</div>
			<?php } 
			unset($_SESSION['data_format']);
			?>

			<?php if (isset($_SESSION['success_pass'])) { ?>
			<div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;You have successfully logged in. 
			</div>
			<?php } 
			unset($_SESSION['success_pass']);
			?>
            <?php if (isset($_SESSION['picdone'])) { ?>
			<div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;You have successfully uploaded the journal files. 
			</div>
			<?php } 
			unset($_SESSION['picdone']);
			?>
             <?php if (isset($_SESSION['picdone2'])) { ?>
			<div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;You have successfully uploaded the supplementary journal files. 
			</div>
			<?php } 
			unset($_SESSION['picdone2']);
			?>

			<?php if (isset($_SESSION['picdone3'])) { ?>
			<div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp;You have successfully uploaded the supplementary journal files. 
			</div>
			<?php } 
			unset($_SESSION['picdone3']);
			?>
			 <?php /** 
			    if (isset($_SESSION['pubcousertemp'])) { 
				 echo var_dump($_SESSION['pubcousertemp']);}
						**/ 
			  ?>

        	<?php if (isset($_SESSION['picerror'])) { ?>
			<div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>&nbsp;&nbsp; <?php echo $_SESSION['picerror']; ?>
			</div>
			<?php } 
			unset($_SESSION['picerror']);
			?>
<div id="content">
<div id="main">


<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			
			<a href="" class="current">New Submission</a></div>
            <h2><font color="#000046"> 
			<?php if (isset($_SESSION['pubcouser']['sub1'])){ 
				echo "Step 1. Starting the Submission";
			} ?>
			<?php if (isset($_SESSION['pubcouser']['sub2'])){ 
				echo "Step 2. Upload File of Journal";
			} ?>
			<?php if (isset($_SESSION['pubcouser']['sub3'])){ 
				echo "Step 3. Enter Metadata";
			} ?>
			<?php if (isset($_SESSION['pubcouser']['sub4'])){ 
				echo "Step 4. Upload Supplementary Files";
			} ?>
			<?php if (isset($_SESSION['pubcouser']['sub5'])){ 
				echo "Step 5. Confirm Your Details";
			} ?>
			</font></h2>


<div id="content">

<ul class="steplist">
<li id="step1" 
<?php if (isset($_SESSION['pubcouser']['sub1'])){ 
	echo "class='current'";
	
}?>
> 
<a href = 'redirect2.php?key=sub1'>
1. Start 
</a>
</li>

<li id="step2" 
<?php if (isset($_SESSION['pubcouser']['sub2'])){ 
    echo "class='current'";
}?>
>
<a href = 'redirect2.php?key=sub2'> 2. Upload Submission
</a>
</li>

<li id="step3" 
<?php if (isset($_SESSION['pubcouser']['sub3'])){ 
    echo "class='current'";
}?>
> 
<a href = 'redirect2.php?key=sub3'>
3. Enter Metadata  
</a>
</li>

<li id="step4" 
<?php if (isset($_SESSION['pubcouser']['sub4'])){ 
    echo "class='current'";
}?>
> 
<a href = 'redirect2.php?key=sub4'>
4. Upload Supplementary Files
</a>
</li>

<li id="step5" 
<?php if (isset($_SESSION['pubcouser']['sub5'])){ 
    echo "class='current'";
}?>>
<a href = 'redirect2.php?key=sub5'>
5. Confirmation
</a>
</li>
</ul>

<div class="separator"></div>

<form class="editor_form" id="submit" enctype="multipart/form-data" method="post" action="<?php echo $myurl.$myurlex."controller/submit.php"; ?>" >


			<input type="hidden" name="journalid" value="<?php echo $_SESSION['pubcouser']['random']; ?>">
<?php if (isset($_SESSION['pubcouser']['sub1'])){ ?>
<div id="commentsForEditor">
<h3>Comments for the Editor</h3>
<label for="commentsToEditor">
	Enter text (optional) </label>
<table width="100%" class="data">
<tbody><tr valign="top">
	<td width="20%" class="label">
<label for="commentsToEditor">
	Enter text (optional) </label>
</td>
	<td width="80%" class="value">
    <textarea name="comments" id="commentsToEditor" rows="15" cols="70" class="textArea">
	<?php 
	if (isset($_SESSION['pubcouser']['sub1_x'])){
		
		echo str_replace('\r\n','<br>',$_SESSION['pubcouser']['sub1_x']);
	}
	?>
	</textarea>
	</td>
    </tr>
</tbody></table>
</div>
<?php } ?>
<?php if (isset($_SESSION['pubcouser']['sub2'])){ ?>

<div id="commentsForEditor">
<h3>Upload Journal File</h3>

<div id="submissionFile">
<h3>Submission File</h3>
<table class="data" width="100%">
<tbody><tr valign="top">
	<?php if (!isset($_SESSION['pubcouser']['sub2_x']) && !isset($_SESSION['pubcouser']['sub2_name']) ){ ?>
	<td colspan="2" class="nodata">No submission file uploaded.</td>
	<?php } else { 
		//&& !isset($_SESSION['pubcouser']['sub2_name']) ."&name=".$_SESSION['pubcouser']['sub2_name']
		?>
	<td colspan="2" >
	<?php //$newstr = str_replace('/',"_",$_SESSION['pubcouser']['sub2_x']); ?>
	<a target='_blank' href="openpdf.php?key=<?php echo $_SESSION['pubcouser']['sub2_x']; ?>&name=<?php echo $_SESSION['pubcouser']['sub2_name']; ?>" >
	<img src='<?php echo $myurl.'banner/pdf_icon.png'; ?>' width='50' height='60' />
	View File</a>
	</td>	
	<?php } ?>
</tr>
</tbody></table>
</div>

<div class="separator"></div>

<div id="addSubmissionFile">
<table class="data" width="100%">
<tbody><tr>
	<td width="30%" class="label">
					
<label for="submissionFile">
	Upload submission file </label>

			</td>
	<td width="70%" class="value">
		<input type="file" class="uploadField" required="required" name="subFile" accept="application/msword" id="submissionFile"> 
       
	</td>
</tr>
</tbody></table>
</div>

</div>
<?php } ?>

<?php if (isset($_SESSION['pubcouser']['sub3'])){ ?>
<div id="titleAndAbstract">
<h3>Title and Abstract</h3>

<table width="100%" class="data">

<tbody><tr valign="top">
	<td width="20%" >
<label for="title">
	Title * </label>
</td>
	<td width="80%" class="value">
    <input type="text" class="textField"  required="required" 
	name="title" id="title" value="<?php 
	if (isset($_SESSION['pubcouser']['sub3_x'])){
	
		echo str_replace('\r\n',"<br>",$_SESSION['pubcouser']['sub3_x']);
	}
	?>" size="60" >
    </td>
</tr>

<tr valign="top">
    <td width="40%" >
    <label for="abstract">
        Abstract *</label>
    </td>
	<td width="60%" class="value">
    <textarea name="abstract" id="abstract" required="required" class="textArea" rows="15" cols="60">
	<?php 
	if (isset($_SESSION['pubcouser']['sub3_xx'])){
		echo str_replace('\r\n',"<br>",$_SESSION['pubcouser']['sub3_xx']);
	}
	?>
	</textarea>
   </td>
</tr>
</tbody>

</table>
<div id="metaCitations">
<h3>References</h3>

<p>Provide a formatted list of references for works cited in this submission. Please separate individual references with a blank line.</p>

<table width="100%" class="data">
<tbody><tr valign="top">
	<td width="20%" >
<label for="citations">
	References </label>
</td>
	<td width="80%" class="value">
    <textarea name="citation" id="citations"  required="required" class="textArea" rows="15" cols="60" >
	<?php 
	if (isset($_SESSION['pubcouser']['sub3_xxx'])){
		//echo $_SESSION['pubcouser']['sub3_xxx'];
		echo str_replace('\r\n',"<br>",$_SESSION['pubcouser']['sub3_xxx']);
	}
	?>
	</textarea>
</td>
</tr>
</tbody>
</table>

<div class="separator"></div>
</div>

</div>
<?php } ?>


<?php if (isset($_SESSION['pubcouser']['sub4'])){ ?>

    <p>This optional step allows Supplementary Files to be added to a submission. The files, which can be in any format, might include (a) research instruments, (b) data sets, which comply with the terms of the study's research ethics review, (c) sources that otherwise would be unavailable to readers, (d) figures and tables that cannot be integrated into the text itself, or other materials that add to the contribution of the work.</p>
    <table class="listing" style="font-size: 16px; " width="100%">
<tbody><tr>
	<td colspan="5" class="headseparator">&nbsp;</td>
</tr>
<tr class="heading" valign="bottom">
	<td width="5%">ID</td>
	<td width="15%">Title</td>
	<td width="15%">File name</td>
	<td width="15%" class="nowrap">Type</td>
	<td width="15%" align="right">Action</td>
</tr>
<tr>
	<td colspan="6" class="headseparator">&nbsp;</td>
</tr>
<?php if (!isset($_SESSION['pubcousertemp'])) { ?>
<tr valign="top">
	<td colspan="4" class="nodata">No supplementary files have been added to this submission.</td>
</tr>
<?php } else {    
	$mysupp = $_SESSION['pubcousertemp'];
	$mysuppcount = count($mysupp);
	$i = 1;
	foreach($mysupp as $mys){ 
	?>
<tr valign="top">
	<td><?php echo $i; ?></td>
	<td><?php echo $mys[0]; ?></td>
	<td><?php echo $mys[11]; ?></td>
	<td><?php echo $mys[1]; ?></td>
	<td><a class='btn btn-danger btn-sm' href='getajax.php?removekey=<?php echo $i; ?>'>Remove</a></td>
</tr>
<?php $i++;} } ?>
</tbody></table>
<?php include 'inc_sup_form.php'; ?>
<table class="data" width="100%">
<tbody>
<tr class="editor_form">
	<td width="30%" >
<label for="uploadSuppFile" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Upload supplementary file </label>
	</td>
	<td width="70%" class="value">
		<input type="file" name="uploadSuppFile" accept="application/msword" id="uploadSuppFile" class="uploadField"> 
        
	</td>
</tr>
<tr class="editor_form">
	<td width="30%" >
<label for="uploadSuppFile" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Click Here to Submit Form***</label>
	</td>
	<td width="70%" class="value">
	<input type="submit" value="Save Supplementary File" name="suppFilesBut" class="button defaultButton">    
	</td>
</tr>
</tbody></table>

<?php } ?>

<?php if (isset($_SESSION['pubcouser']['sub5'])){ ?>

<p>Submit This Journal For Approval. By Clicking this Button, your changes are final.</p>
<table class="listing" style="font-size: 16px; " width="100%">
<tbody>
<tr>
<td colspan="5" class="headseparator">&nbsp;</td>
</tr>
<tr class="heading" valign="bottom">
<td colspan="5">
<input type="submit" value="Final Submission" name="finalsubmit" class="button defaultButton"> 
</td>
</tr>

</table>
<?php } ?>

<div class="separator"></div>
<?php if (!isset($_SESSION['pubcouser']['sub5'])){ ?>
<p>
<input type="submit" value="Save and continue" name="savesubmit" class="button defaultButton"> 
<input type="button" value="Cancel" class="button" ></p>
<?php } ?>
<p><span class="formRequired">* Denotes required field</span></p>

</form>


</div><!-- content -->
</div>

</div>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
