<?php 
include "../includes/header.php";
include "../classes/connection.php";
include "../functions/index.php";

unset($_SESSION['pubcouser_reg']['join']);
unset($_SESSION['pubcouser_reg']['join2']);
?>
<body id="pkp-user-login">

<div id="container">
<?php include "../includes/navheader.php"; ?>

<div id="body">
<div id="main">
<div id="breadcrumb">
	<a href="../index.php">Home</a> 
			<a href="search_author.php" class="current">Search</a></div>
            <h2><font color="#000046">Browse Author Index</font></h2>
            
		
<div id="content">



<div id="authors" style="overflow-y: scroll; max-height: 500px; " > 
		
		<?php echo showauthor($pdb, 'A'); ?>
		<?php echo showauthor($pdb, 'B'); ?>
		<?php echo showauthor($pdb, 'C'); ?>
		<?php echo showauthor($pdb, 'D'); ?>
		<?php echo showauthor($pdb, 'E'); ?>
		<?php echo showauthor($pdb, 'F'); ?>
		<?php echo showauthor($pdb, 'G'); ?>
		<?php echo showauthor($pdb, 'H'); ?>
		<?php echo showauthor($pdb, 'I'); ?>
		<?php echo showauthor($pdb, 'J'); ?>
		<?php echo showauthor($pdb, 'K'); ?>
		<?php echo showauthor($pdb, 'L'); ?>
		<?php echo showauthor($pdb, 'M'); ?>
		<?php echo showauthor($pdb, 'N'); ?>
		<?php echo showauthor($pdb, 'O'); ?>
		<?php echo showauthor($pdb, 'P'); ?>
		<?php echo showauthor($pdb, 'Q'); ?>
		<?php echo showauthor($pdb, 'R'); ?>
		<?php echo showauthor($pdb, 'S'); ?>
		<?php echo showauthor($pdb, 'T'); ?>
		<?php echo showauthor($pdb, 'U'); ?>
		<?php echo showauthor($pdb, 'V'); ?>
		<?php echo showauthor($pdb, 'W'); ?>
		<?php echo showauthor($pdb, 'X'); ?>
		<?php echo showauthor($pdb, 'Y'); ?>
		<?php echo showauthor($pdb, 'Z'); ?>


	
</div>

</div>
</div>

<script type="text/javascript" src="<?php echo $myurl."arrow6.js"; ?>"></script>
</div>

</div><!-- container -->

<?php include "../includes/footer.php"; ?>
