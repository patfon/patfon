<?php 
session_start();
if (isset($_GET['removekey']))
{
    $kk = $_GET['removekey'];
    $newkey = intval($kk) - 1;
    unset($_SESSION['pubcousertemp'][$newkey]);
    header("Location: submitjournal.php");
}

?>