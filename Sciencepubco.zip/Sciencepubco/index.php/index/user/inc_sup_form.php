<div id="supplementaryFileData">
<h3>Supplementary File Metadata</h3>

<p>To index this supplementary material, provide the following metadata for the uploaded supplementary file.</p>
<input type="hidden" name="journalsuppid" value="<?php echo mt_rand(1,500); ?>">
<table class="data" width="100%">
<tbody><tr valign="top">
	<td  > 
<label  style="width: 80px; font-size: 15px;  font-weight: bold;"> Title *
	</label>
</td>
	<td width="80%" class="value">
   
    <input type="text" class="textField editor_field" name="title" id="title" value="" size="60" maxlength="255">
    </td>
</tr>
<tr valign="top">
	<td width="20%">
<label style="width: 80px; font-size: 15px;  font-weight: bold;" for="creator">
	Creator (or owner) of file </label>
</td>
	<td width="80%" class="value">
	<input type="text" name="creator" class="textField" id="creator" value="" size="60" maxlength="255"></td>
</tr>
<tr valign="top">
	<td width="20%" >
<label style="width: 80px; font-size: 15px;  font-weight: bold;" for="subject">
	Keywords </label>
</td>
	<td width="80%" class="value"><input type="text" name="keyword" class="textField editor_field" id="subject" value="" size="60" maxlength="255"></td>
</tr>
<tr valign="top">
	<td width="20%" >
<label for="type" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Type *</label>
</td>
	<td width="80%" class="value">
    <select name="type" class="selectMenu"  id="type" size="1"><option label="Research Instrument" value="Research Instrument">Research Instrument</option>
<option label="Research Materials" value="Research Materials">Research Materials</option>
<option label="Research Results" value="Research Results">Research Results</option>
<option label="Transcripts" value="Transcripts">Transcripts</option>
<option label="Data Analysis" value="Data Analysis">Data Analysis</option>
<option label="Data Set" value="Data Set">Data Set</option>
<option label="Source Text" value="Source Text">Source Text</option>
<option label="Other" value="">Other</option>
</select><br>
<label for="typeOther" style="width: 80px; font-size: 15px;  font-weight: bold;">Specify other</label> 
<input type="text" name="typeOther" id="typeOther" class="textField editor_field" value="" size="45" maxlength="255"></td>
</tr>
<tr valign="top">
	<td width="20%" >
<label for="description" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Brief description *</label>
</td>
	<td width="80%" class="value">
    <textarea name="desc" class="textArea"   id="description" rows="5" cols="60" ></textarea>
    </td>
</tr>
<tr valign="top">
	<td width="20%" >
<label for="publisher" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Publisher </label>
</td>
	<td width="80%" class="value">
    <input type="text" name="pub"  class="textField editor_field" id="publisher" value="" size="60" maxlength="255">
	</td>
</tr>
<tr valign="top">
	<td>&nbsp;</td>
	<td><span class="instruct">Use only with formally published materials.</span></td>
</tr>
<tr valign="top">
	<td width="20%" >
<label for="sponsor" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Contributor or sponsoring agency </label>
</td>
	<td width="80%" class="value"><input type="text" name="sponsor" class="textField editor_field" id="sponsor" value="" size="60" maxlength="255"></td>
</tr>
<tr valign="top">
	<td width="20%" >
<label for="dateCreated" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Date *</label>
</td>
	<td width="80%" class="value">
    <input type="date" name="datecr"   class="textField editor_field" id="dateCreated" value="<?php echo date('yyyy-mm-dd'); ?>" > YYYY-MM-DD</td>
</tr>
<tr valign="top">
	<td>&nbsp;</td>
	<td><span class="instruct">Date when data was collected or instrument created.</span></td>
</tr>
<tr valign="top" >
	<td width="20%" >
<label for="source" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Source </label>
</td>
	<td width="80%" class="value">
    <input type="text" name="source" class="textField editor_field" id="source" value="" size="60" maxlength="255"></td>
</tr>
<tr valign="top">
	<td>&nbsp;</td>
	<td><span class="instruct">Name of study or other point of origin.</span></td>
</tr>
<tr valign="top">
	<td width="20%" >
<label for="language" style="width: 80px; font-size: 15px;  font-weight: bold;">
	Language *</label>
</td>
	<td width="80%" class="value">
    <input type="text" name="lang" class="textField editor_field" id="language" value="" size="5" maxlength="10"></td>
</tr>
<tr valign="top">
	<td>&nbsp;</td>
	<td><span class="instruct">English=en; French=fr; Spanish=es. <a target='_blank' href="http://www.loc.gov/standards/iso639-2/php/code_list.php" target="_blank">Additional codes</a>.</span></td>
</tr>
</tbody></table>
</div>