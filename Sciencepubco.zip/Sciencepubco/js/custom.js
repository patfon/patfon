///used for password validation
function validatepass(){
    console.log('entry.....');
            var password = $("#passwordx").val();
            var confirmPassword = $("#passwordxx").val();
        
            if (password !== confirmPassword) {
             
                $(".cdivclass").addClass("has-error");
                $("#regsubmit").attr("disabled","disabled");
                $(".cdivclass").removeClass("has-success");
                $(".cdivclass .help-block").html("The passwords do not match...");
            }
            else {
                $(".cdivclass .help-block").html("");
                $(".cdivclass").addClass("has-success");
                $(".cdivclass").removeClass("has-error");
                $("#regsubmit").removeAttr("disabled");
            }
        
}
function validatepass2(){
  
            var password = $("#email").val();
            var confirmPassword = $("#confirmEmail").val();
        
            if (password !== confirmPassword) {
            
                $(".cdivclass2").addClass("has-error");
                $("#regsubmit").attr("disabled","disabled");
                $(".cdivclass2").removeClass("has-success");
                $(".cdivclass2 .help-block").html("The emails do not match...");
            }
            else {
                $(".cdivclass2 .help-block").html("");
                $(".cdivclass2").addClass("has-success");
                $(".cdivclass2").removeClass("has-error");
                $("#regsubmit").removeAttr("disabled");
            }
        
}
$(document).ready(function() {
    $('#passwordxx').keyup(validatepass);
    $('#confirmEmail').keyup(validatepass2);
    
    
    
    
    
    });

