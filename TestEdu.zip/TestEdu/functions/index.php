<?php 


  /*** functions **/
  
  
  function getstates($con){
  
    $query = (" SELECT * FROM states ");
    $src = array();
    $result = mysqli_query($con,$query) or die(mysqli_error($con));
     if (mysqli_num_rows($result) > 0){
       while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
        
         $src[] = $r;
        }
     }
    
     return $src;
    
    }

    function getstateid($con,$id){
  
      $query = (" SELECT * FROM states WHERE id = $id");
      $src = array();
      $result = mysqli_query($con,$query) or die(mysqli_error($con));
       if (mysqli_num_rows($result) > 0){
         while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
          
           $src[] = $r;
          }
       }
      
       return $src;
      
      }

    function delstate($con,$id){

      $query = (" DELETE FROM states WHERE id = $id ");
      if (mysqli_query($con, $query)) {
       $src = true;
       $_SESSION['msg']['deletesubject'] = 1;
      } else {
        echo "Error deleting record: " . mysqli_error($con);
       $src = false;
      }
       return $src;
      
      }  
