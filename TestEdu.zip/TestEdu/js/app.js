var agro = angular.module('myApp', []);
//my main controller
agro.controller('AppCtrl', function($scope,$http,$timeout) {
  
   
   $scope.dataLoaded = true;
   $scope.elementIdx = "Click on Map to Get Information About Particular Region";  

   //get all data of states from database
   var statesrequest =  $http.get("controller/Home/polljson.php")
   .then(function (response) { 
    $scope.dataxx = response.data.myrecords;
    return response;
    });

    $scope.updateVal = function(Val,Val2) {
       
        statesrequest.then(function (data) { 
                console.log(Val2);
            $scope.findValue = function() {     
                angular.forEach($scope.dataxx, function(value, key) {
                    if (value === Val2) {
                        console.log('I found something');
                        $scope.thevalue = value;
                        
                    }
                    else {
                       console.log('I didnt see anything');
                       $scope.thevalue = "";
                        
                    }
                    });
               };
            
                
        });    
   
       //get value from weather API first
        /**    $scope.dataLoaded = false;    
            $http.get(Val)
                        .success(function(data) { 
                        
                            console.log(data);
                            $scope.dataLoaded = true;
                        })
                        .error(function(error) {
                            $scope.dataLoaded = true;
                            alert('An error occured');
                        }); 
                        **/
    }
    

    //Polling my data
    var loadTime = 1000, //Load the data every second
        errorCount = 0, //Counter for the server errors
        loadPromise; //Pointer to the promise created by the Angular $timout service


    var getData = function() {
        $http.get('http://httpbin.org/delay/1?now=' + Date.now())

        .then(function(res) {
             $scope.data = res.data.args;

              errorCount = 0;
              nextLoad();
        })

        .catch(function(res) {
             $scope.data = 'Server error';
             nextLoad(++errorCount * 2 * loadTime);
        });
    };

     var cancelNextLoad = function() {
         $timeout.cancel(loadPromise);
     };

    var nextLoad = function(mill) {
        mill = mill || loadTime;

        //Always make sure the last timeout is cleared before starting a new one
        cancelNextLoad();
        $timeout(getData, mill);
    };


    //Start polling the data from the server
    getData();


        //Always clear the timeout when the view is destroyed, otherwise it will   keep polling
        $scope.$on('$destroy', function() {
            cancelNextLoad();
        });

        $scope.data = 'Loading...';


});

//import the svg 
agro.directive('mySvg', ['$compile', function ($compile) {
    return {
        restrict: 'A',
        templateUrl: 'images/nigeria.svg',
        link: function (scope, element, attrs) {
           var regions = element[0].querySelectorAll('.state');
            angular.forEach(regions, function (path, key) {
                var regionElement = angular.element(path);
                regionElement.attr("region", "");
              
                $compile(regionElement)(scope);
            });
        }
    };
}]);
///import the     
agro.directive('region', ['$compile', function ($compile) {
    return {
        restrict: 'A',
        scope: true,
        link: function (scope, element, attrs) {
            scope.regionClick = function () {
            
            
            var statename = element.attr("id");
            var urlx = "http://api.wunderground.com/api/49aab05138acd7cd/geolookup/conditions/q/Nigeria/"+statename+".json";
            scope.updateVal(urlx, statename);
            }           
            element.attr("ng-click", "regionClick()");
            element.removeAttr("region");
            $compile(element)(scope);
        }
    }
}]);

