<?php include 'includes/general/header.php'; ?>
            
<?php include 'classes/connection.php' ; ?>            
<?php include 'functions/index.php'; ?>



            <div id="content" style="height: 80%;">
                
            <?php include 'includes/general/menu.php'; ?>
           <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                        <div class="box">
              
                            <div id="holder" my-svg></div>

                        </div> 
            
                </div>
            
            </div>
    
                
                
               
            </div>
            <div class="loading" ng-hide="dataLoaded">Loading&#8230;</div>
            
            <!-- end content -->
            <?php include 'includes/general/footer.php'; ?>