<div id="left">
                    <div id="menu">
                        <h6 id="h-menu" class="selected"><a href="#products"><span>Home</span></a></h6>
                        <ul id="menu-home" class="opened" style="display:block;">
                                <li><a href="<?php echo $myurl.'index.php'; ?>">Index</a></li>
                               
                                <li><a href="<?php echo $myurl.'print.php'; ?>">Print Current Weather Report</a></li>
                               
                                
                        </ul>
                      

                    </div>
        
</div>