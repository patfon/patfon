<?php 
 session_start();
 $documentroot = "testedu/superadmin";
 $GLOBALS['myurl'] = "http://".$_SERVER['HTTP_HOST']."/".$documentroot."/";
?>
<!DOCTYPE html>
<html>
<<head>
         <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
            <link href="<?php echo $myurl.'images/littlelogo.gif' ;?>" rel="shortcut icon">
            <title>Admin Test States With Weather Info.</title> 
            
   
    
             <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
            <!-- stylesheets -->
            <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/reset.css'; ?>">
            <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/style.css'; ?> " media="screen">
            <link rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/style1.css'; ?> " media="screen">
            <link rel="stylesheet" type="text/css" href= <?php echo $myurl.'lib/datatables/dataTables.bootstrap.css'; ?> >
            <link rel="stylesheet" type="text/css" href= <?php echo $myurl.'css/select2.min.css'; ?> >
            <link id="color" rel="stylesheet" type="text/css" href="<?php echo $myurl.'css/colors/blue.css'; ?> ">
            <!-- scripts (jquery,datatables) -->
            <script src="<?php echo $myurl.'js/angularx.js'; ?> " type="text/javascript"></script>
            <script src="<?php echo $myurl.'js/raphael-min.js'; ?> " type="text/javascript"></script>
            <script src="<?php echo $myurl.'js/nigeria.js'; ?> " type="text/javascript"></script>
            <script src="<?php echo $myurl.'js/jquery2.0.3.min.js'; ?> " type="text/javascript"></script>
           
            <script type="text/javascript" src="<?php echo $myurl.'lib/datatables/jquery.dataTables.min.js'; ?>"></script>
            <script type="text/javascript" src="<?php echo $myurl.'lib/datatables/dataTables.bootstrap.min.js' ;?>"></script>
            <script type="text/javascript" >
            $(document).ready(function() {
   
                 $('.mydatatables').DataTable();
  
            } );
            </script>
          
            <script src="<?php echo $myurl.'js/myservice.js'; ?>" type="text/javascript"></script>
            <!--[if IE]><script language="javascript" type="text/javascript" src="js/excanvas.min.js"></script><![endif]-->
           
            
            <!-- scripts (custom) -->
           
        </head>
     <body>
<!-- Header In the Front-->
     <div id="header">
                <!-- logo -->
                <div id="logo">
                    <h1><a href="/home/index" target="_blank">
                        <font color="white" size="8">Weather Test PHP {{ elementidx }}</font>
                    </a></h1>
                </div>
                <!-- end logo -->
                <ul id="user">
                    <li><a href="<?php echo $myurl.'logout.php'; ?>">Logout</a></li>
                  
                </ul>
                
            </div>