<?php session_start(); ?>
<?php include '../../classes/connection.php' ;
//add a new State

if (isset($_POST['butadd'])){

    $myfield =  mysqli_real_escape_string($pdb,$_POST['name']);//clean post data 
    $myfield2 =  mysqli_real_escape_string($pdb,$_POST['capital']);//clean post data 
    $myfield3 =  mysqli_real_escape_string($pdb,$_POST['local']);//clean post data 


    $query = ("INSERT INTO states (_name,_capital,_local) 
    VALUES (' $myfield','$myfield2','$myfield3' ) ");
//insert into the database
    if (mysqli_query($pdb, $query)) {
            $_SESSION['msg']['addsubject'] = 1;
            header('Location: ../../index.php');
    }



}
//update a new State
if (isset($_POST['butupdate'])){

    $myid = $_POST['stid'];//State ID 
    $myfield =  mysqli_real_escape_string($pdb,$_POST['name']);//clean post data 
    $myfield2 =  mysqli_real_escape_string($pdb,$_POST['capital']);//clean post data 
    $myfield3 =  mysqli_real_escape_string($pdb,$_POST['local']);//clean post data 
    
    $query = ("UPDATE states SET _name = '$myfield', _capital = '$myfield2', _local = '$myfield3' WHERE id = $myid ");
    //update into the database
        if (mysqli_query($pdb, $query)) {
                $_SESSION['msg']['updatesubject'] = 1;
                header('Location: ../../index.php');
        }
    
    
    
    }