<?php session_start(); ?>
<?php include '../../classes/connection.php' ;

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$query = (" SELECT * FROM states ");
$outp = "";
$result = mysqli_query($pdb,$query) or die(mysqli_error($pdb));
     if (mysqli_num_rows($result) > 0){
       while ($rs = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 

    if ($outp != "") {$outp .= ",";}
    $outp .= '{"State":"'  . $rs["_name"] . '",';
    $outp .= '"City":"'   . $rs["_capital"] . '",';
    $outp .= '"Lga":"'. $rs["_local"]     . '"}';
}
$outp ='{"myrecords":['.$outp.']}';


echo($outp);
     }