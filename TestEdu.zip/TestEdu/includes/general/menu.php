<div id="left">
                    <div id="menu">
                        <h6 id="h-menu" class="selected"><a href="#products"><span>Home</span></a></h6>
                        <ul id="menu-home" class="opened" style="display:block;">
                                <li><a href="<?php echo $myurl.'index.php'; ?>">Weather Map</a></li>
                                <li><a target= "_blank" href="<?php echo $myurl.'login.php'; ?>">Login to Admin</a></li>
                           
                               
                                
                        </ul>
                      

                    </div>

                    <br></br>
                    <div id="menu">
                        <h6 id="h-menu" class="selected"><a href="#products"><span>States Added</span></a></h6>
                    <ul id="menu-home" class="opened" style="display:block;">
                              <?php $mystates = getstates($pdb);
                              if (!empty($mystates)){
                                  foreach ($mystates as $mys){
                              ?>
                                 <li><a href="#"><?php echo $mys['_name']." : "; ?></a> {{ nga. }} </li>
                              <?php } } else { ?>
                                <li><a href="#"><?php echo "No State has been Added yet" ?></a></li>
                              <?php } ?>
                               
                                
                        </ul>
                    </div>
</div>
<br><br>
