<?php
session_start();

unset($_SESSION['pubcouser']);

header('location:../login.php')


?>