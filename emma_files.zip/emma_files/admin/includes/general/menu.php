<div id="left">
                    <div id="menu">
                        <h6 id="h-menu" class="selected"><a href="#products"><span>General Information</span></a></h6>
                        <ul id="menu-home" class="opened" style="display:block;">
                         <li><a href="<?php echo $myurl.'index.php'; ?>">My Activities</a></li>
                               
                             
                                
                        </ul>
                        <h6 id="h-menu" class="selected"><a href="#pages"><span>Submission</span></a></h6>
                        <ul id="menu-journal" class="opened" style="display:block;">
                         <li><a href="<?php echo $myurl.'includes/submission/submission.php'; ?>">Submit to Journal</a></li>
                         <li><a href="#">Submit to Special Issue</a></li>	
						 <li><a href="<?php echo $myurl.'includes/submission/manuscript.php'; ?>">My Manuscripts</a></li>
						 <li><a href="#">Pay for my Manuscripts</a></li>						 
                        </ul>
                       
                       
                        <h6 id="h-menu" class="selected"><a href="#join"><span>Journal Activity</span></a></h6>
                        <ul id="menu-news" class="opened" style="display:block;">
                         <li><a href="#">Application Result</a></li>	
                         <li><a href="#">Editorial Result</a></li>
                         <li><a href="#">Reviewer Members</a></li>		
                     
                        </ul>
                       <h6 id="h-menu" class="selected"><a href="#links"><span>Personal Profile</span></a></h6>
                        <ul id="menu-sub" class="opened" style="display:block;">
                        <li><a href="<?php echo $myurl.'includes/submission/personal.php'; ?>">Personal Information</a></li>	
						<li><a href="<?php echo $myurl.'includes/submission/upload_image.php'; ?>">Upload Your Photo</a></li>
                        <li><a href="<?php echo $myurl.'includes/submission/qualification.php'; ?>">Educational Qualification</a></li>
						<li><a href="<?php echo $myurl.'includes/submission/specialty.php'; ?>">specialty</a></li>
						<li><a href="<?php echo $myurl.'includes/submission/website.php'; ?>">Personal website</a></li>
                        <li><a href="<?php echo $myurl.'includes/submission/expirience.php'; ?>">Work Experience</a></li>
						<li><a href="<?php echo $myurl.'includes/submission/books.php'; ?>">Books</a></li>
						<li><a href="<?php echo $myurl.'includes/submission/project.php'; ?>">Projects</a></li>
						<li><a href="<?php echo $myurl.'includes/submission/awards.php'; ?>">Honors and awards</a></li>
						<li><a href="<?php echo $myurl.'includes/submission/chcrid.php'; ?>">Change Password</a></li>
                          
                        </ul>
                      

                       </div>
        <div id="date-picker"></div>  
</div>