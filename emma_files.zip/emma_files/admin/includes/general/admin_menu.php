
<div class="box">
               	<div class="messages" align="left">
				<div id="message-warning" class="message message-warning" style="background:#f0f7e7;border-color:#F3E0E0;width: 800px;">
						<div class="image">
						</div>
							<div class="text" align="left">
							    <a href="<?php echo $myurl.'includes/submission/submission.php'; ?>" target="_blank">
									<img src="<?php echo $img_path."journal.jpg"; ?>" style="padding-left: 0px;">
							    </a>
							    <a href="/author/paper_load_submitPaperCategory" target="_blank">
									<img src="<?php echo $img_path."special_issues.jpg"; ?>" style="padding-left: 33px;">
							    </a>
							    <div style="clear:both;"></div>
							</div>
				</div>
					<div id="message-warning" class="message message-warning" style="background:#eaf6f8 ;border-color:#F3E0E0;width: 800px;">
						<div class="image">
						</div>
							<div class="text" align="left">
							    <a href="/common/joinaseditorialmember" target="_blank">
									<img src="<?php echo $img_path."editorial_board.jpg"; ?>" style="padding-left: 0px;">
							    </a>
								<a href="<?php echo $myurl.'includes/submission/applyreviewer.php';?>" target="_blank">
									<img src="<?php echo $img_path."reviewer.jpg"; ?>" style="padding-left: 33px;">
							    </a>
							    <div style="clear:both;"></div>
							</div>
					</div>
				</div>
				</div>
				