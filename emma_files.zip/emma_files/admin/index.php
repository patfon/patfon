<?php include 'includes/general/header.php'; ?>
<?php include 'classes/connection.php' ; ?>            
<?php include 'functions/index.php'; ?>



            <div id="content" style="height: 80%;">
                
            <?php include 'includes/general/menu.php'; ?>
			
                 
                   
                <!-- end content / left -->
             
            <div id="content" style="min-height: 400px;">
                
                <div id="right">
                
                <div class="box">
            <!--Alert msg-->
           
             <!--end Alert msg-->

<!-- First Header showing Example-->
              
<!-- end First Header showing Example-->
<!-- Second Header showing Table List-->
                        <div class="title">
                        <h5>Homepage</h5>
                        </div>
						<?php 
						include('includes/general/admin_menu.php');
						
						?>
						
						
				
						
						
						
						
                        <!-- end box / title -->
                        
                    </div>     </div>  </div>        
    
                
                
                <div style="clear: both;overflow: hidden;height: 510px;"></div>
            </div>
            
            <!-- end content -->
            <?php include '../../includes/general/footer.php'; ?>