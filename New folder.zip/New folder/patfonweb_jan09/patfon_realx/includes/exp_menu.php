<!--main content start-->
<section id="main-content">
	<section class="wrapper">

	
			<!---main content here -->
<div class="market-updates">
			<div class="col-md-3 market-update-gd">
				<div class="market-update-block clr-block-2">
					<a href="add_exp.php"> <div class="col-md-4 market-update-right">
						<i class="fa fa-plus"> </i>
					</div>
					 <div class="col-md-8 market-update-left">
					 <h4>Add Expenditure</h4>
					 </a>
                    </div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="monthly_exp.php"> <div class="market-update-block clr-block-2">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-calendar"></i>
					</div>
					<div class="col-md-8 market-update-left">
					<h4>Monthly Summary</h4>
					</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="termly_exp.php"> <div class="market-update-block clr-block-2">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-exchange"></i>
					</div>
					<div class="col-md-8 market-update-left">
						<h4>Termly Summary</h4>
						</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-3 market-update-gd">
				<a href="yearly_exp.php"> <div class="market-update-block clr-block-2">
					<div class="col-md-4 market-update-right">
						<i class="fa fa-bar-chart" aria-hidden="true"></i>
					</div>
					<div class="col-md-8 market-update-left">
						<h4>Yearly Summary</h4>
						</a>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
		   <div class="clearfix"> </div>
		</div>
		
		   <div class="clearfix"> </div>
		<!--main contents end-->
	
		<div class="col-md-6 w3agile-notifications">
		<div class="clearfix"> </div>
		</div>
		
</section>
 
</section>
<!--main content end-->